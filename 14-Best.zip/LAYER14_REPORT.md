# WISP Layer 14 · Settings UI, appearance, data controls

## Delivered
- Added settings search and screens for appearance, interface, effects, sound, chat, language/time, and data/reset.
- Added built-in Dark, Pure Black, Midnight, Light, and System theme selection; live preview; custom theme editor with an explicit unsaved state; save/delete flows.
- Added draggable navigation and home-block ordering with accessible up/down controls, density controls, optional tab visibility, and quick-action selection.
- Added CSS for compact/comfortable density, softer effects, appearance transitions, compact/wide chat, message text sizing, and desktop side navigation.
- Fixed the settings crash for Pure Black, Midnight, and custom themes by resolving labels safely.
- Added full JSON account export, including chat attachments as base64, profile, memory, and tools data; added per-section data reset; connected the existing account deletion API to a password-confirmed UI.
- Fixed the browser E2E tab helper so it returns from Chat using Chat's visible back control before switching tabs. Added settings coverage for mobile themes, search, settings screens, density, side navigation, and export.

## Verification
- Server, tools, memory, voice, actions, auth, subscription, and theme-engine Node test suites: PASS.
- Export/reset integration check: PASS, including invalid-section rejection.
- Changed JavaScript files: `node --check` PASS.
- Single-file build: `python3 tools/build_single.py` PASS.
- Browser E2E: NOT VERIFIED. The test run exceeded the available command window; the Playwright package resolves, but its expected Chromium executable was not present at the configured path. No phone or desktop browser result is claimed.

## Notes
- Export is account-scoped on the server and returns JSON; image attachments are embedded as base64.
- Destructive data resets and account deletion require an in-product confirmation; account deletion also requires the current password.
