/* WISP · Design System · Icons
 * Линейные иконки 24×24, stroke = currentColor. Единый вес линии 1.6. */
(function (App) {
  'use strict';
  const P = {
    back: '<path d="M15 5.5 8.5 12l6.5 6.5"/>',
    check: '<path d="m5.5 12.5 4.2 4.2 8.8-9.4" stroke-width="2.4"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2.6"/><rect x="9.6" y="9.6" width="4.8" height="4.8" rx="1"/><path d="M9.5 2.8v3.2M14.5 2.8v3.2M9.5 18v3.2M14.5 18v3.2M2.8 9.5h3.2M2.8 14.5h3.2M18 9.5h3.2M18 14.5h3.2"/>',
    gamepad: '<path d="M7.6 7.5h8.8a4.6 4.6 0 0 1 4.5 5.5l-.7 3.6a2.2 2.2 0 0 1-3.8 1.1L14.6 16H9.4l-1.8 1.7a2.2 2.2 0 0 1-3.8-1.1L3.1 13a4.6 4.6 0 0 1 4.5-5.5Z"/><path d="M8.2 10.4v3.2M6.6 12h3.2"/><path d="M15.4 11.2h.01M17.4 13h.01" stroke-width="2.4"/>',
    code: '<path d="m8.5 7.5-4.5 4.5 4.5 4.5M15.5 7.5 20 12l-4.5 4.5M13.6 4.8l-3.2 14.4"/>',
    palette: '<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.1 0 1.8-.8 1.8-1.8 0-.5-.2-.9-.5-1.2-.3-.4-.5-.8-.5-1.3 0-1 .8-1.8 1.8-1.8h2.1a3.8 3.8 0 0 0 3.8-3.8c0-3.9-3.8-7.1-8.5-7.1Z"/><path d="M7.6 11.6h.01M10.2 7.8h.01M14.8 8h.01" stroke-width="2.6"/>',
    atom: '<ellipse cx="12" cy="12" rx="9" ry="3.6"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(-60 12 12)"/><path d="M12 12h.01" stroke-width="2.8"/>',
    dumbbell: '<path d="M6.5 7.5v9M17.5 7.5v9M3.8 10v4M20.2 10v4M6.5 12h11"/>',
    note: '<path d="M9 17.5V6.2l10-2.2v11.5"/><circle cx="6.6" cy="17.5" r="2.4"/><circle cx="16.6" cy="15.5" r="2.4"/>',
    book: '<path d="M3.5 5.6c2.8-.9 5.6-.6 8.5 1.2v12.6c-2.9-1.8-5.7-2.1-8.5-1.2ZM20.5 5.6c-2.8-.9-5.6-.6-8.5 1.2v12.6c2.9-1.8 5.7-2.1 8.5-1.2Z"/>',
    chart: '<path d="M4 19.5h16M7 16v-3.5M12 16V8.5M17 16V5.5"/>',
    pen: '<path d="M12 3.5 17.8 10 15 17.5H9L6.2 10Z"/><path d="M12 3.5v7.6"/><circle cx="12" cy="12.4" r="1.3"/><path d="M8.5 20.5h7"/>',
    compass: '<circle cx="12" cy="12" r="8.5"/><path d="m15.4 8.6-2 4.8-4.8 2 2-4.8Z"/>',
    dots: '<path d="M6 12h.01M12 12h.01M18 12h.01" stroke-width="2.8"/>',
    bell: '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15Z"/><path d="M10 20.6a2.3 2.3 0 0 0 4 0"/>',
    mic: '<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.6 11.5a6.4 6.4 0 0 0 12.8 0M12 18v2.6"/>',
    shield: '<path d="M12 3.5 19 6v5.6c0 4.2-3 7.5-7 8.9-4-1.4-7-4.7-7-8.9V6Z"/><path d="m9 12 2.1 2.1 3.9-4"/>',
    wave: '<path d="M4 10.5v3M8 7.5v9M12 4.5v15M16 7.5v9M20 10.5v3"/>',
    /* Layer 2 */
    notes: '<path d="M6.5 3.5h8l4 4v13h-12Z"/><path d="M14.5 3.5v4h4M9.5 12.5h5M9.5 16h3.5"/>',
    task: '<circle cx="12" cy="12" r="8.5"/><path d="m8.4 12.2 2.5 2.5 4.8-5"/>',
    image: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="m4 17 4.6-4.4a1.6 1.6 0 0 1 2.2 0L15 16.5l1.6-1.5a1.6 1.6 0 0 1 2.2 0l1.7 1.6"/>',
    send: '<path d="M12 19V5.5M6.5 11 12 5.5l5.5 5.5" stroke-width="2"/>',
    home: '<path d="M4 10.5 12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5H15v-5.5H9v5.5H5.5A1.5 1.5 0 0 1 4 19Z"/>',
    chat: '<path d="M5 5.5h14a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-7.5L7 20.5v-3H5A1.5 1.5 0 0 1 3.5 16V7A1.5 1.5 0 0 1 5 5.5Z"/>',
    memory: '<path d="M12 3.5c.6 4.4 2.6 6.9 7.5 8.5-4.9 1.6-6.9 4.1-7.5 8.5-.6-4.4-2.6-6.9-7.5-8.5 4.9-1.6 6.9-4.1 7.5-8.5Z"/>',
    tools: '<rect x="4" y="4" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="2"/>',
    close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.8 20c.9-3.6 3.7-5.6 7.2-5.6s6.3 2 7.2 5.6"/>',
    chevron: '<path d="m9.5 6 6 6-6 6"/>',
    stop: '<rect x="7.5" y="7.5" width="9" height="9" rx="2.2" fill="currentColor" stroke="none"/>',
    /* Layer 3 */
    compose: '<path d="M12.5 4.5H7A2.5 2.5 0 0 0 4.5 7v10A2.5 2.5 0 0 0 7 19.5h10a2.5 2.5 0 0 0 2.5-2.5v-5.5"/><path d="M17.6 3.9a1.9 1.9 0 0 1 2.7 2.7L13 13.9l-3.4.8.8-3.4Z"/>',
    copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2.5"/><path d="M15.5 8.5V7A2.5 2.5 0 0 0 13 4.5H7A2.5 2.5 0 0 0 4.5 7v6A2.5 2.5 0 0 0 7 15.5h1.5"/>',
    refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"/><path d="M19.5 4.5v4h-4"/>',
    edit: '<path d="M15.8 4.7a2 2 0 0 1 2.9 0l.6.6a2 2 0 0 1 0 2.9L8.6 18.9l-4.1 1 1-4.1Z"/><path d="m14 6.5 3.5 3.5"/>',
    trash: '<path d="M4.5 7h15M9.5 7V5.5A1.5 1.5 0 0 1 11 4h2a1.5 1.5 0 0 1 1.5 1.5V7M6.5 7l.8 11.2A2 2 0 0 0 9.3 20h5.4a2 2 0 0 0 2-1.8L17.5 7"/>',
    history: '<path d="M4.6 12a7.4 7.4 0 1 0 2.2-5.2"/><path d="M4.5 4.8v3.7h3.7"/><path d="M12 8.2V12l2.8 1.8"/>',
    more: '<path d="M6 12h.01M12 12h.01M18 12h.01" stroke-width="2.6"/>',
    arrowDown: '<path d="M12 5v13.5M6.5 13 12 18.5l5.5-5.5" stroke-width="1.9"/>',
    imageAdd: '<path d="M20.5 12.5V16a3 3 0 0 1-3 3h-11a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3h6"/><circle cx="9" cy="10" r="1.5"/><path d="m4 17 4.4-4.2a1.6 1.6 0 0 1 2.2 0L15 17"/><path d="M18 3.5v6M15 6.5h6"/>',
    alert: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.8v5M12 16.2h.01" stroke-width="2"/>',
    wifiOff: '<path d="M3.5 3.5l17 17"/><path d="M8.7 15.4a4.7 4.7 0 0 1 6.1-.4M5.6 12.2a9.3 9.3 0 0 1 5-2.6M18.4 12.2a9.2 9.2 0 0 0-2.2-1.6M2.8 9a13.8 13.8 0 0 1 4.4-2.6M12 5.6c3.5 0 6.7 1.3 9.2 3.4M12 19h.01" />',
    /* Layer 4 */
    plus: '<path d="M12 5.5v13M5.5 12h13" stroke-width="1.9"/>',
    calendar: '<rect x="4" y="5.5" width="16" height="14.5" rx="3"/><path d="M4 10h16M8.5 3.5v3.5M15.5 3.5v3.5"/><path d="M8 14h.01M12 14h.01M16 14h.01" stroke-width="2.4"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    /* Layer 5 */
    pin: '<path d="M9.2 4.5h5.6l-.8 5.2 3.5 3.3v1.5H6.5V13l3.5-3.3Z"/><path d="M12 14.5v5.5"/>',
    heart: '<path d="M12 19.5s-7.5-4.4-7.5-9.6A4.1 4.1 0 0 1 12 7.6a4.1 4.1 0 0 1 7.5 2.3c0 5.2-7.5 9.6-7.5 9.6Z"/>',
    briefcase: '<rect x="3.5" y="7.5" width="17" height="12" rx="2.6"/><path d="M9 7.5V6a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 6v1.5M3.5 12.5h17"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.6"/><path d="M12 12h.01" stroke-width="2.6"/>',
    people: '<circle cx="9" cy="9" r="3.2"/><path d="M3.5 19c.7-3 2.8-4.6 5.5-4.6s4.8 1.6 5.5 4.6"/><path d="M15.2 6.2a3 3 0 0 1 0 5.6M17 14.6c1.8.5 3 1.9 3.5 4.4"/>',
    download: '<path d="M12 4.5v10.5M7.5 11 12 15.5 16.5 11"/><path d="M5 19.5h14"/>',
    power: '<path d="M12 4v7.5"/><path d="M7.4 6.8a7 7 0 1 0 9.2 0"/>',
    /* Layer 6 */
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M20.5 12h-2.2M5.7 12H3.5M18 6l-1.6 1.6M7.6 16.4 6 18M18 18l-1.6-1.6M7.6 7.6 6 6"/><circle cx="12" cy="12" r="6.4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4"/>',
    moon: '<path d="M19.5 14.6A7.8 7.8 0 0 1 9.4 4.5a7.8 7.8 0 1 0 10.1 10.1Z"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.2M12 7.9h.01" stroke-width="2"/>',
    logout: '<path d="M14.5 4.5H7A2.5 2.5 0 0 0 4.5 7v10A2.5 2.5 0 0 0 7 19.5h7.5"/><path d="M10.5 12h10M17 8.5l3.5 3.5-3.5 3.5"/>',
    camera: '<path d="M4 8.5A2 2 0 0 1 6 6.5h1.8L9.3 4.5h5.4l1.5 2H18a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z"/><circle cx="12" cy="12.6" r="3.4"/>',
    link: '<path d="M10.5 13.5a3.8 3.8 0 0 0 5.4 0l2.7-2.7a3.8 3.8 0 0 0-5.4-5.4l-1 1"/><path d="M13.5 10.5a3.8 3.8 0 0 0-5.4 0l-2.7 2.7a3.8 3.8 0 0 0 5.4 5.4l1-1"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.6"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.3 2.4 3.4 5.2 3.4 8.5s-1.1 6.1-3.4 8.5c-2.3-2.4-3.4-5.2-3.4-8.5S9.7 5.9 12 3.5Z"/>',
    plane: '<path d="M20.5 4 3.8 10.6c-.7.3-.7 1.3 0 1.5l4.6 1.6 1.7 5.3c.2.7 1.1.9 1.6.3l2.5-2.7 4.3 3.2c.6.4 1.4.1 1.5-.6L21.5 5c.1-.7-.5-1.2-1-1Z"/><path d="m8.4 13.7 9.1-6.4"/>',
    mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2.6"/><path d="m4.5 7 7.5 6 7.5-6"/>',
    sliders: '<path d="M5 7h8M17 7h2M5 17h2M11 17h8"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    /* Layer 9 · показать / скрыть пароль */
    eye: '<path d="M2.8 12s3.4-6.3 9.2-6.3 9.2 6.3 9.2 6.3-3.4 6.3-9.2 6.3S2.8 12 2.8 12Z"/><circle cx="12" cy="12" r="2.8"/>',
    'eye-off': '<path d="M10.2 5.9a8.6 8.6 0 0 1 1.8-.2c5.8 0 9.2 6.3 9.2 6.3a16 16 0 0 1-2.4 3.2M6.6 7.1C4.2 8.7 2.8 12 2.8 12s3.4 6.3 9.2 6.3a8.7 8.7 0 0 0 4.4-1.2"/><path d="M9.9 9.9a2.8 2.8 0 0 0 4 4M4 4l16 16"/>',
    spark: '<path d="M12 3.5c.6 4.4 2.6 6.9 7.5 8.5-4.9 1.6-6.9 4.1-7.5 8.5-.6-4.4-2.6-6.9-7.5-8.5 4.9-1.6 6.9-4.1 7.5-8.5Z" fill="currentColor" stroke="none"/>',
  };
  App.ui.icon = function (name, cls) {
    const svg = `<svg class="${cls || 'ds-icon'}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${P[name] || ''}</svg>`;
    const t = document.createElement('template');
    t.innerHTML = svg;
    return t.content.firstChild;
  };
})(window.WispApp);
