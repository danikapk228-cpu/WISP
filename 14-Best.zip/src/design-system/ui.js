/* WISP · Design System · UI
 * Переиспользуемые компоненты интерфейса. Только представление: данные приходят пропсами, изменения уходят колбэками. */
(function (App) {
  'use strict';
  const ui = App.ui;

  const reduceMQ = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  ui.reducedMotion = () => reduceMQ.matches;
  ui.finePointer = () => (window.matchMedia ? matchMedia('(pointer: fine)').matches : true);

  /* Тактильный отклик там, где он есть (Android). На iOS API нет, визуальный отклик остаётся. */
  ui.haptic = (ms) => { try { if (navigator.vibrate) navigator.vibrate(ms || 8); } catch (e) {} };

  /* h('div', {class, attrs, on}, ...children) */
  function h(tag, props, ...children) {
    const el = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k === 'style') Object.assign(el.style, v);
        else if (k === 'dataset') Object.assign(el.dataset, v);
        else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k in el && typeof v !== 'string') el[k] = v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    append(el, children);
    return el;
  }
  function append(el, children) {
    for (const c of children.flat(Infinity)) {
      if (c == null || c === false) continue;
      el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
    }
  }
  ui.h = h;

  /* Нажатие: класс .is-pressed на время касания (тактильное сжатие) */
  function pressable(el) {
    const on = () => el.classList.add('is-pressed');
    const off = () => el.classList.remove('is-pressed');
    el.addEventListener('pointerdown', (e) => { if (e.button === 0 || e.pointerType !== 'mouse') on(); });
    ['pointerup', 'pointercancel', 'pointerleave', 'blur'].forEach((t) => el.addEventListener(t, off));
    el.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter') on(); });
    el.addEventListener('keyup', off);
    return el;
  }
  ui.pressable = pressable;

  /* ── Button ── */
  ui.Button = function ({ label, variant, size, onClick, disabled, count }) {
    const labelEl = h('span', { text: label });
    const countEl = h('span', { class: 'ds-btn__count', hidden: true });
    const el = pressable(h('button', {
      type: 'button',
      class: `ds-btn ds-btn--${variant || 'primary'}${size === 'small' ? ' ds-btn--small' : ''}`,
      disabled: !!disabled,
      onClick: (e) => { if (!el.disabled && onClick) onClick(e); },
    }, labelEl, countEl));
    el.setDisabled = (v) => { el.disabled = !!v; };
    el.setLabel = (v) => { labelEl.textContent = v; };
    el.setCount = (n) => { countEl.hidden = !n; countEl.textContent = n ? String(n) : ''; };
    el.setBusy = (v) => { el.classList.toggle('is-busy', !!v); el.setAttribute('aria-busy', v ? 'true' : 'false'); };
    if (count) el.setCount(count);
    return el;
  };

  ui.IconButton = function ({ icon, label, onClick }) {
    return pressable(h('button', { type: 'button', class: 'ds-iconbtn', 'aria-label': label, onClick }, ui.icon(icon)));
  };

  ui.TextButton = function ({ label, onClick }) {
    return h('button', { type: 'button', class: 'ds-textbtn', onClick, text: label });
  };

  const checkMark = (radio) => h('span', { class: `ds-check${radio ? ' ds-check--radio' : ''}`, 'aria-hidden': 'true' }, radio ? null : ui.icon('check'));

  /* ── ChoiceCard: плитка множественного выбора ── */
  ui.ChoiceCard = function ({ icon, label, selected, onToggle }) {
    const el = pressable(h('button', {
      type: 'button', class: 'ds-choice', role: 'checkbox', 'aria-checked': selected ? 'true' : 'false',
      onClick: () => {
        const next = el.getAttribute('aria-checked') !== 'true';
        el.setAttribute('aria-checked', next ? 'true' : 'false');
        ui.haptic(next ? 10 : 6);
        onToggle && onToggle(next);
      },
    }, ui.icon(icon, 'ds-icon ds-choice__icon'), h('span', { class: 'ds-choice__label', text: label }), checkMark(false)));
    return el;
  };

  /* ── OptionRow: строка одиночного выбора (radio). extra — раскрывается при выборе. ── */
  ui.OptionRow = function ({ title, label, desc, selected, onSelect, extra, muted }) {
    const main = h('span', { class: 'ds-row__main' },
      title ? h('span', { class: 'ds-row__title', text: title }) : null,
      label ? h('span', { class: 'ds-row__label', text: label }) : null,
      desc ? h('span', { class: 'ds-row__desc', text: desc }) : null,
      extra ? h('span', { class: 'ds-reveal' }, h('div', null, extra)) : null);
    const el = pressable(h('button', {
      type: 'button', class: `ds-row${muted ? ' ds-row--muted' : ''}`, role: 'radio', 'aria-checked': selected ? 'true' : 'false',
      onClick: () => { ui.haptic(10); onSelect && onSelect(); },
    }, main, h('span', { class: 'ds-row__end' }, checkMark(true))));
    el.setSelected = (v) => el.setAttribute('aria-checked', v ? 'true' : 'false');
    return el;
  };

  /* Группа radio с клавиатурной навигацией стрелками */
  ui.RadioGroup = function ({ label, rows }) {
    const el = h('div', { class: 'ds-list', role: 'radiogroup', 'aria-label': label }, rows);
    el.addEventListener('keydown', (e) => {
      if (!['ArrowDown', 'ArrowUp'].includes(e.key)) return;
      const i = rows.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      rows[(i + (e.key === 'ArrowDown' ? 1 : rows.length - 1)) % rows.length].focus();
    });
    return el;
  };

  /* ── TextField ── */
  ui.TextField = function ({ value, placeholder, maxLength, label, autocomplete, onInput, onSubmit }) {
    const input = h('input', {
      class: 'ds-input', type: 'text', value: value || '', placeholder, maxLength,
      autocomplete: autocomplete || 'off', autocapitalize: 'words', spellcheck: 'false', enterKeyHint: 'next',
      'aria-label': label,
    });
    input.addEventListener('input', () => onInput && onInput(input.value));
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); onSubmit && onSubmit(); } });
    return h('label', { class: 'ds-field' }, input);
  };

  /* ── TextArea с автоувеличением и счётчиком ── */
  ui.TextArea = function ({ value, placeholder, maxLength, label, onInput }) {
    const ta = h('textarea', { class: 'ds-textarea', placeholder, maxLength, 'aria-label': label, rows: 5 });
    ta.value = value || '';
    const counter = h('span', { class: 'ds-counter', 'aria-hidden': 'true' });
    const sync = () => {
      counter.textContent = `${ta.value.length} / ${maxLength}`;
      ta.style.height = 'auto';
      ta.style.height = Math.max(168, ta.scrollHeight + 2) + 'px';
    };
    ta.addEventListener('input', () => { sync(); onInput && onInput(ta.value); });
    requestAnimationFrame(sync);
    const el = h('label', { class: 'ds-field' }, ta, counter);
    el.textarea = ta;
    return el;
  };

  /* ── Progress ── */
  ui.Progress = function ({ total, label }) {
    const segs = Array.from({ length: total }, () => h('span', { class: 'ds-progress__seg' }, h('i')));
    const el = h('div', { class: 'ds-progress', role: 'progressbar', 'aria-label': label || 'Прогресс', 'aria-valuemin': '0', 'aria-valuemax': String(total) }, segs);
    el.set = (index) => {          // index текущего шага (0..total-1)
      segs.forEach((s, i) => { s.classList.toggle('is-done', i < index); s.classList.toggle('is-current', i === index); });
      el.setAttribute('aria-valuenow', String(index + 1));
      el.setAttribute('aria-valuetext', `Шаг ${index + 1} из ${total}`);
    };
    return el;
  };

  /* ── SpeechBubble: реплика WISP с «печатью» текста ── */
  ui.SpeechBubble = function ({ text, speed, onDone }) {
    const live = h('span', { class: 'ds-bubble__live', 'aria-hidden': 'true' });
    const caret = h('span', { class: 'ds-bubble__caret' });
    const el = h('div', { class: 'ds-bubble', role: 'status', 'aria-live': 'polite' },
      h('span', { class: 'ds-bubble__ghost', 'aria-hidden': 'true', text }),
      live,
      h('span', { class: 'ds-sr', text }));
    let i = 0, timer = 0, finished = false;
    const done = () => {
      if (finished) return; finished = true; clearTimeout(timer);
      live.textContent = text; caret.remove();
      onDone && onDone();
    };
    const tick = () => {
      // по словам-слогам: 1–2 символа за шаг, паузы на знаках препинания
      i = Math.min(text.length, i + (Math.random() < 0.35 ? 2 : 1));
      live.textContent = text.slice(0, i); live.appendChild(caret);
      if (i >= text.length) return done();
      const ch = text[i - 1];
      timer = setTimeout(tick, /[.!?]/.test(ch) ? 260 : /[,—:]/.test(ch) ? 130 : (speed || 26));
    };
    el.start = (delay) => {
      if (ui.reducedMotion()) return done();
      live.appendChild(caret);
      timer = setTimeout(tick, delay || 0);
    };
    el.finish = done;
    el.addEventListener('click', done);
    return el;
  };

  /* ── StatusPill ── */
  const STATUS = {
    granted: ['Включено', 'on'], prompt: ['Выключено', 'off'], denied: ['Запрещено', 'warn'],
    unsupported: ['Недоступно', 'off'], unavailable: ['Недоступно', 'off'], skipped: ['Позже', 'off'],
  };
  ui.StatusPill = function (status) {
    const el = h('span', { class: 'ds-pill' });
    el.set = (s) => { const [t, tone] = STATUS[s] || STATUS.prompt; el.textContent = t; el.className = `ds-pill ds-pill--${tone}`; };
    el.set(status);
    return el;
  };

  ui.Chip = (text) => h('span', { class: 'ds-chip', text });
})(window.WispApp);

/* ── ScreenLayout: общая раскладка экрана (используют онбординг и главный экран) ── */
(function (App) {
  'use strict';
  const { h } = App.ui;
  App.ui.ScreenLayout = function ({ eyebrow, title, subtitle, body, footer, center, label, titleHidden }) {
    let i = 0;
    const st = (node) => { if (node) { node.classList.add('ds-stagger'); node.style.setProperty('--i', String(i++)); } return node; };
    const titleEl = title ? h('h1', { class: `ds-title${titleHidden ? ' ds-sr' : ''}`, tabindex: '-1', text: title }) : null;
    const content = h('div', { class: 'ds-screen__content' },
      eyebrow ? st(h('p', { class: 'ds-eyebrow', text: eyebrow })) : null,
      titleHidden ? titleEl : st(titleEl),
      subtitle ? st(h('p', { class: 'ds-subtitle', text: subtitle })) : null,
      body ? h('div', { class: 'ds-screen__body' }, [].concat(body).map((n) => (n && n.dataset && n.dataset.noStagger ? n : st(n)))) : null);
    const footerEl = footer ? h('div', { class: 'ds-screen__footer' }, st(h('div', { class: 'ds-screen__footer-inner' }, footer))) : null;
    const el = h('section', { class: `ds-screen${center ? ' ds-screen--center' : ''}`, 'aria-label': label || title || '' },
      h('div', { class: 'ds-screen__scroll' }, h('div', { class: 'ds-screen__inner' }, content), footerEl));
    el.titleEl = titleEl;
    el.scroller = el.querySelector('.ds-screen__inner');
    /* каскад для элементов внутри body (карточки сетки и т.п.) */
    el.stagger = (nodes, from) => { let k = from == null ? i : from; nodes.forEach((n) => { n.classList.add('ds-stagger'); n.style.setProperty('--i', String(k++)); }); };
    return el;
  };
})(window.WispApp);

/* ── Sheet: нижняя стеклянная панель (на широких экранах: окно по центру) ──
 * Закрытие: крестик, тап по фону, Escape, свайп вниз. Фокус удерживается внутри и возвращается на место. */
(function (App) {
  'use strict';
  const ui = App.ui;
  const { h } = ui;
  let seq = 0;
  const OUT_MS = 380;

  ui.Sheet = function ({ title, content, onClose }) {
    const id = `ds-sheet-title-${++seq}`;
    const titleEl = h('h2', { class: 'ds-sheet__title', id, tabindex: '-1', text: title });
    const closeBtn = ui.IconButton({ icon: 'close', label: 'Закрыть', onClick: () => api.requestClose() });
    const head = h('div', { class: 'ds-sheet__head' }, titleEl, closeBtn);
    const body = h('div', { class: 'ds-sheet__body' }, content);
    const grab = h('div', { class: 'ds-sheet__grab', 'aria-hidden': 'true' });
    const panel = h('div', { class: 'ds-sheet__panel', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': id }, grab, head, body);
    const scrim = h('div', { class: 'ds-sheet__scrim', 'aria-hidden': 'true', onClick: () => api.requestClose() });
    const el = h('div', { class: 'ds-sheet ds-root' }, scrim, panel);
    let opener = null, closed = false;

    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); api.requestClose(); return; }
      if (e.key !== 'Tab') return;
      const f = [...panel.querySelectorAll('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])')].filter((n) => !n.disabled && n.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === titleEl)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }

    /* свайп вниз за шапку */
    let drag = null;
    const dragStart = (e) => {
      if (e.target.closest('button')) return;
      drag = { y: e.clientY, t: performance.now(), dy: 0, id: e.pointerId };
      panel.classList.add('is-dragging');
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) {}
    };
    const dragMove = (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      drag.dy = Math.max(0, e.clientY - drag.y);
      panel.style.transform = `translate3d(0, ${drag.dy}px, 0)`;
    };
    const dragEnd = () => {
      if (!drag) return;
      const v = drag.dy / Math.max(1, performance.now() - drag.t);
      const go = drag.dy > 96 || (drag.dy > 24 && v > 0.6);
      panel.classList.remove('is-dragging');
      panel.style.transform = '';
      drag = null;
      if (go) api.requestClose();
    };
    [grab, head].forEach((n) => {
      n.addEventListener('pointerdown', dragStart);
      n.addEventListener('pointermove', dragMove);
      n.addEventListener('pointerup', dragEnd);
      n.addEventListener('pointercancel', dragEnd);
    });

    const api = {
      el, panel, body,
      get open() { return !closed; },
      /* requestClose можно переопределить (например, чтобы закрывать через историю браузера) */
      requestClose() { api.close(); },
      mount(container) {
        opener = document.activeElement;
        container.appendChild(el);
        document.addEventListener('keydown', onKey, true);
        requestAnimationFrame(() => requestAnimationFrame(() => {
          el.classList.add('is-open');
          titleEl.focus({ preventScroll: true });
        }));
        return api;
      },
      close(opts) {
        if (closed) return;
        closed = true;
        document.removeEventListener('keydown', onKey, true);
        el.classList.remove('is-open');
        el.classList.add('is-closing');
        setTimeout(() => el.remove(), opts && opts.instant ? 0 : OUT_MS);
        if (!(opts && opts.keepFocus) && opener && opener.focus && document.contains(opener)) opener.focus({ preventScroll: true });
        onClose && onClose();
      },
    };
    return api;
  };
})(window.WispApp);
