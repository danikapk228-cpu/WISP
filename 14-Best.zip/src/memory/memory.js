/* WISP · Layer 5 · Memory
 * Экран «Memory — WISP remembers what matters»: что WISP помнит о пользователе между разговорами.
 * Все данные приходят с сервера (MemoryAPI): здесь нет локальной копии памяти и нет имитации.
 * Шапка: каждое воспоминание — маленький огонёк в «созвездии», рядом счётчик и выключатель памяти.
 * Ниже поиск, категории, предложения WISP (ждут «да»), закреплённые и остальные воспоминания,
 * настройки (предложения, экспорт, очистка). Правка и добавление — в нижней панели. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Kit, Format } = App.tools;
  App.memory = App.memory || {};

  const CATS = [
    { id: 'personal', label: 'Personal', icon: 'user', hint: 'о тебе' },
    { id: 'preferences', label: 'Preferences', icon: 'heart', hint: 'предпочтения и привычки' },
    { id: 'work', label: 'Work & Projects', icon: 'briefcase', hint: 'проекты и работа' },
    { id: 'goals', label: 'Goals', icon: 'target', hint: 'цели и планы' },
    { id: 'people', label: 'People', icon: 'people', hint: 'важные люди' },
    { id: 'other', label: 'Other', icon: 'spark', hint: 'остальное' },
  ];
  const CAT = Object.fromEntries(CATS.map((c) => [c.id, c]));
  const SOURCE = { user: 'добавлено вручную', explicit: 'из чата', suggested: 'предложил WISP' };
  const plural = (n, a, b, c) => App.tools.plural(n, a, b, c);
  const fullDate = (t) => new Date(t).toLocaleString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  function shortDate(t) {
    const d = new Date(t);
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: d.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' }).replace('.', '');
  }

  /* Выключатель (role=switch). onChange может вернуть Promise<boolean>: false = откатить */
  function Switch({ checked, label, onChange }) {
    const el = ui.pressable(h('button', { type: 'button', class: 'mm-switch', role: 'switch', 'aria-checked': checked ? 'true' : 'false', 'aria-label': label },
      h('span', { class: 'mm-switch__knob', 'aria-hidden': 'true' })));
    let busy = false;
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (busy) return;
      const next = el.getAttribute('aria-checked') !== 'true';
      el.setAttribute('aria-checked', next ? 'true' : 'false');
      ui.haptic(8);
      if (!onChange) return;
      busy = true; el.classList.add('is-busy');
      const ok = await onChange(next);
      busy = false; el.classList.remove('is-busy');
      if (ok === false) el.setAttribute('aria-checked', next ? 'false' : 'true');
    });
    el.set = (v) => el.setAttribute('aria-checked', v ? 'true' : 'false');
    return el;
  }

  /* Огонёк воспоминания: стабильное место по id, закреплённые ярче */
  function hash(s) { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return x >>> 0; }

  App.memory.MemoryView = function ({ root, store, director, assistant, api, openSheet, closeSheet, openPlan, openChat, onBack, onLayout }) {
    let data = null;                 // ответ GET /memories (всё, без фильтра)
    let shown = [];                  // после фильтра/поиска (ответ сервера)
    let filter = 'all', query = '';
    let loading = false, failed = null, destroyed = false, visible = false, seq = 0, timer = 0, focusId = null;
    const knownDots = new Set();

    /* ── подсказка внизу ── */
    const notice = h('p', { class: 'home-notice tl-notice mm-notice', role: 'status', 'aria-live': 'polite' });
    let noticeTimer = 0;
    function setNotice(text, tone, ttl) {
      clearTimeout(noticeTimer);
      if (!text) { notice.classList.remove('is-on'); return; }
      notice.textContent = text; notice.dataset.tone = tone || 'info'; notice.classList.add('is-on');
      noticeTimer = setTimeout(() => notice.classList.remove('is-on'), ttl || 4200);
    }
    function fail(r, fallback) {
      const e = r && r.error;
      setNotice(e ? Kit.errorText(e) : fallback || 'Не получилось.', 'warn', e && e.code === 'limit_memory' ? 6500 : 4800);
      director.react('blink');
    }

    /* ── Шапка ── */
    const addBtn = Kit.AddButton('Добавить воспоминание', () => openEditor(null));
    const bar = Kit.TopBar({ title: 'Memory', sub: 'WISP remembers what matters', onBack: () => onBack(), backLabel: 'На главный экран', actions: [addBtn] });

    const sky = h('div', { class: 'mm-sky', 'aria-hidden': 'true' });
    const countN = h('span', { class: 'mm-count__n', text: '0' });
    const countL = h('span', { class: 'mm-count__l', text: 'воспоминаний' });
    const countSub = h('span', { class: 'mm-count__sub' });
    const meter = h('i', { class: 'mm-meter__fill' });
    const power = Switch({ checked: true, label: 'Память включена', onChange: (v) => setSetting({ enabled: v }) });
    const powerLabel = h('span', { class: 'mm-power__label', text: 'Вкл' });
    const hero = h('section', { class: 'mm-hero', 'aria-label': 'Сколько WISP помнит' },
      sky,
      h('div', { class: 'mm-count', role: 'status', 'aria-live': 'polite' }, countN, h('span', { class: 'mm-count__txt' }, countL, countSub)),
      h('label', { class: 'mm-power' }, powerLabel, power),
      h('span', { class: 'mm-meter', 'aria-hidden': 'true' }, meter));
    const offNote = h('div', { class: 'mm-off', hidden: true },
      ui.icon('power', 'ds-icon mm-off__icon'),
      h('p', { text: 'Память выключена. Я не использую её в ответах и не запоминаю новое. Всё, что уже сохранено, на месте.' }));

    /* ── Поиск ── */
    const clear = h('button', { type: 'button', class: 'tl-search__clear', 'aria-label': 'Очистить поиск', hidden: true, onClick: () => { search.value = ''; onQuery(''); search.focus(); } }, ui.icon('close'));
    const search = Kit.Input({ type: 'search', placeholder: 'Поиск по памяти', maxLength: 100, label: 'Поиск по памяти', onInput: (v) => onQuery(v) });
    search.classList.add('tl-search__input');
    const searchRow = h('label', { class: 'tl-search mm-search' }, ui.icon('search', 'ds-icon tl-search__icon'), search, clear);

    /* ── Категории ── */
    const CHIPS = [{ id: 'all', label: 'All' }, { id: 'pinned', label: 'Pinned', icon: 'pin' }, ...CATS];
    const chipBtns = CHIPS.map((c) => ui.pressable(h('button', { type: 'button', class: 'mm-chip', role: 'radio', 'aria-checked': c.id === filter ? 'true' : 'false', dataset: { id: c.id }, onClick: () => setFilter(c.id) },
      c.icon ? ui.icon(c.icon, 'ds-icon mm-chip__icon') : null, h('span', { text: c.label }), h('span', { class: 'mm-chip__n' }))));
    const chips = h('div', { class: 'mm-chips', role: 'radiogroup', 'aria-label': 'Категории' }, chipBtns);
    chips.addEventListener('keydown', (e) => {
      if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
      const i = CHIPS.findIndex((c) => c.id === filter);
      const n = (i + (e.key === 'ArrowRight' ? 1 : CHIPS.length - 1)) % CHIPS.length;
      e.preventDefault(); setFilter(CHIPS[n].id); chipBtns[n].focus();
    });

    const list = h('div', { class: 'mm-list', 'aria-busy': 'true' });

    /* ── Настройки ── */
    const suggestSw = Switch({ checked: true, label: 'Предлагать запомнить', onChange: (v) => setSetting({ suggest: v }) });
    const exportBtn = h('a', { class: 'mm-set mm-set--link', download: 'wisp-memory.json' },
      h('span', { class: 'mm-set__icon' }, ui.icon('download')), h('span', { class: 'mm-set__main' }, h('span', { class: 'mm-set__label', text: 'Скачать память' }), h('span', { class: 'mm-set__sub', text: 'Файл JSON со всеми воспоминаниями' })));
    const clearBtn = ui.pressable(h('button', { type: 'button', class: 'mm-set mm-set--danger', onClick: () => openClear() },
      h('span', { class: 'mm-set__icon' }, ui.icon('trash')), h('span', { class: 'mm-set__main' }, h('span', { class: 'mm-set__label', text: 'Очистить всю память' }), h('span', { class: 'mm-set__sub', text: 'История чатов останется' }))));
    const settings = h('section', { class: 'mm-settings', 'aria-label': 'Настройки памяти' },
      h('h3', { class: 'tl-h', text: 'Настройки памяти' }),
      h('div', { class: 'mm-setgroup' },
        h('div', { class: 'mm-set' }, h('span', { class: 'mm-set__icon' }, ui.icon('spark')),
          h('span', { class: 'mm-set__main' }, h('span', { class: 'mm-set__label', text: 'Предлагать запомнить' }), h('span', { class: 'mm-set__sub', text: 'Без твоего «да» ничего не сохраняется' })), suggestSw),
        exportBtn, clearBtn),
      h('p', { class: 'mm-privacy', text: 'Память хранится на сервере WISP и видна только тебе. Пароли, коды и номера карт я не запоминаю, а личное — только с отдельного согласия.' }));

    const offline = h('div', { class: 'tl-offline', hidden: true });
    const inner = h('div', { class: 'tl-inner mm-inner' }, offline, hero, offNote, searchRow, chips, list, settings);
    const scroll = h('div', { class: 'tl-scroll mm-scroll' }, inner);
    const screen = h('div', { class: 'tl-screen is-current' }, bar, scroll);
    const el = h('section', { class: 'home-panel memory', id: 'home-panel-memory', role: 'tabpanel', 'aria-label': 'Memory' }, h('div', { class: 'tl-stack' }, screen), notice);

    /* ── Отрисовка ── */
    function paintHero() {
      const d = data;
      const n = d ? d.total : 0;
      countN.textContent = String(n);
      countL.textContent = plural(n, 'воспоминание', 'воспоминания', 'воспоминаний');
      const lim = d && d.limits ? d.limits.items_max : null;
      const plan = (assistant.session && assistant.session.plan && assistant.session.plan.title) || 'Free';
      countSub.textContent = d ? (d.pending_total ? `ждут ответа: ${d.pending_total} · ` : '') + (lim ? `из ${lim} на ${plan}` : '') : '';
      const pct = lim ? Math.min(100, Math.round((n / lim) * 100)) : 0;
      meter.style.width = pct + '%';
      hero.classList.toggle('is-full', pct >= 90);
      const on = !d || d.settings.enabled;
      power.set(on); powerLabel.textContent = on ? 'Вкл' : 'Выкл';
      power.setAttribute('aria-label', on ? 'Память включена' : 'Память выключена');
      hero.classList.toggle('is-off', !on);
      offNote.hidden = on;
      el.classList.toggle('is-off', !on);
      if (d) suggestSw.set(d.settings.suggest);
      paintSky();
      chipBtns.forEach((b, i) => {
        const id = CHIPS[i].id;
        const c = !d ? '' : id === 'all' ? d.total : id === 'pinned' ? d.pinned : d.by_category[id];
        b.querySelector('.mm-chip__n').textContent = c ? String(c) : '';
        b.hidden = !!d && id !== 'all' && !c && filter !== id;           // пустые категории не мешают
        b.setAttribute('aria-checked', id === filter ? 'true' : 'false');
      });
      chips.hidden = !d || !d.total;
      searchRow.hidden = !d || !d.total;
      const href = api.exportUrl();
      if (href) exportBtn.href = href; else exportBtn.removeAttribute('href');
      exportBtn.classList.toggle('is-off', !d || !d.total);
      clearBtn.disabled = !d || (!d.total && !d.pending_total);
      settings.hidden = !d;
    }
    function paintSky() {
      const items = data ? data.memories.concat(data.pending) : [];
      const dots = items.slice(0, 48).map((m) => {
        const x = hash(m.id), y = hash(m.id + '·');
        const pending = m.status === 'pending';
        const d = h('i', { class: `mm-dot${m.pinned ? ' is-pinned' : ''}${pending ? ' is-pending' : ''}${knownDots.size && !knownDots.has(m.id) ? ' is-new' : ''}` });
        d.style.left = (6 + (x % 880) / 10) + '%';
        d.style.top = (14 + (y % 700) / 10) + '%';
        d.style.setProperty('--s', String(0.75 + (x % 5) / 8 + (m.pinned ? 0.5 : 0)));
        d.style.setProperty('--d', `${(y % 4000) / 1000}s`);
        return d;
      });
      sky.replaceChildren(...dots);
      items.forEach((m) => knownDots.add(m.id));
    }

    function metaLine(m) {
      const parts = [SOURCE[m.source] || '', `сохранено ${shortDate(m.created_at)}`];
      if (m.updated_at - m.created_at > 60000) parts.push(`изменено ${Format.ago(m.updated_at)}`);
      return parts.filter(Boolean).join(' · ');
    }
    function card(m) {
      const c = CAT[m.category] || CAT.other;
      const pin = ui.pressable(h('button', { type: 'button', class: 'mm-card__pin', 'aria-pressed': m.pinned ? 'true' : 'false', 'aria-label': m.pinned ? 'Открепить' : 'Закрепить', title: m.pinned ? 'Открепить' : 'Закрепить', onClick: (e) => { e.stopPropagation(); togglePin(m, pin); } }, ui.icon('pin')));
      const el = h('article', { class: `mm-card${m.pinned ? ' is-pinned' : ''}`, role: 'listitem', dataset: { id: m.id } },
        ui.pressable(h('button', { type: 'button', class: 'mm-card__main', onClick: () => openEditor(m), 'aria-label': `${c.label}: ${m.content}. Изменить` },
          h('span', { class: 'mm-card__cat' }, ui.icon(c.icon, 'ds-icon mm-card__caticon'), h('span', { text: c.label }), m.sensitive ? h('span', { class: 'mm-card__tag', text: 'личное' }) : null),
          h('span', { class: 'mm-card__text', text: m.content }),
          h('span', { class: 'mm-card__meta', text: metaLine(m) }))),
        pin);
      return el;
    }
    function pendingCard(m) {
      const c = CAT[m.category] || CAT.other;
      const yes = ui.Button({ label: m.sensitive ? 'Сохранить личное' : 'Запомнить', size: 'small', onClick: () => confirmPending(m, yes) });
      const no = ui.Button({ label: 'Не надо', variant: 'ghost', size: 'small', onClick: () => dismissPending(m, no) });
      return h('article', { class: `mm-sugg${m.sensitive ? ' is-sensitive' : ''}`, role: 'listitem', dataset: { id: m.id } },
        h('p', { class: 'mm-sugg__k' }, ui.icon('spark', 'ds-icon mm-sugg__spark'), m.sensitive ? 'Личное · нужно твоё согласие' : m.replaces_id ? 'WISP предлагает обновить' : 'WISP предлагает запомнить'),
        h('p', { class: 'mm-sugg__text', text: m.content }),
        h('p', { class: 'mm-sugg__meta', text: `${c.label} · ${Format.ago(m.created_at)}` }),
        h('div', { class: 'mm-sugg__actions' }, yes, no));
    }
    function skeleton() { return h('div', { class: 'mm-skel' }, h('i'), h('i'), h('i')); }

    function render() {
      list.removeAttribute('aria-busy');
      if (!api.available) { list.replaceChildren(); return; }
      if (!data && loading) { list.setAttribute('aria-busy', 'true'); list.replaceChildren(skeleton()); return; }
      if (!data && failed) {
        list.replaceChildren(Kit.Empty({ icon: 'alert', title: 'Не получилось загрузить память', text: Kit.errorText(failed), action: ui.Button({ label: 'Повторить', variant: 'secondary', size: 'small', onClick: () => load(true) }) }));
        return;
      }
      if (!data) { list.replaceChildren(); return; }
      const nodes = [];
      const plain = filter === 'all' && !query;
      if (plain && data.pending.length) {
        nodes.push(h('section', { class: 'mm-section' }, h('h3', { class: 'tl-h', text: data.pending.length === 1 ? 'Ждёт твоего ответа' : `Ждут твоего ответа · ${data.pending.length}` }),
          h('div', { class: 'mm-stack', role: 'list' }, data.pending.map(pendingCard))));
      }
      if (!data.total && !data.pending.length) nodes.push(emptyState());
      else if (!shown.length && data.total) {
        nodes.push(query ? Kit.Empty({ icon: 'search', title: 'Ничего не нашлось', text: `По запросу «${query}» воспоминаний нет.` })
          : Kit.Empty({ icon: (CAT[filter] || { icon: 'pin' }).icon, title: filter === 'pinned' ? 'Закреплённых пока нет' : 'В этой категории пусто', text: filter === 'pinned' ? 'Нажми на булавку у важного воспоминания: закреплённое я учитываю в каждом ответе.' : null }));
      } else if (shown.length) {
        const pinned = plain ? shown.filter((m) => m.pinned) : [];
        const rest = plain ? shown.filter((m) => !m.pinned) : shown;
        if (pinned.length) nodes.push(h('section', { class: 'mm-section' }, h('h3', { class: 'tl-h', text: 'Закреплено' }), h('div', { class: 'mm-stack', role: 'list' }, pinned.map(card))));
        if (rest.length) nodes.push(h('section', { class: 'mm-section' }, plain && pinned.length ? h('h3', { class: 'tl-h', text: 'Остальное' }) : null, h('div', { class: 'mm-stack', role: 'list' }, rest.map(card))));
      }
      list.replaceChildren(...nodes);
      if (focusId) {
        const target = list.querySelector(`[data-id="${CSS.escape(focusId)}"]`);
        focusId = null;
        if (target) { target.scrollIntoView({ block: 'center', behavior: ui.reducedMotion() ? 'auto' : 'smooth' }); target.classList.add('is-flash'); setTimeout(() => target.classList.remove('is-flash'), 1600); }
      }
    }
    function emptyState() {
      const ex = (t) => ui.pressable(h('button', { type: 'button', class: 'mm-example', onClick: () => openChat && openChat(t) }, h('span', { text: `«${t}»` })));
      return h('div', { class: 'mm-empty' },
        h('span', { class: 'mm-empty__glow', 'aria-hidden': 'true' }, ui.icon('memory')),
        h('p', { class: 'mm-empty__title', text: 'Пока я ничего не запомнил' }),
        h('p', { class: 'mm-empty__text', text: 'Скажи в чате «запомни…», и факт появится здесь. Иногда я сам предложу сохранить что-то полезное, но запомню только после твоего «да».' }),
        h('div', { class: 'mm-examples' }, ex('Запомни, что я разрабатываю игру на JavaScript'), ex('Запомни, что я предпочитаю короткие ответы')),
        h('div', { class: 'mm-empty__actions' }, ui.Button({ label: 'Добавить вручную', variant: 'secondary', size: 'small', onClick: () => openEditor(null) })));
    }
    function paintOffline() {
      const why = !api.available ? 'Эта копия WISP открыта без сервера, поэтому памяти негде жить. Запусти сервер WISP и открой приложение по его адресу.'
        : assistant.state === 'server_down' ? 'Нет связи с сервером WISP. Память никуда не делась: она появится, когда связь вернётся.' : null;
      offline.hidden = !why;
      if (why) offline.replaceChildren(ui.icon('alert', 'ds-icon tl-offline__icon'), h('p', { text: why }),
        api.available ? ui.Button({ label: 'Проверить снова', variant: 'secondary', size: 'small', onClick: () => assistant.bootstrap(true) }) : null);
      hero.hidden = !api.available;
      addBtn.hidden = !api.available;
    }

    /* ── Данные ── */
    async function load(force) {
      if (!api.available || !assistant.ready) { paintOffline(); paintHero(); render(); return; }
      const my = ++seq;
      loading = true;
      if (force || !data) render();
      const all = await api.list({});
      let r = all;
      if (all.ok && (filter !== 'all' || query)) r = await api.list({ q: query, category: filter });
      if (destroyed || my !== seq) return;
      loading = false;
      if (!all.ok || !r.ok) { failed = (r.ok ? all : r).error; if (data) fail(r.ok ? all : r); render(); paintOffline(); return; }
      failed = null;
      data = all.data;
      shown = r.data.memories;
      paintOffline(); paintHero(); render();
    }
    function onQuery(v) {
      query = v.trim(); clear.hidden = !v;
      clearTimeout(timer); timer = setTimeout(() => load(), 200);
    }
    function setFilter(id) {
      if (id === filter) return;
      filter = id; ui.haptic(6); paintHero(); load();
    }
    async function setSetting(b) {
      const r = await api.setSettings(b);
      if (!r.ok) { fail(r); return false; }
      if (data) { data.settings = r.data.settings; paintHero(); }
      if ('enabled' in b) { director.react(b.enabled ? 'small' : 'blink'); setNotice(b.enabled ? 'Память включена. Снова учитываю то, что ты разрешил помнить.' : 'Память выключена. Записи на месте, но я их не использую.', 'info', 3600); }
      return true;
    }
    async function togglePin(m, btn) {
      const next = !m.pinned;
      btn.setAttribute('aria-pressed', next ? 'true' : 'false');
      const r = await api.update(m.id, { pinned: next });
      if (!r.ok) { btn.setAttribute('aria-pressed', m.pinned ? 'true' : 'false'); fail(r); return; }
      ui.haptic(next ? 12 : 6);
      if (next) director.react('nod');
      load();
    }
    async function confirmPending(m, btn) {
      btn.setBusy(true);
      const r = await api.confirm(m.id, m.sensitive ? { confirm_sensitive: true } : {});
      btn.setBusy(false);
      if (!r.ok) { fail(r); return; }
      director.react('small');
      setNotice(r.data.op === 'updated' ? 'Обновил воспоминание.' : 'Запомнил.', 'info', 2600);
      load();
    }
    async function dismissPending(m, btn) {
      btn.setBusy(true);
      const r = await api.dismiss(m.id);
      btn.setBusy(false);
      if (!r.ok) { fail(r); return; }
      setNotice('Хорошо, не буду это запоминать.', 'info', 2600);
      load();
    }

    /* ── Добавление и правка ── */
    function openEditor(m) {
      const limits = (data && data.limits) || { item_max_chars: 300 };
      let category = m ? m.category : (CAT[filter] ? filter : 'other');
      let touchedCat = !!m || !!CAT[filter];
      let pinned = m ? m.pinned : filter === 'pinned';
      const counter = h('span', { class: 'mm-ed__count', 'aria-hidden': 'true' });
      const area = Kit.Area({ value: m ? m.content : '', placeholder: 'Например: «Разрабатывает игру на JavaScript»', maxLength: limits.item_max_chars, label: 'Что запомнить', rows: 3, onInput: () => { paintCount(); err.hidden = true; consent.hidden = true; if (!touchedCat) guessCat(); } });
      function paintCount() { const n = area.value.length; counter.textContent = n > limits.item_max_chars * 0.7 ? `${n} / ${limits.item_max_chars}` : ''; save.setDisabled(!area.value.trim()); }
      const catBtns = CATS.map((c) => ui.pressable(h('button', { type: 'button', class: 'mm-catpick', role: 'radio', 'aria-checked': c.id === category ? 'true' : 'false', dataset: { id: c.id }, onClick: () => { touchedCat = true; pick(c.id); } },
        ui.icon(c.icon, 'ds-icon mm-catpick__icon'), h('span', { class: 'mm-catpick__label', text: c.label }), h('span', { class: 'mm-catpick__hint', text: c.hint }))));
      function pick(id) { category = id; catBtns.forEach((b) => b.setAttribute('aria-checked', b.dataset.id === id ? 'true' : 'false')); }
      /* подсказка категории по словам, пока пользователь не выбрал сам (окончательно решает сервер) */
      function guessCat() {
        const t = area.value.toLowerCase();
        const g = /мам|пап|брат|сестр|сын|доч|жен|муж|друг|подруг|коллег|собак|кошк|кот\b/.test(t) ? 'people'
          : /хочу|цель|мечта|планир|собираюсь/.test(t) ? 'goals'
          : /проект|работ|разрабат|игру|стартап|клиент/.test(t) ? 'work'
          : /нрав|люблю|предпочит|не люблю|коротк|подробн/.test(t) ? 'preferences'
          : /меня зовут|мне \d|живу|родил/.test(t) ? 'personal' : 'other';
        pick(g);
      }
      const pinSw = Switch({ checked: pinned, label: 'Закрепить', onChange: (v) => { pinned = v; return true; } });
      const err = h('p', { class: 'mm-ed__err', role: 'alert', hidden: true });
      const consentText = h('p', { class: 'mm-consent__text' });
      const consent = h('div', { class: 'mm-consent', hidden: true }, ui.icon('shield', 'ds-icon mm-consent__icon'), h('div', null, consentText,
        h('div', { class: 'mm-consent__actions' }, ui.Button({ label: 'Да, сохранить', size: 'small', onClick: () => submit(true) }), ui.Button({ label: 'Изменить текст', variant: 'ghost', size: 'small', onClick: () => { consent.hidden = true; area.focus(); } }))));
      const save = ui.Button({ label: m ? 'Сохранить' : 'Запомнить', onClick: () => submit(false) });
      const dates = m ? h('p', { class: 'mm-ed__dates' }, `Создано ${fullDate(m.created_at)}`, h('br'), `Обновлено ${fullDate(m.updated_at)} · ${SOURCE[m.source] || ''}`) : null;
      const del = m ? Kit.DeleteButton({ label: 'Удалить воспоминание', confirm: 'Нажми ещё раз — удалю навсегда', onConfirm: async (b) => {
        b.setBusy(true);
        const r = await api.remove(m.id);
        b.setBusy(false);
        if (!r.ok) { showErr(r.error); return; }
        closeSheet(); director.react('nod'); setNotice('Удалено. Больше не буду это учитывать.', 'info', 3000); load();
      } }) : null;
      function showErr(e) { err.textContent = e && e.code === 'limit_memory' && assistant.session && assistant.session.user.plan !== 'plus' ? `${e.message}` : Kit.errorText(e); err.hidden = false; director.react('blink'); }
      async function submit(confirmSensitive) {
        const content = area.value.trim();
        if (!content) return;
        save.setBusy(true);
        const body = { content, category, pinned };
        if (confirmSensitive) body.confirm_sensitive = true;
        const r = m ? await api.update(m.id, body) : await api.create(body);
        save.setBusy(false);
        if (!r.ok) {
          if (r.error && r.error.code === 'memory_sensitive') { consentText.textContent = r.error.message; consent.hidden = false; err.hidden = true; return; }
          showErr(r.error);
          if (r.error && r.error.code === 'limit_memory' && assistant.session && assistant.session.user.plan !== 'plus') err.appendChild(h('button', { type: 'button', class: 'tl-link mm-ed__plan', text: ' Узнать о Plus', onClick: () => openPlan() }));
          return;
        }
        closeSheet();
        director.react('small');
        const merged = !m && r.data.op === 'updated';
        if (merged) focusId = r.data.memory.id;
        setNotice(m ? 'Сохранил изменения.' : merged ? 'Похожее уже было — обновил его, без дубликата.' : 'Запомнил.', 'info', 3000);
        load();
      }
      openSheet({ title: m ? 'Воспоминание' : 'Новое воспоминание', content: [
        h('div', { class: 'mm-ed' },
          Kit.Field('Что запомнить', area), counter,
          h('p', { class: 'tl-field__label mm-ed__label', text: 'Категория' }),
          h('div', { class: 'mm-catgrid', role: 'radiogroup', 'aria-label': 'Категория' }, catBtns),
          h('div', { class: 'mm-set mm-set--plain' }, h('span', { class: 'mm-set__icon' }, ui.icon('pin')),
            h('span', { class: 'mm-set__main' }, h('span', { class: 'mm-set__label', text: 'Закрепить' }), h('span', { class: 'mm-set__sub', text: 'Закреплённое я учитываю в каждом ответе' })), pinSw),
          consent, err, dates,
          h('div', { class: 'home-sheet__actions' }, save, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() }))),
      ] });
      paintCount();
      if (!m) setTimeout(() => area.focus({ preventScroll: true }), 380);
    }

    function openClear() {
      const n = data ? data.total + data.pending_total : 0;
      const del = Kit.DeleteButton({ label: 'Очистить всю память', confirm: 'Нажми ещё раз, чтобы очистить', onConfirm: async (b) => {
        b.setBusy(true);
        const r = await api.clear();
        b.setBusy(false);
        if (!r.ok) { fail(r); return; }
        closeSheet(); director.react('blink');
        setNotice(`Память очищена: ${r.data.deleted} ${plural(r.data.deleted, 'запись', 'записи', 'записей')}.`, 'info', 3600);
        filter = 'all'; query = ''; search.value = ''; clear.hidden = true;
        load();
      } });
      openSheet({ title: 'Очистить память?', content: [
        h('p', { class: 'home-sheet__lead', text: `Я забуду всё, что помню о тебе: ${n} ${plural(n, 'запись', 'записи', 'записей')}, включая неразобранные предложения.` }),
        h('p', { class: 'home-sheet__note', text: 'История чатов останется. Это нельзя отменить.' }),
        h('div', { class: 'home-sheet__actions' }, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    /* маскот: в шапке экрана, как во вкладке Tools */
    function measure() {
      const slot = bar.mascotEl;
      const r = slot.getBoundingClientRect();
      const rr = root.getBoundingClientRect();
      if (!r.height) return null;
      return { h: 30, cy: r.top - rr.top + r.height / 2, cx: r.left - rr.left + r.width / 2 };
    }

    const unsubApi = api.subscribe((e) => { if (!destroyed && (e.source === 'external' || !visible)) { if (visible) load(); else data = data && { ...data, stale: true }; } });
    const unsubA = assistant.subscribe(() => { if (destroyed) return; paintOffline(); if (assistant.ready && visible && (!data || data.stale) && !loading) load(); });
    paintOffline(); paintHero(); render();

    return {
      el, measure,
      onShow() {
        visible = true; load(!data);
        requestAnimationFrame(() => { if (!destroyed) onLayout(); });
        setTimeout(() => { if (!destroyed && visible) onLayout(); }, 820);
      },
      onHide() { visible = false; },
      /* открыть и подсветить воспоминание (из карточки в чате) */
      focus(id) { focusId = id || null; filter = 'all'; query = ''; search.value = ''; clear.hidden = true; if (visible) load(); },
      destroy() { destroyed = true; unsubApi(); unsubA(); clearTimeout(timer); clearTimeout(noticeTimer); },
    };
  };
  App.memory.CATS = CATS;
})(window.WispApp);
