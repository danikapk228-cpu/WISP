/* WISP · Tools · Tasks
 * Менеджер задач: быстрый ввод, название и описание, срок, приоритет Low / Medium / High,
 * выполнение с анимацией, удаление, фильтры All / Active / Completed. Источник правды — сервер. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Kit, Format } = App.tools;

  const PRIORITY = [{ id: 'low', label: 'Low' }, { id: 'medium', label: 'Medium' }, { id: 'high', label: 'High' }];
  const ORDER = { high: 0, medium: 1, low: 2 };

  function dueText(d) {
    if (!d) return null;
    const n = Format.diffDays(Format.today(), d);
    return { text: n < 0 ? `просрочено · ${Format.dayLabel(d)}` : Format.dayLabel(d), warn: n < 0, today: n === 0 };
  }
  function sort(list) {
    return [...list].sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      if (a.done) return (b.completed_at || 0) - (a.completed_at || 0);
      if ((a.due_date || '9') !== (b.due_date || '9')) return (a.due_date || '9999') < (b.due_date || '9999') ? -1 : 1;
      if (a.priority !== b.priority) return ORDER[a.priority] - ORDER[b.priority];
      return b.created_at - a.created_at;
    });
  }

  App.tools.Tasks = function (ctx, opts) {
    const { api } = ctx;
    let items = [];
    let filter = 'active';
    let destroyed = false;

    const add = Kit.AddButton('Новая задача с деталями', () => edit(null));
    const bar = Kit.TopBar({ title: 'Tasks', onBack: () => ctx.back(), actions: [add] });

    /* быстрый ввод: Enter = задача с приоритетом Medium без срока */
    const quickBtn = ui.pressable(h('button', { type: 'button', class: 'tl-quick__go', 'aria-label': 'Добавить задачу', disabled: true, onClick: () => quickAdd() }, ui.icon('plus')));
    const quick = Kit.Input({ placeholder: 'Новая задача…', maxLength: 200, label: 'Новая задача', onInput: (v) => { quickBtn.disabled = !v.trim(); }, onEnter: () => quickAdd() });
    const quickRow = h('div', { class: 'tl-quick' }, quick, quickBtn);

    const seg = Kit.Segmented({
      label: 'Фильтр задач', value: filter,
      options: [{ id: 'all', label: 'All', count: 0 }, { id: 'active', label: 'Active', count: 0 }, { id: 'completed', label: 'Completed', count: 0 }],
      onChange: (id) => { filter = id; render(); },
    });
    const list = h('div', { class: 'tl-list', role: 'list', 'aria-label': 'Задачи' }, Kit.Loader());
    const scroll = h('div', { class: 'tl-scroll' }, h('div', { class: 'tl-inner' }, quickRow, seg, list));
    const el = h('div', { class: 'tl-screen', role: 'region', 'aria-label': 'Tasks' }, bar, scroll);

    async function load() {
      const r = await api.tasks.list('all');
      if (destroyed) return;
      if (!r.ok) {
        list.replaceChildren(Kit.Empty({ icon: 'alert', title: 'Не получилось загрузить', text: Kit.errorText(r.error), action: ui.Button({ label: 'Повторить', variant: 'secondary', size: 'small', onClick: () => load() }) }));
        return;
      }
      items = r.data.tasks;
      render();
    }

    function visible() {
      if (filter === 'active') return items.filter((t) => !t.done);
      if (filter === 'completed') return items.filter((t) => t.done);
      return items;
    }
    function render() {
      seg.setCounts({ all: items.length, active: items.filter((t) => !t.done).length, completed: items.filter((t) => t.done).length });
      const v = sort(visible());
      if (!v.length) {
        const empty = filter === 'completed'
          ? Kit.Empty({ icon: 'task', title: 'Пока ничего не выполнено', text: 'Отмечай дела кружком слева, и они появятся здесь.' })
          : items.length && filter === 'active'
            ? Kit.Empty({ icon: 'spark', title: 'Всё сделано', text: 'Можно выдохнуть. Или добавить что-то новое.' })
            : Kit.Empty({ icon: 'task', title: 'Список дел пуст', text: 'Напиши задачу в поле выше или попроси в чате: «Создай задачу закончить проект».' });
        list.replaceChildren(empty);
        return;
      }
      list.replaceChildren(...v.map(row));
    }

    function row(t) {
      const due = dueText(t.due_date);
      const check = Kit.Check({ checked: t.done, label: t.done ? `Вернуть: ${t.title}` : `Выполнено: ${t.title}`, onToggle: (val) => toggle(t, val, item) });
      const meta = [];
      meta.push(h('span', { class: `tl-prio tl-prio--${t.priority}`, text: PRIORITY.find((p) => p.id === t.priority).label }));
      if (due) meta.push(h('span', { class: `tl-item__due${due.warn && !t.done ? ' is-warn' : ''}${due.today && !t.done ? ' is-today' : ''}`, text: due.text }));
      if (t.description) meta.push(h('span', { class: 'tl-item__desc', text: t.description }));
      const item = h('div', { class: `tl-item tl-task${t.done ? ' is-done' : ''}`, role: 'listitem', dataset: { id: t.id } },
        check,
        ui.pressable(h('button', { type: 'button', class: 'tl-item__main', onClick: () => edit(t) },
          h('span', { class: 'tl-item__title' }, h('span', { class: 'tl-strike', text: t.title })),
          h('span', { class: 'tl-item__sub' }, meta))),
        t.source === 'ai' ? h('span', { class: 'tl-ai', title: 'Создано в чате', 'aria-label': 'Создано в чате' }, ui.icon('spark')) : null);
      return item;
    }

    /* Выполнение: кружок заливается, галочка рисуется, текст зачёркивается, строка уходит из «Active» */
    async function toggle(t, done, item) {
      item.classList.toggle('is-completing', done);
      item.classList.toggle('is-done', done);
      const leaves = (filter === 'active' && done) || (filter === 'completed' && !done);
      const res = await api.tasks.update(t.id, { done });
      if (destroyed) return;
      if (!res.ok) {
        ctx.fail(res);
        item.classList.remove('is-completing'); item.classList.toggle('is-done', !done);
        item.querySelector('.tl-check').set(!done);
        return;
      }
      Object.assign(t, res.data.task);
      if (done) ctx.director.react(items.every((x) => x.done) ? 'joy' : 'small');
      if (leaves) {
        setTimeout(() => {
          if (destroyed) return;
          item.style.height = item.offsetHeight + 'px';
          requestAnimationFrame(() => { item.classList.add('is-leaving'); item.style.height = '0px'; });
          setTimeout(() => { if (!destroyed) render(); }, 360);
        }, ui.reducedMotion() ? 0 : 560);
      } else setTimeout(() => { if (!destroyed) render(); }, 560);
    }

    let quickBusy = false;
    async function quickAdd() {
      const title = quick.value.trim();
      if (!title || quickBusy) return;
      quickBusy = true; quickBtn.disabled = true;
      const r = await api.tasks.create({ title });
      quickBusy = false;
      if (destroyed) return;
      if (!r.ok) { ctx.fail(r); quickBtn.disabled = !quick.value.trim(); return; }
      quick.value = '';
      items.unshift(r.data.task);
      if (filter === 'completed') { filter = 'active'; seg.set('active'); }
      render();
      ctx.director.react('nod');
      const n = list.querySelector(`[data-id="${r.data.task.id}"]`);
      if (n) n.classList.add('is-fresh');
    }

    function edit(t) {
      const isNew = !t;
      const title = Kit.Input({ value: t ? t.title : quick.value.trim(), placeholder: 'Что нужно сделать', maxLength: 200, label: 'Название' });
      const desc = Kit.Area({ value: t ? t.description : '', placeholder: 'Описание (необязательно)', maxLength: 4000, rows: 3, label: 'Описание' });
      const due = Kit.Input({ type: 'date', value: t && t.due_date ? t.due_date : '', label: 'Срок' });
      const dueChips = h('div', { class: 'tl-chips' }, [['Сегодня', Format.today()], ['Завтра', Format.addDays(Format.today(), 1)], ['Без срока', '']].map(([l, v]) => ui.pressable(h('button', { type: 'button', class: 'tl-chip', onClick: () => { due.value = v; ui.haptic(6); } }, l))));
      const prio = Kit.Segmented({ label: 'Приоритет', value: t ? t.priority : 'medium', options: PRIORITY, small: true });
      prio.classList.add('tl-prio-seg');
      const err = h('p', { class: 'tl-form__err', role: 'alert' });
      const saveBtn = ui.Button({ label: isNew ? 'Добавить задачу' : 'Сохранить', onClick: () => save() });
      const actions = [saveBtn];
      if (!isNew) {
        actions.push(ui.Button({ label: t.done ? 'Вернуть в активные' : 'Отметить выполненной', variant: 'secondary', onClick: async () => {
          const r = await api.tasks.update(t.id, { done: !t.done });
          if (!r.ok) { err.textContent = Kit.errorText(r.error); return; }
          Object.assign(t, r.data.task); ctx.closeSheet(); render();
        } }));
        actions.push(Kit.DeleteButton({ label: 'Удалить задачу', onConfirm: async (b) => {
          b.setBusy(true);
          const r = await api.tasks.remove(t.id);
          b.setBusy(false);
          if (!r.ok) { err.textContent = Kit.errorText(r.error); return; }
          items = items.filter((x) => x.id !== t.id);
          ctx.closeSheet(); render(); ctx.notice('Задача удалена.', 'info', 2400);
        } }));
      }
      let busy = false;
      async function save() {
        if (busy) return;
        const name = title.value.trim();
        if (!name) { err.textContent = 'Назови задачу.'; title.focus(); return; }
        busy = true; saveBtn.setBusy(true);
        const body = { title: name, description: desc.value, due_date: due.value || null, priority: prio.get() };
        const r = isNew ? await api.tasks.create(body) : await api.tasks.update(t.id, body);
        busy = false; saveBtn.setBusy(false);
        if (!r.ok) { err.textContent = Kit.errorText(r.error); ctx.director.react('blink'); return; }
        if (isNew) { items.unshift(r.data.task); quick.value = ''; quickBtn.disabled = true; } else Object.assign(t, r.data.task);
        ctx.closeSheet();
        render();
        ctx.director.react('nod');
      }
      ctx.openSheet({ title: isNew ? 'Новая задача' : 'Задача', content: [
        h('div', { class: 'tl-form' },
          Kit.Field('Название', title),
          Kit.Field('Описание', desc),
          Kit.Field('Срок', due), dueChips,
          h('div', { class: 'tl-field' }, h('span', { class: 'tl-field__label', text: 'Приоритет' }), prio),
          err),
        h('div', { class: 'home-sheet__actions' }, actions),
      ] });
    }

    const unsub = api.subscribe((e) => { if (!destroyed && (e.source === 'external' && (e.kind === 'tasks' || e.kind === 'task'))) load(); });
    load();
    if (opts.create) setTimeout(() => { if (ui.finePointer()) quick.focus(); else edit(null); }, 380);

    return { el, bar, destroy() { destroyed = true; unsub(); } };
  };
})(window.WispApp);
