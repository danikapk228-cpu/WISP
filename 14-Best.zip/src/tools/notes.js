/* WISP · Tools · Notes
 * Заметки: список с поиском (на сервере, без учёта регистра), редактор с автосохранением
 * и датой последнего изменения. Новая заметка появляется на сервере с первым введённым символом. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Kit, Format } = App.tools;

  const firstLine = (s) => (String(s || '').split('\n').map((l) => l.trim()).find(Boolean) || '');
  function headline(n) { return n.title || firstLine(n.content) || 'Без названия'; }
  function snippet(n) {
    const body = n.title ? n.content : String(n.content || '').split('\n').slice(1).join(' ');
    return body.replace(/\s+/g, ' ').trim().slice(0, 160);
  }

  App.tools.Notes = function (ctx, opts) {
    const { api } = ctx;
    let items = [];
    let query = '';
    let destroyed = false, seq = 0, timer = 0;

    const add = Kit.AddButton('Новая заметка', () => ctx.push('note', { note: null, onSaved: upsert }));
    const bar = Kit.TopBar({ title: 'Notes', onBack: () => ctx.back(), actions: [add] });
    const clear = h('button', { type: 'button', class: 'tl-search__clear', 'aria-label': 'Очистить поиск', hidden: true, onClick: () => { search.value = ''; onQuery(''); search.focus(); } }, ui.icon('close'));
    const search = Kit.Input({ type: 'search', placeholder: 'Поиск по заметкам', maxLength: 100, label: 'Поиск по заметкам', onInput: (v) => onQuery(v) });
    search.classList.add('tl-search__input');
    const searchRow = h('label', { class: 'tl-search' }, ui.icon('search', 'ds-icon tl-search__icon'), search, clear);
    const list = h('div', { class: 'tl-list tl-notes', role: 'list', 'aria-label': 'Заметки' }, Kit.Loader());
    const scroll = h('div', { class: 'tl-scroll' }, h('div', { class: 'tl-inner' }, searchRow, list));
    const el = h('div', { class: 'tl-screen', role: 'region', 'aria-label': 'Notes' }, bar, scroll);

    function onQuery(v) {
      query = v.trim();
      clear.hidden = !v;
      clearTimeout(timer);
      timer = setTimeout(load, 220);
    }
    async function load() {
      const my = ++seq;
      const r = await api.notes.list(query);
      if (destroyed || my !== seq) return;
      if (!r.ok) { list.replaceChildren(Kit.Empty({ icon: 'alert', title: 'Не получилось загрузить', text: Kit.errorText(r.error), action: ui.Button({ label: 'Повторить', variant: 'secondary', size: 'small', onClick: () => load() }) })); return; }
      items = r.data.notes;
      render();
    }
    function render() {
      if (!items.length) {
        list.replaceChildren(query
          ? Kit.Empty({ icon: 'search', title: 'Ничего не нашлось', text: `По запросу «${query}» заметок нет.` })
          : Kit.Empty({ icon: 'notes', title: 'Здесь будут твои мысли', text: 'Запиши идею или скажи в чате: «Запиши, что мне понравилась эта идея».', action: ui.Button({ label: 'Новая заметка', variant: 'secondary', size: 'small', onClick: () => ctx.push('note', { note: null, onSaved: upsert }) }) }));
        return;
      }
      list.replaceChildren(...items.map((n) => ui.pressable(h('button', { type: 'button', class: 'tl-note', role: 'listitem', onClick: () => ctx.push('note', { note: n, onSaved: upsert, onDeleted: drop }) },
        h('span', { class: 'tl-note__title', text: headline(n) }),
        snippet(n) ? h('span', { class: 'tl-note__snip', text: snippet(n) }) : null,
        h('span', { class: 'tl-note__time' }, n.source === 'ai' ? ui.icon('spark', 'ds-icon tl-note__ai') : null, `изменено ${Format.ago(n.updated_at)}`)))));
    }
    function upsert(n) { items = [n, ...items.filter((x) => x.id !== n.id)]; render(); }
    function drop(id) { items = items.filter((x) => x.id !== id); render(); }

    const unsub = api.subscribe((e) => { if (!destroyed && e.source === 'external' && (e.kind === 'note' || e.kind === 'notes')) load(); });
    load();
    if (opts && opts.create) setTimeout(() => { if (!destroyed) ctx.push('note', { note: null, onSaved: upsert }); }, 420);
    return { el, bar, onShow() { if (items.length || query) render(); }, destroy() { destroyed = true; unsub(); clearTimeout(timer); } };
  };

  /* ── Редактор заметки: автосохранение ── */
  App.tools.NoteEditor = function (ctx, opts) {
    const { api } = ctx;
    const limits = (ctx.assistant.session && ctx.assistant.session.tools) || { note_max_chars: 10000 };
    let note = opts.note ? { ...opts.note } : null;
    let dirty = false, saving = false, again = false, failed = false, destroyed = false, deleted = false;
    let timer = 0, retry = 0;

    const del = ui.IconButton({ icon: 'trash', label: 'Удалить заметку', onClick: () => askDelete() });
    del.classList.add('tl-bar__btn');
    del.hidden = !note;
    const bar = Kit.TopBar({ title: note ? headline(note) : 'Новая заметка', onBack: () => ctx.back(), backLabel: 'К заметкам', actions: [del] });
    const status = h('p', { class: 'tl-save', role: 'status', 'aria-live': 'polite' });
    bar.querySelector('.tl-bar__names').appendChild(status);

    const title = h('input', { class: 'tl-ed__title', type: 'text', placeholder: 'Заголовок', maxLength: 200, 'aria-label': 'Заголовок', autocomplete: 'off', enterKeyHint: 'next' });
    const body = h('textarea', { class: 'tl-ed__body', placeholder: 'Начни писать…', maxLength: limits.note_max_chars || 10000, 'aria-label': 'Текст заметки' });
    title.value = note ? note.title : '';
    body.value = note ? note.content : '';
    title.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); body.focus(); } });
    const counter = h('span', { class: 'tl-ed__count', 'aria-hidden': 'true' });
    const fit = () => { body.style.height = 'auto'; body.style.height = Math.max(240, body.scrollHeight + 4) + 'px'; counter.textContent = body.value.length > (limits.note_max_chars || 10000) * 0.8 ? `${body.value.length} / ${limits.note_max_chars}` : ''; };
    [title, body].forEach((n) => n.addEventListener('input', () => { fit(); changed(); }));
    const scroll = h('div', { class: 'tl-scroll tl-ed' }, h('div', { class: 'tl-inner' }, title, body, counter));
    const el = h('div', { class: 'tl-screen tl-screen--editor', role: 'region', 'aria-label': 'Заметка' }, bar, scroll);
    scroll.addEventListener('click', (e) => { if (e.target === scroll || e.target === scroll.firstChild) body.focus(); });

    function paintStatus() {
      if (failed) {
        status.replaceChildren(h('span', { class: 'is-warn', text: 'Не сохранено' }), ' · ', h('button', { type: 'button', class: 'tl-link', text: 'Повторить', onClick: () => save() }));
        return;
      }
      if (saving || dirty) { status.textContent = 'Сохраняю…'; return; }
      status.textContent = note ? `Сохранено · изменено ${Format.ago(note.updated_at)}` : 'Заметка сохранится сама';
    }
    function changed() {
      dirty = true; failed = false;
      clearTimeout(timer);
      timer = setTimeout(save, 700);
      paintStatus();
    }
    async function save() {
      clearTimeout(timer); clearTimeout(retry);
      if ((destroyed && !dirty) || deleted) return;
      if (saving) { again = true; return; }
      const payload = { title: title.value, content: body.value };
      if (!note && !payload.title.trim() && !payload.content.trim()) { dirty = false; paintStatus(); return; }
      saving = true; dirty = false; paintStatus();
      const r = note ? await api.notes.update(note.id, payload) : await api.notes.create(payload);
      saving = false;
      if (r.ok) {
        note = r.data.note;
        failed = false;
        del.hidden = false;
        bar.titleEl.textContent = headline(note);
        opts.onSaved && opts.onSaved(note);
      } else {
        dirty = true; failed = true;
        if (r.error && r.error.code === 'limit_tools') { ctx.fail(r); }
        else retry = setTimeout(() => { if (dirty) save(); }, 4000);       // сеть вернётся — сохраню сам
      }
      if (again) { again = false; if (dirty && !failed) return save(); }
      if (!destroyed) paintStatus();
    }
    function flush() { if (dirty && !deleted) save(); }

    function askDelete() {
      if (!note) { ctx.back(); return; }
      ctx.openSheet({ title: 'Удалить заметку?', content: [
        h('p', { class: 'home-sheet__lead', text: `«${headline(note)}» будет удалена.` }),
        h('p', { class: 'home-sheet__note', text: 'Это нельзя отменить.' }),
        h('div', { class: 'home-sheet__actions' },
          ui.Button({ label: 'Удалить', variant: 'danger', onClick: async () => {
            clearTimeout(timer); clearTimeout(retry); dirty = false; deleted = true;
            const r = await api.notes.remove(note.id);
            if (!r.ok) deleted = false;
            if (!r.ok) { ctx.fail(r); return; }
            const id = note.id; note = null;
            opts.onDeleted && opts.onDeleted(id);
            ctx.closeSheet();
            setTimeout(() => ctx.back(), 60);
            ctx.notice('Заметка удалена.', 'info', 2400);
          } }),
          ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => ctx.closeSheet() })),
      ] });
    }

    const onHide = () => { if (document.hidden) flush(); };
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', flush);
    const ticker = setInterval(() => { if (!saving && !dirty && !failed) paintStatus(); }, 30000);
    paintStatus();
    requestAnimationFrame(fit);
    if (!note) setTimeout(() => { if (!destroyed) (opts.focusBody ? body : title).focus({ preventScroll: true }); }, 360);

    return {
      el, bar,
      beforeLeave: flush,
      onHide: flush,
      destroy() { destroyed = true; flush(); document.removeEventListener('visibilitychange', onHide); window.removeEventListener('pagehide', flush); clearInterval(ticker); },
    };
  };
})(window.WispApp);
