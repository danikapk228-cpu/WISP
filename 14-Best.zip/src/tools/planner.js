/* WISP · Tools · Daily planner
 * Простое расписание одного дня: события со временем (добавить, изменить, удалить), переход по дням,
 * линия «сейчас» на сегодняшнем дне. Ниже — напоминания и задачи со сроком на этот день (из тех же данных).
 * Сложного календаря нет намеренно. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Kit, Format } = App.tools;

  App.tools.Planner = function (ctx, opts) {
    const { api } = ctx;
    let day = opts.date || Format.today();
    let agenda = null;
    let destroyed = false, seq = 0;

    const add = Kit.AddButton('Новое событие', () => edit(null));
    const bar = Kit.TopBar({ title: 'Daily planner', onBack: () => ctx.back(), actions: [add] });

    const prev = ui.IconButton({ icon: 'back', label: 'Предыдущий день', onClick: () => go(-1) });
    const next = ui.IconButton({ icon: 'chevron', label: 'Следующий день', onClick: () => go(1) });
    prev.classList.add('tl-day__btn'); next.classList.add('tl-day__btn');
    const dayTitle = h('p', { class: 'tl-day__title' });
    const daySub = h('p', { class: 'tl-day__sub' });
    const todayBtn = h('button', { type: 'button', class: 'tl-chip tl-day__today', text: 'Сегодня', onClick: () => { day = Format.today(); load(); } });
    const dayBar = h('div', { class: 'tl-day' }, prev, h('div', { class: 'tl-day__names', 'aria-live': 'polite' }, dayTitle, daySub), next);
    const timeline = h('div', { class: 'tl-timeline', role: 'list', 'aria-label': 'События дня' }, Kit.Loader());
    const also = h('div', { class: 'tl-also' });
    const scroll = h('div', { class: 'tl-scroll' }, h('div', { class: 'tl-inner' }, dayBar, todayBtn, timeline, also));
    const el = h('div', { class: 'tl-screen', role: 'region', 'aria-label': 'Daily planner' }, bar, scroll);

    /* свайп влево/вправо по дню */
    let sx = null;
    scroll.addEventListener('touchstart', (e) => { const t = e.touches[0]; sx = { x: t.clientX, y: t.clientY }; }, { passive: true });
    scroll.addEventListener('touchend', (e) => {
      if (!sx) return;
      const t = e.changedTouches[0]; const dx = t.clientX - sx.x, dy = t.clientY - sx.y; sx = null;
      if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.6) go(dx < 0 ? 1 : -1);
    }, { passive: true });

    function go(n) { day = Format.addDays(day, n); ui.haptic(6); load(); }

    function paintDay() {
      const n = Format.diffDays(Format.today(), day);
      dayTitle.textContent = n === 0 ? 'Сегодня' : n === 1 ? 'Завтра' : n === -1 ? 'Вчера' : Format.parse(day).toLocaleDateString('ru-RU', { weekday: 'long' }).replace(/^./, (c) => c.toUpperCase());
      daySub.textContent = Format.longDate(day);
      todayBtn.hidden = n === 0;
    }

    async function load() {
      paintDay();
      const my = ++seq;
      timeline.replaceChildren(Kit.Loader());
      also.replaceChildren();
      const r = await api.agenda(day);
      if (destroyed || my !== seq) return;
      if (!r.ok) { timeline.replaceChildren(Kit.Empty({ icon: 'alert', title: 'Не получилось загрузить', text: Kit.errorText(r.error), action: ui.Button({ label: 'Повторить', variant: 'secondary', size: 'small', onClick: () => load() }) })); return; }
      agenda = r.data.agenda;
      render();
    }

    function render() {
      const events = agenda.events;
      const isToday = day === Format.today();
      if (!events.length) {
        timeline.replaceChildren(Kit.Empty({ icon: 'calendar', title: isToday ? 'День пока свободен' : 'На этот день ничего нет', text: 'Добавь событие или скажи в чате: «Запланируй тренировку завтра в 8:00».', action: ui.Button({ label: 'Добавить событие', variant: 'secondary', size: 'small', onClick: () => edit(null) }) }));
      } else {
        const nowHm = Format.hm(new Date());
        const nodes = [];
        let nowPlaced = !isToday;
        for (const e of events) {
          if (!nowPlaced && e.start_time > nowHm) { nodes.push(nowLine(nowHm)); nowPlaced = true; }
          const past = isToday && (e.end_time || e.start_time) < nowHm;
          const live = isToday && e.start_time <= nowHm && e.end_time && e.end_time > nowHm;
          nodes.push(ui.pressable(h('button', { type: 'button', class: `tl-ev${past ? ' is-past' : ''}${live ? ' is-live' : ''}`, role: 'listitem', onClick: () => edit(e) },
            h('span', { class: 'tl-ev__time' }, h('span', { class: 'tl-ev__start', text: e.start_time }), e.end_time ? h('span', { class: 'tl-ev__end', text: e.end_time }) : null),
            h('span', { class: 'tl-ev__rail', 'aria-hidden': 'true' }),
            h('span', { class: 'tl-ev__card' },
              h('span', { class: 'tl-ev__title', text: e.title }),
              e.note ? h('span', { class: 'tl-ev__note', text: e.note }) : null,
              live ? h('span', { class: 'tl-ev__badge', text: 'Сейчас' }) : null))));
        }
        if (!nowPlaced) nodes.push(nowLine(nowHm));
        timeline.replaceChildren(...nodes);
      }
      // то же, что в напоминаниях и задачах, — на этот день
      const rows = [];
      for (const r of agenda.reminders) {
        rows.push(ui.pressable(h('button', { type: 'button', class: `tl-also__row${r.done ? ' is-done' : ''}`, onClick: () => ctx.push('reminders') },
          ui.icon('bell', 'ds-icon tl-also__icon'), h('span', { class: 'tl-also__t', text: Format.hm(new Date(r.remind_at)) }), h('span', { class: 'tl-also__v', text: r.title }))));
      }
      for (const t of agenda.tasks) {
        rows.push(ui.pressable(h('button', { type: 'button', class: 'tl-also__row', onClick: () => ctx.push('tasks') },
          ui.icon('task', 'ds-icon tl-also__icon'), h('span', { class: `tl-also__t tl-prio tl-prio--${t.priority}`, text: t.priority === 'high' ? 'High' : t.priority === 'low' ? 'Low' : 'Med' }), h('span', { class: 'tl-also__v', text: t.title }))));
      }
      if (agenda.overdue_tasks) rows.push(h('p', { class: 'tl-quiet', text: `Просроченных задач: ${agenda.overdue_tasks}` }));
      also.replaceChildren(...(rows.length ? [h('h3', { class: 'tl-h', text: 'Также в этот день' }), h('div', { class: 'tl-group' }, rows)] : []));
    }
    function nowLine(hm) {
      return h('div', { class: 'tl-now', role: 'presentation' }, h('span', { class: 'tl-now__t', text: hm }), h('span', { class: 'tl-now__line' }));
    }

    function edit(e) {
      const isNew = !e;
      const title = Kit.Input({ value: e ? e.title : '', placeholder: 'Например, тренировка', maxLength: 120, label: 'Название' });
      const date = Kit.Input({ type: 'date', value: e ? e.date : day, label: 'Дата' });
      const suggested = (() => { if (e) return e.start_time; const d = new Date(); d.setMinutes(0, 0, 0); d.setHours(d.getHours() + 1); return day === Format.today() ? Format.hm(d) : '09:00'; })();
      const start = Kit.Input({ type: 'time', value: suggested, label: 'Начало' });
      const end = Kit.Input({ type: 'time', value: e && e.end_time ? e.end_time : '', label: 'Конец' });
      const note = Kit.Area({ value: e ? e.note : '', placeholder: 'Заметка (необязательно)', maxLength: 1000, rows: 2, label: 'Заметка' });
      const err = h('p', { class: 'tl-form__err', role: 'alert' });
      const saveBtn = ui.Button({ label: isNew ? 'Добавить в план' : 'Сохранить', onClick: () => save() });
      const actions = [saveBtn];
      if (!isNew) actions.push(Kit.DeleteButton({ label: 'Удалить событие', onConfirm: async (b) => {
        b.setBusy(true);
        const r = await api.events.remove(e.id);
        b.setBusy(false);
        if (!r.ok) { err.textContent = Kit.errorText(r.error); return; }
        ctx.closeSheet(); load(); ctx.notice('Событие удалено.', 'info', 2400);
      } }));
      let busy = false;
      async function save() {
        if (busy) return;
        if (!title.value.trim()) { err.textContent = 'Назови событие.'; title.focus(); return; }
        if (!date.value || !start.value) { err.textContent = 'Выбери дату и время начала.'; return; }
        if (end.value && end.value <= start.value) { err.textContent = 'Конец должен быть позже начала.'; return; }
        busy = true; saveBtn.setBusy(true);
        const body = { title: title.value.trim(), date: date.value, start_time: start.value, end_time: end.value || null, note: note.value };
        const r = isNew ? await api.events.create(body) : await api.events.update(e.id, body);
        busy = false; saveBtn.setBusy(false);
        if (!r.ok) { err.textContent = Kit.errorText(r.error); ctx.director.react('blink'); return; }
        ctx.closeSheet();
        if (r.data.event.date !== day) { day = r.data.event.date; }
        load();
        ctx.director.react('nod');
      }
      ctx.openSheet({ title: isNew ? 'Новое событие' : 'Событие', content: [
        h('div', { class: 'tl-form' },
          Kit.Field('Название', title),
          Kit.Field('Дата', date),
          h('div', { class: 'tl-form__row' }, Kit.Field('Начало', start), Kit.Field('Конец', end, 'необязательно')),
          Kit.Field('Заметка', note),
          err),
        h('div', { class: 'home-sheet__actions' }, actions),
      ] });
    }

    const unsub = api.subscribe((ev) => { if (!destroyed && (ev.source === 'external' || ev.kind === 'reminders' || ev.kind === 'tasks')) load(); });
    const tick = setInterval(() => { if (!destroyed && agenda && day === Format.today()) render(); }, 60000);
    load();
    if (opts.create) setTimeout(() => edit(null), 380);
    return { el, bar, onShow() { if (agenda) load(); }, destroy() { destroyed = true; unsub(); clearInterval(tick); } };
  };
})(window.WispApp);
