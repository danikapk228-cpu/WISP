/* WISP · Tools · Reminder scheduler
 * Доставка напоминаний, пока WISP открыт:
 *  · берёт с сервера активные напоминания и ставит один таймер на ближайшее;
 *  · в нужную минуту сначала отмечает на сервере «показано» (чтобы две вкладки не показали дважды),
 *    затем показывает системное уведомление (если пользователь разрешил) и баннер внутри WISP;
 *  · то, что наступило, пока WISP был закрыт (за последние 12 часов), показывает как пропущенное при открытии;
 *  · системное уведомление идёт через Service Worker (Android требует именно так), иначе через new Notification.
 * Ограничение платформы: когда приложение закрыто или iOS заморозил вкладку, JS не работает, и уведомления нет.
 * Серверные push-уведомления (Web Push) — отдельная задача, здесь не имитируются. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Format } = App.tools;

  const MISSED_WINDOW = 12 * 60 * 60 * 1000;
  const MAX_TIMER = 30 * 60 * 1000;               // перепроверяем хотя бы раз в 30 минут (сон устройства, смена времени)
  const SW_URL = 'src/sw.js';

  App.tools.Scheduler = function ({ api, assistant, root, director, onOpen }) {
    let list = [];
    let timer = 0, destroyed = false, syncing = null;
    const shown = new Set();
    const pending = [];                             // сработали, пока вкладка была скрыта: покажем баннер при возвращении
    let swReg = null;

    /* Service Worker нужен только для показа системных уведомлений; кешей и перехвата сети в нём нет */
    async function registration() {
      if (swReg) return swReg;
      if (!('serviceWorker' in navigator) || !window.isSecureContext || location.protocol === 'file:') return null;
      try { swReg = await navigator.serviceWorker.register(SW_URL, { scope: './src/' }); return swReg; } catch (e) { return null; }
    }

    async function sync() {
      if (destroyed || !api.available || !assistant.ready) return;
      if (syncing) return syncing;
      syncing = (async () => {
        const r = await api.reminders.list('active');
        syncing = null;
        if (!r.ok || destroyed) return;
        list = r.data.reminders;
        const now = Date.now();
        // наступившие, но не показанные (WISP был закрыт или спал)
        for (const rem of list) {
          if (rem.remind_at <= now && !rem.notified_at && now - rem.remind_at < MISSED_WINDOW) fire(rem, now - rem.remind_at > 90 * 1000);
        }
        plan();
      })();
      return syncing;
    }

    function plan() {
      clearTimeout(timer);
      const now = Date.now();
      const next = list.filter((r) => !r.done && !r.notified_at && r.remind_at > now && !shown.has(r.id)).sort((a, b) => a.remind_at - b.remind_at)[0];
      if (!next) { timer = setTimeout(sync, MAX_TIMER); return; }
      const wait = Math.min(MAX_TIMER, Math.max(0, next.remind_at - now));
      timer = setTimeout(() => (next.remind_at - Date.now() <= 1000 ? fire(next, false).then(plan) : sync()), wait);
    }

    async function fire(rem, missed) {
      if (shown.has(rem.id)) return;
      shown.add(rem.id);
      const r = await api.reminders.notified(rem.id);
      // другая вкладка/устройство уже показали: не дублируем системное уведомление
      const first = !r.ok || r.data.first;
      if (r.ok) Object.assign(rem, r.data.reminder);
      if (rem.done) return;
      if (first && !document.hasFocus()) await system(rem, missed);
      if (!document.hidden) { banner(rem, missed); if (!missed && App.settings && App.settings.Sound) App.settings.Sound.play('notify'); } else pending.push({ rem, missed });
    }

    async function system(rem, missed) {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;
      const title = missed ? `Пропущено: ${rem.title}` : rem.title;
      const options = { body: rem.description || (missed ? `Было на ${Format.when(rem.remind_at).toLowerCase()}` : 'Напоминание WISP'), tag: `wisp-reminder-${rem.id}`, renotify: false, data: { id: rem.id } };
      const reg = await registration();
      try {
        if (reg && reg.showNotification) { await reg.showNotification(title, options); return; }
      } catch (e) { /* падаем на обычный способ */ }
      try { const n = new Notification(title, options); n.onclick = () => { window.focus(); n.close(); onOpen && onOpen(rem); }; } catch (e) { /* браузер требует Service Worker */ }
    }

    /* ── Баннер внутри WISP: «Готово» или «Через 10 минут» ── */
    const host = h('div', { class: 'tl-toasts', 'aria-live': 'assertive' });
    root.appendChild(host);
    function banner(rem, missed) {
      director && director.react('double');
      ui.haptic(30);
      const done = ui.Button({ label: 'Готово', size: 'small', onClick: async () => {
        done.setBusy(true);
        const r = await api.reminders.update(rem.id, { done: true });
        done.setBusy(false);
        if (r.ok) close();
      } });
      const later = ui.Button({ label: 'Через 10 мин', variant: 'secondary', size: 'small', onClick: async () => {
        later.setBusy(true);
        const r = await api.reminders.update(rem.id, Format.inMinutes(10));
        later.setBusy(false);
        if (r.ok) { shown.delete(rem.id); close(); sync(); }
      } });
      const x = h('button', { type: 'button', class: 'tl-toast__x', 'aria-label': 'Скрыть', onClick: () => close() }, ui.icon('close'));
      const el = h('div', { class: 'tl-toast', role: 'alertdialog', 'aria-label': `Напоминание: ${rem.title}` },
        h('span', { class: 'tl-toast__icon' }, ui.icon('bell')),
        h('div', { class: 'tl-toast__main' },
          h('p', { class: 'tl-toast__k', text: missed ? `Пропущено · ${Format.when(rem.remind_at)}` : `Напоминание · ${Format.hm(new Date(rem.remind_at))}` }),
          h('p', { class: 'tl-toast__t', text: rem.title }),
          rem.description ? h('p', { class: 'tl-toast__d', text: rem.description }) : null,
          h('div', { class: 'tl-toast__actions' }, done, later)),
        x);
      host.appendChild(el);
      requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('is-in')));
      function close() { el.classList.remove('is-in'); el.classList.add('is-out'); setTimeout(() => el.remove(), 420); }
    }

    /* Перечитываем, когда что-то изменилось, вкладка вернулась, сеть появилась, сессия готова */
    const unsubApi = api.subscribe((e) => { if (e.kind === 'reminders' || e.kind === 'reminder' || e.source === 'external') sync(); });
    const unsubA = assistant.subscribe(() => { if (assistant.ready) sync(); });
    const onVis = () => {
      if (document.hidden) return;
      while (pending.length) { const p = pending.shift(); if (!p.rem.done) banner(p.rem, p.missed); }
      sync();
    };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('online', sync);
    window.addEventListener('focus', onVis);
    if ('Notification' in window && Notification.permission === 'granted') registration();
    sync();

    return {
      sync,
      registration,
      destroy() {
        destroyed = true; clearTimeout(timer); unsubApi(); unsubA();
        document.removeEventListener('visibilitychange', onVis);
        window.removeEventListener('online', sync); window.removeEventListener('focus', onVis);
        host.remove();
      },
    };
  };
})(window.WispApp);
