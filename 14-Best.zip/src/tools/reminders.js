/* WISP · Tools · Reminders
 * Настоящие напоминания: создание, правка, удаление, «выполнено». Хранятся на сервере (момент в UTC + пояс).
 * Уведомления показывает планировщик (tools/scheduler.js), пока WISP открыт; ограничения браузера и iOS
 * объясняются честно, без обещаний системного будильника. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Kit, Format } = App.tools;
  const { Capabilities } = App.core;

  /* Что реально умеют уведомления в этом браузере */
  function limitsText() {
    const env = Capabilities.env;
    const out = [
      'Пока WISP открыт (на компьютере — даже во вкладке в фоне), я покажу уведомление в нужную минуту.',
      'Если приложение закрыто, браузер не даёт сайту разбудить себя: такое напоминание я покажу при следующем открытии как пропущенное.',
      'Это не системный будильник. Для важного (лекарства, поезд) поставь ещё и будильник на телефоне.',
    ];
    if (env.isIOS && !env.isStandalone) out.splice(1, 0, 'На iPhone уведомления от веб-приложений работают, только если WISP добавлен на экран «Домой»: «Поделиться» → «На экран „Домой“» (iOS 16.4 и новее). Без этого напоминания видны только внутри WISP.');
    else if (env.isIOS) out.splice(1, 0, 'На iPhone iOS приостанавливает свёрнутые веб-приложения, поэтому уведомление придёт, когда WISP на экране или ты его откроешь.');
    if (!env.secure) out.unshift('Уведомлениям нужно защищённое соединение (https или localhost).');
    return out;
  }

  App.tools.Reminders = function (ctx, opts) {
    const { api } = ctx;
    let items = [];
    let loaded = false, showDone = false, destroyed = false;

    const add = Kit.AddButton('Новое напоминание', () => edit(null));
    const bar = Kit.TopBar({ title: 'Reminders', onBack: () => ctx.back(), actions: [add] });
    const info = h('button', { type: 'button', class: 'tl-link', text: 'Как работают уведомления', onClick: () => openInfo() });
    const cap = App.home.Sheets.notificationsRow({ store: ctx.store, director: ctx.director });
    cap.classList.add('tl-cap');
    cap.appendChild(info);
    const list = h('div', { class: 'tl-list', 'aria-live': 'polite' }, Kit.Loader());
    const scroll = h('div', { class: 'tl-scroll' }, h('div', { class: 'tl-inner' }, cap, list));
    const el = h('div', { class: 'tl-screen', role: 'region', 'aria-label': 'Reminders' }, bar, scroll);

    async function load() {
      const r = await api.reminders.list('all');
      if (destroyed) return;
      loaded = true;
      if (!r.ok) { list.replaceChildren(errorState(r)); return; }
      items = r.data.reminders;
      render();
    }
    function errorState(r) {
      return Kit.Empty({ icon: 'alert', title: 'Не получилось загрузить', text: Kit.errorText(r.error), action: ui.Button({ label: 'Повторить', variant: 'secondary', size: 'small', onClick: () => load() }) });
    }

    function render() {
      const now = Date.now();
      const active = items.filter((r) => !r.done).sort((a, b) => a.remind_at - b.remind_at);
      const missed = active.filter((r) => r.remind_at <= now);
      const upcoming = active.filter((r) => r.remind_at > now);
      const done = items.filter((r) => r.done).sort((a, b) => (b.done_at || 0) - (a.done_at || 0));
      const out = [];
      if (!active.length && !done.length) {
        out.push(Kit.Empty({ icon: 'bell', title: 'Пока ничего не нужно помнить', text: 'Создай напоминание или попроси в чате: «Напомни завтра в 10:00 позвонить маме».', action: ui.Button({ label: 'Создать напоминание', variant: 'secondary', size: 'small', onClick: () => edit(null) }) }));
      }
      if (missed.length) out.push(section('Пропущенные', missed.map((r) => row(r, 'missed'))));
      if (upcoming.length) out.push(section(missed.length ? 'Предстоящие' : null, upcoming.map((r) => row(r))));
      else if (active.length === 0 && done.length) out.push(h('p', { class: 'tl-quiet', text: 'Все напоминания выполнены.' }));
      if (done.length) {
        const toggle = h('button', { type: 'button', class: 'tl-fold', 'aria-expanded': showDone ? 'true' : 'false', onClick: () => { showDone = !showDone; render(); } },
          h('span', { text: `Выполненные · ${done.length}` }), ui.icon('chevron', 'ds-icon tl-fold__chev'));
        out.push(toggle);
        if (showDone) out.push(h('div', { class: 'tl-group is-done' }, done.slice(0, 50).map((r) => row(r, 'done'))));
      }
      list.replaceChildren(...out);
    }
    function section(title, rows) {
      return h('div', { class: 'tl-section' }, title ? h('h3', { class: 'tl-h', text: title }) : null, h('div', { class: 'tl-group' }, rows));
    }

    function row(r, kind) {
      const check = Kit.Check({ checked: r.done, label: r.done ? `Вернуть: ${r.title}` : `Выполнено: ${r.title}`, onToggle: (v) => toggle(r, v, item) });
      const meta = h('span', { class: `tl-item__meta${kind === 'missed' ? ' is-warn' : ''}` },
        ui.icon(kind === 'missed' ? 'alert' : 'clock', 'ds-icon tl-item__mi'), Format.when(r.remind_at));
      const item = ui.pressable(h('div', { class: `tl-item${r.done ? ' is-done' : ''}`, role: 'listitem' },
        check,
        h('button', { type: 'button', class: 'tl-item__main', onClick: () => edit(r) },
          h('span', { class: 'tl-item__title', text: r.title }),
          h('span', { class: 'tl-item__sub' }, meta, r.description ? h('span', { class: 'tl-item__desc', text: r.description }) : null)),
        r.source === 'ai' ? h('span', { class: 'tl-ai', title: 'Создано в чате', 'aria-label': 'Создано в чате' }, ui.icon('spark')) : null));
      return item;
    }

    async function toggle(r, done, itemEl) {
      itemEl.classList.toggle('is-completing', done);
      const res = await api.reminders.update(r.id, { done });
      if (destroyed) return;
      if (!res.ok) { ctx.fail(res); itemEl.querySelector('.tl-check').set(!done); itemEl.classList.remove('is-completing'); return; }
      Object.assign(r, res.data.reminder);
      if (done) ctx.director.react('small');
      setTimeout(() => { if (!destroyed) render(); }, done ? 620 : 0);
    }

    /* ── Создание и правка ── */
    function edit(r) {
      const isNew = !r;
      const start = r ? {
        date: r.date || Format.key(new Date(r.remind_at)),
        time: r.time || Format.hm(new Date(r.remind_at)),
      } : Format.quickTimes()[0];
      let busy = false;
      const title = Kit.Input({ value: r ? r.title : '', placeholder: 'Например, позвонить маме', maxLength: 120, label: 'О чём напомнить', onEnter: () => save() });
      const desc = Kit.Area({ value: r ? r.description : '', placeholder: 'Подробности (необязательно)', maxLength: 1000, rows: 2, label: 'Описание' });
      const date = Kit.Input({ type: 'date', value: start.date, label: 'Дата' });
      const time = Kit.Input({ type: 'time', value: start.time, label: 'Время' });
      date.min = Format.today();
      const chips = h('div', { class: 'tl-chips', role: 'group', 'aria-label': 'Быстрый выбор' }, Format.quickTimes().map((q) => ui.pressable(h('button', {
        type: 'button', class: 'tl-chip', onClick: () => { date.value = q.date; time.value = q.time; ui.haptic(6); },
      }, q.label))));
      const err = h('p', { class: 'tl-form__err', role: 'alert' });
      const saveBtn = ui.Button({ label: isNew ? 'Напомнить' : 'Сохранить', onClick: () => save() });
      const tzNote = r && r.timezone && r.timezone !== api.timezone() ? h('p', { class: 'home-sheet__note', text: `Поставлено по времени ${r.timezone}. Показываю, когда это будет у тебя.` }) : null;
      const actions = [saveBtn];
      if (!isNew) {
        actions.push(ui.Button({ label: r.done ? 'Вернуть в активные' : 'Отметить выполненным', variant: 'secondary', onClick: async () => {
          const res = await api.reminders.update(r.id, { done: !r.done });
          if (!res.ok) { err.textContent = Kit.errorText(res.error); return; }
          Object.assign(r, res.data.reminder); ctx.closeSheet(); render();
        } }));
        actions.push(Kit.DeleteButton({ label: 'Удалить', onConfirm: async (b) => {
          b.setBusy(true);
          const res = await api.reminders.remove(r.id);
          b.setBusy(false);
          if (!res.ok) { err.textContent = Kit.errorText(res.error); return; }
          items = items.filter((x) => x.id !== r.id);
          ctx.closeSheet(); render(); ctx.notice('Напоминание удалено.', 'info', 2400);
        } }));
      }
      async function save() {
        if (busy) return;
        err.textContent = '';
        const t = title.value.trim();
        if (!t) { err.textContent = 'Напиши, о чём напомнить.'; title.focus(); return; }
        if (!date.value || !time.value) { err.textContent = 'Выбери дату и время.'; return; }
        const body = { title: t, description: desc.value };
        if (isNew || date.value !== start.date || time.value !== start.time) {
          body.date = date.value;
          body.time = time.value;
          if (!isNew) body.timezone = r.timezone;
        }
        busy = true; saveBtn.setBusy(true);
        const res = isNew ? await api.reminders.create(body) : await api.reminders.update(r.id, body);
        busy = false; saveBtn.setBusy(false);
        if (!res.ok) { err.textContent = Kit.errorText(res.error); ctx.director.react('blink'); return; }
        const saved = res.data.reminder;
        if (isNew) items.push(saved); else Object.assign(r, saved);
        ctx.closeSheet();
        render();
        ctx.director.react('small');
        ctx.notice(`Напомню: ${Format.when(saved.remind_at).toLowerCase()}.`, 'info', 3200);
      }
      ctx.openSheet({ title: isNew ? 'Новое напоминание' : 'Напоминание', content: [
        h('div', { class: 'tl-form' },
          Kit.Field('О чём напомнить', title),
          h('div', { class: 'tl-form__row' }, Kit.Field('Дата', date), Kit.Field('Время', time)),
          chips,
          Kit.Field('Описание', desc),
          tzNote, err),
        h('div', { class: 'home-sheet__actions' }, actions),
      ] });
      if (isNew && ui.finePointer()) setTimeout(() => title.focus(), 420);
    }

    function openInfo() {
      ctx.openSheet({ title: 'Как работают напоминания', content: [
        h('div', { class: 'tl-info' }, limitsText().map((t) => h('p', { class: 'tl-info__p', text: t }))),
        h('div', { class: 'home-sheet__actions' }, ui.Button({ label: 'Понятно', variant: 'secondary', onClick: () => ctx.closeSheet() })),
      ] });
    }

    const unsub = api.subscribe((e) => { if (!destroyed && (e.kind === 'reminders' || e.source === 'external')) load(); });
    const tick = setInterval(() => { if (loaded && !destroyed) render(); }, 60000);   // «пропущенные» без перезагрузки
    load();
    if (opts.create) setTimeout(() => edit(null), 380);

    return {
      el, bar,
      destroy() { destroyed = true; unsub(); clearInterval(tick); },
    };
  };
  App.tools.Reminders.limitsText = limitsText;
})(window.WispApp);
