/* WISP · Tools · Format
 * Даты и время для интерфейса. Всё считается в локальном времени устройства: сервер хранит момент
 * напоминания в UTC и пояс, в котором его поставили; на экране показываем, когда это будет здесь. */
(function (App) {
  'use strict';
  App.tools = App.tools || {};
  const pad = (n) => String(n).padStart(2, '0');
  const DAY = 86400000;

  const key = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = () => key(new Date());
  const parse = (k) => { const [y, m, d] = String(k).split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (k, n) => { const d = parse(k); d.setDate(d.getDate() + n); return key(d); };
  const diffDays = (a, b) => Math.round((parse(b) - parse(a)) / DAY);
  const hm = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

  /* «Сегодня», «Завтра», «Вчера», «пн, 16 нояб.» */
  function dayLabel(k, opts) {
    const n = diffDays(today(), k);
    if (n === 0) return 'Сегодня';
    if (n === 1) return 'Завтра';
    if (n === -1) return 'Вчера';
    const d = parse(k);
    const sameYear = d.getFullYear() === new Date().getFullYear();
    return d.toLocaleDateString('ru-RU', { weekday: opts && opts.long ? 'long' : 'short', day: 'numeric', month: opts && opts.long ? 'long' : 'short', year: sameYear ? undefined : 'numeric' });
  }
  /* «пятница, 13 ноября» */
  const longDate = (k) => parse(k).toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' });

  /* момент (ms) → «Сегодня, 18:30» в локальном времени */
  function when(ms) { const d = new Date(ms); return `${dayLabel(key(d))}, ${hm(d)}`; }

  /* «только что», «5 мин назад», «вчера в 18:02», «3 нояб.» */
  function ago(ms) {
    const s = Math.round((Date.now() - ms) / 1000);
    if (s < 45) return 'только что';
    if (s < 3600) return `${Math.max(1, Math.round(s / 60))} мин назад`;
    const d = new Date(ms);
    const n = diffDays(key(d), today());
    if (n === 0) return `сегодня в ${hm(d)}`;
    if (n === 1) return `вчера в ${hm(d)}`;
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: d.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
  }

  /* Ближайшие удобные моменты для напоминания */
  function quickTimes() {
    const now = new Date();
    const inHour = new Date(now.getTime() + 60 * 60000);
    inHour.setMinutes(Math.ceil(inHour.getMinutes() / 5) * 5, 0, 0);
    const out = [{ label: 'Через час', date: key(inHour), time: hm(inHour) }];
    if (now.getHours() < 18) out.push({ label: 'Вечером', date: today(), time: '19:00' });
    out.push({ label: 'Завтра утром', date: addDays(today(), 1), time: '09:00' });
    return out;
  }

  /* Сейчас + n минут → дата и время для повторного напоминания */
  function inMinutes(n) { const d = new Date(Date.now() + n * 60000); return { date: key(d), time: hm(d) }; }

  App.tools.Format = { key, today, parse, addDays, diffDays, hm, dayLabel, longDate, when, ago, quickTimes, inMinutes };
})(window.WispApp);
