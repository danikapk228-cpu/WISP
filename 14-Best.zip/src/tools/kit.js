/* WISP · Tools · Kit
 * Мелкие компоненты экранов инструментов поверх дизайн-системы: верхняя панель, поля, сегменты,
 * круглый чекбокс с анимацией, пустое состояние, кнопка удаления с подтверждением, всплывающая подсказка. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;

  /* Верхняя панель экрана: назад · маскот · заголовок · действия справа */
  function TopBar({ title, sub, onBack, backLabel, actions }) {
    const back = ui.IconButton({ icon: 'back', label: backLabel || 'Назад', onClick: () => onBack && onBack() });
    back.classList.add('tl-bar__btn');
    const slot = h('span', { class: 'tl-bar__slot', 'aria-hidden': 'true' });
    const titleEl = h('h2', { class: 'tl-bar__title', tabindex: '-1', text: title });
    const subEl = sub ? h('p', { class: 'tl-bar__sub', text: sub }) : null;
    const end = h('div', { class: 'tl-bar__end' }, actions || []);
    const el = h('header', { class: `tl-bar${sub ? ' has-sub' : ''}` }, back, slot, h('div', { class: 'tl-bar__names' }, titleEl, subEl), end);
    el.mascotEl = slot; el.titleEl = titleEl; el.end = end;
    return el;
  }

  function AddButton(label, onClick) {
    const b = ui.IconButton({ icon: 'plus', label, onClick });
    b.classList.add('tl-bar__btn', 'tl-add');
    return b;
  }

  /* ── Поля ── */
  function Field(label, control, hint) {
    return h('label', { class: 'tl-field' }, h('span', { class: 'tl-field__label', text: label }), control, hint ? h('span', { class: 'tl-field__hint', text: hint }) : null);
  }
  function Input({ value, placeholder, maxLength, type, label, onInput, onEnter, autocap, inputmode }) {
    const el = h('input', {
      class: 'tl-input', type: type || 'text', placeholder: placeholder || '', maxLength: maxLength || undefined,
      autocomplete: 'off', spellcheck: type ? 'false' : 'true', 'aria-label': label || placeholder || '',
      autocapitalize: autocap === false ? 'off' : 'sentences', enterKeyHint: onEnter ? 'done' : undefined, inputMode: inputmode || undefined,
    });
    el.value = value || '';
    el.addEventListener('input', () => onInput && onInput(el.value));
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing && onEnter) { e.preventDefault(); onEnter(el.value); } });
    return el;
  }
  function Area({ value, placeholder, maxLength, label, rows, onInput }) {
    const el = h('textarea', { class: 'tl-input tl-area', placeholder: placeholder || '', maxLength: maxLength || undefined, rows: rows || 3, 'aria-label': label || placeholder || '' });
    el.value = value || '';
    const fit = () => { el.style.height = 'auto'; el.style.height = Math.min(320, Math.max(84, el.scrollHeight + 2)) + 'px'; };
    el.addEventListener('input', () => { fit(); onInput && onInput(el.value); });
    requestAnimationFrame(fit);
    return el;
  }

  /* ── Сегменты (фильтры, приоритет) ── */
  function Segmented({ options, value, label, onChange, small }) {
    let cur = value;
    const btns = options.map((o) => ui.pressable(h('button', {
      type: 'button', class: 'tl-seg__btn', role: 'radio', 'aria-checked': o.id === cur ? 'true' : 'false', dataset: { id: o.id },
      onClick: () => set(o.id, true),
    }, h('span', { class: 'tl-seg__label', text: o.label }), o.count != null ? h('span', { class: 'tl-seg__count', text: String(o.count) }) : null)));
    const thumb = h('span', { class: 'tl-seg__thumb', 'aria-hidden': 'true' });
    const el = h('div', { class: `tl-seg${small ? ' tl-seg--small' : ''}`, role: 'radiogroup', 'aria-label': label || '' }, thumb, btns);
    el.style.setProperty('--n', String(options.length));
    function paint() {
      const i = Math.max(0, options.findIndex((o) => o.id === cur));
      el.style.setProperty('--i', String(i));
      btns.forEach((b) => b.setAttribute('aria-checked', b.dataset.id === cur ? 'true' : 'false'));
    }
    function set(id, user) {
      if (id === cur) return;
      cur = id; paint();
      if (user) { ui.haptic(6); onChange && onChange(id); }
    }
    el.addEventListener('keydown', (e) => {
      if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
      const i = options.findIndex((o) => o.id === cur);
      const n = (i + (e.key === 'ArrowRight' ? 1 : options.length - 1)) % options.length;
      e.preventDefault(); set(options[n].id, true); btns[n].focus();
    });
    el.setCounts = (counts) => btns.forEach((b, i) => { const c = b.querySelector('.tl-seg__count'); if (c && counts[options[i].id] != null) c.textContent = String(counts[options[i].id]); });
    el.set = (id) => set(id, false);
    el.get = () => cur;
    paint();
    return el;
  }

  /* ── Круглый чекбокс: заливка + рисующаяся галочка ── */
  function Check({ checked, label, onToggle }) {
    const el = ui.pressable(h('button', {
      type: 'button', class: 'tl-check', role: 'checkbox', 'aria-checked': checked ? 'true' : 'false', 'aria-label': label,
    }, h('svg', null)));
    el.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6.5 12.4 3.6 3.6 7.4-7.6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" pathLength="1"/></svg>';
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const next = el.getAttribute('aria-checked') !== 'true';
      el.setAttribute('aria-checked', next ? 'true' : 'false');
      if (next) { el.classList.remove('is-pop'); void el.offsetWidth; el.classList.add('is-pop'); }
      ui.haptic(next ? 12 : 6);
      onToggle && onToggle(next, el);
    });
    el.set = (v) => el.setAttribute('aria-checked', v ? 'true' : 'false');
    return el;
  }

  function Empty({ icon, title, text, action }) {
    return h('div', { class: 'tl-empty' },
      h('span', { class: 'tl-empty__icon' }, ui.icon(icon)),
      h('p', { class: 'tl-empty__title', text: title }),
      text ? h('p', { class: 'tl-empty__text', text }) : null,
      action || null);
  }

  /* Удаление в два касания: первое меняет надпись, второе удаляет */
  function DeleteButton({ label, confirm, onConfirm }) {
    let armed = 0;
    const b = ui.Button({
      label: label || 'Удалить', variant: 'danger',
      onClick: () => {
        if (!armed) {
          b.setLabel(confirm || 'Нажми ещё раз, чтобы удалить');
          ui.haptic(10);
          armed = setTimeout(() => { armed = 0; b.setLabel(label || 'Удалить'); }, 3200);
          return;
        }
        clearTimeout(armed); armed = 0;
        onConfirm && onConfirm(b);
      },
    });
    return b;
  }

  function Loader() { return h('div', { class: 'chat-loading tl-loader', 'aria-hidden': 'true' }, h('i'), h('i'), h('i')); }

  /* Понятный текст ошибки сервера */
  function errorText(err) {
    if (!err) return 'Что-то пошло не так.';
    if (err.code === 'offline') return 'Нет интернета. Попробуй, когда связь вернётся.';
    if (err.code === 'network' || err.code === 'not_connected') return 'Нет связи с сервером WISP.';
    if (err.code === 'server_error') return 'Сервер ответил ошибкой. Попробуй ещё раз.';
    return err.message || 'Не получилось.';
  }

  App.tools.Kit = { TopBar, AddButton, Field, Input, Area, Segmented, Check, Empty, DeleteButton, Loader, errorText };
})(window.WispApp);
