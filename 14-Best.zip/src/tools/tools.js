/* WISP · Layer 4 · Tools
 * Экран «Your tools»: компактная сетка инструментов и стек экранов внутри вкладки.
 * Каждый инструмент работает с сервером (ToolsAPI); данные не дублируются на клиенте.
 * Системный «назад» закрывает экран инструмента (шаги истории ведёт Home). Маскот сидит в шапке. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Kit, Format } = App.tools;

  const TOOLS = [
    { id: 'reminders', icon: 'bell', label: 'Reminders', hint: 'Напомню в нужный момент' },
    { id: 'tasks', icon: 'task', label: 'Tasks', hint: 'Дела и приоритеты' },
    { id: 'notes', icon: 'notes', label: 'Notes', hint: 'Мысли и идеи' },
    { id: 'planner', icon: 'calendar', label: 'Daily planner', hint: 'Расписание дня' },
  ];

  App.tools.ToolsView = function ({ root, store, director, assistant, api, openSheet, closeSheet, onBack, onLayout, openImage, openPlan, history }) {
    const stack = [];                 // [{ screen, pushed }]
    let shown = false, destroyed = false;
    let summary = null;

    /* ── подсказка внизу экрана ── */
    const notice = h('p', { class: 'home-notice tl-notice', role: 'status', 'aria-live': 'polite' });
    let noticeTimer = 0;
    function setNotice(text, tone, ttl) {
      clearTimeout(noticeTimer);
      if (!text) { notice.classList.remove('is-on'); return; }
      notice.textContent = text;
      notice.dataset.tone = tone || 'info';
      notice.classList.add('is-on');
      noticeTimer = setTimeout(() => notice.classList.remove('is-on'), ttl || 4200);
    }

    const ctx = {
      api, store, director, assistant, root, Kit, Format,
      notice: setNotice,
      openSheet, closeSheet, openPlan,
      push: (id, opts) => push(id, opts),
      back: () => back(),
      /* ошибка сервера → подсказка; лимит тарифа → с предложением Plus */
      fail(r, fallback) {
        const e = (r && r.error) || null;
        const msg = e ? Kit.errorText(e) : fallback || 'Не получилось.';
        setNotice(msg, 'warn', e && e.code === 'limit_tools' ? 6500 : 4800);
        director.react('blink');
      },
    };

    /* ── Корневой экран ── */
    const tiles = TOOLS.map((t) => {
      const meta = h('span', { class: 'tl-tile__meta', text: t.hint });
      const dot = h('i', { class: 'tl-tile__dot', 'aria-hidden': 'true', hidden: true });
      const b = ui.pressable(h('button', { type: 'button', class: 'tl-tile', dataset: { tool: t.id }, onClick: () => { director.react('nod'); push(t.id); } },
        h('span', { class: 'tl-tile__icon' }, ui.icon(t.icon), dot),
        h('span', { class: 'tl-tile__label', text: t.label }),
        meta));
      b.meta = meta; b.dot = dot; b.def = t;
      return b;
    });
    const imageRow = ui.pressable(h('button', { type: 'button', class: 'tl-row tl-row--image', onClick: () => openImage() },
      h('span', { class: 'tl-row__icon' }, ui.icon('image')),
      h('span', { class: 'tl-row__main' }, h('span', { class: 'tl-row__label', text: 'Image understanding' }), h('span', { class: 'tl-row__sub', text: 'Покажи фото в чате, и я его разберу' })),
      ui.icon('chevron', 'ds-icon tl-row__chev')));
    const nextUp = h('button', { type: 'button', class: 'tl-next', hidden: true, onClick: () => push('reminders') });
    const offline = h('div', { class: 'tl-offline', hidden: true });
    const grid = h('div', { class: 'tl-grid', role: 'list' }, tiles);
    const rootBar = Kit.TopBar({ title: 'Your tools', sub: 'A little help with everyday life', onBack: () => onBack(), backLabel: 'На главный экран' });
    const rootScroll = h('div', { class: 'tl-scroll' }, h('div', { class: 'tl-inner' }, offline, nextUp, grid, imageRow,
      h('p', { class: 'tl-hint', text: 'Можно и словами: «Напомни завтра в 10:00 позвонить маме» в чате.' })));
    const rootEl = h('div', { class: 'tl-screen is-root is-current' }, rootBar, rootScroll);
    const rootScreen = { el: rootEl, bar: rootBar, onShow: () => refreshSummary() };

    const stackEl = h('div', { class: 'tl-stack' }, rootEl);
    const el = h('section', { class: 'home-panel tools', id: 'home-panel-tools', role: 'tabpanel', 'aria-label': 'Your tools' }, stackEl, notice);

    function paintSummary() {
      const s = summary;
      const meta = {
        reminders: s ? (s.reminders_active ? `${s.reminders_active} ${plural(s.reminders_active, 'активное', 'активных', 'активных')}` : 'Ничего не ждёт') : null,
        tasks: s ? (s.tasks_active ? `${s.tasks_active} ${plural(s.tasks_active, 'дело', 'дела', 'дел')}${s.tasks_today ? ` · ${s.tasks_today} сегодня` : ''}` : 'Всё сделано') : null,
        notes: s ? (s.notes ? `${s.notes} ${plural(s.notes, 'заметка', 'заметки', 'заметок')}` : 'Пока пусто') : null,
        planner: s ? (s.events_today ? `${s.events_today} ${plural(s.events_today, 'событие', 'события', 'событий')} сегодня` : 'Сегодня свободно') : null,
      };
      const today = { reminders: s && s.next_reminder && Format.key(new Date(s.next_reminder.remind_at)) === Format.today(), tasks: s && s.tasks_today > 0, planner: s && s.events_today > 0 };
      tiles.forEach((t) => {
        t.meta.textContent = meta[t.def.id] || t.def.hint;
        t.dot.hidden = !today[t.def.id];
      });
      if (s && s.next_reminder) {
        nextUp.hidden = false;
        nextUp.replaceChildren(ui.icon('bell', 'ds-icon tl-next__icon'),
          h('span', { class: 'tl-next__k', text: 'Дальше' }),
          h('span', { class: 'tl-next__v', text: s.next_reminder.title }),
          h('span', { class: 'tl-next__t', text: Format.when(s.next_reminder.remind_at) }));
      } else nextUp.hidden = true;
      const why = !api.available ? 'Эта копия WISP открыта без сервера, поэтому инструментам негде хранить данные. Запусти сервер WISP и открой приложение по его адресу.'
        : assistant.state === 'server_down' ? 'Нет связи с сервером WISP. Данные никуда не делись: они появятся, когда связь вернётся.' : null;
      offline.hidden = !why;
      if (why) offline.replaceChildren(ui.icon('alert', 'ds-icon tl-offline__icon'), h('p', { text: why }),
        api.available ? ui.Button({ label: 'Проверить снова', variant: 'secondary', size: 'small', onClick: () => assistant.bootstrap(true) }) : null);
    }
    async function refreshSummary() {
      if (!api.available || !assistant.ready) { paintSummary(); return; }
      const r = await api.summary();
      if (destroyed) return;
      if (r.ok) summary = r.data.summary;
      paintSummary();
    }

    /* ── Стек экранов ── */
    const FACTORIES = () => ({ reminders: App.tools.Reminders, tasks: App.tools.Tasks, notes: App.tools.Notes, planner: App.tools.Planner, note: App.tools.NoteEditor });
    function top() { return stack.length ? stack[stack.length - 1].screen : rootScreen; }

    function push(id, opts) {
      const make = FACTORIES()[id];
      if (!make || destroyed) return null;
      const screen = make(ctx, opts || {});
      const prev = top();
      const pushed = history.push();
      stack.push({ screen, pushed });
      screen.el.classList.add('tl-screen', 'from-right');
      stackEl.appendChild(screen.el);
      prev.el.classList.remove('is-current');
      prev.el.classList.add('is-under');
      prev.el.inert = true;
      requestAnimationFrame(() => requestAnimationFrame(() => { screen.el.classList.remove('from-right'); screen.el.classList.add('is-current'); }));
      screen.onShow && screen.onShow();
      layoutSoon();
      ui.haptic(6);
      return screen;
    }
    /* закрыть верхний экран (без шага истории: его уже сделал браузер или его не было) */
    function pop() {
      const item = stack.pop();
      if (!item) return false;
      const s = item.screen;
      s.beforeLeave && s.beforeLeave();
      s.el.classList.remove('is-current');
      s.el.classList.add('to-right');
      s.el.inert = true;
      setTimeout(() => { s.el.remove(); s.destroy && s.destroy(); }, 420);
      const prev = top();
      prev.el.classList.remove('is-under');
      prev.el.classList.add('is-current');
      prev.el.inert = false;
      prev.onShow && prev.onShow();
      layoutSoon();
      return true;
    }
    function back() {
      if (!stack.length) { onBack(); return; }
      if (stack[stack.length - 1].pushed) history.back();          // popstate → Home → handlePop()
      else pop();
    }
    function reset() { while (stack.length) { const it = stack.pop(); it.screen.beforeLeave && it.screen.beforeLeave(); it.screen.el.remove(); it.screen.destroy && it.screen.destroy(); } rootEl.classList.remove('is-under'); rootEl.classList.add('is-current'); rootEl.inert = false; layoutSoon(); }

    function layoutSoon() {
      requestAnimationFrame(() => { if (shown && !destroyed) onLayout(); });
      setTimeout(() => { if (shown && !destroyed) onLayout(); }, 820);
    }

    /* маскот: в шапке текущего экрана */
    function measure() {
      const slot = top().bar ? top().bar.mascotEl : null;
      if (!slot) return null;
      const r = slot.getBoundingClientRect();
      const rr = root.getBoundingClientRect();
      if (!r.height) return null;
      return { h: 30, cy: r.top - rr.top + r.height / 2, cx: r.left - rr.left + r.width / 2 };
    }

    const unsubApi = api.subscribe(() => { if (!destroyed && shown && !stack.length) refreshSummary(); });
    const unsubA = assistant.subscribe(() => { if (!destroyed) { paintSummary(); if (assistant.ready && shown && !summary) refreshSummary(); } });
    paintSummary();

    return {
      el, measure,
      onShow() { shown = true; top().onShow && top().onShow(); if (!stack.length) refreshSummary(); layoutSoon(); },
      onHide() { shown = false; const t = top(); t.onHide && t.onHide(); },
      open(id, opts) { reset(); const s = push(id, opts); return s; },
      push: (id, opts) => push(id, opts),
      depth: () => stack.length,
      pushedDepth: () => stack.filter((x) => x.pushed).length,
      handlePop() { if (!stack.length) return false; pop(); return true; },
      reset,
      destroy() { destroyed = true; reset(); unsubApi(); unsubA(); clearTimeout(noticeTimer); },
    };
  };

  function plural(n, one, few, many) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
    return many;
  }
  App.tools.plural = plural;
  App.tools.TOOLS = TOOLS;
})(window.WispApp);
