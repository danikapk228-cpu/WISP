/* WISP · Core · Capabilities
 * Возможности устройства: проверка поддержки, текущее состояние, запрос по действию пользователя.
 * Ничего не запрашивается автоматически. Если API недоступен, возвращается честная причина.
 * Статусы: granted | denied | prompt | unsupported | unavailable */
(function (App) {
  'use strict';

  const ua = navigator.userAgent || '';
  const isIOS = /iP(hone|ad|od)/.test(ua) || (/Macintosh/.test(ua) && 'ontouchend' in document);
  const isStandalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  const secure = window.isSecureContext !== false;

  const ok = () => ({ ok: true });
  const no = (reason) => ({ ok: false, reason });

  async function queryPermission(name) {
    try {
      if (!navigator.permissions || !navigator.permissions.query) return null;
      const s = await navigator.permissions.query({ name });
      return s.state;                                    // granted | denied | prompt
    } catch (e) { return null; }                        // браузер не умеет спрашивать про это разрешение
  }

  /* ── Уведомления ── */
  const notifications = {
    id: 'notifications',
    title: 'Уведомления',
    icon: 'bell',
    why: 'Чтобы напоминать о важном и сообщать, когда я что-то для тебя подготовил. Только по делу.',
    action: 'Разрешить',
    support() {
      if (!secure) return no('Нужно защищённое соединение (https).');
      if (!('Notification' in window)) {
        return no(isIOS && !isStandalone
          ? 'На iPhone уведомления работают, когда WISP добавлен на экран «Домой».'
          : 'Этот браузер не поддерживает веб-уведомления.');
      }
      return ok();
    },
    async query() {
      const p = Notification.permission;
      return p === 'default' ? 'prompt' : p;
    },
    async request() {
      const result = await new Promise((resolve) => {
        try {
          const r = Notification.requestPermission(resolve);
          if (r && typeof r.then === 'function') r.then(resolve, () => resolve(Notification.permission));
        } catch (e) { resolve(Notification.permission); }
      });
      if (result === 'granted') {
        // короткое настоящее уведомление-подтверждение
        try { new Notification('WISP на связи', { body: 'Буду писать только по делу.', silent: true }); } catch (e) { /* Android требует Service Worker: разрешение всё равно получено */ }
      }
      return result === 'default' ? 'prompt' : result;
    },
    deniedHint: 'Ты запретил уведомления. Включить их можно в настройках сайта в браузере.',
  };

  /* ── Микрофон ── */
  const microphone = {
    id: 'microphone',
    title: 'Микрофон',
    icon: 'mic',
    why: 'Чтобы со мной можно было говорить голосом. Слушаю только тогда, когда ты сам включаешь микрофон.',
    action: 'Разрешить',
    support() {
      if (!secure) return no('Нужно защищённое соединение (https).');
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return no('Этот браузер не даёт доступ к микрофону.');
      return ok();
    },
    async query() {
      return (await queryPermission('microphone')) || 'prompt';
    },
    async request() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());      // сразу отпускаем: сейчас слушать нечего
        return 'granted';
      } catch (e) {
        if (e && (e.name === 'NotFoundError' || e.name === 'OverconstrainedError' || e.name === 'NotReadableError')) return 'unavailable';
        return 'denied';
      }
    },
    deniedHint: 'Доступ к микрофону запрещён. Его можно разрешить в настройках сайта в браузере.',
    unavailableHint: 'Микрофон не найден или занят другим приложением.',
  };

  /* ── Надёжная память (Storage API) ── */
  const storage = {
    id: 'storage',
    title: 'Надёжная память',
    icon: 'shield',
    why: 'Попрошу браузер не стирать то, что я о тебе знаю, даже если на устройстве станет мало места.',
    action: 'Включить',
    support() {
      if (!secure) return no('Нужно защищённое соединение (https).');
      if (!navigator.storage || !navigator.storage.persist) return no('Браузер не поддерживает постоянное хранилище.');
      return ok();
    },
    async query() {
      try { return (await navigator.storage.persisted()) ? 'granted' : 'prompt'; } catch (e) { return 'prompt'; }
    },
    async request() {
      try { return (await navigator.storage.persist()) ? 'granted' : 'denied'; } catch (e) { return 'denied'; }
    },
    deniedHint: 'Браузер решил не закреплять память. Данные сохраняются, но могут удалиться при очистке браузера.',
  };

  /* ── Голос (синтез речи на устройстве) ── */
  function loadVoices(timeout) {
    return new Promise((resolve) => {
      const synth = window.speechSynthesis;
      const now = synth.getVoices();
      if (now && now.length) return resolve(now);
      let done = false;
      const finish = () => { if (done) return; done = true; resolve(synth.getVoices() || []); };
      synth.addEventListener ? synth.addEventListener('voiceschanged', finish, { once: true }) : (synth.onvoiceschanged = finish);
      setTimeout(finish, timeout || 1200);
    });
  }
  const voice = {
    id: 'voice',
    title: 'Мой голос',
    icon: 'wave',
    why: 'Чтобы я мог зачитывать ответы вслух. Голос синтезируется прямо на устройстве.',
    action: 'Послушать',
    support() {
      if (!('speechSynthesis' in window) || typeof window.SpeechSynthesisUtterance !== 'function') return no('Этот браузер не умеет синтезировать речь.');
      return ok();
    },
    async query(saved) {
      return saved === 'granted' ? 'granted' : 'prompt';   // у синтеза речи нет системного разрешения
    },
    async request(ctx) {
      const voices = await loadVoices();
      const ru = voices.find((v) => /^ru(-|_|$)/i.test(v.lang));
      if (!ru) return 'unavailable';
      return new Promise((resolve) => {
        const u = new SpeechSynthesisUtterance(ctx && ctx.name ? `Привет, ${ctx.name}! Это мой голос.` : 'Привет! Это мой голос.');
        u.voice = ru; u.lang = ru.lang; u.rate = 1; u.pitch = 1.08;
        let settled = false;
        const end = (s) => { if (!settled) { settled = true; resolve(s); } };
        u.onend = () => end('granted');
        u.onerror = () => end('denied');
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(u);
        setTimeout(() => end('granted'), 6000);
      });
    },
    unavailableHint: 'В системе нет русского голоса, поэтому вслух я пока говорить не смогу.',
    deniedHint: 'Не получилось воспроизвести голос. Проверь звук и попробуй ещё раз.',
    retryable: true,
  };

  const LIST = [notifications, microphone, storage, voice];

  /* Текущее состояние с учётом сохранённого в профиле. */
  async function resolveStatus(cap, saved) {
    const s = cap.support();
    if (!s.ok) return { status: 'unsupported', reason: s.reason };
    if (cap.id === 'voice') {
      if (saved === 'unavailable') return { status: 'unavailable', reason: cap.unavailableHint };
      return { status: await cap.query(saved) };
    }
    const live = await cap.query();
    if (live === 'prompt' && saved === 'unavailable') return { status: 'unavailable', reason: cap.unavailableHint };
    if (live === 'prompt' && saved === 'denied' && cap.id === 'storage') return { status: 'denied', reason: cap.deniedHint };
    if (live === 'denied') return { status: 'denied', reason: cap.deniedHint };
    return { status: live };
  }

  async function request(cap, ctx) {
    const status = await cap.request(ctx);
    const reason = status === 'denied' ? cap.deniedHint : status === 'unavailable' ? cap.unavailableHint : undefined;
    return { status, reason };
  }

  App.core.Capabilities = { LIST, get: (id) => LIST.find((c) => c.id === id), resolveStatus, request, env: { isIOS, isStandalone, secure } };
})(window.WispApp);
