/* WISP · Core · ProfileStore
 * Состояние профиля в рантайме: единая точка изменений, подписки, сохранение через репозиторий. */
(function (App) {
  'use strict';
  const { Profile } = App.core;

  class ProfileStore {
    constructor(repository) {
      this.repo = repository;
      this.profile = Profile.createProfile();
      this.listeners = new Set();
    }
    async init() { this.profile = await this.repo.load(); return this.profile; }
    get user() { return this.profile.user; }
    update(patch) {
      this.profile = Profile.applyPatch(this.profile, patch);
      this.repo.saveSoon(this.profile);
      this.listeners.forEach((fn) => fn(this.profile));
      return this.profile;
    }
    /* Layer 6: принять профиль целиком (с сервера или из другой вкладки) без новой отметки времени:
     * это не новое изменение, а уже сохранённое где-то ещё. persist:false — не писать обратно в хранилище. */
    adopt(raw, opts) {
      this.profile = Profile.normalize(raw);
      if (!opts || opts.persist !== false) this.repo.saveSoon(this.profile, 0);
      this.listeners.forEach((fn) => fn(this.profile));
      return this.profile;
    }
    setPermission(key, status) { return this.update(Profile.permissionPatch(key, status)); }
    async flush() { await this.repo.save(this.profile); }
    async reset() {
      await this.repo.clear();
      this.profile = Profile.createProfile();
      this.listeners.forEach((fn) => fn(this.profile));
    }
    subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
    exportForServer() { return Profile.toServerPayload(this.profile); }
  }

  App.core.ProfileStore = ProfileStore;
})(window.WispApp);
