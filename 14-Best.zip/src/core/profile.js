/* WISP · Core · Profile
 * Доменная модель профиля: схема, справочники, нормализация, сериализация для сервера.
 * Ничего не знает ни об интерфейсе, ни о хранилище.
 * Layer 6: + user.avatar (data:image, до 90 КБ) и user.preferences (настройки). Старые профили получают значения по умолчанию.
 * Layer 13: схема настроек — общая с сервером (src/core/preferences-schema.js). */
(function (App) {
  'use strict';

  const SCHEMA_VERSION = 1;
  const LIMITS = { name: 32, about: 1000 };

  const INTERESTS = [
    { id: 'technology',  label: 'Технологии',       icon: 'chip' },
    { id: 'games',       label: 'Игры',             icon: 'gamepad' },
    { id: 'programming', label: 'Программирование', icon: 'code' },
    { id: 'creativity',  label: 'Творчество',       icon: 'palette' },
    { id: 'science',     label: 'Наука',            icon: 'atom' },
    { id: 'sport',       label: 'Спорт',            icon: 'dumbbell' },
    { id: 'music',       label: 'Музыка',           icon: 'note' },
    { id: 'learning',    label: 'Обучение',         icon: 'book' },
    { id: 'business',    label: 'Бизнес',           icon: 'chart' },
    { id: 'design',      label: 'Дизайн',           icon: 'pen' },
    { id: 'travel',      label: 'Путешествия',      icon: 'compass' },
    { id: 'other',       label: 'Другое',           icon: 'dots' },
  ];

  const OCCUPATIONS = [
    { id: 'school',      label: 'Учусь в школе' },
    { id: 'university',  label: 'Учусь в университете' },
    { id: 'work',        label: 'Работаю' },
    { id: 'own_project', label: 'Развиваю собственный проект' },
    { id: 'multiple',    label: 'Занимаюсь несколькими делами' },
    { id: 'other',       label: 'Другое' },
    { id: 'undisclosed', label: 'Не хочу указывать' },
  ];

  const hi = (name, withName, noName) => (name ? withName(name) : noName);
  const PERSONALITIES = [
    { id: 'friendly', title: 'Дружелюбный', desc: 'Общительный и позитивный.', reaction: 'joy',
      sample: (n) => hi(n, (x) => `Привет, ${x}! Рад тебя видеть. Чем займёмся сегодня?`, 'Привет! Рад тебя видеть. Чем займёмся сегодня?') },
    { id: 'calm', title: 'Спокойный', desc: 'Мягкий и рассудительный.', reaction: 'calm',
      sample: (n) => hi(n, (x) => `Здравствуй, ${x}. Давай спокойно разберёмся, что сегодня важно.`, 'Здравствуй. Давай спокойно разберёмся, что сегодня важно.') },
    { id: 'business', title: 'Деловой', desc: 'Краткий и эффективный.', reaction: 'nod',
      sample: (n) => hi(n, (x) => `${x}, на связи. Какая задача?`, 'На связи. Какая задача?') },
    { id: 'humor', title: 'С юмором', desc: 'Весёлый и немного ироничный.', reaction: 'double',
      sample: (n) => hi(n, (x) => `О, ${x}! Я уже начал скучать. Спасаем мир или хотя бы этот день?`, 'О, привет! Я уже начал скучать. Спасаем мир или хотя бы этот день?') },
    { id: 'adaptive', title: 'Адаптивный', desc: 'Подстраивается под настроение и ситуацию.', reaction: 'hop',
      sample: (n) => hi(n, (x) => `Привет, ${x}. Подстроюсь под твой ритм: могу коротко, могу подробно.`, 'Привет. Подстроюсь под твой ритм: могу коротко, могу подробно.') },
  ];
  const DEFAULT_PERSONALITY = 'adaptive';

  /* Тариф. Источник правды: сервер (подписка). Клиент сам Plus не включает, только показывает то, что пришло в профиле. */
  const PLANS = [
    { id: 'free', title: 'Free' },
    { id: 'plus', title: 'Plus' },
  ];
  const DEFAULT_PLAN = 'free';

  /* Layer 6 · Настройки. Живут в том же профиле (одно хранилище, одна нормализация).
   * Layer 13: схема вынесена в src/core/preferences-schema.js — её же подключает сервер (server/account/profile.js),
   * поэтому клиент и сервер больше не могут разойтись. Значения по умолчанию = поведение WISP 12. */
  const PrefSchema = App.core.PrefSchema;
  const PREFERENCES = PrefSchema.SCHEMA;
  const AVATAR_MAX = 90000;
  const AVATAR_RE = /^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/;
  const defaultPreferences = () => PrefSchema.defaults();
  const sanitizePreferences = (v) => PrefSchema.sanitize(v);
  const sanitizeAvatar = (v) => (typeof v === 'string' && v.length <= AVATAR_MAX && AVATAR_RE.test(v) ? v : null);

  const PERMISSION_KEYS = ['notifications', 'microphone', 'storage', 'voice'];
  const PERMISSION_STATUSES = ['granted', 'denied', 'prompt', 'unsupported', 'unavailable', 'skipped'];

  const nowISO = () => new Date().toISOString();
  const ids = (list) => list.map((x) => x.id);

  function createProfile() {
    const t = nowISO();
    return {
      schema_version: SCHEMA_VERSION,
      user: {
        name: null,
        interests: [],
        occupation: null,
        about: '',
        assistant_personality: null,
        permissions: {},
        onboarding_completed: false,
        plan: DEFAULT_PLAN,
        avatar: null,
        preferences: defaultPreferences(),
      },
      meta: { created_at: t, updated_at: t, completed_at: null },
    };
  }

  /* ── Санитизация ── */
  const CONTROL = /[\x00-\x08\u000B\u000C\u000E-\u001F\u007F]/g;
  function sanitizeName(v) {
    if (typeof v !== 'string') return null;
    const s = v.replace(CONTROL, '').replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, LIMITS.name).trim();
    return s || null;
  }
  function sanitizeAbout(v) {
    if (typeof v !== 'string') return '';
    return v.replace(CONTROL, '').replace(/\r\n?/g, '\n').slice(0, LIMITS.about);
  }
  function sanitizeInterests(v) {
    if (!Array.isArray(v)) return [];
    const allowed = ids(INTERESTS);
    return allowed.filter((id) => v.includes(id));               // порядок каталога, без дублей
  }
  const oneOf = (v, list) => (ids(list).includes(v) ? v : null);
  function sanitizePermissions(v) {
    const out = {};
    if (!v || typeof v !== 'object') return out;
    for (const key of PERMISSION_KEYS) {
      const p = v[key];
      if (p && PERMISSION_STATUSES.includes(p.status)) {
        out[key] = { status: p.status, updated_at: typeof p.updated_at === 'string' ? p.updated_at : nowISO() };
      }
    }
    return out;
  }

  /* Нормализация любых входных данных (из хранилища или с сервера).
   * Неизвестные поля отбрасываются: в профиль физически не попадут токены, ключи и прочие секреты. */
  function normalize(raw) {
    const base = createProfile();
    if (!raw || typeof raw !== 'object') return base;
    const u = raw.user || {};
    const m = raw.meta || {};
    return {
      schema_version: SCHEMA_VERSION,
      user: {
        name: sanitizeName(u.name),
        interests: sanitizeInterests(u.interests),
        occupation: oneOf(u.occupation, OCCUPATIONS),
        about: sanitizeAbout(u.about),
        assistant_personality: oneOf(u.assistant_personality, PERSONALITIES),
        permissions: sanitizePermissions(u.permissions),
        onboarding_completed: u.onboarding_completed === true,
        plan: oneOf(u.plan, PLANS) || DEFAULT_PLAN,
        avatar: sanitizeAvatar(u.avatar),
        preferences: sanitizePreferences(u.preferences),
      },
      meta: {
        created_at: typeof m.created_at === 'string' ? m.created_at : base.meta.created_at,
        updated_at: typeof m.updated_at === 'string' ? m.updated_at : base.meta.updated_at,
        completed_at: typeof m.completed_at === 'string' ? m.completed_at : null,
      },
    };
  }

  /* Иммутабельное обновление: возвращает новый нормализованный профиль. */
  function applyPatch(profile, patch) {
    const next = {
      ...profile,
      user: { ...profile.user, ...patch },
      meta: { ...profile.meta, updated_at: nowISO() },
    };
    if (patch.permissions) next.user.permissions = { ...profile.user.permissions, ...patch.permissions };
    if (patch.preferences) next.user.preferences = { ...profile.user.preferences, ...patch.preferences };
    if (patch.onboarding_completed === true && !profile.meta.completed_at) next.meta.completed_at = nowISO();
    if (patch.onboarding_completed === false) next.meta.completed_at = null;
    return normalize(next);
  }

  const permissionPatch = (key, status) => ({ permissions: { [key]: { status, updated_at: nowISO() } } });

  /* Контракт для будущей синхронизации с сервером: стабильный JSON без служебных полей клиента. */
  function toServerPayload(profile) {
    const p = normalize(profile);
    return JSON.parse(JSON.stringify({ schema_version: p.schema_version, user: p.user, meta: p.meta }));
  }

  const find = (list, id) => list.find((x) => x.id === id) || null;

  App.core.Profile = {
    SCHEMA_VERSION, LIMITS, INTERESTS, OCCUPATIONS, PERSONALITIES, DEFAULT_PERSONALITY, PERMISSION_KEYS, PLANS, DEFAULT_PLAN,
    PREFERENCES, AVATAR_MAX, defaultPreferences, sanitizePreferences, sanitizeAvatar,
    createProfile, normalize, applyPatch, permissionPatch, toServerPayload,
    sanitizeName, sanitizeAbout,
    interest: (id) => find(INTERESTS, id),
    occupation: (id) => find(OCCUPATIONS, id),
    personality: (id) => find(PERSONALITIES, id),
    effectivePersonality: (p) => find(PERSONALITIES, p.user.assistant_personality || DEFAULT_PERSONALITY),
    plan: (p) => find(PLANS, p.user.plan) || find(PLANS, DEFAULT_PLAN),
  };
})(window.WispApp);
