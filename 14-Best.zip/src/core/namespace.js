/* WISP · общий неймспейс приложения.
 * Классические скрипты (без бандлера и ES-модулей), чтобы проект открывался и с file://, и с любого статического хостинга. */
window.WispApp = window.WispApp || { core: {}, ui: {}, screens: {}, onboarding: {}, home: {}, chat: {}, tools: {} };
