/* WISP · Core · Memory API (Layer 5)
 * Клиент долговременной памяти поверх того же AssistantClient: тот же сервер, та же httpOnly-сессия.
 * Память хранится только на сервере (SQLite, таблица memories) и привязана к пользователю сессии.
 * Здесь нет второй копии и нет localStorage: экран Memory всегда читает сервер.
 * bus: экран Memory, карточки в чате и действия AI сообщают «память изменилась», подписчики перечитывают. */
(function (App) {
  'use strict';

  function MemoryAPI(assistant) {
    const listeners = new Set();
    const enc = encodeURIComponent;
    function emit(detail) { listeners.forEach((fn) => { try { fn({ kind: 'memory', ...(detail || {}) }); } catch (e) { /* подписчик не должен ломать остальных */ } }); }
    async function call(method, path, body, change) {
      const r = await assistant.request(method, path, body);
      if (r.ok && change) emit({ op: change, data: r.data });
      return r;
    }
    return {
      get available() { return assistant.connected; },
      get ready() { return assistant.ready; },
      subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
      /* изменения, сделанные не через этот клиент (AI в чате) */
      notify(detail) { emit({ source: 'external', ...(detail || {}) }); },

      list: ({ q, category } = {}) => {
        const qs = [q ? `q=${enc(q)}` : '', category && category !== 'all' ? `category=${enc(category)}` : ''].filter(Boolean).join('&');
        return call('GET', `/memories${qs ? '?' + qs : ''}`);
      },
      create: (b) => call('POST', '/memories', b, 'created'),
      update: (id, b) => call('PATCH', `/memories/${enc(id)}`, b, 'updated'),
      remove: (id) => call('DELETE', `/memories/${enc(id)}`, undefined, 'deleted'),
      confirm: (id, b) => call('POST', `/memories/${enc(id)}/confirm`, b || {}, 'confirmed'),
      dismiss: (id) => call('POST', `/memories/${enc(id)}/dismiss`, {}, 'dismissed'),
      clear: () => call('DELETE', '/memories', { confirm: 'clear_all' }, 'cleared'),
      settings: () => call('GET', '/memory/settings'),
      setSettings: (b) => call('PATCH', '/memory/settings', b, 'settings'),
      /* файл отдаёт сервер (Content-Disposition), cookie сессии уходит автоматически */
      exportUrl: () => (assistant.base ? `${assistant.base}/memories/export` : null),
    };
  }

  App.core.MemoryAPI = MemoryAPI;
})(window.WispApp);
