/* WISP · Core · Storage
 * Слой хранения. Интерфейс адаптера (async):
 *   read(key) → Promise<object|null>
 *   write(key, value) → Promise<void>
 *   remove(key) → Promise<void>
 * Сейчас используется LocalStorageAdapter. Для переноса на сервер достаточно передать
 * в репозиторий адаптер с тем же интерфейсом (например, поверх fetch к вашему API,
 * авторизация через httpOnly-cookie). Секреты и API-ключи в клиентском хранилище не держим:
 * профиль проходит через Profile.normalize(), который отбрасывает любые неизвестные поля. */
(function (App) {
  'use strict';
  const { Profile } = App.core;

  const KEYS = {
    profile: 'wisp:profile:v1',
    progress: 'wisp:onboarding:v1',
    chat: 'wisp:chat:v1',
  };

  class LocalStorageAdapter {
    constructor(namespace) {
      this.ns = namespace || '';
      this.memory = new Map();
      this.persistent = false;
      try {
        const probe = '__wisp_probe__';
        window.localStorage.setItem(probe, '1');
        window.localStorage.removeItem(probe);
        this.persistent = true;
      } catch (e) {
        // приватный режим / запрет хранилища: работаем в памяти, интерфейс тот же
      }
    }
    async read(key) {
      try {
        if (this.memory.has(key)) {
          const fallback = this.memory.get(key);
          return fallback ? JSON.parse(fallback) : null;
        }
        const raw = this.persistent ? window.localStorage.getItem(this.ns + key) : null;
        return raw ? JSON.parse(raw) : null;
      } catch (e) { return null; }
    }
    async write(key, value) {
      const raw = JSON.stringify(value);
      if (this.persistent) {
        try { window.localStorage.setItem(this.ns + key, raw); this.memory.delete(key); return; } catch (e) { /* квота: падаем в память */ }
      }
      this.memory.set(key, raw);
    }
    async remove(key) {
      if (this.persistent) {
        try { window.localStorage.removeItem(this.ns + key); this.memory.delete(key); return; }
        catch (e) { this.memory.set(key, null); return; }
      }
      this.memory.delete(key);
    }
  }

  /* Репозиторий профиля: загрузка, нормализация, отложенное сохранение (без потерь при закрытии). */
  class ProfileRepository {
    constructor(adapter) {
      this.adapter = adapter;
      this.pending = null;
      this.timer = 0;
      const flush = () => this.flush();
      window.addEventListener('pagehide', flush);
      document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
    }
    async load() {
      return Profile.normalize(await this.adapter.read(KEYS.profile));
    }
    saveSoon(profile, delay) {
      this.pending = profile;
      clearTimeout(this.timer);
      this.timer = setTimeout(() => this.flush(), delay == null ? 250 : delay);
    }
    async save(profile) {
      this.pending = profile;
      return this.flush();
    }
    async flush() {
      clearTimeout(this.timer);
      if (!this.pending) return;
      const p = this.pending; this.pending = null;
      await this.adapter.write(KEYS.profile, Profile.toServerPayload(p));
    }
    async clear() {
      this.pending = null; clearTimeout(this.timer);
      await this.adapter.remove(KEYS.profile);
    }
  }

  /* Прогресс онбординга (состояние интерфейса, не часть профиля пользователя). */
  class ProgressRepository {
    constructor(adapter) { this.adapter = adapter; }
    async load() {
      const v = await this.adapter.read(KEYS.progress);
      return v && typeof v.step === 'string' ? { step: v.step, mode: v.mode === 'edit' ? 'edit' : 'first' } : null;
    }
    async save(step, mode) { await this.adapter.write(KEYS.progress, { step, mode: mode || 'first', updated_at: new Date().toISOString() }); }
    async clear() { await this.adapter.remove(KEYS.progress); }
  }

  /* Layer 3: состояние интерфейса чата (не история!). История диалогов хранится на сервере.
   * Здесь только: какой диалог был открыт последним и черновики неотправленного текста. */
  class ChatStateRepository {
    constructor(adapter) { this.adapter = adapter; this.state = null; this.timer = 0; }
    async load() {
      const v = await this.adapter.read(KEYS.chat);
      const drafts = {};
      if (v && v.drafts && typeof v.drafts === 'object') {
        for (const [k, t] of Object.entries(v.drafts).slice(-20)) if (typeof t === 'string' && t) drafts[k] = t.slice(0, 16000);
      }
      this.state = { last: v && typeof v.last === 'string' ? v.last : null, drafts };
      return this.state;
    }
    get() { return this.state || { last: null, drafts: {} }; }
    setLast(id) { this.state = { ...this.get(), last: id || null }; this.saveSoon(); }
    setDraft(key, text) {
      const drafts = { ...this.get().drafts };
      if (text && text.trim()) drafts[key] = text; else delete drafts[key];
      this.state = { ...this.get(), drafts };
      this.saveSoon();
    }
    draft(key) { return this.get().drafts[key] || ''; }
    saveSoon() { clearTimeout(this.timer); this.timer = setTimeout(() => this.adapter.write(KEYS.chat, this.get()), 300); }
    async clear() { this.state = { last: null, drafts: {} }; await this.adapter.remove(KEYS.chat); }
  }

  App.core.Storage = { KEYS, LocalStorageAdapter, ProfileRepository, ProgressRepository, ChatStateRepository };
})(window.WispApp);
