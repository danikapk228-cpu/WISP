/* WISP · Core · Assistant
 * Клиент серверного API WISP. Во фронтенде нет ключей и адресов провайдеров: браузер общается только
 * со своим сервером (тот же origin), сервер сам хранит ключи, проверяет тариф, лимиты и владельца диалога.
 *
 * Подключение: <meta name="wisp-assistant-endpoint" content="/api"> в index.html (база API).
 * Пусто или страница открыта как файл (file://) = AI не подключён, и интерфейс честно об этом говорит.
 * Сессия: httpOnly-cookie, которую выставляет сервер (JS её не видит и не хранит).
 * Layer 9: сессия бывает гостевой (устройство) или аккаунта. Клиент больше не создаёт сессию молча:
 *  · bootstrap() только спрашивает сервер «кто я» (GET /session); нет сессии → state = 'signed_out' (экран входа);
 *  · startGuest() — «Продолжить без аккаунта» (POST /session);
 *  · 401 посреди работы = сессия закончилась (выход на другом устройстве, смена пароля, срок): state = 'expired',
 *    сессия забывается, приложение очищает экран и просит войти снова. Новая сессия сама не появляется.
 *
 * Поток ответа: POST → text/event-stream, события start → (delta | tool)* → done | error.
 * Layer 4: событие tool = сервер выполнил действие по просьбе модели (напоминание, задача…). Часовой пояс
 * устройства уходит на сервер, чтобы «завтра в 10:00» означало 10:00 у пользователя. */
(function (App) {
  'use strict';
  const { Profile } = App.core;

  const HEADERS = { 'X-WISP-Client': '1' };
  const TIMEOUT_MS = 20000;               // обычные запросы (не поток)
  const FIRST_EVENT_MS = 60000;           // ожидание начала потока
  function newClientId() {
    const c = typeof globalThis !== 'undefined' ? globalThis.crypto : null;
    if (c && typeof c.randomUUID === 'function') return c.randomUUID();
    return `wisp_${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`.slice(0, 80);
  }

  function resolveEndpoint(raw) {
    if (!raw || typeof raw !== 'string' || !raw.trim()) return null;
    try {
      const url = new URL(raw.trim(), location.href);
      const sameOrigin = url.origin === location.origin;
      // cookie сессии работает только на своём origin, поэтому API принимаем только оттуда
      if (sameOrigin && /^https?:$/.test(url.protocol)) return url.href.replace(/\/+$/, '');
    } catch (e) { /* некорректный адрес = не подключено */ }
    return null;
  }

  /* IANA-пояс устройства (Europe/Moscow). Сервер проверяет его сам. */
  function timezone() {
    /* Layer 13: свой пояс из настроек («Язык и время») важнее пояса устройства */
    const P = App.settings && App.settings.Prefs;
    if (P && P.timezone) return P.timezone();
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) { return 'UTC'; }
  }

  const offline = () => typeof navigator !== 'undefined' && navigator.onLine === false;
  const netError = () => ({ code: offline() ? 'offline' : 'network', message: offline() ? 'Нет подключения к интернету.' : 'Не удалось связаться с сервером.' });

  /* Разбор SSE из fetch-потока */
  async function* readSSE(body) {
    const reader = body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let i;
        while ((i = buf.search(/\r?\n\r?\n/)) >= 0) {
          const block = buf.slice(0, i);
          buf = buf.slice(i + (buf[i] === '\r' ? 4 : 2));
          let event = 'message';
          const data = [];
          for (const line of block.split(/\r?\n/)) {
            if (line.startsWith(':')) continue;
            if (line.startsWith('event:')) event = line.slice(6).trim();
            else if (line.startsWith('data:')) data.push(line.slice(5).replace(/^ /, ''));
          }
          if (!data.length) continue;
          let parsed = null;
          try { parsed = JSON.parse(data.join('\n')); } catch (e) { continue; }
          yield { event, data: parsed };
        }
      }
    } finally {
      try { reader.releaseLock(); } catch (e) { /* уже закрыт */ }
    }
  }

  class AssistantClient {
    constructor({ endpoint }) {
      this.base = resolveEndpoint(endpoint);
      this.session = null;
      this.state = this.base ? 'idle' : 'no_endpoint';      // idle | connecting | ready | server_down | no_endpoint
      this.listeners = new Set();
      this.booting = null;
    }
    get connected() { return !!this.base; }
    get ready() { return this.state === 'ready' && !!this.session; }
    get signedIn() { return !!(this.session && this.session.kind === 'account'); }

    /* Layer 9: сессия потеряна (401). Один раз сообщаем приложению (onAuthLost), дальше запросы просто отказывают. */
    lose(reason) {
      if (!this.session && this.state !== 'ready') return;
      this.session = null;
      this.state = 'expired';
      this.emit();
      if (this.onAuthLost) { try { this.onAuthLost(reason || 'expired'); } catch (e) { /* приложение само разберётся */ } }
    }
    /* Выход: клиент забывает сессию (cookie стирает сервер) */
    signOut() { this.session = null; this.booting = null; this.state = this.base ? 'signed_out' : 'no_endpoint'; this.emit(); }

    /* Контекст для сервера: только то, что нужно для персонализации. Разрешения и служебные поля не уходят.
     * Layer 6: prefs — настройки ответов (длина, оформление, обращение по имени, персонализация). Аватар не уходит. */
    static context(profile) {
      const u = Profile.toServerPayload(profile).user;
      const p = u.preferences || Profile.defaultPreferences();
      return {
        name: u.name,
        interests: u.interests,
        occupation: u.occupation,
        about: u.about,
        personality: Profile.effectivePersonality(profile).id,
        prefs: { length: p.answer_length, style: p.answer_style, use_name: p.use_name, personalize: p.personalize, lang: p.reply_lang, address: p.address },
      };
    }

    subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
    emit() { this.listeners.forEach((fn) => { try { fn(this); } catch (e) { /* подписчик не должен ломать клиента */ } }); }
    setSession(s) { this.session = s; this.state = 'ready'; this.emit(); }
    patchUsage(usage) { if (this.session && usage) { this.session = { ...this.session, usage }; this.emit(); } }

    /* ── Обычный JSON-запрос. Ответ: { ok, status, data } или { ok:false, status, error:{code,message,…} } ── */
    async request(method, path, body, opts) {
      if (!this.base) return { ok: false, status: 0, error: { code: 'not_connected', message: 'AI не подключён.' } };
      const o = opts || {};
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), o.timeout || TIMEOUT_MS);
      try {
        const res = await fetch(this.base + path, {
          method,
          credentials: 'same-origin',
          headers: body !== undefined ? { ...HEADERS, 'Content-Type': 'application/json', Accept: 'application/json' } : { ...HEADERS, Accept: 'application/json' },
          body: body !== undefined ? JSON.stringify(body) : undefined,
          signal: ctrl.signal,
          cache: 'no-store',
        });
        const data = await res.json().catch(() => null);
        // Layer 9: 401 = сессии больше нет. Для /auth/* это обычный ответ («неверный пароль»), а не потеря сессии.
        if (res.status === 401 && !o.noRetry && path !== '/session' && !path.startsWith('/auth/')) this.lose('expired');
        if (!res.ok) return { ok: false, status: res.status, error: (data && data.error) || { code: 'server_error', message: 'Ошибка сервера.' } };
        return { ok: true, status: res.status, data };
      } catch (e) {
        return { ok: false, status: 0, error: netError() };
      } finally {
        clearTimeout(timer);
      }
    }

    /* Кто я на сервере (Layer 9): GET /session. Сессию не создаёт. Повторные вызовы ждут один запрос.
     * Результат: данные сессии или null (state: signed_out — сессии нет; expired — была и закончилась; server_down). */
    bootstrap(force) {
      if (!this.base) { this.state = 'no_endpoint'; this.emit(); return Promise.resolve(null); }
      if (this.booting && !force) return this.booting;
      const had = !!this.session;
      this.state = 'connecting'; this.emit();
      this.booting = this.request('GET', '/session', undefined, { noRetry: true }).then(async (r) => {
        this.booting = null;
        if (r.ok) {
          this.setSession(r.data);
          // часовой пояс устройства (Layer 4): тот же POST /session, что и раньше, но только для существующей сессии
          this.request('POST', '/session', { timezone: timezone() }, { noRetry: true }).then((x) => { if (x.ok && this.session && x.data.user.id === this.session.user.id) this.setSession(x.data); });
          return r.data;
        }
        if (r.status === 401) {
          if (had) this.lose('expired');
          else { this.session = null; this.state = 'signed_out'; this.emit(); }
          return null;
        }
        this.state = 'server_down'; this.lastError = r.error; this.emit();
        return null;
      });
      return this.booting;
    }
    /* «Продолжить без аккаунта»: гостевая сессия устройства (как в Layers 3–8) */
    async startGuest() {
      const r = await this.request('POST', '/session', { timezone: timezone() }, { noRetry: true });
      if (r.ok) this.setSession(r.data);
      return r;
    }
    async refreshSession() {
      const r = await this.request('GET', '/session');
      if (r.ok) this.setSession(r.data);
      return r;
    }

    /* ── Диалоги ── */
    listConversations(offset) { return this.request('GET', `/conversations?offset=${encodeURIComponent(Number.isSafeInteger(offset) && offset >= 0 ? offset : 0)}`); }
    getConversation(id) { return this.request('GET', `/conversations/${encodeURIComponent(id)}`); }
    renameConversation(id, title) { return this.request('PATCH', `/conversations/${encodeURIComponent(id)}`, { title }); }
    setConversationModel(id, model) { return this.request('PATCH', `/conversations/${encodeURIComponent(id)}`, { model }); }
    deleteConversation(id) { return this.request('DELETE', `/conversations/${encodeURIComponent(id)}`); }
    deleteMessage(cid, mid) { return this.request('DELETE', `/conversations/${encodeURIComponent(cid)}/messages/${encodeURIComponent(mid)}`); }

    sendMessage({ conversationId, content, attachments, model, profile, clientId, input }, handlers) {
      return this.stream(`/conversations/${conversationId ? encodeURIComponent(conversationId) : 'new'}/messages`, {
        content, model: model || undefined, profile: AssistantClient.context(profile), timezone: timezone(),
        client_id: clientId || newClientId(),
        input: input === 'voice' ? 'voice' : undefined,
        attachments: (attachments || []).map((a) => ({ data: a.dataUrl, width: a.width, height: a.height })),
      }, handlers);
    }
    getAction(id) {
      return this.request('GET', `/actions/${encodeURIComponent(id)}`);
    }
    actionRecords(refs) {
      return this.repeatableRequest('POST', '/actions/records', { refs: Array.isArray(refs) ? refs : [] });
    }
    confirmAction(id) {
      return this.repeatableRequest('POST', `/actions/${encodeURIComponent(id)}/confirm`, {});
    }
    cancelAction(id) {
      return this.repeatableRequest('POST', `/actions/${encodeURIComponent(id)}/cancel`, {});
    }
    async repeatableRequest(method, path, body) {
      const first = await this.request(method, path, body);
      // Confirm/cancel are idempotent on the server, so retry only ambiguous transport/server failures.
      if (first.ok || (first.status > 0 && first.status < 500)) return first;
      return this.request(method, path, body);
    }
    regenerate({ conversationId, model, profile }, handlers) {
      return this.stream(`/conversations/${encodeURIComponent(conversationId)}/regenerate`, { model: model || undefined, profile: AssistantClient.context(profile), timezone: timezone() }, handlers);
    }
    editAndRegenerate({ conversationId, messageId, content, model, profile }, handlers) {
      return this.stream(`/conversations/${encodeURIComponent(conversationId)}/messages/${encodeURIComponent(messageId)}/edit`, {
        content, model: model || undefined, profile: AssistantClient.context(profile), timezone: timezone(),
      }, handlers);
    }

    /* Потоковый запрос. handlers: { signal, onStart, onDelta, onTool, onDone, onError }.
     * Результат (Promise): { phase } где phase:
     *   done        ответ получен целиком
     *   error       сервер начал ответ, но генерация завершилась ошибкой (данные сохранены на сервере)
     *   rejected    сервер отклонил запрос до начала (лимит, тариф, модель…) — сообщение НЕ сохранено
     *   unsent      запрос не дошёл до сервера (нет сети) — сообщение НЕ сохранено
     *   interrupted связь оборвалась посреди ответа — сообщение пользователя сохранено, ответ частичный
     *   aborted     пользователь сам остановил ответ */
    async stream(path, body, h, retried) {
      const handlers = h || {};
      if (!this.base) return { phase: 'unsent', error: { code: 'not_connected', message: 'AI не подключён.' } };
      if (offline()) return { phase: 'unsent', error: netError() };
      const ctrl = new AbortController();
      const external = handlers.signal;
      const onAbort = () => ctrl.abort();
      if (external) { if (external.aborted) ctrl.abort(); else external.addEventListener('abort', onAbort, { once: true }); }
      let started = false;
      let accepted = false;
      let timedOut = false;
      let firstTimer = setTimeout(() => { timedOut = true; ctrl.abort(); }, FIRST_EVENT_MS);
      const clearFirst = () => { clearTimeout(firstTimer); firstTimer = 0; };
      try {
        let res;
        try {
          res = await fetch(this.base + path, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { ...HEADERS, 'Content-Type': 'application/json', Accept: 'text/event-stream' },
            body: JSON.stringify(body),
            signal: ctrl.signal,
            cache: 'no-store',
          });
        } catch (e) {
          if (external && external.aborted) return { phase: 'aborted' };
          return { phase: 'unsent', error: timedOut ? { code: 'timeout', message: 'Сервер слишком долго не отвечал.' } : netError() };
        }
        const type = res.headers.get('content-type') || '';
        accepted = res.ok && type.includes('text/event-stream');
        if (!type.includes('text/event-stream')) {
          clearFirst();
          const data = await res.json().catch(() => null);
          if (res.status === 401) this.lose('expired');           // Layer 9: сессия закончилась — не пересоздаём
          const error = (data && data.error) || { code: res.ok ? 'bad_response' : 'server_error', message: 'Сервер ответил ошибкой.' };
          return { phase: 'rejected', status: res.status, error };
        }
        let final = null;
        try {
          for await (const ev of readSSE(res.body)) {
            if (ev.event === 'start') { started = true; clearFirst(); handlers.onStart && handlers.onStart(ev.data); }
            else if (ev.event === 'delta') { handlers.onDelta && handlers.onDelta(ev.data.text || ''); }
            else if (ev.event === 'tool') { handlers.onTool && handlers.onTool(ev.data.action || {}); }
            else if (ev.event === 'done') { final = { phase: 'done', data: ev.data }; if (ev.data.usage) this.patchUsage(ev.data.usage); handlers.onDone && handlers.onDone(ev.data); }
            else if (ev.event === 'error') { final = { phase: 'error', data: ev.data, error: { code: ev.data.code, message: ev.data.message, retryable: ev.data.retryable } }; if (ev.data.usage) this.patchUsage(ev.data.usage); handlers.onError && handlers.onError(ev.data); }
          }
        } catch (e) {
          if (external && external.aborted && !(accepted && !started)) return { phase: 'aborted', started, accepted };
          return started || accepted
            ? { phase: 'interrupted', started, accepted, error: started
              ? { code: 'connection_lost', message: 'Связь прервалась.' }
              : { code: 'request_ambiguous', message: 'Сообщение могло сохраниться. Проверь историю перед повторной отправкой.' } }
            : { phase: 'unsent', error: netError() };
        }
        if (final) return final;
        if (external && external.aborted && !(accepted && !started)) return { phase: 'aborted', started, accepted };
        return started || accepted
          ? { phase: 'interrupted', started, accepted, error: started
            ? { code: 'connection_lost', message: 'Связь прервалась.' }
            : { code: 'request_ambiguous', message: 'Сообщение могло сохраниться. Проверь историю перед повторной отправкой.' } }
          : { phase: 'unsent', error: netError() };
      } finally {
        clearFirst();
        if (external) external.removeEventListener('abort', onAbort);
      }
    }
  }

  function fromDocument() {
    const meta = document.querySelector('meta[name="wisp-assistant-endpoint"]');
    return new AssistantClient({ endpoint: meta ? meta.getAttribute('content') : null });
  }

  App.core.Assistant = { AssistantClient, fromDocument, resolveEndpoint, timezone };
})(window.WispApp);
