/* WISP · Core · Preferences schema (Layer 13)
 * Единственное описание настроек пользователя для клиента И сервера: значения по умолчанию, допустимые варианты,
 * диапазоны, нормализация. Раньше схема повторялась в src/core/profile.js и server/account/profile.js и могла
 * разойтись; теперь оба подключают этот файл (браузер — тегом <script>, сервер — require()).
 *
 * Правила:
 *  · неизвестные ключи отбрасываются, неверные значения заменяются значением по умолчанию — настройка
 *    не может «сломать» интерфейс или попасть в базу мусором;
 *  · значения по умолчанию = поведение WISP 12 (стандартная тёмная тема, все блоки на месте), поэтому старые
 *    профили выглядят ровно так же, как раньше;
 *  · типы: enum (values), bool, str (длина), num (диапазон + шаг), color (#rrggbb или ''), order (перестановка),
 *    set (подмножество), tz (IANA-пояс или '' = как на устройстве), themes (сохранённые темы). */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.WispApp = root.WispApp || { core: {} }; root.WispApp.core = root.WispApp.core || {}; root.WispApp.core.PrefSchema = api; }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;
  const HEX = /^#[0-9a-f]{6}$/;

  /* Каталоги, на которые ссылаются настройки (id не переводятся: это ключи, а не подписи) */
  const TABS = ['home', 'chat', 'memory', 'tools'];
  const TABS_REQUIRED = ['home', 'chat'];
  const HOME_BLOCKS = ['greeting', 'actions', 'composer'];
  const HOME_HIDEABLE = ['greeting', 'subtitle', 'actions', 'suggestions', 'plan_badge'];
  const QUICK_ACTIONS = ['reminder', 'note', 'task', 'image', 'event', 'new_chat', 'memory', 'history'];
  const QUICK_MAX = 4;
  const THEME_PRESETS = ['dark', 'black', 'midnight', 'light', 'system', 'custom'];
  const THEMES_MAX = 12;

  const SCHEMA = {
    /* ── Layer 6 ── */
    theme: { def: 'dark', values: THEME_PRESETS },
    motion: { def: 'system', values: ['system', 'reduce'] },
    density: { def: 'standard', values: ['compact', 'standard', 'comfortable'] },
    answer_length: { def: 'balanced', values: ['short', 'balanced', 'detailed'] },
    answer_style: { def: 'auto', values: ['auto', 'plain', 'structured'] },
    use_name: { def: true, bool: true },
    personalize: { def: true, bool: true },
    notify_reminders: { def: true, bool: true },
    /* ── Layer 7 · голос ── */
    voice_replies: { def: true, bool: true },
    voice_autoplay: { def: false, bool: true },
    voice_rate: { def: 'normal', values: ['slow', 'normal', 'fast', 'faster'] },
    voice_id: { def: '', str: 160 },

    /* ── Layer 13 · Оформление ── */
    theme_custom: { def: '', str: 16 },                    // id сохранённой темы при theme = 'custom'
    themes: { def: [], themes: true },                     // сохранённые темы пользователя
    accent: { def: '', color: true },                      // свой акцент поверх готовой темы ('' = цвет темы)
    glass: { def: 50, num: [0, 100], step: 5 },            // прозрачность панелей: 0 — плотнее, 100 — прозрачнее
    radius: { def: 100, num: [20, 150], step: 5 },         // скругления, % от стандартных
    ui_scale: { def: 100, num: [90, 125], step: 5 },       // размер элементов, %

    /* ── Анимации и эффекты ── */
    fx_level: { def: 'full', values: ['full', 'soft', 'off'] },
    fx_speed: { def: 'normal', values: ['fast', 'normal', 'slow'] },
    fx_appear: { def: 'rise', values: ['rise', 'fade', 'scale', 'none'] },
    fx_glow: { def: 100, num: [0, 150], step: 10 },
    fx_blur: { def: 100, num: [0, 150], step: 10 },

    /* ── Звук и отклик ── */
    sound_on: { def: false, bool: true },
    sound_volume: { def: 60, num: [0, 100], step: 5 },
    sound_ui: { def: true, bool: true },
    haptics: { def: true, bool: true },
    mascot_react: { def: true, bool: true },

    /* ── Интерфейс ── */
    nav_order: { def: TABS.slice(), order: TABS },
    nav_hidden: { def: [], set: TABS.filter((t) => !TABS_REQUIRED.includes(t)) },
    nav_labels: { def: true, bool: true },
    nav_position: { def: 'bottom', values: ['bottom', 'side'] },
    home_blocks: { def: HOME_BLOCKS.slice(), order: HOME_BLOCKS },
    home_hidden: { def: [], set: HOME_HIDEABLE },
    quick_actions: { def: ['reminder', 'note', 'task', 'image'], set: QUICK_ACTIONS, max: QUICK_MAX },
    start_tab: { def: 'home', values: ['home', 'chat', 'memory', 'tools', 'last'] },
    history_view: { def: 'flat', values: ['flat', 'grouped'] },

    /* ── Чат ── */
    chat_send: { def: 'auto', values: ['auto', 'enter', 'mod'] },
    chat_layout: { def: 'airy', values: ['airy', 'compact'] },
    chat_width: { def: 'normal', values: ['normal', 'wide'] },
    chat_text: { def: 'm', values: ['s', 'm', 'l', 'xl'] },
    chat_time: { def: 'auto', values: ['auto', 'always', 'never'] },
    chat_scroll: { def: 'smart', values: ['smart', 'always', 'off'] },
    chat_markdown: { def: 'full', values: ['full', 'plain'] },
    chat_code_hl: { def: true, bool: true },
    chat_restore: { def: true, bool: true },
    chat_drafts: { def: true, bool: true },
    chat_home_send: { def: 'new', values: ['new', 'continue'] },
    chat_starters: { def: true, bool: true },

    /* ── Язык и время ── */
    reply_lang: { def: 'auto', values: ['auto', 'ru', 'en'] },
    address: { def: 'ty', values: ['ty', 'vy'] },
    timezone: { def: '', tz: true },
  };

  const clone = (v) => (Array.isArray(v) ? v.slice() : v);
  function defaults() { const out = {}; for (const [k, d] of Object.entries(SCHEMA)) out[k] = clone(d.def); return out; }

  function cleanStr(v, max) { return typeof v === 'string' ? v.replace(CONTROL, '').replace(/\s+/g, ' ').trim().slice(0, max).trim() : ''; }
  function color(v) { if (typeof v !== 'string') return ''; const s = v.trim().toLowerCase(); return HEX.test(s) ? s : ''; }

  let tzCache = null;
  function validTz(v) {
    if (typeof v !== 'string' || !v || v.length > 64 || !/^[A-Za-z0-9_+\-/]+$/.test(v)) return false;
    tzCache = tzCache || new Map();
    if (tzCache.has(v)) return tzCache.get(v);
    let ok = false;
    try { new Intl.DateTimeFormat('en-US', { timeZone: v }); ok = true; } catch (e) { ok = false; }
    if (tzCache.size < 500) tzCache.set(v, ok);
    return ok;
  }

  /* Сохранённая тема: фон, основной, вторичный и акцентный цвета. Старые tint/accent темы читаются без потерь. */
  function sanitizeTheme(t) {
    if (!t || typeof t !== 'object' || Array.isArray(t)) return null;
    const id = typeof t.id === 'string' && /^[a-z0-9]{4,16}$/.test(t.id) ? t.id : null;
    const bg = color(t.bg), primary = color(t.primary) || color(t.accent);
    const secondary = color(t.secondary) || color(t.tint) || primary;
    const accent = color(t.accent) || primary;
    if (!id || !bg || !primary || !accent) return null;
    return { id, name: cleanStr(t.name, 24) || 'Моя тема', bg, primary, secondary, accent, glow: color(t.glow) };
  }
  function sanitizeThemes(v) {
    if (!Array.isArray(v)) return [];
    const out = [], seen = new Set();
    for (const t of v) {
      const s = sanitizeTheme(t);
      if (!s || seen.has(s.id)) continue;
      seen.add(s.id); out.push(s);
      if (out.length >= THEMES_MAX) break;
    }
    return out;
  }

  function sanitizeOne(d, v) {
    if (d.bool) return typeof v === 'boolean' ? v : d.def;
    if (d.str) return typeof v === 'string' ? v.replace(CONTROL, '').trim().slice(0, d.str) : d.def;
    if (d.num) {
      const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;
      if (!Number.isFinite(n)) return d.def;
      const step = d.step || 1;
      const r = Math.round(Math.min(d.num[1], Math.max(d.num[0], n)) / step) * step;
      return Math.min(d.num[1], Math.max(d.num[0], r));
    }
    if (d.color) return color(v);
    if (d.tz) return validTz(v) ? v : '';
    if (d.themes) return sanitizeThemes(v);
    if (d.order) {
      const list = Array.isArray(v) ? v.filter((x, i) => d.order.includes(x) && v.indexOf(x) === i) : [];
      d.def.forEach((x) => { if (!list.includes(x)) list.push(x); });   // новые элементы каталога не теряются
      return list;
    }
    if (d.set) {
      const list = Array.isArray(v) ? v.filter((x, i) => d.set.includes(x) && v.indexOf(x) === i) : clone(d.def);
      return d.max ? list.slice(0, d.max) : list;
    }
    return d.values.includes(v) ? v : d.def;
  }

  function sanitize(raw) {
    const p = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    const out = {};
    for (const [k, d] of Object.entries(SCHEMA)) out[k] = sanitizeOne(d, p[k]);
    /* согласованность: тема «Своя» без существующей сохранённой темы = стандартная тёмная */
    if (out.theme === 'custom' && !out.themes.some((t) => t.id === out.theme_custom)) { out.theme = 'dark'; out.theme_custom = ''; }
    if (out.theme !== 'custom') out.theme_custom = out.theme_custom && out.themes.some((t) => t.id === out.theme_custom) ? out.theme_custom : '';
    return out;
  }

  /* Ключи по разделам: для сброса раздела и для экспорта настроек */
  const GROUPS = {
    appearance: ['theme', 'theme_custom', 'accent', 'glass', 'radius', 'ui_scale'],
    effects: ['motion', 'fx_level', 'fx_speed', 'fx_appear', 'fx_glow', 'fx_blur'],
    sound: ['sound_on', 'sound_volume', 'sound_ui', 'haptics', 'mascot_react'],
    interface: ['nav_order', 'nav_hidden', 'nav_labels', 'nav_position', 'home_blocks', 'home_hidden', 'quick_actions', 'start_tab', 'history_view', 'density'],
    chat: ['chat_send', 'chat_layout', 'chat_width', 'chat_text', 'chat_time', 'chat_scroll', 'chat_markdown', 'chat_code_hl', 'chat_restore', 'chat_drafts', 'chat_home_send', 'chat_starters'],
    behavior: ['answer_length', 'answer_style', 'use_name', 'personalize'],
    region: ['reply_lang', 'address', 'timezone'],
    notifications: ['notify_reminders'],
    voice: ['voice_replies', 'voice_autoplay', 'voice_rate', 'voice_id'],
  };
  function groupDefaults(name) {
    const d = defaults(), out = {};
    (GROUPS[name] || []).forEach((k) => { out[k] = d[k]; });
    return out;
  }

  return {
    SCHEMA, GROUPS, TABS, TABS_REQUIRED, HOME_BLOCKS, HOME_HIDEABLE, QUICK_ACTIONS, QUICK_MAX, THEME_PRESETS, THEMES_MAX,
    defaults, sanitize, sanitizeTheme, groupDefaults, validTz, color,
  };
});
