/* WISP · Core · Tools API (Layer 4)
 * Клиент инструментов поверх того же AssistantClient: тот же сервер, та же httpOnly-сессия, те же заголовки.
 * Данные хранятся только на сервере (SQLite) и привязаны к пользователю; здесь нет второй копии данных.
 * bus: кто угодно (экран Tools, чат после действия AI, напоминания) сообщает «изменилось kind»,
 * а подписчики (списки, счётчики, планировщик уведомлений) перечитывают свои данные. */
(function (App) {
  'use strict';
  const { timezone } = App.core.Assistant;

  function ToolsAPI(assistant) {
    const listeners = new Set();
    const enc = encodeURIComponent;
    const tzq = () => `tz=${enc(timezone())}`;

    function emit(kind, detail) { listeners.forEach((fn) => { try { fn({ kind, ...(detail || {}) }); } catch (e) { /* подписчик не должен ломать остальных */ } }); }
    async function call(method, path, body, kind) {
      const r = await assistant.request(method, path, body);
      if (r.ok && kind && method !== 'GET') emit(kind);
      return r;
    }

    return {
      get available() { return assistant.connected; },
      get ready() { return assistant.ready; },
      timezone,
      subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
      /* изменения, сделанные не через этот клиент (например, AI в чате) */
      notify(kind, detail) { emit(kind, { source: 'external', ...(detail || {}) }); },

      summary: () => call('GET', `/tools/summary?${tzq()}`),
      agenda: (date) => call('GET', `/agenda?date=${enc(date)}&${tzq()}`),

      notes: {
        list: (q) => call('GET', `/notes${q ? `?q=${enc(q)}` : ''}`),
        get: (id) => call('GET', `/notes/${enc(id)}`),
        create: (b) => call('POST', '/notes', b, 'notes'),
        update: (id, b) => call('PATCH', `/notes/${enc(id)}`, b, 'notes'),
        remove: (id) => call('DELETE', `/notes/${enc(id)}`, undefined, 'notes'),
      },
      tasks: {
        list: (filter) => call('GET', `/tasks?filter=${enc(filter || 'all')}`),
        get: (id) => call('GET', `/tasks/${enc(id)}`),
        create: (b) => call('POST', '/tasks', b, 'tasks'),
        update: (id, b) => call('PATCH', `/tasks/${enc(id)}`, b, 'tasks'),
        remove: (id) => call('DELETE', `/tasks/${enc(id)}`, undefined, 'tasks'),
      },
      reminders: {
        list: (status) => call('GET', `/reminders?status=${enc(status || 'all')}`),
        get: (id) => call('GET', `/reminders/${enc(id)}`),
        create: (b) => call('POST', '/reminders', { ...b, timezone: timezone() }, 'reminders'),
        update: (id, b) => call('PATCH', `/reminders/${enc(id)}`, b.date || b.time
          ? { ...b, timezone: Object.prototype.hasOwnProperty.call(b, 'timezone') ? b.timezone : timezone() }
          : b, 'reminders'),
        notified: (id) => call('POST', `/reminders/${enc(id)}/notified`, {}),
        remove: (id) => call('DELETE', `/reminders/${enc(id)}`, undefined, 'reminders'),
      },
      events: {
        list: (date) => call('GET', `/events?date=${enc(date)}&${tzq()}`),
        get: (id) => call('GET', `/events/${enc(id)}`),
        create: (b) => call('POST', `/events?${tzq()}`, b, 'events'),
        update: (id, b) => call('PATCH', `/events/${enc(id)}?${tzq()}`, b, 'events'),
        remove: (id) => call('DELETE', `/events/${enc(id)}`, undefined, 'events'),
      },
    };
  }

  App.core.ToolsAPI = ToolsAPI;
})(window.WispApp);
