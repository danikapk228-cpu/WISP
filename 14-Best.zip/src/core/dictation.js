/* WISP · Core · Dictation
 * Голосовой ввод через Web Speech API (распознавание речи браузером).
 * Слушает только после нажатия, останавливается сам по паузе или по повторному нажатию.
 * Если API нет или доступ запрещён, возвращается честная причина. */
(function (App) {
  'use strict';
  const { Capabilities } = App.core;

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition || null;
  const secure = window.isSecureContext !== false;
  const mic = Capabilities.get('microphone');

  const ERRORS = {
    'not-allowed': mic.deniedHint,
    'service-not-allowed': 'Распознавание речи отключено в настройках устройства или браузера.',
    'audio-capture': mic.unavailableHint,
    'no-speech': 'Не расслышал. Нажми на микрофон и попробуй ещё раз.',
    network: 'Нет связи с сервисом распознавания речи. Проверь интернет.',
    'language-not-supported': 'Браузер не распознаёт русскую речь.',
  };

  function support() {
    if (!secure) return { ok: false, reason: 'Голосовой ввод работает только по защищённому соединению (https).' };
    if (!SR) return { ok: false, reason: 'Этот браузер не поддерживает голосовой ввод.' };
    return { ok: true };
  }

  /* Доступность с учётом разрешения микрофона: unsupported | denied | ready */
  async function availability(savedMic) {
    const s = support();
    if (!s.ok) return { state: 'unsupported', reason: s.reason };
    const m = await Capabilities.resolveStatus(mic, savedMic);
    if (m.status === 'denied') return { state: 'denied', reason: mic.deniedHint };
    if (m.status === 'unsupported') return { state: 'unsupported', reason: m.reason };
    return { state: 'ready' };
  }

  /* onText(finalText, interimText) · onState('listening' | 'idle') · onError(code, message) */
  function create({ lang, onText, onState, onError }) {
    let rec = null, finalText = '', active = false;
    function stop() { if (rec) { try { rec.stop(); } catch (e) {} } }
    function start() {
      if (active || !support().ok) return false;
      rec = new SR();
      rec.lang = lang || 'ru-RU';
      rec.interimResults = true;
      rec.continuous = false;
      rec.maxAlternatives = 1;
      finalText = '';
      rec.onstart = () => { active = true; onState && onState('listening'); };
      rec.onresult = (e) => {
        let interim = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) finalText += r[0].transcript; else interim += r[0].transcript;
        }
        onText && onText(finalText, interim);
      };
      rec.onerror = (e) => {
        const code = (e && e.error) || 'unknown';
        if (code === 'aborted') return;
        onError && onError(code, ERRORS[code] || 'Не получилось распознать речь. Попробуй ещё раз.');
      };
      rec.onend = () => { active = false; rec = null; onState && onState('idle'); };
      try { rec.start(); return true; } catch (e) { rec = null; onError && onError('start', 'Не получилось включить микрофон.'); return false; }
    }
    return { start, stop, get active() { return active; } };
  }

  App.core.Dictation = { support, availability, create };
})(window.WispApp);
