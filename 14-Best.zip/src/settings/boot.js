/* WISP · Layer 6 / 13 · Boot appearance
 * Подключается в <head> до стилей приложения: ставит тему, палитру, множители и атрибуты вёрстки из сохранённого
 * профиля ещё до первой отрисовки, чтобы тема не мигала, а интерфейс не «прыгал».
 * Профиль: последний активный (аккаунт или гость, ключ wisp:active-profile:v1), иначе гостевой wisp:profile:v1.
 * Ничего не пишет. Полная логика (подписка на изменения, системная тема) — в src/settings/preferences.js. */
(function () {
  'use strict';
  var p = {};
  try {
    var key = window.localStorage.getItem('wisp:active-profile:v1') || 'wisp:profile:v1';
    if (!/^wisp:(?:profile:v1|account:[A-Za-z0-9_-]+:wisp:profile:v1)$/.test(key)) key = 'wisp:profile:v1';
    var raw = window.localStorage.getItem(key);
    p = (raw && JSON.parse(raw).user.preferences) || {};
    /* Схема уже загружена? Тогда нормализуем так же, как приложение (иначе движок сам отбросит мусор). */
    var S = window.WispApp && window.WispApp.core && window.WispApp.core.PrefSchema;
    if (S) p = S.sanitize(p);
  } catch (e) { p = {}; }
  if (!p || typeof p !== 'object') p = {};
  var mq = function (q) { try { return window.matchMedia(q).matches; } catch (e) { return false; } };
  var sys = mq('(prefers-color-scheme: light)') ? 'light' : 'dark';
  var html = document.documentElement;
  if (window.WispThemeEngine) {
    window.WispThemeEngine.applyAttrs(p);
    window.WispThemeEngine.apply(p, sys);
    return;
  }
  var theme = p.theme === 'system' ? sys : (p.theme === 'light' ? 'light' : 'dark');
  if (p.density === 'compact') html.setAttribute('data-density', 'compact');
  if (p.motion === 'reduce') html.setAttribute('data-motion', 'reduce');
  html.setAttribute('data-theme', theme);
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme === 'light' ? '#f3f2f9' : '#050508');
  var cs = document.querySelector('meta[name="color-scheme"]');
  if (cs) cs.setAttribute('content', theme);
})();
