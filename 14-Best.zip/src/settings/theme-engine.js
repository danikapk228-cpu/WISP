/* WISP · Layer 13 · Theme engine
 * Runs both in the head bootstrap (before CSS is painted) and in the app runtime.
 * The default dark theme deliberately leaves the original design tokens untouched:
 * with all defaults not a single inline variable is written.
 *
 * Что делает:
 *  · палитра: пресеты Dark / Black / Midnight / Light / системная / своя тема (фон + 4 цветовые роли);
 *  · режим своей темы (светлый/тёмный) выбирается по контрасту текста с фоном, а не по порогу яркости;
 *  · защита контраста: основной цвет (им пишутся ссылки и акцентный текст) тянется до 4.5:1 к фону,
 *    акцент (рамки, фокус) — до 3:1. Исходный цвет темы не меняется, меняется только то, что рисуется;
 *  · множители, не зависящие от палитры: скругления (--wisp-rk), размытие (--wisp-bk),
 *    скорость анимаций (--wisp-tk), размер интерфейса (--wisp-ui); прозрачность и свечение работают и в Dark. */
(function (root) {
  'use strict';

  const PRESETS = {
    black:    { bg: '#000000', primary: '#c3bcff', secondary: '#bdb6ff', accent: '#c8c1ff', glow: '#a59bff' },
    midnight: { bg: '#080b1c', primary: '#c3bcff', secondary: '#bdb6ff', accent: '#c8c1ff', glow: '#a59bff' },
    light:    { bg: '#f3f2f9', primary: '#5a4bd4', secondary: '#6252e0', accent: '#5a4bd4', glow: '#6c5ceb' },
  };
  const DEFAULT_DARK = {
    bg: '#050508', primary: '#c3bcff', secondary: '#bdb6ff', accent: '#c8c1ff', glow: '#a59bff',
  };
  const INK_DARK = '#17152b';      // текст светлых тем
  const INK_LIGHT = '#f4f3ff';     // текст тёмных тем
  const MIN_PRIMARY = 4.5;
  const MIN_ACCENT = 3;
  const SPEED = { fast: 0.65, normal: 1, slow: 1.5 };
  const PALETTE_VARS = [
    '--wisp-bg', '--wisp-ink', '--wisp-ink-2', '--wisp-ink-3', '--wisp-on-ink',
    '--wisp-lav', '--wisp-lav-soft', '--wisp-lav-line', '--wisp-lav-glow',
    '--wisp-glass', '--wisp-glass-2', '--wisp-glass-strong', '--wisp-glass-line',
    '--wisp-glass-hi', '--wisp-shadow',
    '--wisp-theme-primary-rgb', '--wisp-theme-secondary-rgb',
    '--wisp-theme-accent-rgb', '--wisp-theme-glow-rgb',
  ];
  const SCALE_VARS = ['--wisp-rk', '--wisp-bk', '--wisp-tk', '--wisp-ui'];

  function validHex(v) { return typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : ''; }
  function channels(hex) {
    const c = validHex(hex);
    return c ? [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)] : null;
  }
  const toHex = (c) => '#' + c.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
  function rgbText(hex) { const c = channels(hex); return c ? c.join(', ') : '195, 188, 255'; }
  function rgba(hex, alpha) {
    const c = channels(hex) || [195, 188, 255];
    return `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${Math.max(0, Math.min(1, alpha)).toFixed(3)})`;
  }
  function luminance(hex) {
    const c = channels(hex) || [5, 5, 8];
    const lin = c.map((v) => {
      const n = v / 255;
      return n <= 0.04045 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2];
  }
  function contrast(a, b) {
    const x = luminance(a), y = luminance(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  }
  /* Светлый ли фон: какой текст читается на нём лучше — тёмный или светлый */
  function isLightBg(bg) { return contrast(bg, INK_DARK) > contrast(bg, INK_LIGHT); }
  /* Подтянуть цвет до нужного контраста с фоном: смешиваем с белым (на тёмном фоне) или с чёрным (на светлом),
   * минимальным шагом, чтобы оттенок остался узнаваемым. */
  function ensureContrast(hex, bg, min) {
    const c = channels(hex);
    if (!c) return validHex(hex);
    if (contrast(hex, bg) >= min) return validHex(hex);
    const target = isLightBg(bg) ? [0, 0, 0] : [255, 255, 255];
    let lo = 0, hi = 1, best = toHex(target);
    for (let i = 0; i < 18; i++) {
      const t = (lo + hi) / 2;
      const mixed = toHex(c.map((v, k) => v + (target[k] - v) * t));
      if (contrast(mixed, bg) >= min) { best = mixed; hi = t; } else lo = t;
    }
    return best;
  }
  const number = (v, fallback, min, max) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
  };

  function resolvePalette(prefs, systemTheme) {
    const p = prefs && typeof prefs === 'object' ? prefs : {};
    let preset = p.theme;
    let custom = null;
    if (preset === 'system') preset = systemTheme === 'light' ? 'light' : 'dark';
    if (preset === 'custom') {
      custom = Array.isArray(p.themes) ? p.themes.find((t) => t && t.id === p.theme_custom) : null;
      if (!custom) preset = 'dark';
    }
    if (!['dark', 'black', 'midnight', 'light', 'custom'].includes(preset)) preset = 'dark';
    const glass = number(p.glass, 50, 0, 100);
    const glowStrength = number(p.fx_glow, 100, 0, 150) / 100;
    /* Dark + свой акцент / прозрачность / свечение = та же тёмная палитра, но через движок */
    const tunedDark = preset === 'dark' && (!!validHex(p.accent) || glass !== 50 || glowStrength !== 1);
    const base = custom ? {
      bg: validHex(custom.bg) || DEFAULT_DARK.bg,
      primary: validHex(custom.primary) || validHex(custom.accent) || DEFAULT_DARK.primary,
      secondary: validHex(custom.secondary) || validHex(custom.tint) || validHex(custom.primary) || DEFAULT_DARK.secondary,
      accent: validHex(custom.accent) || validHex(custom.primary) || DEFAULT_DARK.accent,
      glow: validHex(custom.glow) || validHex(custom.accent) || validHex(custom.primary) || DEFAULT_DARK.glow,
    } : (PRESETS[preset] || DEFAULT_DARK);
    const bg = validHex(base.bg) || DEFAULT_DARK.bg;
    const light = preset === 'light' || (preset === 'custom' && isLightBg(bg));
    const userAccent = validHex(p.accent);
    const rawPrimary = userAccent || base.primary;
    const rawAccent = userAccent || base.accent;
    const primary = ensureContrast(rawPrimary, bg, MIN_PRIMARY);
    const accent = ensureContrast(rawAccent, bg, MIN_ACCENT);
    const active = preset !== 'dark' || tunedDark;
    return {
      preset: active ? (preset === 'dark' ? 'custom' : preset) : 'dark',
      source: preset,
      mode: light ? 'light' : 'dark',
      active,
      light,
      bg,
      primary,
      secondary: userAccent || base.secondary,
      accent,
      glow: userAccent || base.glow,
      adjusted: { primary: primary !== validHex(rawPrimary), accent: accent !== validHex(rawAccent) },
      contrast: { text: contrast(bg, light ? INK_DARK : INK_LIGHT), primary: contrast(primary, bg), accent: contrast(accent, bg) },
      glass,
      glowStrength,
    };
  }

  function scales(prefs) {
    const p = prefs && typeof prefs === 'object' ? prefs : {};
    return {
      rk: number(p.radius, 100, 20, 150) / 100,
      bk: number(p.fx_blur, 100, 0, 150) / 100,
      tk: SPEED[p.fx_speed] || 1,
      ui: number(p.ui_scale, 100, 90, 125) / 100,
    };
  }

  function setVar(style, key, value) { style.setProperty(key, value); }
  function clearPalette(style) {
    PALETTE_VARS.forEach((key) => style.removeProperty(key));
    for (let i = 0; i <= 100; i++) style.removeProperty(`--wisp-theme-glow-a${String(i).padStart(3, '0')}`);
  }
  const fmt = (n) => String(Math.round(n * 1000) / 1000);

  function apply(prefs, systemTheme, doc) {
    const d = doc || root.document;
    if (!d || !d.documentElement) return resolvePalette(prefs, systemTheme);
    const html = d.documentElement;
    const style = html.style;
    const palette = resolvePalette(prefs, systemTheme);
    html.setAttribute('data-theme', palette.mode);
    html.setAttribute('data-theme-preset', palette.preset);

    if (!palette.active) {
      clearPalette(style);
    } else {
      const p = palette;
      const surface = p.light ? '#ffffff' : '#f0eeff';
      const line = p.light ? '#26205c' : '#e6e2ff';
      const g = p.glass;
      /* при значении 50 формулы дают ровно исходные токены Dark и Light */
      const glass = p.light ? 0.86 - g * 0.0044 : 0.07 - g * 0.0005;
      const glass2 = p.light ? 1 - g * 0.0028 : 0.105 - g * 0.0006;
      const strong = p.light ? 1 - g * 0.0028 : 0.80 - g * 0.0036;
      const glowAlpha = (p.light ? 0.26 : 0.40) * p.glowStrength;

      setVar(style, '--wisp-bg', p.bg);
      setVar(style, '--wisp-ink', p.light ? INK_DARK : INK_LIGHT);
      setVar(style, '--wisp-ink-2', p.light ? 'rgba(23, 21, 43, .70)' : 'rgba(232, 229, 255, .66)');
      setVar(style, '--wisp-ink-3', p.light ? 'rgba(23, 21, 43, .54)' : 'rgba(232, 229, 255, .44)');
      setVar(style, '--wisp-on-ink', p.light ? '#f8f7ff' : '#0b0a14');
      setVar(style, '--wisp-lav', p.primary);
      setVar(style, '--wisp-lav-soft', rgba(p.secondary, p.light ? 0.11 : 0.12));
      setVar(style, '--wisp-lav-line', rgba(p.accent, p.light ? 0.46 : 0.52));
      setVar(style, '--wisp-lav-glow', rgba(p.glow, glowAlpha));
      setVar(style, '--wisp-glass', rgba(surface, glass));
      setVar(style, '--wisp-glass-2', rgba(surface, glass2));
      setVar(style, '--wisp-glass-strong', rgba(p.light ? '#fcfbff' : '#161522', strong));
      setVar(style, '--wisp-glass-line', rgba(line, 0.10));
      setVar(style, '--wisp-glass-hi', `inset 0 1px 0 ${rgba('#ffffff', p.light ? 0.75 : 0.06)}`);
      setVar(style, '--wisp-shadow', p.light
        ? '0 1px 2px rgba(38, 32, 92, .06), 0 14px 34px -16px rgba(38, 32, 92, .20)'
        : '0 1px 2px rgba(0, 0, 0, .45), 0 14px 34px -14px rgba(0, 0, 0, .7)');
      setVar(style, '--wisp-theme-primary-rgb', rgbText(p.primary));
      setVar(style, '--wisp-theme-secondary-rgb', rgbText(p.secondary));
      setVar(style, '--wisp-theme-accent-rgb', rgbText(p.accent));
      setVar(style, '--wisp-theme-glow-rgb', rgbText(p.glow));
      for (let i = 0; i <= 100; i++) {
        const scaled = Math.min(1, i / 100 * p.glowStrength);
        setVar(style, `--wisp-theme-glow-a${String(i).padStart(3, '0')}`, scaled.toFixed(3));
      }
    }

    /* множители: пишутся только когда отличаются от стандарта */
    const s = scales(prefs);
    const want = { '--wisp-rk': s.rk, '--wisp-bk': s.bk, '--wisp-tk': s.tk, '--wisp-ui': s.ui };
    SCALE_VARS.forEach((k) => { if (want[k] !== 1) setVar(style, k, fmt(want[k])); else style.removeProperty(k); });

    const themeColor = d.querySelector('meta[name="theme-color"]');
    if (themeColor) themeColor.setAttribute('content', palette.bg);
    const scheme = d.querySelector('meta[name="color-scheme"]');
    if (scheme) scheme.setAttribute('content', palette.mode);
    return palette;
  }

  /* Атрибуты <html>, от которых зависит вёрстка: ставятся до первой отрисовки (boot.js) и при каждом изменении.
   * Значение по умолчанию = атрибута нет, поэтому профиль WISP 12 даёт ровно ту же разметку. */
  const ATTRS = {
    'data-density': (p) => (p.density === 'compact' || p.density === 'comfortable' ? p.density : null),
    'data-motion': (p) => (p.motion === 'reduce' || p.fx_level === 'off' ? 'reduce' : null),
    'data-fx': (p) => (p.fx_level === 'soft' || p.fx_level === 'off' ? p.fx_level : null),
    'data-appear': (p) => (['fade', 'scale', 'none'].includes(p.fx_appear) ? p.fx_appear : null),
    'data-nav': (p) => (p.nav_position === 'side' ? 'side' : null),
    'data-nav-labels': (p) => (p.nav_labels === false ? 'off' : null),
    'data-chat-layout': (p) => (p.chat_layout === 'compact' ? 'compact' : null),
    'data-chat-width': (p) => (p.chat_width === 'wide' ? 'wide' : null),
    'data-chat-text': (p) => (['s', 'l', 'xl'].includes(p.chat_text) ? p.chat_text : null),
  };
  function applyAttrs(prefs, doc) {
    const d = doc || root.document;
    if (!d || !d.documentElement) return;
    const p = prefs && typeof prefs === 'object' ? prefs : {};
    const html = d.documentElement;
    Object.keys(ATTRS).forEach((k) => {
      const v = ATTRS[k](p);
      if (v == null) { if (html.removeAttribute) html.removeAttribute(k); } else html.setAttribute(k, v);
    });
  }

  root.WispThemeEngine = { PRESETS, DEFAULT_DARK, resolvePalette, apply, applyAttrs, scales, luminance, contrast, ensureContrast, isLightBg, validHex, MIN_PRIMARY, MIN_ACCENT };
})(typeof window !== 'undefined' ? window : globalThis);
