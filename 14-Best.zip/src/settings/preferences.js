/* WISP · Layer 6 / 13 · Preferences
 * Применяет настройки ко всему приложению сразу после изменения:
 *  · тема и палитра: движок тем (src/settings/theme-engine.js) — html[data-theme], data-theme-preset, переменные;
 *  · множители скруглений, размытия, скорости анимаций и размера интерфейса — тоже движок;
 *  · атрибуты вёрстки: плотность, эффекты, появление, навигация, вид чата (WispThemeEngine.applyAttrs);
 *  · анимации: ui.reducedMotion() учитывает «Меньше движения» и «Эффекты: выкл.» — его уже спрашивают все слои;
 *  · отклик: ui.haptic() молчит, если вибрация выключена;
 *  · часовой пояс: свой пояс из настроек уходит на сервер вместо пояса устройства.
 * Источник значений один — профиль (ProfileStore, user.preferences). Отдельного хранилища нет. */
(function (App) {
  'use strict';
  const { Profile } = App.core;
  const ui = App.ui;
  const html = document.documentElement;
  const mm = (q) => (window.matchMedia ? matchMedia(q) : { matches: false, addEventListener() {} });
  const mqLight = mm('(prefers-color-scheme: light)');
  const mqReduce = mm('(prefers-reduced-motion: reduce)');
  const ThemeEngine = window.WispThemeEngine;

  let prefs = Profile.defaultPreferences();
  const listeners = new Set();

  const resolveTheme = (t) => {
    if (ThemeEngine) return ThemeEngine.resolvePalette({ ...prefs, theme: t }, mqLight.matches ? 'light' : 'dark').mode;
    return t === 'system' ? (mqLight.matches ? 'light' : 'dark') : t === 'light' ? 'light' : 'dark';
  };

  /* системное «Уменьшение движения» уважается всегда; настройки могут только добавить спокойствия */
  const systemReduced = ui.reducedMotion;
  ui.reducedMotion = () => prefs.motion === 'reduce' || prefs.fx_level === 'off' || systemReduced();
  const vibrate = ui.haptic;
  ui.haptic = (ms) => {
    if (prefs.haptics !== false) vibrate(ms);
    if (App.settings.Sound) App.settings.Sound.play('tap');     // «Звуки нажатий» (если звук включён)
  };

  function paint(p) {
    if (ThemeEngine) {
      ThemeEngine.applyAttrs(p);
      ThemeEngine.apply(p, mqLight.matches ? 'light' : 'dark');
      return;
    }
    const theme = resolveTheme(p.theme);
    html.setAttribute('data-theme', theme);
    if (p.density === 'compact') html.setAttribute('data-density', 'compact'); else html.removeAttribute('data-density');
    if (p.motion === 'reduce') html.setAttribute('data-motion', 'reduce'); else html.removeAttribute('data-motion');
  }

  function apply(next, opts) {
    const p = Profile.sanitizePreferences(next);
    const prevKey = `${html.getAttribute('data-theme')}|${html.getAttribute('data-theme-preset')}|${html.style.getPropertyValue('--wisp-bg')}`;
    prefs = p;
    const run = () => paint(p);
    const nextPalette = ThemeEngine ? ThemeEngine.resolvePalette(p, mqLight.matches ? 'light' : 'dark') : null;
    const nextKey = nextPalette ? `${nextPalette.mode}|${nextPalette.preset}|${nextPalette.active ? nextPalette.bg : ''}` : prevKey;
    const animate = opts && opts.animate && prevKey !== nextKey && !(opts && opts.instant) && !ui.reducedMotion() && document.startViewTransition;
    if (animate) { try { document.startViewTransition(run); } catch (e) { run(); } } else run();
    listeners.forEach((fn) => { try { fn(p); } catch (e) { /* подписчик не должен ломать остальных */ } });
  }

  const onSystem = () => { if (prefs.theme === 'system') apply(prefs, { animate: true }); else listeners.forEach((fn) => fn(prefs)); };
  if (mqLight.addEventListener) mqLight.addEventListener('change', onSystem);
  if (mqReduce.addEventListener) mqReduce.addEventListener('change', () => listeners.forEach((fn) => fn(prefs)));

  /* Подписка на профиль: любое изменение настроек (экран Settings, другая вкладка, сервер) применяется сразу */
  let preview = null;               // временные значения редактора тем: показываются, но не сохраняются
  function watch(store) {
    let last = JSON.stringify(store.user.preferences);
    apply(store.user.preferences);
    return store.subscribe((p) => {
      const key = JSON.stringify(p.user.preferences);
      if (key === last) return;
      last = key;
      apply(preview ? { ...p.user.preferences, ...preview } : p.user.preferences, { animate: true });
    });
  }

  /* Пояс для сервера: свой из настроек или пояс устройства */
  function timezone() {
    if (prefs.timezone) return prefs.timezone;
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) { return 'UTC'; }
  }

  App.settings = App.settings || {};
  App.settings.Prefs = {
    apply, watch, resolveTheme, timezone,
    get: () => prefs,
    theme: () => resolveTheme(prefs.theme),
    palette: () => (ThemeEngine ? ThemeEngine.resolvePalette(prefs, mqLight.matches ? 'light' : 'dark') : null),
    systemTheme: () => (mqLight.matches ? 'light' : 'dark'),
    systemReducedMotion: () => mqReduce.matches,
    /* Живое превью (редактор тем): показать значения поверх сохранённых. clearPreview(saved) — вернуть сохранённые. */
    preview(patch, saved) { preview = patch || null; apply({ ...saved, ...(patch || {}) }, { instant: true }); },
    clearPreview(saved) { if (!preview) return; preview = null; apply(saved, { instant: true }); },
    get previewing() { return !!preview; },
    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  };
})(window.WispApp);
