/* WISP · Layer 13 · Sound
 * Короткие звуки интерфейса, синтезированные Web Audio (без файлов и сетевых запросов).
 * Настройки (раздел «Звук и отклик»):
 *  · sound_on — общий выключатель (по умолчанию выключен: WISP 12 был беззвучным);
 *  · sound_volume — громкость 0–100;
 *  · sound_ui — звуки нажатий и переключателей; события (отправка, ответ, напоминание) звучат независимо от него.
 * Аудио создаётся лениво, только после жеста пользователя: браузеры не дают играть звук без него. */
(function (App) {
  'use strict';
  App.settings = App.settings || {};
  const UI_KINDS = new Set(['tap', 'toggle']);
  /* [частота, начало (с), длительность (с), тип волны, громкость 0–1] */
  const PATTERNS = {
    tap: [[880, 0, 0.045, 'sine', 0.35]],
    toggle: [[660, 0, 0.05, 'sine', 0.35], [990, 0.045, 0.06, 'sine', 0.3]],
    send: [[520, 0, 0.08, 'sine', 0.45], [780, 0.06, 0.1, 'sine', 0.4]],
    receive: [[784, 0, 0.12, 'sine', 0.38], [1046, 0.09, 0.18, 'sine', 0.3]],
    success: [[660, 0, 0.1, 'sine', 0.4], [880, 0.08, 0.1, 'sine', 0.38], [1320, 0.16, 0.2, 'sine', 0.3]],
    notify: [[988, 0, 0.14, 'triangle', 0.45], [1318, 0.16, 0.22, 'triangle', 0.4]],
    error: [[300, 0, 0.12, 'triangle', 0.45], [220, 0.1, 0.18, 'triangle', 0.4]],
  };
  let ctx = null;
  let last = 0;

  function prefs() { const P = App.settings.Prefs; return P ? P.get() : {}; }
  function context() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }
  function enabled(kind) {
    const p = prefs();
    if (!p.sound_on || !(p.sound_volume > 0)) return false;
    if (UI_KINDS.has(kind) && p.sound_ui === false) return false;
    return true;
  }

  function play(kind, opts) {
    const force = opts && opts.force;
    if (!PATTERNS[kind] || (!force && !enabled(kind))) return false;
    if (document.hidden && kind !== 'notify') return false;
    const now = Date.now();
    if (!force && UI_KINDS.has(kind) && now - last < 60) return false;      // дребезг нажатий не превращается в треск
    last = now;
    const ac = context();
    if (!ac) return false;
    try { if (ac.state === 'suspended') ac.resume(); } catch (e) { /* без звука */ }
    const vol = Math.max(0, Math.min(100, (opts && opts.volume != null) ? opts.volume : prefs().sound_volume)) / 100;
    const t0 = ac.currentTime + 0.01;
    const master = ac.createGain();
    master.gain.value = 0.22 * vol * vol;          // квадрат: громкость на слух ровнее
    master.connect(ac.destination);
    PATTERNS[kind].forEach(([f, at, dur, type, g]) => {
      const o = ac.createOscillator();
      const env = ac.createGain();
      o.type = type; o.frequency.value = f;
      env.gain.setValueAtTime(0.0001, t0 + at);
      env.gain.exponentialRampToValueAtTime(g, t0 + at + 0.012);
      env.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
      o.connect(env); env.connect(master);
      o.start(t0 + at); o.stop(t0 + at + dur + 0.03);
    });
    return true;
  }

  App.settings.Sound = {
    play,
    supported: () => !!(window.AudioContext || window.webkitAudioContext),
    kinds: Object.keys(PATTERNS),
  };
})(window.WispApp);
