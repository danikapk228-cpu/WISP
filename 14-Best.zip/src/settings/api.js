/* WISP · Layer 6 · Account API
 * Клиент раздела настроек поверх того же AssistantClient: тот же сервер, та же httpOnly-сессия, те же заголовки.
 * Тариф и права проверяет сервер; клиент ничего из этого не присылает. */
(function (App) {
  'use strict';
  App.settings = App.settings || {};
  App.settings.AccountAPI = function (assistant) {
    return {
      get available() { return assistant.connected; },
      get ready() { return assistant.ready; },
      app: () => assistant.request('GET', '/app'),
      account: () => assistant.request('GET', '/account'),
      export: () => assistant.request('GET', '/account/export', undefined, { timeout: 120000 }),
      reset: (section) => assistant.request('POST', '/account/reset', { section, confirm: 'reset' }, { timeout: 30000 }),
      getProfile: () => assistant.request('GET', '/profile'),
      putProfile: (profile) => assistant.request('PUT', '/profile', { profile }),
      clearHistory: () => assistant.request('DELETE', '/conversations', { confirm: 'clear_all' }),
      /* без повторной сессии при 401: после выхода новая сессия создаётся только перезагрузкой */
      logout: () => assistant.request('POST', '/account/logout', { confirm: 'delete_device_data' }, { noRetry: true }),
    };
  };
})(window.WispApp);
