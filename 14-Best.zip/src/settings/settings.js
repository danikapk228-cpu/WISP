/* WISP · Layer 6 · Settings
 * Раздел настроек: главный список категорий и экраны Аккаунт · Внешний вид · Поведение WISP ·
 * Память и приватность · Уведомления · О приложении. Экран открывается поверх главного (как Tools/Memory),
 * «назад» — кнопкой и системным жестом (через историю браузера, её ведёт Home).
 *
 * Принцип: показываем только то, что действительно работает. Что ещё не сделано — честно помечено «Пока нет»
 * и не притворяется переключателем.
 * Данные:
 *  · профиль и настройки — ProfileStore (тот же, что у онбординга), сохраняются локально + на сервер (ProfileSync);
 *  · память — существующий MemoryAPI Layer 5 (/api/memory/settings), без второй копии;
 *  · тариф, дата регистрации, объём данных — только с сервера (/api/account);
 *  · уведомления — Capabilities (Layer 1) + настройка напоминаний, которую учитывает планировщик Layer 4. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Profile, Capabilities } = App.core;
  const { Kit } = App.tools;
  App.settings = App.settings || {};

  const VERSION = '0.6.0';
  const THEMES = [
    { id: 'dark', label: 'Тёмная', icon: 'moon' },
    { id: 'black', label: 'Pure Black', icon: 'moon' },
    { id: 'midnight', label: 'Midnight', icon: 'spark' },
    { id: 'light', label: 'Светлая', icon: 'sun' },
    { id: 'system', label: 'Как в системе', icon: 'sliders' },
  ];
  const LENGTHS = [
    { id: 'short', label: 'Коротко', desc: 'Пара предложений, без лишнего. Подробности — по просьбе.' },
    { id: 'balanced', label: 'Баланс', desc: 'Длина под вопрос: коротко на простое, подробнее на сложное.' },
    { id: 'detailed', label: 'Подробно', desc: 'Развёрнуто, с примерами и шагами.' },
  ];
  const STYLES = [
    { id: 'auto', label: 'Авто', desc: 'Списки и таблицы, когда они помогают. В беседе — просто текст.' },
    { id: 'plain', label: 'Текстом', desc: 'Обычный текст, минимум разметки. Код всё равно в блоках.' },
    { id: 'structured', label: 'Структурно', desc: 'Короткие абзацы, списки, главное выделено.' },
  ];
  const plural = (n, a, b, c) => App.tools.plural(n, a, b, c);
  const longDate = (t) => new Date(t).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });

  /* Выключатель: тот же вид, что в Memory (.mm-switch). onChange может вернуть Promise<false> — откат. */
  function Switch({ checked, label, onChange, disabled }) {
    const el = ui.pressable(h('button', { type: 'button', class: 'mm-switch st-switch', role: 'switch', 'aria-checked': checked ? 'true' : 'false', 'aria-label': label, disabled: !!disabled },
      h('span', { class: 'mm-switch__knob', 'aria-hidden': 'true' })));
    let busy = false;
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (busy || el.disabled) return;
      const next = el.getAttribute('aria-checked') !== 'true';
      el.setAttribute('aria-checked', next ? 'true' : 'false');
      ui.haptic(8);
      if (!onChange) return;
      busy = true; el.classList.add('is-busy');
      const ok = await onChange(next);
      busy = false; el.classList.remove('is-busy');
      if (ok === false) el.setAttribute('aria-checked', next ? 'false' : 'true');
    });
    el.set = (v) => el.setAttribute('aria-checked', v ? 'true' : 'false');
    return el;
  }

  function SelectControl({ label, value, options, onChange, disabled }) {
    const el = h('select', { class: 'st-select', 'aria-label': label, disabled: !!disabled },
      options.map((o) => h('option', { value: o.id, text: o.label })));
    el.value = value;
    el.addEventListener('change', () => onChange && onChange(el.value));
    return el;
  }

  function RangeControl({ label, value, min, max, step, onChange, format }) {
    const output = h('output', { class: 'st-range__value', text: format ? format(value) : `${value}%` });
    const input = h('input', { type: 'range', min, max, step: step || 1, value, 'aria-label': label });
    const paint = (v) => { input.value = String(v); output.textContent = format ? format(v) : `${v}%`; };
    input.addEventListener('input', () => { paint(Number(input.value)); onChange && onChange(Number(input.value)); });
    const el = h('label', { class: 'st-range' },
      h('span', { class: 'st-range__head' }, h('span', { class: 'st-range__label', text: label }), output),
      input);
    el.set = paint;
    return el;
  }

  function SettingControl({ label, sub, control }) {
    return h('div', { class: 'st-control' },
      h('span', { class: 'st-control__copy' }, h('span', { class: 'st-control__label', text: label }), sub ? h('span', { class: 'st-control__sub', text: sub }) : null),
      control);
  }

  function themeName(p) {
    if (p.theme === 'custom') {
      const custom = (p.themes || []).find((t) => t.id === p.theme_custom);
      return custom ? custom.name : 'Своя тема';
    }
    const theme = THEMES.find((t) => t.id === p.theme);
    return theme ? theme.label : 'Тёмная';
  }

  /* Строка списка. Вариант с кнопкой (onClick), со своим элементом справа (end) или статичная. */
  function Row({ icon, label, sub, value, onClick, end, tone, chevron, href, id, disabled }) {
    const main = h('span', { class: 'st-row__main' },
      h('span', { class: 'st-row__label', text: label }),
      sub ? h('span', { class: 'st-row__sub', text: sub }) : null);
    const valueEl = value != null ? h('span', { class: 'st-row__value', text: value }) : null;
    const parts = [
      icon ? h('span', { class: 'st-row__icon' }, ui.icon(icon)) : null,
      main, valueEl, end || null,
      (onClick || href) && chevron !== false ? ui.icon(href ? 'link' : 'chevron', 'ds-icon st-row__chev') : null,
    ];
    const cls = `st-row${tone ? ' st-row--' + tone : ''}${onClick || href ? ' is-action' : ''}`;
    let el;
    if (href) el = ui.pressable(h('a', { class: cls, href, target: '_blank', rel: 'noopener noreferrer' }, parts));
    else if (onClick) el = ui.pressable(h('button', { type: 'button', class: cls, onClick, disabled: !!disabled }, parts));
    else el = h('div', { class: cls }, parts);
    if (id) el.dataset.row = id;
    el.setValue = (v) => { if (valueEl) valueEl.textContent = v; };
    el.setSub = (v) => { const s = main.querySelector('.st-row__sub'); if (s) s.textContent = v; else if (v) main.appendChild(h('span', { class: 'st-row__sub', text: v })); };
    return el;
  }
  const Group = (title, rows, note) => h('section', { class: 'st-section' },
    title ? h('h3', { class: 'tl-h st-h', text: title }) : null,
    h('div', { class: 'st-group' }, rows),
    note ? h('p', { class: 'st-note', text: note }) : null);
  const Soon = () => h('span', { class: 'ds-pill ds-pill--off st-soon', text: 'Пока нет' });

  function AvatarView(user, size) {
    const el = h('span', { class: `st-avatar${size ? ' st-avatar--' + size : ''}`, 'aria-hidden': 'true' });
    if (user.avatar) el.appendChild(h('img', { src: user.avatar, alt: '', decoding: 'async' }));
    else {
      const ch = user.name ? Array.from(user.name.trim())[0] : '';
      el.appendChild(ch ? h('span', { class: 'st-avatar__letter', text: ch.toLocaleUpperCase('ru') }) : ui.icon('user', 'ds-icon st-avatar__icon'));
    }
    return el;
  }

  App.settings.SettingsView = function (deps) {
    const { root, store, director, assistant, accountApi, memoryApi, toolsApi, sync, openSheet, closeSheet, openPlan, openMemory,
      onEditProfile, onSignedOut, onOpenAuth, onEraseLocal, onClose, onLayout, history: hist, chat } = deps;
    const Prefs = App.settings.Prefs;
    let open = false, destroyed = false;
    let stack = [];                         // [{ id, el, bar, cleanup }]
    let account = null, accountErr = null, accountLoading = null;
    let appInfo = null;
    let memSettings = null, memErr = null;

    const prefs = () => store.user.preferences;
    const setPref = (patch, msg) => { store.update({ preferences: patch }); saved(msg); };

    /* ── Уведомление внизу: «Сохранено», ошибки ── */
    const notice = h('p', { class: 'home-notice tl-notice st-notice', role: 'status', 'aria-live': 'polite' });
    let noticeTimer = 0;
    function setNotice(text, tone, ttl) {
      clearTimeout(noticeTimer);
      if (!text) { notice.classList.remove('is-on'); return; }
      notice.textContent = text; notice.dataset.tone = tone || 'info'; notice.classList.add('is-on');
      noticeTimer = setTimeout(() => notice.classList.remove('is-on'), ttl || 2600);
    }
    /* «Сохранено» — сразу (локальная копия записана); если сервер не принял, sync сообщит отдельно */
    function saved(msg) {
      const s = sync ? sync.status() : { connected: false };
      setNotice(msg || (s.connected ? 'Сохранено' : 'Сохранено на этом устройстве'), 'info', 1800);
    }
    let lastSyncState = null;
    const unsubSync = sync ? sync.subscribe((s) => {
      if (s.state === 'error' && lastSyncState !== 'error' && open) setNotice('Сохранено на устройстве. На сервер отправлю, когда будет связь.', 'warn', 4200);
      lastSyncState = s.state;
      paintSyncLines();
    }) : () => {};

    const stackEl = h('div', { class: 'tl-stack st-stack' });
    const el = h('section', { class: 'home-panel settings', id: 'home-panel-settings', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Настройки' }, stackEl, notice);
    el.inert = true; el.setAttribute('aria-hidden', 'true');

    /* ── Каркас экрана ── */
    function Screen(id, title, sub, content) {
      const bar = Kit.TopBar({ title, sub, onBack: () => back(), backLabel: stack.length ? 'Назад' : 'Закрыть настройки' });
      const inner = h('div', { class: 'tl-inner st-inner' }, content);
      const scroll = h('div', { class: 'tl-scroll st-scroll' }, inner);
      const screen = h('div', { class: 'tl-screen st-screen', dataset: { screen: id } }, bar, scroll);
      return { id, el: screen, bar, scroll, inner };
    }

    function back() { if (hist) hist.back(); else pop(); }

    /* ═══════════ Главный экран ═══════════ */
    const syncLines = [];
    function syncLine() { const p = h('p', { class: 'st-sync' }); syncLines.push(p); paintSyncLine(p); return p; }
    function syncText() {
      if (!assistant.connected) return { text: 'Гостевой режим: всё сохраняется на этом устройстве.', tone: 'local' };
      const s = sync ? sync.status() : { state: 'local' };
      if (s.state === 'saving' || s.state === 'pending') return { text: 'Сохраняю на сервер WISP…', tone: 'busy' };
      if (s.state === 'error') return { text: 'Сохранено на устройстве. Нет связи с сервером WISP.', tone: 'warn' };
      return { text: 'Настройки сохранены на сервере WISP и на этом устройстве.', tone: 'ok' };
    }
    function paintSyncLine(p) { const t = syncText(); p.textContent = t.text; p.dataset.tone = t.tone; }
    function paintSyncLines() { syncLines.forEach((p) => { if (p.isConnected) paintSyncLine(p); }); }

    function mainScreen() {
      const me = ui.pressable(h('button', { type: 'button', class: 'st-me', onClick: () => push('account') }));
      const rows = {
        appearance: Row({ id: 'appearance', icon: 'palette', label: 'Внешний вид', onClick: () => push('appearance') }),
        interface: Row({ id: 'interface', icon: 'sliders', label: 'Интерфейс', onClick: () => push('interface') }),
        effects: Row({ id: 'effects', icon: 'wave', label: 'Эффекты', onClick: () => push('effects') }),
        sound: Row({ id: 'sound', icon: 'note', label: 'Звук', onClick: () => push('sound') }),
        chat: Row({ id: 'chat', icon: 'chat', label: 'Чат', onClick: () => push('chat') }),
        region: Row({ id: 'region', icon: 'globe', label: 'Язык и время', onClick: () => push('region') }),
        behavior: Row({ id: 'behavior', icon: 'chat', label: 'Поведение WISP', onClick: () => push('behavior') }),
        privacy: Row({ id: 'privacy', icon: 'memory', label: 'Память и приватность', onClick: () => push('privacy') }),
        notifications: Row({ id: 'notifications', icon: 'bell', label: 'Уведомления', onClick: () => push('notifications') }),
        data: Row({ id: 'data', icon: 'shield', label: 'Данные и сброс', onClick: () => push('data') }),
        about: Row({ id: 'about', icon: 'info', label: 'О приложении', onClick: () => push('about') }),
      };
      const search = Kit.Input({ placeholder: 'Поиск по настройкам', label: 'Поиск по настройкам' });
      search.type = 'search';
      search.autocapitalize = 'off';
      const searchEmpty = h('p', { class: 'st-search-empty', text: 'Ничего не нашёл. Попробуй другое слово.', hidden: true });
      const primaryRows = ['appearance', 'interface', 'effects', 'sound', 'chat', 'region', 'behavior', 'privacy', 'notifications', 'data'].map((k) => rows[k]);
      const primaryGroup = Group(null, primaryRows);
      const aboutGroup = Group(null, [rows.about]);
      const searchTerms = {
        appearance: 'оформление тема цвет black midnight pure black светлая тёмная прозрачность скругления масштаб',
        interface: 'интерфейс вкладки навигация панель боковая порядок перетаскивание быстрые действия',
        effects: 'эффекты анимация движение скорость свечение размытие',
        sound: 'звук громкость нажатия вибрация тактильный отклик',
        chat: 'чат сообщения enter ширина размер текста время прокрутка markdown код черновики',
        region: 'язык время часовой пояс таймзона русский английский обращение ты вы',
        behavior: 'поведение характер ответы длина стиль персонализация имя анкета',
        privacy: 'память приватность история диалоги воспоминания',
        notifications: 'уведомления напоминания разрешение',
        data: 'данные экспорт сброс очистить удалить аккаунт',
        about: 'о приложении версия поддержка сайт',
      };
      search.addEventListener('input', () => {
        const q = search.value.trim().toLocaleLowerCase('ru');
        let visible = 0;
        Object.keys(rows).forEach((key) => {
          const match = !q || `${rows[key].textContent} ${searchTerms[key] || ''}`.toLocaleLowerCase('ru').includes(q);
          rows[key].hidden = !match;
          if (match) visible++;
        });
        primaryGroup.hidden = !primaryRows.some((row) => !row.hidden);
        aboutGroup.hidden = rows.about.hidden;
        searchEmpty.hidden = !q || visible > 0;
      });
      function paint() {
        const u = store.user;
        const plan = Profile.plan(store.profile);
        const since = account ? longDate(account.user.created_at) : (assistant.session ? longDate(assistant.session.user.created_at) : null);
        me.replaceChildren(
          AvatarView(u, 'medium'),
          h('span', { class: 'st-me__main' },
            h('span', { class: 'st-me__name', text: u.name || 'Без имени' }),
            h('span', { class: 'st-me__sub' }, h('span', { class: `st-plan${plan.id === 'plus' ? ' is-plus' : ''}`, text: plan.title }), since ? h('span', { text: `с ${since}` }) : h('span', { text: assistant.connected ? 'Аккаунт этого устройства' : 'Гостевой режим' }))),
          ui.icon('chevron', 'ds-icon st-row__chev'));
        me.setAttribute('aria-label', `Аккаунт: ${u.name || 'без имени'}, тариф ${plan.title}`);
        const p = u.preferences;
        rows.appearance.setValue(themeName(p));
        rows.interface.setValue(p.nav_position === 'side' ? 'Боковая панель' : 'Нижняя панель');
        rows.effects.setValue(p.fx_level === 'off' ? 'Выкл.' : p.fx_level === 'soft' ? 'Мягкие' : 'Включены');
        rows.sound.setValue(p.sound_on ? 'Включён' : 'Выключен');
        rows.chat.setValue(p.chat_layout === 'compact' ? 'Компактный' : 'Стандартный');
        rows.region.setValue(p.reply_lang === 'auto' ? 'Авто' : p.reply_lang === 'ru' ? 'Русский' : 'English');
        rows.behavior.setValue(Profile.effectivePersonality(store.profile).title);
        rows.privacy.setValue(!assistant.connected ? 'Нужен сервер' : memSettings ? (memSettings.enabled ? 'Память вкл.' : 'Память выкл.') : '');
        const notif = 'Notification' in window ? Notification.permission : 'unsupported';
        rows.notifications.setValue(notif === 'granted' ? (p.notify_reminders ? 'Включены' : 'Выключены') : notif === 'denied' ? 'Запрещены' : notif === 'default' ? 'Не разрешены' : 'Недоступны');
        rows.data.setValue(assistant.connected ? 'Экспорт и очистка' : 'Настройки устройства');
        rows.about.setValue(`Версия ${appInfo && appInfo.version ? appInfo.version : VERSION}`);
      }
      const s = Screen('main', 'Настройки', 'WISP под тебя', [
        h('section', { class: 'st-section st-section--me' }, me),
        h('section', { class: 'st-section st-search' }, search),
        searchEmpty,
        primaryGroup,
        aboutGroup,
        syncLine(),
      ]);
      s.paint = paint;
      paint();
      return s;
    }

    /* ═══════════ Аккаунт ═══════════ */
    function accountScreen() {
      const u = store.user;
      const file = h('input', { type: 'file', accept: 'image/*', class: 'st-file', tabindex: '-1', 'aria-hidden': 'true' });
      const bigAvatar = h('span', { class: 'st-avatar-wrap' });
      const pick = ui.Button({ label: 'Выбрать фото', variant: 'secondary', size: 'small', onClick: () => file.click() });
      const drop = ui.Button({ label: 'Убрать', variant: 'ghost', size: 'small', onClick: () => { store.update({ avatar: null }); paintAvatar(); saved('Фото убрано'); } });
      const avatarBtn = ui.pressable(h('button', { type: 'button', class: 'st-avatar-btn', 'aria-label': 'Изменить фото профиля', onClick: () => file.click() }, bigAvatar, h('span', { class: 'st-avatar-btn__cam', 'aria-hidden': 'true' }, ui.icon('camera'))));
      function paintAvatar() {
        bigAvatar.replaceChildren(AvatarView(store.user, 'large'));
        drop.hidden = !store.user.avatar;
      }
      file.addEventListener('change', async () => {
        const f = file.files && file.files[0];
        file.value = '';
        if (!f) return;
        pick.setBusy(true);
        try {
          const url = await App.settings.Avatar.fromFile(f);
          store.update({ avatar: url });
          paintAvatar();
          director.react('small');
          saved('Фото обновлено');
        } catch (e) {
          setNotice(e.reason || 'Не получилось загрузить фото.', 'warn', 4200);
          director.react('blink');
        } finally { pick.setBusy(false); }
      });

      /* имя: сохраняется по Enter / уходу с поля; тот же sanitizeName, что в онбординге */
      const nameHint = h('span', { class: 'tl-field__hint st-hint' });
      const nameInput = Kit.Input({ value: u.name || '', placeholder: 'Как к тебе обращаться', maxLength: Profile.LIMITS.name, label: 'Имя', autocap: true, onEnter: () => nameInput.blur() });
      nameInput.setAttribute('autocomplete', 'given-name');
      nameInput.setAttribute('autocapitalize', 'words');
      const commitName = () => {
        const v = Profile.sanitizeName(nameInput.value);
        if (v === store.user.name) { nameInput.value = v || ''; return; }
        store.update({ name: v });
        nameInput.value = v || '';
        nameHint.textContent = v ? '' : 'Без имени WISP будет обращаться нейтрально.';
        saved(v ? 'Имя сохранено' : 'Имя убрано');
        director.react('nod');
      };
      nameInput.addEventListener('blur', commitName);
      nameInput.addEventListener('input', () => { nameHint.textContent = `${nameInput.value.length} / ${Profile.LIMITS.name}`; });

      const planRow = Row({ icon: 'spark', label: 'Тариф', value: Profile.plan(store.profile).title, onClick: () => openPlan() });
      const since = Row({ icon: 'calendar', label: 'Дата регистрации', value: '…' });
      const mail = assistant.signedIn
        ? Row({ icon: 'mail', label: 'Электронная почта', value: '…', sub: 'Аккаунт WISP' })
        : Row({ icon: 'mail', label: 'Войти или создать аккаунт', sub: 'Аккаунт синхронизирует данные между устройствами', onClick: () => onOpenAuth && onOpenAuth({ kind: 'login' }) });
      const idRow = assistant.connected ? Row({ icon: 'copy', label: 'ID для поддержки', value: '…', onClick: async () => {
        const id = account && account.user.id;
        if (!id) return;
        const ok = await App.chat.Markdown.copyText(id);
        setNotice(ok ? 'ID скопирован' : id, 'info', 2400);
      }, chevron: false }) : null;
      const editRow = Row({ icon: 'edit', label: 'Ответы знакомства', sub: 'Интересы, занятие, о себе', onClick: () => onEditProfile() });
      const out = Row({ icon: 'logout', label: assistant.signedIn ? 'Выйти' : 'Стереть данные устройства', sub: assistant.signedIn ? 'Данные аккаунта останутся в WISP' : 'Удалит гостевые данные с сервера и этого устройства', tone: 'danger', onClick: () => openLogout(), chevron: false });
      const errLine = h('p', { class: 'st-note st-note--warn', hidden: true });

      function paint() {
        planRow.setValue(Profile.plan(store.profile).title);
        if (!assistant.connected) { since.setValue(longDate(store.profile.meta.created_at)); since.setSub('Профиль создан на этом устройстве'); return; }
        if (account) {
          since.setValue(longDate(account.user.created_at));
          if (idRow) idRow.setValue(account.user.id.slice(0, 8) + '…');
          if (assistant.signedIn && account.account) {
            mail.setValue(account.account.email);
            mail.setSub(account.account.email_verified ? 'Почта подтверждена' : 'Почта ещё не подтверждена');
          }
          errLine.hidden = true;
        } else if (accountErr) {
          since.setValue('—');
          errLine.hidden = false;
          errLine.replaceChildren(document.createTextNode(Kit.errorText(accountErr) + ' '), ui.TextButton({ label: 'Повторить', onClick: () => loadAccount(true).then(paintAll) }));
        }
      }
      paintAvatar();
      const s = Screen('account', 'Аккаунт', null, [
        h('section', { class: 'st-section st-hero' }, avatarBtn, h('div', { class: 'st-hero__actions' }, pick, drop), file),
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Имя' }), h('label', { class: 'tl-field st-field' }, nameInput, nameHint)),
        Group('Аккаунт', [planRow, since, mail, idRow].filter(Boolean)),
        errLine,
        Group('Профиль', [editRow]),
        Group(null, [out]),
        syncLine(),
      ]);
      s.paint = paint;
      s.cleanup = () => commitName();
      paint();
      if (assistant.connected) loadAccount().then(() => !destroyed && paint());
      return s;
    }

    function openLogout() {
      const guest = !assistant.signedIn;
      const what = h('ul', { class: 'st-list' });
      const fill = () => {
        what.replaceChildren();
        const d = account && account.data;
        const items = guest ? ['гостевые диалоги и данные Tools', 'воспоминания', 'профиль, настройки и черновики'] : [
          d ? `диалоги: ${d.conversations}` : 'все диалоги и картинки',
          d ? `воспоминания: ${d.memories}` : 'долговременная память',
          d ? `заметки, задачи, напоминания, планы: ${d.notes + d.tasks + d.reminders + d.events}` : 'заметки, задачи, напоминания и планы',
          'профиль и настройки',
        ];
        items.forEach((t) => what.appendChild(h('li', { text: t })));
      };
      fill();
      if (!guest && !account) loadAccount().then(fill);
      const err = h('p', { class: 'st-note st-note--warn', hidden: true });
      let del = guest ? Kit.DeleteButton({
        label: 'Стереть данные устройства',
        confirm: 'Нажми ещё раз — удалить навсегда',
        onConfirm: async (b) => {
          b.setBusy(true);
          err.hidden = true;
          if (assistant.connected) {
            const r = await accountApi.logout();
            if (!r.ok) { b.setBusy(false); err.hidden = false; err.textContent = Kit.errorText(r.error); director.react('blink'); return; }
          }
          if (onEraseLocal) await onEraseLocal();
          await onSignedOut();
        },
      }) : null;
      if (!guest) {
        del = ui.Button({ label: 'Выйти', variant: 'danger', onClick: async () => {
          del.setBusy(true);
          const r = await accountApi.logout();
          del.setBusy(false);
          if (!r.ok) { err.hidden = false; err.textContent = Kit.errorText(r.error); director.react('blink'); return; }
          await onSignedOut();
        } });
      }
      openSheet({ title: guest ? 'Стереть гостевые данные?' : 'Выйти из WISP?', content: [
        h('p', { class: 'home-sheet__lead', text: guest
          ? 'Удалю гостевые данные с сервера и этого устройства. Данные аккаунтов не затрону.'
          : 'Текущий сеанс завершится. Данные аккаунта останутся на сервере и будут доступны после следующего входа.' }),
        guest ? h('p', { class: 'home-sheet__note', text: 'Будет удалено:' }) : null, guest ? what : null,
        err,
        h('div', { class: 'home-sheet__actions' }, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    async function loadAccount(force) {
      if (!assistant.connected) return null;
      if (account && !force) return account;
      if (accountLoading) return accountLoading;
      accountLoading = (async () => {
        const r = await accountApi.account();
        accountLoading = null;
        if (r.ok) { account = r.data; accountErr = null; } else { accountErr = r.error; }
        return account;
      })();
      return accountLoading;
    }

    /* ═══════════ Внешний вид ═══════════ */
    function appearanceScreen() {
      let editingId = null, draft = null, dirty = false;
      const presetGrid = h('div', { class: 'st-themes', role: 'radiogroup', 'aria-label': 'Готовые темы' });
      const presetCards = THEMES.map((t) => ui.pressable(h('button', {
        type: 'button', class: 'st-theme', role: 'radio', dataset: { id: t.id },
        onClick: () => {
          if (prefs().theme === t.id) return;
          closeEditor();
          setPref({ theme: t.id, theme_custom: '', accent: '' }, 'Тема изменена');
          director.react('nod');
        },
      },
      h('span', { class: `st-theme__pv st-theme__pv--${t.id}`, 'aria-hidden': 'true' }, h('i', { class: 'st-pv__bar' }), h('i', { class: 'st-pv__card' }), h('i', { class: 'st-pv__line' }), h('i', { class: 'st-pv__dot' })),
      h('span', { class: 'st-theme__label' }, ui.icon(t.icon, 'ds-icon st-theme__icon'), h('span', { text: t.label })))));
      presetGrid.replaceChildren(...presetCards);
      const customGrid = h('div', { class: 'st-themes st-themes--custom', role: 'radiogroup', 'aria-label': 'Свои темы' });
      const customActions = h('div', { class: 'st-custom-actions' });
      const themeNote = h('p', { class: 'st-note' });
      const livePreview = h('div', { class: 'st-live-preview', 'aria-label': 'Предпросмотр темы' },
        h('div', { class: 'st-live-preview__head' }, h('span', { class: 'st-live-preview__spark' }), h('span', { text: 'WISP' }), h('span', { class: 'st-live-preview__tag', text: 'Превью' })),
        h('div', { class: 'st-live-preview__msg' }, h('span', { text: 'Привет! Тема применяется сразу.' })),
        h('div', { class: 'st-live-preview__reply' }, h('span', { text: 'Отлично, можно настроить цвета под себя.' })));

      const editorName = Kit.Input({ value: '', placeholder: 'Название темы', maxLength: 24, label: 'Название своей темы' });
      const colorFields = [
        { key: 'bg', label: 'Фон', value: '#080b1c' },
        { key: 'primary', label: 'Основной', value: '#c3bcff' },
        { key: 'secondary', label: 'Вторичный', value: '#bdb6ff' },
        { key: 'accent', label: 'Акцент', value: '#c8c1ff' },
        { key: 'glow', label: 'Свечение', value: '#a59bff' },
      ];
      const colorInputs = Object.fromEntries(colorFields.map((f) => {
        const input = h('input', { type: 'color', class: 'st-color', value: f.value, 'aria-label': f.label });
        input.addEventListener('input', () => { if (draft) { draft[f.key] = input.value; updateDraft(); } });
        return [f.key, input];
      }));
      const dirtyMark = h('span', { class: 'st-dirty', text: 'Не сохранено', hidden: true, 'aria-live': 'polite' });
      const editorError = h('p', { class: 'st-note st-note--warn', hidden: true });
      const saveTheme = ui.Button({ label: 'Сохранить тему', variant: 'primary', disabled: true, onClick: saveDraft });
      const cancelTheme = ui.Button({ label: 'Отменить', variant: 'ghost', onClick: closeEditor });
      const deleteTheme = Kit.DeleteButton({
        label: 'Удалить тему',
        confirm: 'Нажми ещё раз, чтобы удалить',
        onConfirm: () => {
          if (!editingId) return;
          const p = prefs();
          const themes = p.themes.filter((t) => t.id !== editingId);
          const active = p.theme === 'custom' && p.theme_custom === editingId;
          store.update({ preferences: { ...prefs(), themes, ...(active ? { theme: 'dark', theme_custom: '', accent: '' } : {}) } });
          closeEditor();
          saved('Тема удалена');
        },
      });
      const editor = h('div', { class: 'st-editor', hidden: true },
        h('div', { class: 'st-editor__head' }, h('h4', { class: 'st-editor__title', text: 'Редактор темы' }), dirtyMark),
        h('label', { class: 'st-field' }, h('span', { class: 'tl-field__label', text: 'Название' }), editorName),
        h('div', { class: 'st-colors' }, colorFields.map((f) => h('label', { class: 'st-color-row' },
          h('span', { text: f.label }), colorInputs[f.key]))),
        editorError,
        h('div', { class: 'st-editor__actions' }, saveTheme, cancelTheme, deleteTheme));
      const newTheme = ui.Button({ label: 'Создать свою тему', variant: 'secondary', size: 'small', onClick: () => openEditor(null) });
      const glass = RangeControl({ label: 'Прозрачность панелей', value: prefs().glass, min: 0, max: 100, step: 5, onChange: (v) => setPref({ glass: v }), format: (v) => `${v}%` });
      const radius = RangeControl({ label: 'Скругления', value: prefs().radius, min: 20, max: 150, step: 5, onChange: (v) => setPref({ radius: v }), format: (v) => `${v}%` });
      const scale = RangeControl({ label: 'Размер интерфейса', value: prefs().ui_scale, min: 90, max: 125, step: 5, onChange: (v) => setPref({ ui_scale: v }), format: (v) => `${v}%` });

      function newId() {
        const raw = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID().replace(/-/g, '') : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
        return `t${raw.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 11)}`;
      }
      function themeCard(theme, isCustom) {
        const pv = h('span', {
          class: `st-theme__pv${isCustom ? ' st-theme__pv--custom' : ` st-theme__pv--${theme.id}`}`,
          'aria-hidden': 'true',
        }, h('i', { class: 'st-pv__bar' }), h('i', { class: 'st-pv__card' }), h('i', { class: 'st-pv__line' }), h('i', { class: 'st-pv__dot' }));
        if (isCustom) {
          pv.style.background = theme.bg;
          pv.querySelector('.st-pv__bar').style.background = theme.primary;
          pv.querySelector('.st-pv__line').style.background = theme.secondary;
          pv.querySelector('.st-pv__card').style.background = `${theme.accent}33`;
          pv.querySelector('.st-pv__dot').style.background = theme.glow;
        }
        return ui.pressable(h('button', {
          type: 'button', class: 'st-theme', role: 'radio', dataset: { id: theme.id },
          'aria-checked': prefs().theme === (isCustom ? 'custom' : theme.id) && (!isCustom || prefs().theme_custom === theme.id) ? 'true' : 'false',
          onClick: () => {
            closeEditor();
            if (isCustom) setPref({ theme: 'custom', theme_custom: theme.id, accent: '' }, 'Своя тема применена');
            else if (prefs().theme !== theme.id) setPref({ theme: theme.id, theme_custom: '', accent: '' }, 'Тема изменена');
          },
        }, pv, h('span', { class: 'st-theme__label' }, ui.icon(isCustom ? 'palette' : theme.icon, 'ds-icon st-theme__icon'), h('span', { text: isCustom ? theme.name : theme.label }))));
      }
      function openEditor(theme) {
        editingId = theme ? theme.id : newId();
        draft = theme ? { ...theme } : { id: editingId, name: 'Моя тема', bg: '#080b1c', primary: '#c3bcff', secondary: '#bdb6ff', accent: '#c8c1ff', glow: '#a59bff' };
        dirty = false;
        editorName.value = draft.name;
        colorFields.forEach((f) => { colorInputs[f.key].value = draft[f.key] || f.value; });
        editorError.hidden = true;
        dirtyMark.hidden = true;
        saveTheme.setDisabled(true);
        deleteTheme.hidden = !theme;
        editor.hidden = false;
        editor.scrollIntoView({ block: 'nearest', behavior: ui.reducedMotion() ? 'auto' : 'smooth' });
      }
      function closeEditor() {
        if (Prefs.previewing) Prefs.clearPreview(prefs());
        editor.hidden = true;
        editingId = null;
        draft = null;
        dirty = false;
        dirtyMark.hidden = true;
        saveTheme.setDisabled(true);
        editorError.hidden = true;
      }
      function updateDraft() {
        if (!draft) return;
        draft.name = editorName.value.trim().slice(0, 24) || 'Моя тема';
        dirty = true;
        dirtyMark.hidden = false;
        saveTheme.setDisabled(false);
        editorError.hidden = true;
        const themes = prefs().themes.filter((t) => t.id !== draft.id).concat({ ...draft });
        Prefs.preview({ theme: 'custom', theme_custom: draft.id, themes, accent: '' }, prefs());
      }
      function saveDraft() {
        if (!draft || !dirty) return;
        const current = prefs();
        const existing = current.themes.some((t) => t.id === draft.id);
        if (!existing && current.themes.length >= App.core.PrefSchema.THEMES_MAX) {
          editorError.hidden = false;
          editorError.textContent = `Можно сохранить не больше ${App.core.PrefSchema.THEMES_MAX} своих тем. Удали одну, чтобы добавить новую.`;
          return;
        }
        const clean = App.core.PrefSchema.sanitizeTheme({ ...draft, name: editorName.value });
        if (!clean) {
          editorError.hidden = false;
          editorError.textContent = 'Проверь название и цвета темы.';
          return;
        }
        const themes = current.themes.filter((t) => t.id !== clean.id).concat(clean);
        store.update({ preferences: { ...current, themes, theme: 'custom', theme_custom: clean.id, accent: '' } });
        if (Prefs.previewing) Prefs.clearPreview(prefs());
        editor.hidden = true;
        editingId = null; draft = null; dirty = false;
        saved('Своя тема сохранена');
      }
      editorName.addEventListener('input', updateDraft);
      const customStart = h('p', { class: 'st-note', text: 'Цвета применяются сразу. Пока не нажмёшь «Сохранить тему», изменения останутся черновиком.' });
      const motionNote = h('p', { class: 'st-note', text: 'Размер текста и контраст темы учитываются автоматически.' });

      function paint() {
        const p = prefs();
        presetCards.forEach((c) => c.setAttribute('aria-checked', p.theme === c.dataset.id ? 'true' : 'false'));
        const savedThemes = p.themes || [];
        customGrid.replaceChildren(...savedThemes.map((t) => themeCard(t, true)));
        customActions.replaceChildren(...savedThemes.map((t) => Row({
          icon: 'palette', label: t.name, sub: 'Открыть в редакторе', value: p.theme === 'custom' && p.theme_custom === t.id ? 'Выбрана' : '',
          onClick: () => openEditor(t),
        })));
        customGrid.hidden = !savedThemes.length;
        customActions.hidden = !savedThemes.length;
        newTheme.setDisabled(savedThemes.length >= App.core.PrefSchema.THEMES_MAX);
        newTheme.setLabel(savedThemes.length >= App.core.PrefSchema.THEMES_MAX ? 'Достигнут лимит тем' : 'Создать свою тему');
        themeNote.textContent = p.theme === 'system'
          ? `Сейчас в системе ${Prefs.systemTheme() === 'light' ? 'светлая' : 'тёмная'} тема. WISP переключится вместе с ней.`
          : p.theme === 'custom' ? `Активная тема: ${themeName(p)}.`
            : p.theme === 'light' ? 'Светлый фон, те же лавандовые акценты.'
              : p.theme === 'black' ? 'Pure Black: полностью чёрный фон, экономит заряд на OLED-экранах.'
                : p.theme === 'midnight' ? 'Midnight: глубокий сине-чёрный фон.'
                  : 'Фирменная тёмная тема WISP.';
        glass.set(p.glass); radius.set(p.radius); scale.set(p.ui_scale);
      }
      const unsub = Prefs.subscribe(() => paint());
      const s = Screen('appearance', 'Внешний вид', null, [
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Готовые темы' }), presetGrid, themeNote),
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Предпросмотр' }), livePreview),
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Свои темы' }), customGrid, customActions, customStart, newTheme, editor),
        Group('Подстройка', [
          SettingControl({ label: 'Прозрачность панелей', sub: 'Меньше значение делает панели плотнее', control: glass }),
          SettingControl({ label: 'Скругления', control: radius }),
          SettingControl({ label: 'Размер интерфейса', control: scale }),
        ], motionNote.textContent),
      ]);
      s.paint = paint;
      s.cleanup = () => { unsub(); if (Prefs.previewing) Prefs.clearPreview(prefs()); };
      paint();
      return s;
    }

    /* ═══════════ Интерфейс ═══════════ */
    function interfaceScreen() {
      const TABS = [
        { id: 'home', label: 'Главная', required: true },
        { id: 'chat', label: 'Чат', required: true },
        { id: 'memory', label: 'Memory', required: false },
        { id: 'tools', label: 'Инструменты', required: false },
      ];
      const BLOCKS = [
        { id: 'greeting', label: 'Приветствие' },
        { id: 'actions', label: 'Быстрые действия' },
        { id: 'composer', label: 'Поле сообщения' },
      ];
      const ACTIONS = [
        { id: 'reminder', label: 'Напоминание' }, { id: 'note', label: 'Заметка' },
        { id: 'task', label: 'Задача' }, { id: 'image', label: 'Изображение' },
        { id: 'event', label: 'Событие' }, { id: 'new_chat', label: 'Новый чат' },
        { id: 'memory', label: 'Память' }, { id: 'history', label: 'История' },
      ];
      function reorderList(key, catalog, label) {
        const list = h('div', { class: 'st-reorder', role: 'list', 'aria-label': label });
        function commit(next) { setPref({ [key]: next }, 'Порядок изменён'); render(); }
        function move(id, delta) {
          const next = prefs()[key].slice();
          const from = next.indexOf(id), to = Math.max(0, Math.min(next.length - 1, from + delta));
          if (from < 0 || from === to) return;
          next.splice(from, 1); next.splice(to, 0, id); commit(next);
        }
        function render() {
          const order = prefs()[key];
          list.replaceChildren(...order.map((id, index) => {
            const item = catalog.find((x) => x.id === id);
            if (!item) return null;
            const up = ui.pressable(h('button', { type: 'button', class: 'st-reorder__move', text: '↑', 'aria-label': `${item.label}: выше`, disabled: index === 0, onClick: () => move(id, -1) }));
            const down = ui.pressable(h('button', { type: 'button', class: 'st-reorder__move', text: '↓', 'aria-label': `${item.label}: ниже`, disabled: index === order.length - 1, onClick: () => move(id, 1) }));
            const row = h('div', { class: 'st-reorder__item', role: 'listitem', draggable: true, dataset: { id } },
              h('span', { class: 'st-reorder__grip', 'aria-hidden': 'true', text: '⠿' }),
              h('span', { class: 'st-reorder__label', text: item.label }),
              h('span', { class: 'st-reorder__actions' }, up, down));
            row.addEventListener('dragstart', (e) => { row.classList.add('is-dragging'); if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', id); } });
            row.addEventListener('dragend', () => row.classList.remove('is-dragging'));
            row.addEventListener('dragover', (e) => { e.preventDefault(); row.classList.add('is-drop-target'); });
            row.addEventListener('dragleave', () => row.classList.remove('is-drop-target'));
            row.addEventListener('drop', (e) => {
              e.preventDefault(); row.classList.remove('is-drop-target');
              const dragged = e.dataTransfer && e.dataTransfer.getData('text/plain');
              if (!dragged || dragged === id) return;
              const next = prefs()[key].filter((x) => x !== dragged);
              const at = next.indexOf(id);
              next.splice(at < 0 ? next.length : at, 0, dragged);
              commit(next);
            });
            return row;
          }));
        }
        render();
        return list;
      }

      const navOrder = reorderList('nav_order', TABS, 'Порядок вкладок');
      const blockOrder = reorderList('home_blocks', BLOCKS, 'Порядок блоков главного экрана');
      const navLabels = Switch({ checked: prefs().nav_labels, label: 'Подписи вкладок', onChange: (v) => setPref({ nav_labels: v }) });
      const navPosition = Kit.Segmented({
        options: [{ id: 'bottom', label: 'Снизу' }, { id: 'side', label: 'Сбоку' }],
        value: prefs().nav_position, label: 'Положение панели', onChange: (v) => setPref({ nav_position: v }),
      });
      const density = Kit.Segmented({
        options: [{ id: 'compact', label: 'Компактный' }, { id: 'standard', label: 'Обычный' }, { id: 'comfortable', label: 'Свободный' }],
        value: prefs().density, label: 'Плотность интерфейса', onChange: (v) => setPref({ density: v }),
      });
      const hiddenTab = (id, label) => Switch({
        checked: !prefs().nav_hidden.includes(id), label: `Показывать вкладку ${label}`,
        onChange: (v) => setPref({ nav_hidden: v ? prefs().nav_hidden.filter((x) => x !== id) : [...prefs().nav_hidden, id] }),
      });
      const tabSwitches = TABS.filter((t) => !t.required).map((t) => Row({ icon: t.id === 'memory' ? 'memory' : 'tools', label: t.label, end: hiddenTab(t.id, t.label) }));
      const hiddenBlock = (id, label) => Switch({
        checked: prefs().home_hidden.includes(id), label: `Скрыть: ${label}`,
        onChange: (v) => setPref({ home_hidden: v ? [...prefs().home_hidden, id] : prefs().home_hidden.filter((x) => x !== id) }),
      });
      const hiddenBlocks = [
        Row({ icon: 'home', label: 'Приветствие', end: hiddenBlock('greeting', 'приветствие') }),
        Row({ icon: 'home', label: 'Подзаголовок', end: hiddenBlock('subtitle', 'подзаголовок') }),
        Row({ icon: 'tools', label: 'Быстрые действия', end: hiddenBlock('actions', 'быстрые действия') }),
        Row({ icon: 'chat', label: 'Подсказки в чате', end: hiddenBlock('suggestions', 'подсказки') }),
        Row({ icon: 'spark', label: 'Значок тарифа', end: hiddenBlock('plan_badge', 'значок тарифа') }),
      ];
      const quickRows = ACTIONS.map((a) => {
        const toggle = Switch({
          checked: prefs().quick_actions.includes(a.id), label: `Быстрое действие: ${a.label}`,
          onChange: (v) => {
            const current = prefs().quick_actions;
            if (v && current.length >= App.core.PrefSchema.QUICK_MAX) {
              setNotice(`На главном экране помещается не больше ${App.core.PrefSchema.QUICK_MAX} действий.`, 'warn');
              return false;
            }
            setPref({ quick_actions: v ? [...current, a.id] : current.filter((x) => x !== a.id) });
            return true;
          },
        });
        return Row({ icon: 'spark', label: a.label, end: toggle });
      });
      const startTab = SelectControl({
        label: 'Стартовый экран', value: prefs().start_tab,
        options: [{ id: 'home', label: 'Главная' }, { id: 'chat', label: 'Чат' }, { id: 'memory', label: 'Memory' }, { id: 'tools', label: 'Инструменты' }, { id: 'last', label: 'Последняя вкладка' }],
        onChange: (v) => setPref({ start_tab: v }),
      });
      const historyView = SelectControl({
        label: 'История диалогов', value: prefs().history_view,
        options: [{ id: 'flat', label: 'Список' }, { id: 'grouped', label: 'По датам' }],
        onChange: (v) => setPref({ history_view: v }),
      });
      const s = Screen('interface', 'Интерфейс', null, [
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Порядок вкладок' }), navOrder, h('p', { class: 'st-note', text: 'Перетаскивай строки или используй стрелки. Главную и чат скрыть нельзя.' })),
        Group('Панель навигации', [
          Row({ icon: 'sliders', label: 'Подписи вкладок', end: navLabels }),
          SettingControl({ label: 'Расположение', sub: 'Боковая панель включается на широком экране', control: navPosition }),
          SettingControl({ label: 'Плотность', sub: 'Компактный режим уменьшает отступы, не размер зоны нажатия', control: density }),
          ...tabSwitches,
        ]),
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Блоки главного экрана' }), blockOrder),
        Group('Что показывать', hiddenBlocks),
        Group('Быстрые действия', quickRows, `До ${App.core.PrefSchema.QUICK_MAX} действий на главном экране.`),
        Group('Запуск и история', [
          SettingControl({ label: 'Стартовый экран', control: startTab }),
          SettingControl({ label: 'История диалогов', control: historyView }),
        ]),
      ]);
      s.paint = () => { navLabels.set(prefs().nav_labels); navPosition.set(prefs().nav_position); density.set(prefs().density); };
      return s;
    }

    /* ═══════════ Эффекты ═══════════ */
    function effectsScreen() {
      const motion = Switch({ checked: prefs().motion === 'reduce', label: 'Уменьшить движение', onChange: (v) => setPref({ motion: v ? 'reduce' : 'system' }) });
      const level = SelectControl({
        label: 'Уровень эффектов', value: prefs().fx_level,
        options: [{ id: 'full', label: 'Полные' }, { id: 'soft', label: 'Мягкие' }, { id: 'off', label: 'Выключены' }],
        onChange: (v) => setPref({ fx_level: v }),
      });
      const speed = SelectControl({
        label: 'Скорость анимации', value: prefs().fx_speed,
        options: [{ id: 'fast', label: 'Быстро' }, { id: 'normal', label: 'Обычно' }, { id: 'slow', label: 'Медленно' }],
        onChange: (v) => setPref({ fx_speed: v }),
      });
      const appear = SelectControl({
        label: 'Появление элементов', value: prefs().fx_appear,
        options: [{ id: 'rise', label: 'Сдвиг вверх' }, { id: 'fade', label: 'Плавное появление' }, { id: 'scale', label: 'Масштаб' }, { id: 'none', label: 'Без анимации' }],
        onChange: (v) => setPref({ fx_appear: v }),
      });
      const glow = RangeControl({ label: 'Свечение', value: prefs().fx_glow, min: 0, max: 150, step: 10, onChange: (v) => setPref({ fx_glow: v }), format: (v) => `${v}%` });
      const blur = RangeControl({ label: 'Размытие стекла', value: prefs().fx_blur, min: 0, max: 150, step: 10, onChange: (v) => setPref({ fx_blur: v }), format: (v) => `${v}%` });
      const note = h('p', { class: 'st-note' });
      function paint() {
        const p = prefs();
        motion.set(p.motion === 'reduce');
        level.value = p.fx_level; speed.value = p.fx_speed; appear.value = p.fx_appear;
        glow.set(p.fx_glow); blur.set(p.fx_blur);
        note.textContent = Prefs.systemReducedMotion()
          ? 'В системе включено уменьшение движения. WISP всегда его уважает.'
          : 'Уровень «Выкл.» отключает переходы и декоративную анимацию.';
      }
      const unsub = Prefs.subscribe(paint);
      const s = Screen('effects', 'Эффекты', null, [
        Group('Анимация', [
          Row({ icon: 'wave', label: 'Уменьшить движение', sub: 'Убирает резкие сдвиги и движение маскота', end: motion }),
          SettingControl({ label: 'Уровень эффектов', control: level }),
          SettingControl({ label: 'Скорость', control: speed }),
          SettingControl({ label: 'Появление', control: appear }),
        ]),
        Group('Свет и стекло', [
          SettingControl({ label: 'Свечение', control: glow }),
          SettingControl({ label: 'Размытие', control: blur }),
        ], 'Свечение и размытие применяются сразу.'),
        note,
      ]);
      s.paint = paint; s.cleanup = unsub; paint();
      return s;
    }

    /* ═══════════ Звук ═══════════ */
    function soundScreen() {
      const all = Switch({ checked: prefs().sound_on, label: 'Звуки WISP', onChange: (v) => setPref({ sound_on: v }) });
      const uiSound = Switch({ checked: prefs().sound_ui, label: 'Звуки нажатий', onChange: (v) => setPref({ sound_ui: v }) });
      const haptics = Switch({ checked: prefs().haptics, label: 'Тактильный отклик', onChange: (v) => setPref({ haptics: v }) });
      const mascot = Switch({ checked: prefs().mascot_react, label: 'Реакции маскота', onChange: (v) => setPref({ mascot_react: v }) });
      const volume = RangeControl({ label: 'Громкость', value: prefs().sound_volume, min: 0, max: 100, step: 5, onChange: (v) => setPref({ sound_volume: v }), format: (v) => `${v}%` });
      const sample = ui.Button({ label: 'Проверить звук', variant: 'secondary', size: 'small', onClick: () => {
        const ok = App.settings.Sound && App.settings.Sound.play('success', { force: true, volume: prefs().sound_volume });
        if (!ok) setNotice('Браузер не поддерживает Web Audio.', 'warn');
      } });
      function paint() {
        all.set(prefs().sound_on); uiSound.set(prefs().sound_ui); haptics.set(prefs().haptics); mascot.set(prefs().mascot_react);
        volume.set(prefs().sound_volume);
        volume.querySelector('input').disabled = !prefs().sound_on;
      }
      const unsub = Prefs.subscribe(paint);
      const s = Screen('sound', 'Звук', null, [
        Group('Отклик', [
          Row({ icon: 'note', label: 'Звуки WISP', sub: 'Короткие сигналы без загружаемых аудиофайлов', end: all }),
          SettingControl({ label: 'Громкость', control: volume }),
          Row({ icon: 'note', label: 'Звуки нажатий', end: uiSound }),
          Row({ icon: 'wave', label: 'Тактильный отклик', sub: 'Если устройство поддерживает вибрацию', end: haptics }),
          Row({ icon: 'spark', label: 'Реакции маскота', end: mascot }),
        ]),
        h('div', { class: 'st-actions' }, sample),
      ]);
      s.paint = paint; s.cleanup = unsub; paint();
      return s;
    }

    /* ═══════════ Чат ═══════════ */
    function chatScreen() {
      const controls = {
        chat_send: SelectControl({ label: 'Отправка сообщения', value: prefs().chat_send,
          options: [{ id: 'auto', label: 'Enter на компьютере' }, { id: 'enter', label: 'Enter везде' }, { id: 'mod', label: 'Ctrl/⌘ + Enter' }],
          onChange: (v) => setPref({ chat_send: v }) }),
        chat_layout: SelectControl({ label: 'Плотность чата', value: prefs().chat_layout,
          options: [{ id: 'airy', label: 'Свободный' }, { id: 'compact', label: 'Компактный' }],
          onChange: (v) => setPref({ chat_layout: v }) }),
        chat_width: SelectControl({ label: 'Ширина сообщений', value: prefs().chat_width,
          options: [{ id: 'normal', label: 'Обычная' }, { id: 'wide', label: 'Широкая' }],
          onChange: (v) => setPref({ chat_width: v }) }),
        chat_text: SelectControl({ label: 'Размер текста', value: prefs().chat_text,
          options: [{ id: 's', label: 'Маленький' }, { id: 'm', label: 'Обычный' }, { id: 'l', label: 'Большой' }, { id: 'xl', label: 'Очень большой' }],
          onChange: (v) => setPref({ chat_text: v }) }),
        chat_time: SelectControl({ label: 'Время сообщений', value: prefs().chat_time,
          options: [{ id: 'auto', label: 'По необходимости' }, { id: 'always', label: 'Всегда' }, { id: 'never', label: 'Не показывать' }],
          onChange: (v) => setPref({ chat_time: v }) }),
        chat_scroll: SelectControl({ label: 'Автопрокрутка', value: prefs().chat_scroll,
          options: [{ id: 'smart', label: 'Умная' }, { id: 'always', label: 'Всегда вниз' }, { id: 'off', label: 'Выключена' }],
          onChange: (v) => setPref({ chat_scroll: v }) }),
        chat_markdown: SelectControl({ label: 'Формат ответов', value: prefs().chat_markdown,
          options: [{ id: 'full', label: 'Markdown' }, { id: 'plain', label: 'Обычный текст' }],
          onChange: (v) => setPref({ chat_markdown: v }) }),
        chat_home_send: SelectControl({ label: 'Сообщение с главного экрана', value: prefs().chat_home_send,
          options: [{ id: 'new', label: 'Новый диалог' }, { id: 'continue', label: 'Продолжить текущий' }],
          onChange: (v) => setPref({ chat_home_send: v }) }),
      };
      const switches = {
        chat_code_hl: Switch({ checked: prefs().chat_code_hl, label: 'Подсветка кода', onChange: (v) => setPref({ chat_code_hl: v }) }),
        chat_restore: Switch({ checked: prefs().chat_restore, label: 'Возвращаться к последнему диалогу', onChange: (v) => setPref({ chat_restore: v }) }),
        chat_drafts: Switch({ checked: prefs().chat_drafts, label: 'Сохранять черновики', onChange: (v) => setPref({ chat_drafts: v }) }),
        chat_starters: Switch({ checked: prefs().chat_starters, label: 'Подсказки для начала', onChange: (v) => setPref({ chat_starters: v }) }),
      };
      const rows = [
        Row({ icon: 'send', label: 'Отправка сообщения', end: controls.chat_send }),
        Row({ icon: 'sliders', label: 'Плотность чата', end: controls.chat_layout }),
        Row({ icon: 'sliders', label: 'Ширина сообщений', end: controls.chat_width }),
        Row({ icon: 'sliders', label: 'Размер текста', end: controls.chat_text }),
        Row({ icon: 'clock', label: 'Время сообщений', end: controls.chat_time }),
        Row({ icon: 'sliders', label: 'Автопрокрутка', end: controls.chat_scroll }),
        Row({ icon: 'chat', label: 'Формат ответов', end: controls.chat_markdown }),
        Row({ icon: 'home', label: 'Отправка с главного экрана', end: controls.chat_home_send }),
        Row({ icon: 'code', label: 'Подсветка кода', end: switches.chat_code_hl }),
        Row({ icon: 'history', label: 'Восстанавливать последний диалог', end: switches.chat_restore }),
        Row({ icon: 'edit', label: 'Сохранять черновики', end: switches.chat_drafts }),
        Row({ icon: 'spark', label: 'Подсказки в пустом чате', end: switches.chat_starters }),
      ];
      const s = Screen('chat', 'Чат', null, [
        Group('Вид и отправка', rows.slice(0, 8)),
        Group('Поведение', rows.slice(8)),
        h('p', { class: 'st-note', text: 'Широкий чат и размер текста особенно заметны на большом экране.' }),
      ]);
      s.paint = () => {
        Object.keys(controls).forEach((k) => { controls[k].value = prefs()[k]; });
        Object.keys(switches).forEach((k) => switches[k].set(prefs()[k]));
      };
      return s;
    }

    /* ═══════════ Язык и время ═══════════ */
    function regionScreen() {
      const language = SelectControl({
        label: 'Язык ответов', value: prefs().reply_lang,
        options: [{ id: 'auto', label: 'Как в разговоре' }, { id: 'ru', label: 'Русский' }, { id: 'en', label: 'English' }],
        onChange: (v) => setPref({ reply_lang: v }),
      });
      const address = Kit.Segmented({
        options: [{ id: 'ty', label: 'На «ты»' }, { id: 'vy', label: 'На «вы»' }],
        value: prefs().address, label: 'Обращение', onChange: (v) => setPref({ address: v }),
      });
      const deviceTz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) { return 'UTC'; } })();
      const timezone = Kit.Input({ value: prefs().timezone, placeholder: deviceTz, label: 'Часовой пояс IANA', autocap: false });
      const tzHint = h('p', { class: 'st-note', text: prefs().timezone ? `Используется ${prefs().timezone}` : `Автоматически: ${deviceTz}` });
      const commitTimezone = () => {
        const value = timezone.value.trim();
        if (value && !App.core.PrefSchema.validTz(value)) {
          tzHint.textContent = 'Неизвестный IANA-пояс. Например: Europe/Moscow или America/Los_Angeles.';
          tzHint.dataset.tone = 'warn';
          timezone.setAttribute('aria-invalid', 'true');
          return;
        }
        timezone.removeAttribute('aria-invalid');
        setPref({ timezone: value });
        tzHint.textContent = value ? `Используется ${value}` : `Автоматически: ${deviceTz}`;
        tzHint.dataset.tone = '';
      };
      timezone.addEventListener('change', commitTimezone);
      timezone.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); timezone.blur(); } });
      const s = Screen('region', 'Язык и время', null, [
        Group('Язык', [SettingControl({ label: 'Язык ответов WISP', sub: 'Авто подстраивается под язык диалога', control: language })]),
        Group('Обращение', [SettingControl({ label: 'Форма обращения', control: address })]),
        Group('Часовой пояс', [SettingControl({ label: 'Часовой пояс', sub: 'Используется для дат, напоминаний и планов', control: timezone }), tzHint]),
      ]);
      s.paint = () => { language.value = prefs().reply_lang; address.set(prefs().address); };
      return s;
    }

    function openResetPreferences(section, label) {
      const err = h('p', { class: 'st-note st-note--warn', hidden: true });
      const reset = Kit.DeleteButton({
        label: `Сбросить ${label}`,
        confirm: 'Нажми ещё раз, чтобы сбросить',
        onConfirm: async (button) => {
          button.setBusy(true); err.hidden = true;
          const patch = App.core.PrefSchema.groupDefaults(section);
          store.update({ preferences: { ...prefs(), ...patch } });
          if (Prefs.previewing) Prefs.clearPreview(prefs());
          button.setBusy(false);
          closeSheet();
          saved(`Сброшено: ${label}`);
        },
      });
      openSheet({ title: `Сбросить «${label}»?`, content: [
        h('p', { class: 'home-sheet__lead', text: `Настройки раздела «${label}» вернутся к значениям по умолчанию.` }),
        h('p', { class: 'home-sheet__note', text: 'Остальные настройки и данные не изменятся.' }),
        err,
        h('div', { class: 'home-sheet__actions' }, reset, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    function openDataReset(section, label, detail) {
      const err = h('p', { class: 'st-note st-note--warn', hidden: true });
      const reset = Kit.DeleteButton({
        label: `Очистить ${label}`,
        confirm: 'Нажми ещё раз, чтобы удалить',
        onConfirm: async (button) => {
          button.setBusy(true); err.hidden = true;
          let r;
          if (section === 'memories') r = memoryApi.clear();
          else r = accountApi.reset(section);
          r = await r;
          button.setBusy(false);
          if (!r.ok) {
            err.hidden = false; err.textContent = Kit.errorText(r.error); director.react('blink');
            return;
          }
          if (section === 'conversations' && chat && chat.resetAfterClear) chat.resetAfterClear();
          if (['notes', 'tasks', 'reminders', 'events'].includes(section) && toolsApi) toolsApi.notify(section);
          closeSheet();
          saved(r.data && r.data.deleted ? `Удалено: ${r.data.deleted}` : `Очищено: ${label}`);
          await loadAccount(true);
          paintAll();
        },
      });
      openSheet({ title: `Очистить ${label}?`, content: [
        h('p', { class: 'home-sheet__lead', text: detail }),
        h('p', { class: 'home-sheet__note', text: 'Это нельзя отменить. Экспортируй данные заранее, если они могут пригодиться.' }),
        err,
        h('div', { class: 'home-sheet__actions' }, reset, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    function openDeleteAccount() {
      if (!assistant.signedIn) {
        if (onOpenAuth) onOpenAuth({ kind: 'login' });
        return;
      }
      const password = Kit.Input({ type: 'password', placeholder: 'Текущий пароль', label: 'Текущий пароль', autocap: false });
      password.autocomplete = 'current-password';
      const err = h('p', { class: 'st-note st-note--warn', hidden: true });
      const del = Kit.DeleteButton({
        label: 'Удалить аккаунт',
        confirm: 'Нажми ещё раз, чтобы удалить',
        onConfirm: async (button) => {
          err.hidden = true;
          if (!password.value) { err.hidden = false; err.textContent = 'Введи текущий пароль.'; password.focus(); return; }
          button.setBusy(true);
          const api = App.auth && App.auth.AuthAPI ? App.auth.AuthAPI(assistant) : null;
          const r = api ? await api.deleteAccount(password.value) : { ok: false, error: { message: 'Удаление аккаунта недоступно.' } };
          button.setBusy(false);
          if (!r.ok) { err.hidden = false; err.textContent = Kit.errorText(r.error); director.react('blink'); return; }
          closeSheet();
          if (onSignedOut) await onSignedOut();
        },
      });
      openSheet({ title: 'Удалить аккаунт WISP?', content: [
        h('p', { class: 'home-sheet__lead', text: 'Аккаунт и все данные на сервере будут удалены без возможности восстановления.' }),
        h('p', { class: 'home-sheet__note', text: 'Введи пароль аккаунта. Текущая сессия завершится.' }),
        h('label', { class: 'tl-field st-field' }, h('span', { class: 'tl-field__label', text: 'Текущий пароль' }), password),
        err,
        h('div', { class: 'home-sheet__actions' }, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    function dataScreen() {
      const summary = h('p', { class: 'st-note' });
      const exportNote = h('p', { class: 'st-note', role: 'status', 'aria-live': 'polite' });
      const exportBtn = ui.Button({ label: 'Скачать архив данных', variant: 'secondary', onClick: async () => {
        exportBtn.setBusy(true); exportNote.textContent = '';
        let payload;
        if (assistant.connected) {
          const r = await accountApi.export();
          if (!r.ok) {
            exportBtn.setBusy(false);
            exportNote.textContent = Kit.errorText(r.error);
            exportNote.dataset.tone = 'warn';
            return;
          }
          payload = r.data;
        } else {
          payload = { exported_at: new Date().toISOString(), profile: store.profile, note: 'Серверные диалоги и данные недоступны без подключения.' };
        }
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = h('a', { href: url, download: `wisp-export-${new Date().toISOString().slice(0, 10)}.json` });
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        exportBtn.setBusy(false);
        exportNote.textContent = 'Файл сохранён. Внутри профиль, настройки, чаты с изображениями, память и записи инструментов.';
        exportNote.dataset.tone = 'ok';
      } });
      const resetDefs = [
        ['appearance', 'Оформление'], ['effects', 'Эффекты'], ['sound', 'Звук'], ['interface', 'Интерфейс'],
        ['chat', 'Чат'], ['behavior', 'Поведение WISP'], ['region', 'Язык и время'], ['notifications', 'Уведомления'], ['voice', 'Голос'],
      ];
      const prefResetRows = resetDefs.map(([section, label]) => Row({
        icon: 'refresh', label: `Сбросить: ${label}`, sub: 'Вернуть значения по умолчанию',
        onClick: () => openResetPreferences(section, label),
      }));
      const dataDefs = [
        ['conversations', 'историю чатов', 'Все диалоги и вложенные изображения будут удалены. Память и записи инструментов останутся.'],
        ['memories', 'память', 'Все воспоминания, включая ожидающие подтверждения, будут удалены.'],
        ['notes', 'заметки', 'Все заметки будут удалены.'],
        ['tasks', 'задачи', 'Все задачи, включая выполненные, будут удалены.'],
        ['reminders', 'напоминания', 'Все напоминания будут удалены.'],
        ['events', 'события плана', 'Все события календаря будут удалены.'],
      ];
      const dataRows = dataDefs.map(([section, label, detail]) => Row({
        icon: 'trash', label: `Очистить ${label}`, sub: detail, tone: 'danger',
        disabled: !assistant.connected,
        onClick: () => openDataReset(section, label, detail),
      }));
      const deleteRow = Row({
        icon: 'trash', label: 'Удалить аккаунт', sub: assistant.signedIn ? 'Удалить аккаунт и все данные на сервере' : 'Доступно после входа в аккаунт',
        tone: 'danger', onClick: () => openDeleteAccount(), chevron: false,
      });
      function paint() {
        const d = account && account.data;
        summary.textContent = d
          ? `На сервере: ${d.conversations} диалогов, ${d.memories} воспоминаний, ${d.notes} заметок, ${d.tasks} задач, ${d.reminders} напоминаний и ${d.events} событий.`
          : assistant.connected ? 'Загружаю сводку данных…' : 'Без сервера доступен только локальный профиль и настройки.';
        dataRows.forEach((row) => {
          const disabled = !assistant.connected;
          row.classList.toggle('is-off', disabled);
          row.disabled = disabled;
        });
        deleteRow.classList.toggle('is-off', !assistant.signedIn);
      }
      const s = Screen('data', 'Данные и сброс', null, [
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Экспорт' }), h('p', { class: 'st-note', text: 'Скачай JSON со своим профилем, настройками, диалогами, изображениями, памятью, заметками, задачами, напоминаниями и событиями.' }), h('div', { class: 'st-actions' }, exportBtn), exportNote),
        summary,
        Group('Сбросить настройки по разделам', prefResetRows),
        Group('Очистить данные по разделам', dataRows, 'Настройки профиля не удаляются. Чтобы сохранить копию, сначала скачай экспорт.'),
        Group('Аккаунт', [deleteRow]),
      ]);
      s.paint = paint;
      if (assistant.connected) loadAccount(true).then(() => { if (!destroyed) paint(); });
      paint();
      return s;
    }

    /* ═══════════ Поведение WISP ═══════════
     * Характер — тот же assistant_personality, что выбирается в знакомстве (Layer 1). Отдельной системы нет. */
    function behaviorScreen() {
      const sample = h('p', { class: 'st-sample__text' });
      const sampleBox = h('div', { class: 'st-sample', 'aria-live': 'polite' }, h('span', { class: 'st-sample__k', text: 'Так WISP поздоровается' }), sample);
      const rows = Profile.PERSONALITIES.map((p) => {
        const row = ui.OptionRow({ title: p.title, desc: p.desc, selected: Profile.effectivePersonality(store.profile).id === p.id,
          onSelect: () => {
            if (store.user.assistant_personality === p.id) return;
            store.update({ assistant_personality: p.id });
            director.react(p.reaction);
            saved('Характер изменён');
            paint();
          } });
        row._id = p.id;
        return row;
      });
      const group = ui.RadioGroup({ label: 'Характер WISP', rows });

      const lenDesc = h('p', { class: 'st-note' });
      const length = Kit.Segmented({ options: LENGTHS.map((o) => ({ id: o.id, label: o.label })), value: prefs().answer_length, label: 'Длина ответов', onChange: (v) => { setPref({ answer_length: v }); paint(); } });
      const styleDesc = h('p', { class: 'st-note' });
      const style = Kit.Segmented({ options: STYLES.map((o) => ({ id: o.id, label: o.label })), value: prefs().answer_style, label: 'Стиль ответов', onChange: (v) => { setPref({ answer_style: v }); paint(); } });

      const useName = Switch({ checked: prefs().use_name, label: 'Обращаться по имени', onChange: (v) => { setPref({ use_name: v }); paint(); } });
      const nameRow = Row({ icon: 'user', label: 'Обращаться по имени', end: useName });
      const personal = Switch({ checked: prefs().personalize, label: 'Учитывать анкету', onChange: (v) => { setPref({ personalize: v }); paint(); } });
      const personalRow = Row({ icon: 'heart', label: 'Учитывать анкету', sub: 'Интересы, занятие и «о себе» из знакомства', end: personal });

      function paint() {
        const cur = Profile.effectivePersonality(store.profile);
        rows.forEach((r) => r.setSelected(r._id === cur.id));
        const p = prefs();
        sample.textContent = `«${cur.sample(p.use_name ? store.user.name : null)}»`;
        length.set(p.answer_length); lenDesc.textContent = LENGTHS.find((o) => o.id === p.answer_length).desc;
        style.set(p.answer_style); styleDesc.textContent = STYLES.find((o) => o.id === p.answer_style).desc;
        useName.set(p.use_name);
        nameRow.setSub(store.user.name ? (p.use_name ? `Иногда, когда это к месту: «${store.user.name}»` : 'Без имени, нейтрально') : 'Имя не указано — его можно добавить в «Аккаунте»');
        personal.set(p.personalize);
      }
      const s = Screen('behavior', 'Поведение WISP', null, [
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Характер' }), group, sampleBox),
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Длина ответов' }), length, lenDesc),
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Стиль ответов' }), style, styleDesc),
        Group('Персонализация', [nameRow, personalRow], 'Изменения действуют со следующего ответа WISP.'),
      ]);
      s.paint = paint;
      paint();
      return s;
    }

    /* ═══════════ Память и приватность ═══════════
     * Выключатели — существующие настройки Layer 5 (users.memory_enabled / memory_suggest) через MemoryAPI. */
    function privacyScreen() {
      const body = h('div');
      const s = Screen('privacy', 'Память и приватность', null, [body]);
      const memOn = Switch({ checked: memSettings ? memSettings.enabled : true, label: 'Долговременная память', onChange: (v) => setMem({ enabled: v }) });
      const sugOn = Switch({ checked: memSettings ? memSettings.suggest : true, label: 'Учиться на разговорах', onChange: (v) => setMem({ suggest: v }) });
      const memRow = Row({ icon: 'memory', label: 'Долговременная память', sub: 'WISP помнит важное между разговорами', end: memOn });
      const sugRow = Row({ icon: 'spark', label: 'Учиться на разговорах', sub: 'Предлагать запомнить важное из чатов. Без твоего «да» ничего не сохраняется', end: sugOn });
      const goMem = Row({ icon: 'search', label: 'Открыть Memory', sub: 'Посмотреть, изменить или удалить воспоминания', onClick: () => openMemory() });
      const histRow = Row({ icon: 'history', label: 'История чатов', sub: 'Хранится на сервере, пока ты её не удалишь', value: '…' });
      const clearRow = Row({ icon: 'trash', label: 'Очистить историю чатов', sub: 'Память, заметки и задачи останутся', tone: 'danger', onClick: () => openClearHistory(), chevron: false });
      const counts = h('p', { class: 'st-note' });

      async function setMem(patch) {
        const r = await memoryApi.setSettings(patch);
        if (!r.ok) { setNotice(Kit.errorText(r.error), 'warn', 4200); director.react('blink'); return false; }
        memSettings = r.data.settings;
        paint();
        saved(patch.enabled === false ? 'Память выключена' : patch.enabled === true ? 'Память включена' : 'Сохранено');
        return true;
      }

      function storageCard() {
        const col = (title, icon, items) => h('div', { class: 'st-store__col' },
          h('p', { class: 'st-store__k' }, ui.icon(icon, 'ds-icon st-store__icon'), h('span', { text: title })),
          h('ul', { class: 'st-list st-list--tight' }, items.map((t) => h('li', { text: t }))));
        return h('div', { class: 'st-store' },
          col('На сервере WISP', 'lock', ['диалоги и картинки из чата', 'долговременная память', 'заметки, задачи, напоминания, планы', 'профиль и настройки']),
          col('На этом устройстве', 'shield', ['копия профиля и настроек', 'черновики сообщений', 'разрешения браузера']));
      }
      const facts = h('ul', { class: 'st-list st-facts' },
        h('li', { text: 'Диалоги, изображения, память, инструменты и профиль хранятся на сервере WISP. Гостевые данные принадлежат этому устройству; данные аккаунта доступны после входа.' }),
        h('li', { text: 'Текст и изображения отправляются выбранному AI-провайдеру только при отправке сообщения. Аудио передаётся на распознавание только после нажатия записи; постоянной записи микрофона нет.' }),
        h('li', { text: 'Предложения памяти без ответа исчезают через 7 дней (в Plus — через 14). Память можно выключить, посмотреть и удалить отдельно.' }),
        h('li', { text: 'Пароли, коды и номера карт WISP не запоминает. Личное — только с отдельного согласия.' }),
        h('li', { text: 'Ключи AI-провайдеров хранятся только на сервере и в браузер не попадают.' }),
        h('li', { text: 'Данные изолированы по аккаунту. Микрофон не записывается постоянно.' }));

      function paint() {
        if (!assistant.connected) {
          body.replaceChildren(
            h('div', { class: 'st-empty' }, ui.icon('wifiOff', 'ds-icon st-empty__icon'),
              h('p', { class: 'st-empty__t', text: 'Память и история чатов работают через сервер WISP' }),
              h('p', { class: 'st-empty__d', text: 'В этой копии сервер не подключён, поэтому WISP ничего не хранит, кроме профиля на устройстве.' })),
            h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Где хранятся данные' }), storageCard(), facts));
          return;
        }
        if (memSettings) { memOn.set(memSettings.enabled); sugOn.set(memSettings.suggest && memSettings.enabled); sugOn.disabled = !memSettings.enabled; }
        const d = account && account.data;
        if (d) {
          histRow.setValue(`${d.conversations} ${plural(d.conversations, 'диалог', 'диалога', 'диалогов')}`);
          goMem.setSub(`${d.memories} ${plural(d.memories, 'воспоминание', 'воспоминания', 'воспоминаний')} · посмотреть, изменить, удалить`);
          counts.textContent = `Сообщений: ${d.messages} · картинок: ${d.images}${d.images_bytes ? ` (${(d.images_bytes / 1048576).toFixed(1).replace('.', ',')} МБ)` : ''}`;
          clearRow.classList.toggle('is-off', !d.conversations);
        }
      }
      const errBox = h('div', { class: 'st-error', hidden: true });
      function showError(e) {
        errBox.hidden = false;
        errBox.replaceChildren(ui.icon('alert', 'ds-icon'), h('span', { text: Kit.errorText(e) }), ui.TextButton({ label: 'Повторить', onClick: () => load(true) }));
      }
      async function load(force) {
        if (!assistant.connected) return;
        body.classList.add('is-loading');
        errBox.hidden = true;
        const [m] = await Promise.all([memoryApi.settings(), loadAccount(force)]);
        if (destroyed) return;
        body.classList.remove('is-loading');
        if (m.ok) { memSettings = m.data.settings; memErr = null; } else { memErr = m.error; }
        if (memErr || accountErr) showError(memErr || accountErr);
        paint();
      }
      if (assistant.connected) {
        body.replaceChildren(errBox,
          Group('Память', [memRow, sugRow, goMem]),
          h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'История чатов' }), h('div', { class: 'st-group' }, histRow, clearRow), counts),
          h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Где хранятся данные' }), storageCard(), facts));
        load(true);
      }
      s.paint = paint;
      s.reload = () => load(true);
      paint();
      return s;
    }

    function openClearHistory() {
      const d = account && account.data;
      const err = h('p', { class: 'st-note st-note--warn', hidden: true });
      const del = Kit.DeleteButton({
        label: 'Очистить историю', confirm: 'Нажми ещё раз, чтобы удалить',
        onConfirm: async (b) => {
          b.setBusy(true); err.hidden = true;
          const r = await accountApi.clearHistory();
          b.setBusy(false);
          if (!r.ok) { err.hidden = false; err.textContent = Kit.errorText(r.error); director.react('blink'); return; }
          if (chat && chat.resetAfterClear) chat.resetAfterClear();
          closeSheet();
          director.react('nod');
          setNotice(r.data.deleted ? `Удалено: ${r.data.deleted} ${plural(r.data.deleted, 'диалог', 'диалога', 'диалогов')}` : 'История уже пуста', 'info', 2800);
          await loadAccount(true);
          paintAll();
        },
      });
      openSheet({ title: 'Очистить историю чатов?', content: [
        h('p', { class: 'home-sheet__lead', text: d ? `Все ${d.conversations} ${plural(d.conversations, 'диалог', 'диалога', 'диалогов')} и картинки в них будут удалены с сервера.` : 'Все диалоги и картинки в них будут удалены с сервера.' }),
        h('p', { class: 'home-sheet__note', text: 'Долговременная память, заметки, задачи и напоминания останутся. Это нельзя отменить.' }),
        err,
        h('div', { class: 'home-sheet__actions' }, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    /* ═══════════ Уведомления ═══════════
     * Разрешение — через Capabilities (Layer 1), напоминания — через планировщик Layer 4. Чего нет, то честно «Пока нет». */
    function notificationsScreen() {
      const permCard = App.home.Sheets.notificationsRow({ store, director });
      const rem = Switch({ checked: prefs().notify_reminders, label: 'Напоминания', onChange: (v) => { setPref({ notify_reminders: v }, v ? 'Уведомления о напоминаниях включены' : 'Уведомления о напоминаниях выключены'); paint(); } });
      const remRow = Row({ icon: 'bell', label: 'Напоминания', sub: 'Системное уведомление в нужную минуту. Внутри открытого WISP напоминание появится всегда', end: rem });
      const tasks = Row({ icon: 'task', label: 'Задачи', sub: 'Уведомления о сроках задач ещё не реализованы', end: Soon() });
      const news = Row({ icon: 'spark', label: 'Общие уведомления WISP', sub: 'Советы и новости WISP ещё не реализованы', end: Soon() });
      tasks.classList.add('is-soon'); news.classList.add('is-soon');
      const test = ui.Button({ label: 'Проверить уведомление', variant: 'secondary', size: 'small', onClick: async () => {
        test.setBusy(true);
        const ok = await testNotification();
        test.setBusy(false);
        setNotice(ok ? 'Отправил тестовое уведомление' : 'Браузер не показал уведомление. Проверь разрешение в настройках.', ok ? 'info' : 'warn', 3600);
      } });
      const testWrap = h('div', { class: 'st-actions' }, test);
      const remNote = h('p', { class: 'st-note' });
      const limits = h('ul', { class: 'st-list st-facts' },
        h('li', { text: 'Напоминания приходят, пока WISP открыт или свёрнут недавно. Закрытое приложение браузер не будит: такие напоминания WISP покажет как пропущенные при следующем открытии.' }),
        Capabilities.env.isIOS ? h('li', { text: 'На iPhone уведомления работают, только если WISP добавлен на экран «Домой» (iOS 16.4 и новее).' }) : null,
        h('li', { text: 'Запрещённые уведомления включаются только в настройках браузера или системы — сайт не может спросить второй раз.' }));
      function perm() { return 'Notification' in window ? Notification.permission : 'unsupported'; }
      function paint() {
        rem.set(prefs().notify_reminders);
        const p = perm();
        testWrap.hidden = p !== 'granted';
        remNote.textContent = p === 'granted' ? '' : p === 'denied' ? 'Уведомления запрещены в браузере — системных напоминаний не будет, пока их не разрешить.' : p === 'default' ? 'Чтобы напоминания приходили системным уведомлением, разреши уведомления выше.' : 'На этом устройстве системные уведомления недоступны — напоминания будут только внутри WISP.';
        remNote.hidden = !remNote.textContent;
      }
      const iv = setInterval(() => { if (open && current() && current().id === 'notifications') paint(); }, 1500);   // разрешение могли выдать в карточке выше
      const s = Screen('notifications', 'Уведомления', null, [
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Разрешение' }), permCard, testWrap),
        Group('Что присылать', [remRow, tasks, news]),
        remNote,
        h('section', { class: 'st-section' }, h('h3', { class: 'tl-h st-h', text: 'Как это работает' }), limits),
      ]);
      s.paint = paint; s.cleanup = () => clearInterval(iv);
      paint();
      return s;
    }
    async function testNotification() {
      if (!('Notification' in window) || Notification.permission !== 'granted') return false;
      const opts = { body: 'Так будут выглядеть напоминания WISP.', tag: 'wisp-test', silent: false };
      try {
        const reg = App.scheduler && App.scheduler.registration ? await App.scheduler.registration() : null;
        if (reg && reg.showNotification) { await reg.showNotification('WISP на связи', opts); return true; }
      } catch (e) { /* падаем на обычный способ */ }
      try { new Notification('WISP на связи', opts); return true; } catch (e) { return false; }
    }

    /* ═══════════ О приложении ═══════════ */
    function aboutScreen() {
      const links = h('div', { class: 'st-group', hidden: true });
      const linksSec = h('section', { class: 'st-section', hidden: true }, h('h3', { class: 'tl-h st-h', text: 'Ссылки' }), links);
      const version = h('span', { class: 'st-about__ver', text: `Версия ${VERSION}` });
      const dev = h('p', { class: 'st-about__dev', hidden: true });
      const aiRow = Row({ icon: 'chip', label: 'AI', value: '…' });
      const serverRow = Row({ icon: 'globe', label: 'Сервер WISP', value: '…' });
      const storeRow = Row({ icon: 'shield', label: 'Где хранятся данные', value: assistant.connected ? 'Сервер' : 'Устройство', onClick: () => push('privacy') });
      function paint() {
        const a = appInfo;
        version.textContent = `Версия ${a && a.version ? a.version : VERSION}`;
        dev.hidden = !(a && a.developer);
        if (a && a.developer) dev.textContent = `Разработчик: ${a.developer}`;
        const items = [];
        if (a && a.telegram) items.push(Row({ icon: 'plane', label: 'Telegram-канал', href: a.telegram }));
        if (a && a.website) items.push(Row({ icon: 'globe', label: 'Сайт', href: a.website }));
        if (a && a.privacy) items.push(Row({ icon: 'lock', label: 'Политика конфиденциальности', href: a.privacy }));
        if (a && a.support) items.push(Row({ icon: 'mail', label: 'Поддержка', value: a.support, href: `mailto:${a.support}` }));
        links.replaceChildren(...items);
        links.hidden = linksSec.hidden = !items.length;
        const st = assistant.state;
        serverRow.setValue(!assistant.connected ? 'Не подключён' : st === 'ready' ? 'На связи' : st === 'connecting' ? 'Подключаюсь…' : 'Нет связи');
        aiRow.setValue(!assistant.connected ? 'Не подключён' : assistant.session ? (assistant.session.ai_connected ? 'Подключён' : 'Нет моделей') : '—');
      }
      const s = Screen('about', 'О приложении', null, [
        h('section', { class: 'st-section st-about' },
          h('span', { class: 'st-about__mark', 'aria-hidden': 'true' }, h('span', { class: 'home-logo__spark st-about__spark' })),
          h('p', { class: 'st-about__name', text: 'WISP' }),
          h('p', { class: 'st-about__tag', text: 'Персональный AI-компаньон' }),
          version, dev),
        linksSec,
        Group('Состояние', [serverRow, aiRow, storeRow]),
      ]);
      s.paint = paint;
      paint();
      loadApp().then(() => !destroyed && paint());
      return s;
    }
    async function loadApp() {
      if (appInfo || !assistant.connected) return appInfo;
      const r = await accountApi.app();
      if (r.ok) appInfo = r.data.app;
      return appInfo;
    }

    /* ═══════════ Стек экранов ═══════════ */
    const BUILD = {
      main: mainScreen, account: accountScreen, appearance: appearanceScreen, interface: interfaceScreen,
      effects: effectsScreen, sound: soundScreen, chat: chatScreen, region: regionScreen, data: dataScreen,
      behavior: behaviorScreen, privacy: privacyScreen, notifications: notificationsScreen, about: aboutScreen,
    };
    const current = () => stack[stack.length - 1] || null;

    function mount(scr, fromRight) {
      if (fromRight) scr.el.classList.add('from-right');
      stackEl.appendChild(scr.el);
      requestAnimationFrame(() => requestAnimationFrame(() => { scr.el.classList.remove('from-right'); scr.el.classList.add('is-current'); }));
      setTimeout(() => { if (scr.bar.titleEl && open) scr.bar.titleEl.focus({ preventScroll: true }); }, 60);
      setTimeout(() => { if (open && current() === scr && onLayout) onLayout(); }, 820);
    }
    function push(id) {
      if (!open || !BUILD[id]) return;
      const prev = current();
      const scr = BUILD[id]();
      if (prev) { prev.el.classList.remove('is-current'); prev.el.classList.add('is-under'); prev.el.inert = true; }
      stack.push(scr);
      mount(scr, true);
      if (hist) hist.push();
      ui.haptic(6);
      requestAnimationFrame(() => onLayout && onLayout());
    }
    function pop() {
      if (stack.length <= 1) return false;
      const scr = stack.pop();
      if (scr.cleanup) scr.cleanup();
      scr.el.classList.remove('is-current'); scr.el.classList.add('to-right');
      setTimeout(() => scr.el.remove(), 480);
      const prev = current();
      prev.el.inert = false; prev.el.classList.remove('is-under'); prev.el.classList.add('is-current');
      if (prev.paint) prev.paint();
      requestAnimationFrame(() => onLayout && onLayout());
      return true;
    }

    function paintAll() { stack.forEach((s) => s.paint && s.paint()); }
    const unsubStore = store.subscribe(() => { if (open && !destroyed) paintAll(); });
    const unsubA = assistant.subscribe(() => { if (open && !destroyed) paintAll(); });

    /* Маскот — в шапке текущего экрана, как в Tools и Memory */
    function measure() {
      const scr = current();
      const slot = scr && scr.bar.mascotEl;
      if (!slot) return null;
      const r = slot.getBoundingClientRect(), rr = root.getBoundingClientRect();
      if (!r.height) return null;
      return { h: 30, cy: r.top - rr.top + r.height / 2, cx: r.left - rr.left + r.width / 2 };
    }

    return {
      el, measure,
      get isOpen() { return open; },
      depth: () => Math.max(0, stack.length - 1),
      open(section) {
        if (destroyed) return;
        if (!open) {
          open = true;
          stack.forEach((s) => s.el.remove()); stack = [];
          el.inert = false; el.removeAttribute('aria-hidden');
          el.classList.add('is-open');
          const main = mainScreen();
          stack.push(main);
          mount(main, false);
          if (assistant.connected) { loadAccount(true).then(() => open && paintAll()); memoryApi.settings().then((r) => { if (r.ok) { memSettings = r.data.settings; if (open) paintAll(); } }); loadApp(); }
        }
        if (section && BUILD[section] && section !== 'main') push(section);
      },
      /* «назад» из истории браузера: сначала экран, потом сам раздел. true — обработано здесь. */
      handlePop() {
        if (!open) return false;
        if (pop()) return true;
        close();
        return true;
      },
      close,
      reloadPrivacy() { stack.forEach((s) => s.reload && s.reload()); },
      destroy() {
        destroyed = true;
        stack.forEach((s) => s.cleanup && s.cleanup());
        unsubStore(); unsubA(); unsubSync();
        clearTimeout(noticeTimer);
        el.remove();
      },
    };

    function close() {
      if (!open) return;
      const scr = current();
      if (document.activeElement && el.contains(document.activeElement)) document.activeElement.blur();
      stack.forEach((s) => s.cleanup && s.cleanup());
      open = false;
      el.classList.remove('is-open');
      el.inert = true; el.setAttribute('aria-hidden', 'true');
      setTimeout(() => { if (!open) { stack.forEach((s) => s.el.remove()); stack = []; } }, 420);
      setNotice(null);
      if (onClose) onClose(scr);
    }
  };

  App.settings.VERSION = VERSION;
  App.settings.AvatarView = AvatarView;
})(window.WispApp);
