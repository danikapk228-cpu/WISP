/* WISP · Layer 6 · Avatar
 * Фото профиля готовится на устройстве: декодирование (с учётом поворота EXIF), квадрат по центру, 256 px, JPEG.
 * Получается data:image/jpeg размером ~15–40 КБ: он хранится в профиле (локально и на сервере), отдельного файла нет.
 * Сервер повторно проверяет формат и размер (server/account/profile.js). */
(function (App) {
  'use strict';
  const { Profile } = App.core;
  App.settings = App.settings || {};

  const MAX_SOURCE = 40 * 1024 * 1024;

  function load(file) {
    const viaImg = () => new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode')); };
      img.src = url;
    });
    if (window.createImageBitmap) return createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => viaImg());
    return viaImg();
  }

  async function fromFile(file) {
    const fail = (reason) => { const e = new Error(reason); e.reason = reason; throw e; };
    if (!file) fail('Файл не выбран.');
    if (!/^image\//.test(file.type || '') && !/\.(jpe?g|png|gif|webp|heic|heif)$/i.test(file.name || '')) fail('Это не изображение.');
    if (file.size > MAX_SOURCE) fail('Файл слишком большой.');
    let img;
    try { img = await load(file); } catch (e) { fail('Не получилось открыть это изображение.'); }
    const w = img.width || img.naturalWidth, h = img.height || img.naturalHeight;
    if (!w || !h) fail('Не получилось открыть это изображение.');
    for (const [size, q] of [[256, 0.86], [224, 0.78], [192, 0.7], [160, 0.62]]) {
      const c = document.createElement('canvas');
      c.width = size; c.height = size;
      const g = c.getContext('2d');
      g.fillStyle = '#16152a';                               // прозрачный PNG: тёмный фон, а не чёрный квадрат
      g.fillRect(0, 0, size, size);
      const side = Math.min(w, h);
      g.imageSmoothingQuality = 'high';
      g.drawImage(img, (w - side) / 2, (h - side) / 2, side, side, 0, 0, size, size);
      const url = c.toDataURL('image/jpeg', q);
      if (url.length <= Profile.AVATAR_MAX && Profile.sanitizeAvatar(url)) { if (img.close) img.close(); return url; }
    }
    fail('Фото получилось слишком большим. Попробуй другое.');
  }

  App.settings.Avatar = { fromFile };
})(window.WispApp);
