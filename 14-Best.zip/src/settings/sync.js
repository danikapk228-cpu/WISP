/* WISP · Layer 6 · Profile sync
 * Профиль и настройки сохраняются в двух местах одного хранилища-цепочки, без дублирующих настроек:
 *  · локальная копия (ProfileRepository → localStorage) — мгновенно, работает и в гостевом режиме (file://, без сервера);
 *  · сервер (PUT /api/profile → SQLite profiles) — для пользователя с сессией; это источник при запуске.
 * При запуске: GET /api/profile → у кого meta.updated_at новее, тот и прав (сервер новее — применяем; устройство новее — отправляем).
 * Между вкладками одного браузера: событие storage. При возврате во вкладку — повторная сверка.
 * Тариф и разрешения браузера на сервер не уходят (сервер их и не принимает).
 * Аккаунтов пока нет, поэтому «между устройствами» = в пределах одной сессии устройства. */
(function (App) {
  'use strict';
  const { Profile, Storage } = App.core;
  App.settings = App.settings || {};

  const PICK = ['name', 'interests', 'occupation', 'about', 'assistant_personality', 'onboarding_completed', 'avatar', 'preferences'];
  function syncable(profile) {
    const p = Profile.toServerPayload(profile);
    const user = {};
    PICK.forEach((k) => { user[k] = p.user[k]; });
    return { schema_version: p.schema_version, user, meta: p.meta };
  }
  const contentKey = (profile) => { const s = syncable(profile); return JSON.stringify(s.user); };
  const stamp = (p) => { const t = Date.parse(p && p.meta && p.meta.updated_at); return Number.isFinite(t) ? t : 0; };
  const meaningful = (p) => !!(p.user.onboarding_completed || p.user.name || p.user.assistant_personality);

  App.settings.ProfileSync = function ({ store, assistant, api }) {
    let state = assistant.connected ? 'pending' : 'local';     // local | pending | saving | saved | error
    let lastError = null, lastSavedAt = null;
    let sent = null;                                         // contentKey того, что лежит на сервере
    let timer = 0, inflight = null, stopped = false, lastPull = 0;
    const listeners = new Set();
    const emit = () => listeners.forEach((fn) => { try { fn(api_()); } catch (e) {} });
    const set = (s, err) => { state = s; lastError = err || null; emit(); };

    async function reconcile() {
      if (stopped || !assistant.connected) return null;
      const s = assistant.ready ? assistant.session : await assistant.bootstrap();
      if (!s || stopped) { if (!stopped) set('error', { code: 'network' }); return null; }
      lastPull = Date.now();
      const r = await api.getProfile();
      if (stopped) return null;
      if (!r.ok) { set('error', r.error); return null; }
      const remote = r.data.profile;
      const local = store.profile;
      if (remote) {
        const rKey = JSON.stringify(remote.user);
        if (rKey === contentKey(local)) { sent = rKey; lastSavedAt = r.data.updated_at; set('saved'); return 'same'; }
        /* A first account login gets its own local namespace. Never let its empty
         * default profile overwrite an existing server profile just because its
         * local timestamp was created a few milliseconds later. */
        if ((assistant.signedIn && meaningful(remote) && !meaningful(local)) || stamp(remote) > stamp(local)) {
          sent = rKey;
          store.adopt({ ...remote, user: { ...remote.user, plan: local.user.plan, permissions: local.user.permissions } });
          lastSavedAt = r.data.updated_at; set('saved');
          return 'pulled';
        }
        if (!meaningful(local) && meaningful(remote)) {
          sent = rKey;
          store.adopt({ ...remote, user: { ...remote.user, plan: local.user.plan, permissions: local.user.permissions } });
          lastSavedAt = r.data.updated_at; set('saved');
          return 'pulled';
        }
        push(0);
        return 'pushed';
      }
      if (meaningful(local)) { push(0); return 'pushed'; }
      set('saved');
      return 'empty';
    }

    function push(delay) {
      if (stopped || !assistant.connected) return;
      clearTimeout(timer);
      timer = setTimeout(send, delay == null ? 600 : delay);
    }
    async function send() {
      if (stopped) return;
      if (inflight) { await inflight; }
      const key = contentKey(store.profile);
      if (key === sent) { if (state !== 'saved') set('saved'); return; }
      set('saving');
      inflight = api.putProfile(syncable(store.profile));
      const r = await inflight;
      inflight = null;
      if (stopped) return;
      if (r.ok) {
        sent = JSON.stringify(r.data.profile.user);
        lastSavedAt = r.data.updated_at;
        set('saved');
        if (contentKey(store.profile) !== sent) push();       // пока летел запрос, поменяли ещё
      } else set('error', r.error);
    }

    /* Изменения профиля → на сервер (с задержкой, чтобы набор имени не слал запрос на каждую букву) */
    const unsub = store.subscribe((p) => { if (!stopped && assistant.connected && contentKey(p) !== sent) { if (state !== 'saving') set('pending'); push(); } });

    /* Другая вкладка этого браузера сохранила профиль: подхватываем без перезагрузки */
    const onStorage = (e) => {
      if (stopped || e.key !== Storage.KEYS.profile || !e.newValue) return;
      try {
        const next = Profile.normalize(JSON.parse(e.newValue));
        if (JSON.stringify(next.user) !== JSON.stringify(store.profile.user) && stamp(next) >= stamp(store.profile)) store.adopt(next, { persist: false });
      } catch (err) { /* чужой формат: игнорируем */ }
    };
    window.addEventListener('storage', onStorage);
    const onVisible = () => { if (!document.hidden && !stopped && assistant.ready && Date.now() - lastPull > 30000) reconcile(); };
    document.addEventListener('visibilitychange', onVisible);
    const onOnline = () => { if (state === 'error') { if (sent == null) reconcile(); else push(0); } };
    window.addEventListener('online', onOnline);

    const ready = assistant.connected ? reconcile() : Promise.resolve(null);

    function api_() {
      return { state, error: lastError, savedAt: lastSavedAt, connected: assistant.connected };
    }
    return {
      ready,
      get state() { return state; },
      status: api_,
      reconcile,
      retry: () => (sent == null ? reconcile() : push(0)),
      flush: () => { clearTimeout(timer); return send(); },
      subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
      stop() {
        stopped = true; clearTimeout(timer); unsub();
        window.removeEventListener('storage', onStorage);
        document.removeEventListener('visibilitychange', onVisible);
        window.removeEventListener('online', onOnline);
      },
    };
  };
})(window.WispApp);
