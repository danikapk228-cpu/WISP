/* WISP · Layer 9 · Account rules (общий файл для браузера и сервера)
 * Одни и те же правила проверяют форму в интерфейсе (подсказки сразу) и запрос на сервере (решение принимает сервер).
 * В браузере: window.WispApp.auth.Rules. На сервере: require('../../src/auth/rules.js').
 *
 * Email: обычный адрес вида имя@домен.зона, до 254 символов, хранится в нижнем регистре.
 * Пароль: от 8 до 128 символов; не из списка самых частых, не повтор и не последовательность, не совпадает с почтой/именем.
 *   Короче 12 символов — нужны хотя бы 3 вида символов (строчные, прописные, цифры, знаки). 12+ — любые символы.
 *   Состав не навязываем сверх этого (рекомендации NIST 800-63B): длинная фраза надёжнее «P@ssw0rd».
 * Имя: 1–32 символа, без управляющих символов (та же нормализация, что у имени в профиле Layer 1). */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.WispApp = root.WispApp || {}; root.WispApp.auth = root.WispApp.auth || {}; root.WispApp.auth.Rules = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const EMAIL_MAX = 254;
  const PASSWORD_MIN = 8;
  const PASSWORD_MAX = 128;
  const NAME_MAX = 32;

  /* Частые пароли и их «улучшения»: сравниваем без регистра и без цифр/знаков в конце */
  const COMMON = new Set([
    'password', 'passw0rd', 'p@ssword', 'p@ssw0rd', 'qwerty', 'qwertyuiop', 'qwerty123', 'qwertyui', 'asdfghjkl', 'asdfgh', 'zxcvbnm',
    '123456', '1234567', '12345678', '123456789', '1234567890', '0987654321', '987654321', '11111111', '00000000', '12341234',
    'iloveyou', 'admin', 'administrator', 'welcome', 'letmein', 'monkey', 'dragon', 'master', 'sunshine', 'princess', 'football',
    'baseball', 'superman', 'batman', 'starwars', 'trustno1', 'whatever', 'shadow', 'michael', 'charlie', 'freedom', 'secret',
    'abc123', 'abcdef', 'abcdefgh', 'changeme', 'default', 'login', 'access', 'hello', 'helloworld', 'wisp', 'wispwisp', 'test',
    'testtest', 'qazwsx', 'qazwsxedc', '1q2w3e4r', '1q2w3e4r5t', '1qaz2wsx', 'zaq12wsx', 'q1w2e3r4', 'aa123456', 'password1',
    'йцукен', 'йцукенгшщз', 'пароль', 'парольпароль', 'привет', 'приветик', 'любовь', 'qwertyqwerty', 'samsung', 'apple', 'iphone',
    'google', 'yandex', 'computer', 'internet', 'killer', 'pokemon', 'minecraft', 'naruto', 'matrix', 'mustang', 'jordan',
  ]);
  const SEQUENCES = ['abcdefghijklmnopqrstuvwxyz', 'qwertyuiopasdfghjklzxcvbnm', '01234567890', 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя', 'йцукенгшщзхъфывапролджэячсмитьбю'];

  const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;

  /* ── Email ── */
  function normalizeEmail(v) {
    if (typeof v !== 'string') return '';
    return v.replace(CONTROL, '').trim().toLowerCase();
  }
  /* Возвращает null, если адрес корректен, иначе код ошибки */
  function emailError(raw) {
    const v = normalizeEmail(raw);
    if (!v) return 'email_required';
    if (v.length > EMAIL_MAX) return 'email_invalid';
    const at = v.lastIndexOf('@');
    if (at < 1 || at !== v.indexOf('@')) return 'email_invalid';
    const local = v.slice(0, at), domain = v.slice(at + 1);
    if (local.length > 64 || !/^[a-z0-9!#$%&'*+/=?^_`{|}~.-]+$/.test(local)) return 'email_invalid';
    if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) return 'email_invalid';
    if (domain.length > 253 || !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:[a-z]{2,63}|xn--[a-z0-9-]{1,59})$/.test(domain)) return 'email_invalid';
    return null;
  }

  /* ── Имя ── */
  function normalizeName(v) {
    if (typeof v !== 'string') return '';
    return v.replace(CONTROL, '').replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, NAME_MAX).trim();
  }
  function nameError(raw) {
    const v = normalizeName(raw);
    if (!v) return 'name_required';
    if (!/[\p{L}\p{N}]/u.test(v)) return 'name_invalid';
    return null;
  }

  /* ── Пароль ── */
  function classes(p) {
    let n = 0;
    if (/\p{Ll}/u.test(p)) n++;
    if (/\p{Lu}/u.test(p)) n++;
    if (/\p{N}/u.test(p)) n++;
    if (/[^\p{L}\p{N}]/u.test(p)) n++;
    return n;
  }
  const lower = (s) => String(s || '').toLowerCase();
  function isSequence(p) {
    const s = lower(p);
    if (/^(.)\1+$/u.test(s)) return true;                                    // ааааааа
    if (/^(.{1,4})\1+$/u.test(s)) return true;                               // abcabcabc, 12121212
    return SEQUENCES.some((seq) => seq.includes(s) || [...seq].reverse().join('').includes(s));
  }
  function isCommon(p) {
    const s = lower(p);
    if (COMMON.has(s)) return true;
    const core = s.replace(/[\d\W_]+$/u, '').replace(/^[\d\W_]+/u, '');      // Password123! → password
    return core.length >= 3 && COMMON.has(core) && s.length - core.length <= 4;
  }

  /* Оценка 0–4 + первая проблема (код). context: { email, name } — пароль не должен их повторять. */
  function passwordCheck(raw, context) {
    const p = typeof raw === 'string' ? raw.normalize('NFKC') : '';
    const ctx = context || {};
    const len = [...p].length;
    if (!len) return { ok: false, score: 0, error: 'password_required' };
    if (len > PASSWORD_MAX) return { ok: false, score: 0, error: 'password_too_long' };
    if (len < PASSWORD_MIN) return { ok: false, score: len >= 6 ? 1 : 0, error: 'password_too_short' };
    if (/^\s|\s$/.test(p)) return { ok: false, score: 1, error: 'password_spaces' };
    if (isCommon(p)) return { ok: false, score: 0, error: 'password_common' };
    if (isSequence(p)) return { ok: false, score: 0, error: 'password_sequence' };
    const local = lower(normalizeEmail(ctx.email).split('@')[0]);
    const name = lower(normalizeName(ctx.name));
    const s = lower(p);
    if ((local.length >= 4 && s.includes(local)) || (name.length >= 4 && s.includes(name))) return { ok: false, score: 1, error: 'password_personal' };
    const c = classes(p);
    const unique = new Set(s).size;
    if (unique < 4) return { ok: false, score: 1, error: 'password_weak' };
    if (len < 12 && c < 3) return { ok: false, score: 1, error: 'password_weak' };
    let score = 2;
    if (len >= 12 && c >= 2) score = 3;
    if ((len >= 16 && c >= 2) || (len >= 12 && c >= 3)) score = 4;
    if (len < 12 && c >= 4) score = 3;
    return { ok: true, score, error: null };
  }

  /* Тексты ошибок: одинаковые в интерфейсе и в ответах сервера. Каждая подсказывает, что сделать дальше. */
  const MESSAGES = {
    email_required: 'Введи адрес электронной почты.',
    email_invalid: 'Похоже, в адресе опечатка. Проверь, что он выглядит как name@example.com.',
    name_required: 'Как к тебе обращаться? Напиши имя.',
    name_invalid: 'В имени должна быть хотя бы одна буква или цифра.',
    password_required: 'Придумай пароль.',
    password_too_short: `Пароль слишком короткий: нужно хотя бы ${PASSWORD_MIN} символов.`,
    password_too_long: `Пароль слишком длинный: максимум ${PASSWORD_MAX} символов.`,
    password_spaces: 'Пароль не должен начинаться или заканчиваться пробелом.',
    password_common: 'Этот пароль слишком часто используют. Придумай свой, например фразу из нескольких слов.',
    password_sequence: 'Повторы и последовательности (1234, aaaa, qwerty) легко подобрать. Придумай другой пароль.',
    password_personal: 'Пароль не должен содержать имя или адрес почты.',
    password_weak: 'Добавь длины (12+ символов) или смешай строчные, прописные буквы, цифры и знаки.',
    password_mismatch: 'Пароли не совпадают. Введи один и тот же пароль дважды.',
  };
  const STRENGTH = ['Очень слабый', 'Слабый', 'Нормальный', 'Хороший', 'Надёжный'];

  return {
    EMAIL_MAX, PASSWORD_MIN, PASSWORD_MAX, NAME_MAX,
    normalizeEmail, emailError, normalizeName, nameError, passwordCheck, MESSAGES, STRENGTH,
    message: (code) => MESSAGES[code] || null,
  };
});
