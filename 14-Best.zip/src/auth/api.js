/* WISP · Layer 9 · Auth API (клиент)
 * Поверх того же AssistantClient: тот же сервер, та же httpOnly-cookie, те же заголовки (X-WISP-Client).
 * Клиент никогда не хранит токен сессии, пароль или user_id: сессию держит браузер в HttpOnly-cookie,
 * а кто пользователь — решает сервер. Ответы 401 этих запросов (например, «неверный пароль») НЕ считаются
 * истёкшей сессией (см. AssistantClient.request: пути /auth/* исключены). */
(function (App) {
  'use strict';
  App.auth = App.auth || {};
  const { timezone } = App.core.Assistant;

  App.auth.AuthAPI = function (assistant) {
    const r = (method, path, body) => assistant.request(method, path, body, { noRetry: true, timeout: 30000 });
    return {
      get available() { return assistant.connected; },
      config: () => r('GET', '/auth/config'),
      register: ({ name, email, password, confirm }) => r('POST', '/auth/register', { name, email, password, password_confirm: confirm }),
      verify: (token) => r('POST', '/auth/verify', { token }),
      resend: (email) => r('POST', '/auth/verify/resend', { email }),
      login: ({ email, password }) => r('POST', '/auth/login', { email, password, timezone: timezone() }),
      logout: () => r('POST', '/auth/logout', {}),
      logoutAll: () => r('POST', '/auth/logout-all', {}),
      sessions: () => r('GET', '/auth/sessions'),
      forgot: (email) => r('POST', '/auth/password/forgot', { email }),
      checkReset: (token) => r('POST', '/auth/password/check', { token }),
      reset: ({ token, password, confirm }) => r('POST', '/auth/password/reset', { token, password, password_confirm: confirm }),
      changePassword: ({ current, password, confirm }) => r('POST', '/auth/password/change', { current, password, password_confirm: confirm }),
      guest: () => r('GET', '/auth/guest'),
      mergeGuest: () => r('POST', '/auth/guest/merge', { confirm: 'merge' }),
      startGuest: () => assistant.startGuest(),
      patchProfile: (patch) => r('PATCH', '/account/profile', patch),
      deleteAccount: (password) => r('POST', '/account/delete', { password }),
      eraseDevice: () => r('POST', '/account/logout', { confirm: 'delete_device_data' }),
    };
  };
})(window.WispApp);
