/* WISP · Layer 9 · Account entry
 * Real account screens over AuthAPI. Session tokens and user IDs never enter the DOM or local storage. */
(function (App) {
  'use strict';
  const ui = App.ui;
  const { h } = ui;
  const Rules = App.auth.Rules;

  const hasGuestData = (g) => !!(g && (g.profile || g.conversations || g.notes || g.tasks || g.reminders || g.events || g.memories));

  App.auth.AuthView = function ({ root, assistant, api, onDone, onGuest, route, offline }) {
    let screen = 'welcome';
    let config = null;
    let busy = false;
    let lastError = null;
    let lastEmail = '';
    let resetToken = route && route.kind === 'reset' ? route.token : '';
    let verifyToken = route && route.kind === 'verify' ? route.token : '';
    let destroyed = false;
    const shell = h('section', {
      class: 'auth-root ds-root',
      role: 'main',
      'aria-label': 'Вход в WISP',
      dataset: { authRoot: '' },
    });
    root.appendChild(shell);

    function control(type, label, name, autocomplete, value) {
      const input = h('input', {
        class: 'auth-field__input',
        type,
        name,
        autocomplete,
        required: true,
        'aria-label': label,
        'data-auth-field': name,
      });
      if (value) input.value = value;
      if (type === 'email') {
        input.inputMode = 'email';
        input.autocapitalize = 'none';
        input.spellcheck = false;
      }
      return h('label', { class: 'auth-field' },
        h('span', { class: 'auth-field__label', text: label }),
        input);
    }

    function note(text, tone) {
      return h('p', { class: `auth-note${tone ? ` auth-note--${tone}` : ''}`, role: 'status', 'aria-live': 'polite', text: text || '' });
    }

    function action(label, fn, variant, id) {
      return ui.pressable(h('button', {
        type: 'button',
        class: `ds-btn ds-btn--${variant || 'primary'} auth-action`,
        'data-auth-action': id || '',
        onClick: fn,
      }, h('span', { text: label })));
    }

    function submit(label, fn) {
      return h('button', {
        type: 'submit',
        class: 'ds-btn ds-btn--primary auth-action',
        'data-auth-action': 'submit',
        disabled: busy,
      }, h('span', { text: busy ? 'Подожди…' : label }));
    }

    function makePage(title, subtitle, body, footer, opts) {
      const o = opts || {};
      const back = o.back === false ? null : ui.IconButton({
        icon: 'back',
        label: 'Назад',
        onClick: () => show(o.backTo || 'welcome'),
      });
      return h('div', { class: 'auth-page' },
        h('header', { class: 'auth-header' },
          back || h('span', { class: 'auth-header__space', 'aria-hidden': 'true' }),
          h('div', { class: 'auth-brand', 'aria-label': 'WISP' },
            h('span', { class: 'home-logo__spark', 'aria-hidden': 'true' }),
            h('span', { text: 'WISP' })),
          h('span', { class: 'auth-header__space', 'aria-hidden': 'true' })),
        h('div', { class: 'auth-scroll' },
          h('div', { class: 'auth-card' },
            h('h1', { class: 'auth-title', tabindex: '-1', text: title }),
            subtitle ? h('p', { class: 'auth-subtitle', text: subtitle }) : null,
            body,
            footer ? h('div', { class: 'auth-footer' }, footer) : null)));
    }

    function show(next, data) {
      if (destroyed) return;
      screen = next;
      lastError = data && data.error ? data.error : null;
      const pages = {
        welcome: welcomePage,
        login: loginPage,
        register: registerPage,
        forgot: forgotPage,
        verifyWait: verifyWaitPage,
        verifyResult: verifyResultPage,
        reset: resetPage,
        tokenError: tokenErrorPage,
        'bad-token': tokenErrorPage,
        merge: mergePage,
        expired: expiredPage,
        offline: offlinePage,
      };
      const page = (pages[next] || welcomePage)(data || {});
      shell.replaceChildren(page);
      requestAnimationFrame(() => {
        const title = shell.querySelector('.auth-title');
        if (title && !ui.reducedMotion()) title.focus({ preventScroll: true });
      });
    }

    function welcomePage() {
      const copy = h('div', { class: 'auth-welcome' },
        h('div', { class: 'auth-wisp-mark', 'aria-hidden': 'true' }, h('span', { class: 'home-logo__spark' })),
        h('p', { class: 'auth-kicker', text: 'Твой AI-компаньон' }),
        h('p', { class: 'auth-welcome__text', text: offline ? 'Сервер пока не отвечает. Можно открыть локальный режим или попробовать позже.' : 'Войди, чтобы продолжить на этом устройстве, или начни как гость.' }));
      const buttons = h('div', { class: 'auth-actions' },
        action('Войти', () => show('login'), 'primary', 'login'),
        config && config.registration
          ? action('Создать аккаунт', () => show('register'), 'secondary', 'register')
          : null,
        config && config.guest_mode && !offline
          ? action('Продолжить как гость', () => continueGuest(), 'ghost', 'guest')
          : null,
        offline
          ? action('Открыть локальный режим', () => onDone(null), 'ghost', 'offline')
          : null,
        offline
          ? action('Попробовать снова', () => loadConfig(true), 'ghost', 'retry')
          : null);
      const err = lastError ? note(lastError.message || 'Нет связи с сервером WISP.', 'error') : null;
      return makePage('WISP', '', [copy, err, buttons], null, { back: false });
    }

    function loginPage(data) {
      const error = data.error || lastError;
      const email = control('email', 'Электронная почта', 'email', 'username', lastEmail);
      const password = control('password', 'Пароль', 'password', 'current-password');
      const form = h('form', { class: 'auth-form', 'data-auth-form': 'login', onSubmit: (e) => { e.preventDefault(); login(email.querySelector('input').value, password.querySelector('input').value); } },
        email, password, error ? note(error.message || 'Не получилось войти.', 'error') : null,
        error && error.code === 'email_not_verified'
          ? ui.TextButton({ label: 'Отправить письмо ещё раз', onClick: () => resend(email.querySelector('input').value) })
          : null,
        submit('Войти', () => {}));
      form.querySelector('[type="submit"]').addEventListener('click', (e) => {
        if (!form.reportValidity()) e.preventDefault();
      });
      const footer = [
        config && config.password_reset ? ui.TextButton({ label: 'Забыл пароль', onClick: () => show('forgot') }) : null,
        config && config.registration ? ui.TextButton({ label: 'Создать аккаунт', onClick: () => show('register') }) : null,
      ].filter(Boolean);
      return makePage('С возвращением', 'Войди в свой аккаунт WISP.', form, footer);
    }

    function registerPage(data) {
      const error = data.error || lastError;
      const name = control('text', 'Имя', 'name', 'given-name');
      const email = control('email', 'Электронная почта', 'email', 'email');
      const password = control('password', 'Пароль', 'password', 'new-password');
      const confirm = control('password', 'Повтори пароль', 'password_confirm', 'new-password');
      const hint = note('От 8 символов. Длинная фраза надёжнее.', '');
      const form = h('form', { class: 'auth-form', 'data-auth-form': 'register', onSubmit: (e) => {
        e.preventDefault();
        register({
          name: name.querySelector('input').value,
          email: email.querySelector('input').value,
          password: password.querySelector('input').value,
          confirm: confirm.querySelector('input').value,
        });
      } }, name, email, password, confirm, hint,
      error ? note(error.message || 'Не получилось создать аккаунт.', 'error') : null,
      submit('Создать аккаунт', () => {}));
      form.querySelector('[type="submit"]').addEventListener('click', (e) => {
        if (!form.reportValidity()) e.preventDefault();
      });
      const footer = [ui.TextButton({ label: 'Уже есть аккаунт? Войти', onClick: () => show('login') })];
      return makePage('Создать аккаунт', 'Пароль и почта останутся только между тобой и сервером WISP.', form, footer);
    }

    function forgotPage(data) {
      const error = data.error || lastError;
      const email = control('email', 'Электронная почта', 'email', 'email', lastEmail);
      const status = data.status ? note(data.status, 'success') : null;
      const form = h('form', { class: 'auth-form', 'data-auth-form': 'forgot', onSubmit: (e) => {
        e.preventDefault();
        forgot(email.querySelector('input').value);
      } }, email, error ? note(error.message || 'Не получилось отправить письмо.', 'error') : null, status, submit('Отправить ссылку', () => {}));
      form.querySelector('[type="submit"]').addEventListener('click', (e) => {
        if (!form.reportValidity()) e.preventDefault();
      });
      return makePage('Восстановить пароль', 'Если аккаунт с таким адресом есть, отправим ссылку для сброса.', form, [
        ui.TextButton({ label: 'Вернуться ко входу', onClick: () => show('login') }),
      ]);
    }

    function verifyWaitPage(data) {
      const sent = data && data.email_sent;
      const message = data && data.message
        ? data.message
        : sent === false
          ? 'Аккаунт сохранён. Письмо может идти несколько минут. Проверь папку «Спам».'
          : 'Открой письмо WISP и подтверди адрес. Войти получится после подтверждения.';
      const resendBtn = ui.TextButton({ label: 'Отправить письмо ещё раз', onClick: () => resend(lastEmail) });
      return makePage('Проверь почту', lastEmail, [
        note(message, 'success'),
        h('p', { class: 'auth-copy', text: `Ссылка действует ${config && config.verify_ttl_hours ? `${config.verify_ttl_hours} ч.` : 'ограниченное время'}.` }),
        resendBtn,
      ], [ui.TextButton({ label: 'Ко входу', onClick: () => show('login') })]);
    }

    function verifyResultPage(data) {
      const error = data.error || lastError;
      return makePage(error ? 'Ссылка не сработала' : 'Почта подтверждена',
        error ? 'Ссылка могла истечь или уже быть использована.' : 'Теперь можно войти в аккаунт.',
        [error ? note(error.message || 'Запроси новое письмо.', 'error') : note(data.message || 'Готово. Почта подтверждена.', 'success')],
        [ui.Button({ label: 'Ко входу', onClick: () => show('login') })]);
    }

    function resetPage(data) {
      const error = data.error || lastError;
      const emailLine = data.email ? note(`Аккаунт: ${data.email}`, '') : null;
      const password = control('password', 'Новый пароль', 'password', 'new-password');
      const confirm = control('password', 'Повтори новый пароль', 'password_confirm', 'new-password');
      const form = h('form', { class: 'auth-form', 'data-auth-form': 'reset', onSubmit: (e) => {
        e.preventDefault();
        reset({
          token: resetToken,
          password: password.querySelector('input').value,
          confirm: confirm.querySelector('input').value,
        });
      } }, emailLine, password, confirm, error ? note(error.message || 'Не получилось изменить пароль.', 'error') : null, submit('Сохранить пароль', () => {}));
      form.querySelector('[type="submit"]').addEventListener('click', (e) => {
        if (!form.reportValidity()) e.preventDefault();
      });
      return makePage('Новый пароль', 'После смены пароля WISP завершит остальные сеансы.', form, [
        ui.TextButton({ label: 'Вернуться ко входу', onClick: () => show('login') }),
      ]);
    }

    function tokenErrorPage(data) {
      return makePage('Ссылка недействительна', data.message || 'Запроси новое письмо и открой самую свежую ссылку.', [
        data.error ? note(data.error.message || 'Ссылка не сработала.', 'error') : null,
      ], [
        config && config.password_reset ? ui.TextButton({ label: 'Сбросить пароль ещё раз', onClick: () => show('forgot') }) : null,
        ui.TextButton({ label: 'Ко входу', onClick: () => show('login') }),
      ]);
    }

    function mergePage(data) {
      const g = data.guest;
      const stats = [
        g.conversations ? `${g.conversations} диалогов` : null,
        g.memories ? `${g.memories} воспоминаний` : null,
        g.notes || g.tasks || g.reminders || g.events ? `${g.notes + g.tasks + g.reminders + g.events} записей в Tools` : null,
        g.profile ? 'профиль и настройки' : null,
      ].filter(Boolean);
      return makePage('Перенести данные?', 'Нашёл данные гостевого режима на этом устройстве.', [
        h('ul', { class: 'auth-list' }, stats.map((x) => h('li', { text: x }))),
        note(data.error && data.error.message, 'error'),
        h('p', { class: 'auth-copy', text: 'Перенос добавит их в аккаунт. Если не переносить, они останутся в гостевом режиме на этом устройстве.' }),
        h('div', { class: 'auth-actions' },
          action(busy ? 'Переношу…' : 'Перенести в аккаунт', () => mergeGuest(), 'primary', 'merge'),
          action('Продолжить без переноса', () => onDone(assistant.session), 'ghost', 'skip-merge')),
      ], null);
    }

    function expiredPage() {
      return makePage('Сеанс закончился', 'Войди снова, чтобы открыть данные аккаунта.', [
        note('Данные аккаунта не удалены.', 'success'),
      ], [ui.Button({ label: 'Войти', onClick: () => show('login') })], { back: false });
    }

    function offlinePage() {
      return makePage('Нет связи с сервером', 'Сохранённый профиль на этом устройстве не потерян.', [
        lastError ? note(lastError.message, 'error') : null,
      ], [
        ui.TextButton({ label: 'Повторить', onClick: () => loadConfig(true) }),
        ui.TextButton({ label: 'Открыть локальный режим', onClick: () => onDone(null) }),
      ], { back: false });
    }

    async function run(fn, failScreen) {
      if (busy || destroyed) return;
      busy = true;
      try { await fn(); }
      catch (e) { show(failScreen || screen, { error: e }); }
      finally { busy = false; }
    }

    async function login(email, password) {
      lastEmail = Rules.normalizeEmail(email);
      const emailError = Rules.emailError(email);
      if (emailError) return show('login', { error: { code: emailError, message: Rules.message(emailError) } });
      if (!password) return show('login', { error: { code: 'password_required', message: Rules.message('password_required') } });
      await run(async () => {
        const r = await api.login({ email: lastEmail, password });
        if (!r.ok) throw r.error;
        assistant.setSession(r.data);
        if (hasGuestData(r.data.guest)) show('merge', { guest: r.data.guest });
        else await onDone(r.data);
      }, 'login');
    }

    async function continueGuest() {
      await run(async () => {
        const r = await onGuest();
        if (!r || !r.ok) throw (r && r.error) || { message: 'Не получилось начать гостевой режим.' };
        await onDone(r.data || assistant.session);
      }, 'welcome');
    }

    async function register(form) {
      lastEmail = Rules.normalizeEmail(form.email);
      const nameErr = Rules.nameError(form.name);
      const emailErr = Rules.emailError(form.email);
      const pass = Rules.passwordCheck(form.password, { email: lastEmail, name: form.name });
      if (nameErr) return show('register', { error: { code: nameErr, message: Rules.message(nameErr) } });
      if (emailErr) return show('register', { error: { code: emailErr, message: Rules.message(emailErr) } });
      if (!pass.ok) return show('register', { error: { code: pass.error, message: Rules.message(pass.error) } });
      if (form.password !== form.confirm) return show('register', { error: { code: 'password_mismatch', message: Rules.message('password_mismatch') } });
      await run(async () => {
        const r = await api.register({ name: Rules.normalizeName(form.name), email: lastEmail, password: form.password, confirm: form.confirm });
        if (!r.ok) throw r.error;
        show('verifyWait', { email: lastEmail, email_sent: r.data.email_sent });
      }, 'register');
    }

    async function resend(email) {
      lastEmail = Rules.normalizeEmail(email || lastEmail);
      const err = Rules.emailError(lastEmail);
      if (err) return show(screen, { error: { code: err, message: Rules.message(err) } });
      await run(async () => {
        const r = await api.resend(lastEmail);
        if (!r.ok) throw r.error;
        show('verifyWait', { email: lastEmail, email_sent: true, message: 'Если адрес ожидает подтверждения, WISP отправил новое письмо.' });
      }, screen);
    }

    async function forgot(email) {
      lastEmail = Rules.normalizeEmail(email);
      const err = Rules.emailError(lastEmail);
      if (err) return show('forgot', { error: { code: err, message: Rules.message(err) } });
      await run(async () => {
        const r = await api.forgot(lastEmail);
        if (!r.ok) throw r.error;
        show('forgot', { status: 'Если аккаунт с таким адресом есть, письмо уже в пути.' });
      }, 'forgot');
    }

    async function reset(form) {
      const pass = Rules.passwordCheck(form.password);
      if (!pass.ok) return show('reset', { error: { code: pass.error, message: Rules.message(pass.error) } });
      if (form.password !== form.confirm) return show('reset', { error: { code: 'password_mismatch', message: Rules.message('password_mismatch') } });
      await run(async () => {
        const r = await api.reset(form);
        if (!r.ok) throw r.error;
        resetToken = '';
        show('verifyResult', { message: 'Пароль сохранён. Теперь войди с новым паролем.' });
      }, 'reset');
    }

    async function mergeGuest() {
      await run(async () => {
        const r = await api.mergeGuest();
        if (!r.ok) throw r.error;
        await onDone(assistant.session, { merged: true });
      }, 'merge');
    }

    async function loadConfig(force) {
      const r = await api.config();
      if (!r.ok) {
        lastError = r.error;
        show(offline ? 'offline' : 'welcome');
        return;
      }
      config = r.data;
      lastError = null;
      if (force) show('welcome');
    }

    async function verifyRoute() {
      if (!verifyToken) return;
      const token = verifyToken;
      verifyToken = '';
      const r = await api.verify(token);
      if (destroyed) return;
      if (!r.ok) show('verifyResult', { error: r.error });
      else show('verifyResult', { message: 'Готово. Почта подтверждена. Теперь войди.' });
      history.replaceState({}, '', location.pathname + location.search);
    }

    async function resetRoute() {
      if (!resetToken) return;
      const r = await api.checkReset(resetToken);
      if (destroyed) return;
      if (!r.ok) {
        show('tokenError', { error: r.error });
        history.replaceState({}, '', location.pathname + location.search);
      } else {
        show('reset', { email: r.data.email_hint });
      }
    }

    loadConfig().then(async () => {
      if (verifyToken) await verifyRoute();
      else if (resetToken) await resetRoute();
      else if (route && route.kind === 'forgot') show('forgot');
      else if (route && route.kind === 'login') show('login');
      else if (route && route.kind === 'register') show(config && config.registration ? 'register' : 'welcome');
      else if (route && route.kind === 'expired') show('expired');
      else if (!assistant.connected || offline) show('offline');
      else show('welcome');
    });

    return {
      el: shell,
      destroy() { destroyed = true; shell.remove(); },
      show,
    };
  };
})(window.WispApp);
