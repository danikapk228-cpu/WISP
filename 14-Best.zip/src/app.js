/* WISP · App bootstrap
 * Account profiles and chat drafts are namespaced by server user ID; guest data stays device-local. */
(function (App) {
  'use strict';
  const { Storage, ProfileStore, Assistant, ToolsAPI, MemoryAPI } = App.core;
  const { MascotDirector, Onboarding, Flow } = App.onboarding;

  const root = document.getElementById('wisp-app');
  const stage = document.querySelector('[data-wisp-entrance]');
  if (!root) return;
  root.classList.add('app-root');

  const director = new MascotDirector(stage, root);
  const assistant = Assistant.fromDocument();
  const toolsApi = ToolsAPI(assistant);
  const memoryApi = MemoryAPI(assistant);
  const authApi = App.auth.AuthAPI(assistant);
  const accountApi = App.settings.AccountAPI(assistant);
  App.assistant = assistant;
  App.toolsApi = toolsApi;
  App.memoryApi = memoryApi;
  App.scheduler = null;
  let adapter = null, store = null, progress = null, chatState = null;
  let profileSync = null, stopPrefsWatch = null;
  let home = null, scheduler = null, authView = null;
  let workspaceUserId = null, entranceShown = false, planExpiryTimer = 0;

  /* Тариф — только с сервера. Обновляем сессию в момент окончания Plus, без перезагрузки. */
  function schedulePlanRefresh() {
    clearTimeout(planExpiryTimer);
    const sub = assistant.session && assistant.session.subscription;
    const end = sub && Number(sub.expires_at);
    if (!Number.isFinite(end) || end <= 0) return;
    const wait = Math.max(0, end - Date.now() + 250);
    planExpiryTimer = setTimeout(async () => {
      const r = await assistant.refreshSession();
      if (!r.ok && assistant.session) {
        planExpiryTimer = setTimeout(schedulePlanRefresh, 60 * 1000);
        return;
      }
      schedulePlanRefresh();
    }, Math.min(wait, 2147480000));
  }
  assistant.subscribe((a) => {
    const s = a.session;
    if (store && workspaceUserId && s && s.user && s.user.id === workspaceUserId) {
      const plan = s.user.plan;
      if (plan && store.user.plan !== plan) store.update({ plan });
    }
    schedulePlanRefresh();
  });

  /* Клавиатура на iPhone: подгоняем корень под видимую область. */
  const vv = window.visualViewport;
  let maxH = 0, lastH = 0, lastOff = 0;
  function fit() {
    const height = vv ? vv.height : window.innerHeight;
    const offset = vv ? vv.offsetTop : 0;
    maxH = Math.max(maxH, height);
    root.style.height = height + 'px';
    root.style.transform = offset ? `translate3d(0, ${offset}px, 0)` : '';
    root._vvOffset = offset;
    const a = document.activeElement;
    const typing = a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA');
    const kb = !!typing && height < maxH * 0.8;
    root.classList.toggle('is-kb', kb);
    if (kb !== director.keyboard) director.setKeyboard(kb);
    else if (height !== lastH || offset !== lastOff) director.apply(true);
    lastH = height; lastOff = offset;
  }
  if (vv) { vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); }
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', () => { maxH = 0; setTimeout(fit, 300); });
  document.addEventListener('focusin', () => setTimeout(fit, 60));
  document.addEventListener('focusout', () => setTimeout(() => { window.scrollTo(0, 0); fit(); }, 60));

  function entranceSettled() {
    return new Promise((resolve) => {
      if (!stage || !window.WISP || window.WISP.settled) return resolve();
      stage.addEventListener('wisp:settled', () => resolve(), { once: true });
      setTimeout(resolve, 7000);
    });
  }

  function routeFromHash() {
    const hash = String(location.hash || '').replace(/^#\/?/, '');
    if (!hash) return null;
    const [kind, token] = hash.split('/');
    if (kind === 'verify' || kind === 'reset') {
      return token && /^[A-Za-z0-9_-]{40,64}$/.test(token) ? { kind, token } : { kind: 'bad-token' };
    }
    if (['login', 'register', 'forgot'].includes(kind)) return { kind };
    return null;
  }

  async function stopWorkspace() {
    if (home) { home.destroy(); home = null; }
    if (scheduler) { scheduler.destroy(); scheduler = null; }
    App.scheduler = null;
    if (profileSync) { profileSync.stop(); profileSync = null; }
    if (stopPrefsWatch) { stopPrefsWatch(); stopPrefsWatch = null; }
  }

  async function activateWorkspace(session) {
    await stopWorkspace();
    workspaceUserId = session && session.user && session.user.id || null;
    const prefix = session && session.kind === 'account' && workspaceUserId
      ? `wisp:account:${String(workspaceUserId).replace(/[^A-Za-z0-9_-]/g, '')}:`
      : '';
    try {
      const activeProfileKey = prefix ? `${prefix}${Storage.KEYS.profile}` : Storage.KEYS.profile;
      window.localStorage.setItem('wisp:active-profile:v1', activeProfileKey);
    } catch (e) { /* Storage can be unavailable in private browsing. */ }
    adapter = new Storage.LocalStorageAdapter(prefix);
    store = new ProfileStore(new Storage.ProfileRepository(adapter));
    progress = new Storage.ProgressRepository(adapter);
    chatState = new Storage.ChatStateRepository(adapter);
    await store.init();
    await chatState.load();
    App.store = store;
    if (App.settings.Prefs) stopPrefsWatch = App.settings.Prefs.watch(store);
    if (session && assistant.connected) {
      profileSync = App.settings.ProfileSync({ store, assistant, api: accountApi });
      await profileSync.ready;
    }
  }

  function startOnboarding(mode, step) {
    const ob = new Onboarding({
      root, store, progress, director, mode, startStep: step,
      onComplete: showHome,
    });
    ob.mount();
  }

  function showHome() {
    if (!store) return;
    progress.clear();
    home = App.home.Home({
      root, store, director, assistant, chatState, toolsApi, memoryApi, accountApi, profileSync,
      onEdit: () => { home = null; startOnboarding('edit', 'name'); },
      onReset: async () => { home = null; await store.reset(); await progress.clear(); assistant.refreshSession(); startOnboarding('first', 'welcome'); },
      onOpenAuth: (route) => showAuth(route || { kind: 'login' }),
      onSignedOut: async () => {
        assistant.signOut();
        const r = await authApi.startGuest();
        if (r.ok) {
          await activateWorkspace(r.data);
          await showApp();
        } else {
          await stopWorkspace();
          await activateWorkspace(null);
          showAuth({ kind: 'login' }, true);
        }
      },
    });
    if (!scheduler && toolsApi.available && assistant.ready) {
      scheduler = App.tools.Scheduler({ api: toolsApi, assistant, root, director, onOpen: () => home && home.openTool('reminders') });
      App.scheduler = scheduler;
    }
  }

  async function showApp() {
    if (!store) return;
    const saved = await progress.load();
    if (!entranceShown) {
      fit();
      await entranceSettled();
      await new Promise((r) => setTimeout(r, App.ui.reducedMotion() ? 0 : 360));
      entranceShown = true;
    }
    if (store.user.onboarding_completed) return showHome();
    const step = saved && Flow.has(saved.step) ? saved.step : 'welcome';
    startOnboarding(saved ? saved.mode : 'first', step);
  }

  function showAuth(route, offline) {
    if (home) { home.destroy(); home = null; }
    if (scheduler) { scheduler.destroy(); scheduler = null; }
    if (profileSync) { profileSync.stop(); profileSync = null; }
    if (authView) authView.destroy();
    authView = App.auth.AuthView({
      root, assistant, api: authApi, route, offline: !!offline,
      onGuest: async () => {
        const r = await authApi.startGuest();
        if (!r.ok) throw r.error;
        return r;
      },
      onDone: async (session) => {
        if (authView) { authView.destroy(); authView = null; }
        await activateWorkspace(session || null);
        await showApp();
      },
    });
  }

  assistant.onAuthLost = () => {
    stopWorkspace().then(() => {
      activateWorkspace(null).then(() => showAuth({ kind: 'expired' }));
    });
  };

  (async function boot() {
    const route = routeFromHash();
    const session = assistant.connected ? await assistant.bootstrap() : null;
    if (session) {
      await activateWorkspace(session);
      await showApp();
      if (route && route.kind !== 'login' && route.kind !== 'register') showAuth(route);
      return;
    }
    if (!assistant.connected) {
      await activateWorkspace(null);
      await showApp();
      return;
    }
    await activateWorkspace(null);
    if (assistant.state === 'server_down') {
      showAuth(route || null, true);
      return;
    }
    showAuth(route);
  })();
})(window.WispApp);
