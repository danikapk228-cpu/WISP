/* WISP · Home · Composer
 * Большая строка ввода: растёт под текст, отправка, голосовой ввод с честным состоянием доступности,
 * подсказки для начала разговора (появляются, когда поле в фокусе и пустое).
 * Layer 3 (чат) использует тот же компонент с дополнительными возможностями:
 *   attach      — кнопка «прикрепить изображение» (+ вставка картинки из буфера обмена);
 *   canSendEmpty — можно отправить без текста (например, только картинку);
 *   setGenerating(true) — кнопка отправки превращается в «остановить ответ» (onStop);
 *   onInput     — для сохранения черновика. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Dictation } = App.core;

  const MAX_H = 148;
  const MIN_H = 42;

  App.home.Composer = function ({ placeholder, suggestions, getMicSaved, onMicStatus, onSend, onNotice, attach, canSendEmpty, onInput, onStop, label, voiceInput }) {
    const ta = h('textarea', {
      class: 'home-composer__input', rows: 1, placeholder, 'aria-label': label || 'Сообщение для WISP',
      enterKeyHint: ui.finePointer() ? 'send' : 'enter', autocapitalize: 'sentences', spellcheck: 'true', maxLength: 16000,
    });
    const sendIcon = ui.icon('send');
    const stopSendIcon = ui.icon('stop');
    const send = ui.pressable(h('button', { type: 'button', class: 'home-send', 'aria-label': 'Отправить', disabled: true }, sendIcon));
    const micIcon = ui.icon('mic');
    const stopIcon = ui.icon('stop');
    const mic = ui.pressable(h('button', { type: 'button', class: 'home-mic', 'aria-label': 'Голосовой ввод' }, micIcon));

    /* прикрепление изображения (Layer 3) */
    let file = null, attachBtn = null;
    if (attach) {
      file = h('input', { type: 'file', accept: 'image/*', multiple: true, class: 'ds-sr', tabindex: '-1', 'aria-hidden': 'true' });
      file.addEventListener('change', () => { const list = [...(file.files || [])]; file.value = ''; if (list.length) attach.onPick(list); });
      attachBtn = ui.pressable(h('button', { type: 'button', class: 'home-attach', 'aria-label': 'Прикрепить изображение' }, ui.icon('imageAdd')));
      attachBtn.addEventListener('click', () => pick());
    }
    function pick() {
      if (!file) return false;
      if (attach.canAttach) {
        const r = attach.canAttach();
        if (r !== true) { onNotice && onNotice(r, 'warn'); return false; }
      }
      file.click();                                            // синхронно в обработчике нажатия: иначе iOS не откроет выбор
      return true;
    }

    const bar = h('div', { class: 'home-composer__bar' }, attachBtn, ta, mic, send, file);
    const list = suggestions || [];
    const chips = list.map((text) => ui.pressable(h('button', {
      type: 'button', class: 'home-suggest__chip', text,
      onPointerdown: (e) => e.preventDefault(),                 // не теряем фокус поля → клавиатура не прыгает
      onClick: () => { setValue(text); ta.focus({ preventScroll: true }); },
    })));
    const suggest = list.length ? h('div', { class: 'home-suggest', role: 'group', 'aria-label': 'С чего начать' }, chips) : null;
    const tray = h('div', { class: 'home-composer__tray', hidden: true });
    const el = h('div', { class: `home-composer${attach ? ' has-attach' : ''}` }, suggest, tray, bar);

    let busy = false;
    let generating = false;
    let micState = { state: 'ready' };
    let dict = null;

    const fine = () => ui.finePointer();
    function autosize() {
      if (!ta.isConnected) return;
      ta.style.height = 'auto';
      const next = ta.value ? Math.min(MAX_H, Math.max(MIN_H, ta.scrollHeight)) : MIN_H;   // пустое поле: всегда одна строка
      ta.style.height = next + 'px';
      ta.classList.toggle('is-scroll', ta.scrollHeight > MAX_H);
    }
    function sync() {
      const has = ta.value.trim().length > 0 || (canSendEmpty ? !!canSendEmpty() : false);
      send.disabled = generating ? false : (busy || !has);
      el.classList.toggle('has-text', ta.value.trim().length > 0);
      autosize();
    }
    function setValue(v) { ta.value = v; sync(); ta.setSelectionRange(ta.value.length, ta.value.length); }

    async function submit() {
      if (generating) return;
      const text = ta.value.trim();
      const allowEmpty = canSendEmpty ? !!canSendEmpty() : false;
      if ((!text && !allowEmpty) || busy) return;
      if (dict && dict.active) dict.stop();
      setBusy(true);
      try {
        const ok = await onSend(text);
        if (ok) { ta.value = ''; sync(); onInput && onInput(''); }
      } finally { setBusy(false); }
    }
    function setBusy(v) { busy = !!v; el.classList.toggle('is-busy', busy); send.setAttribute('aria-busy', busy ? 'true' : 'false'); sync(); }
    function setGenerating(v) {
      generating = !!v;
      el.classList.toggle('is-generating', generating);
      send.replaceChild(generating ? stopSendIcon : sendIcon, send.firstChild);
      send.setAttribute('aria-label', generating ? 'Остановить ответ' : 'Отправить');
      sync();
    }

    ta.addEventListener('input', () => { sync(); onInput && onInput(ta.value); });
    /* Layer 13 · «Чат → Отправка»:
     *  auto  — на компьютере Enter отправляет (Shift+Enter: новая строка), на телефоне Enter переносит строку;
     *  enter — Enter отправляет везде, Shift+Enter — новая строка;
     *  mod   — Ctrl/⌘+Enter отправляет, Enter — новая строка. */
    const sendMode = () => { const P = App.settings && App.settings.Prefs; return (P && P.get().chat_send) || 'auto'; };
    function keySends(e) {
      if (e.key !== 'Enter' || e.isComposing || e.keyCode === 229) return false;
      const mode = sendMode();
      if (mode === 'mod') return e.ctrlKey || e.metaKey;
      if (e.shiftKey) return false;
      if (mode === 'enter') return true;
      return fine() || e.ctrlKey || e.metaKey;
    }
    ta.addEventListener('keydown', (e) => {
      if (keySends(e)) { e.preventDefault(); submit(); }
    });
    ta.addEventListener('focus', () => {
      const mode = sendMode();
      ta.enterKeyHint = mode === 'enter' || (mode === 'auto' && fine()) ? 'send' : 'enter';
    });
    ta.addEventListener('focus', () => el.classList.add('is-focus'));
    ta.addEventListener('blur', () => el.classList.remove('is-focus'));
    if (attach) {
      ta.addEventListener('paste', (e) => {
        const items = [...((e.clipboardData && e.clipboardData.files) || [])].filter((f) => /^image\//.test(f.type));
        if (!items.length) return;
        e.preventDefault();
        if (attach.canAttach) { const r = attach.canAttach(); if (r !== true) { onNotice && onNotice(r, 'warn'); return; } }
        attach.onPick(items);
      });
    }
    send.addEventListener('click', () => { if (generating) { onStop && onStop(); return; } submit(); });

    /* ── голосовой ввод: Home использует Web Speech API, чат может передать запись на сервер ── */
    function setMicMode(state, reason) {
      const active = state === 'listening';
      const unavailable = state === 'unavailable';
      const processing = ['starting', 'stopping', 'processing'].includes(state);
      el.classList.toggle('is-listening', active);
      mic.classList.toggle('is-unavailable', unavailable);
      mic.disabled = processing || unavailable;
      mic.setAttribute('aria-disabled', mic.disabled ? 'true' : 'false');
      mic.setAttribute('aria-pressed', active ? 'true' : 'false');
      mic.setAttribute('aria-label', active ? 'Остановить запись' : processing ? 'Распознаю запись' : 'Голосовой ввод');
      mic.replaceChild(active ? stopIcon : micIcon, mic.firstChild);
      mic.title = reason || (active ? 'Остановить запись' : processing ? 'Распознаю запись…' : unavailable ? 'Голосовой ввод недоступен' : 'Голосовой ввод');
      micState = { state, reason: reason || '' };
    }

    if (voiceInput) {
      mic.addEventListener('click', () => voiceInput.onToggle && voiceInput.onToggle());
      setMicMode(voiceInput.unavailable ? 'unavailable' : 'idle', voiceInput.reason || '');
    } else {
      let base = '';
      dict = Dictation.create({
        lang: 'ru-RU',
        onState: (s) => {
          const on = s === 'listening';
          el.classList.toggle('is-listening', on);
          mic.setAttribute('aria-pressed', on ? 'true' : 'false');
          mic.setAttribute('aria-label', on ? 'Остановить голосовой ввод' : 'Голосовой ввод');
          mic.replaceChild(on ? stopIcon : micIcon, mic.firstChild);
          if (on) { onMicStatus && onMicStatus('granted'); onNotice && onNotice('Слушаю… Нажми ещё раз, чтобы закончить.', 'info', 0); }
          else onNotice && onNotice(null);
        },
        onText: (fin, interim) => {
          const sep = base && !/\s$/.test(base) ? ' ' : '';
          ta.value = (base + sep + fin + interim).slice(0, 16000);
          sync();
          onInput && onInput(ta.value);
        },
        onError: (code, message) => {
          if (code === 'not-allowed') { onMicStatus && onMicStatus('denied'); paintMic({ state: 'denied', reason: message }); }
          if (code === 'audio-capture') onMicStatus && onMicStatus('unavailable');
          onNotice && onNotice(message, 'warn');
        },
      });
      function paintMic(a) {
        micState = a;
        const off = a.state !== 'ready';
        mic.classList.toggle('is-unavailable', off);
        mic.setAttribute('aria-disabled', off ? 'true' : 'false');
        mic.title = off ? a.reason : 'Голосовой ввод';
      }
      mic.addEventListener('click', async () => {
        if (dict.active) { dict.stop(); return; }
        if (micState.state !== 'ready') {
          // состояние могло измениться в настройках браузера: перепроверяем перед отказом
          paintMic(await Dictation.availability(getMicSaved()));
          if (micState.state !== 'ready') { onNotice && onNotice(micState.reason, 'warn'); return; }
        }
        base = ta.value;
        dict.start();
      });
      Dictation.availability(getMicSaved()).then(paintMic);
    }
    sync();
    requestAnimationFrame(sync);                           // высота считается, когда поле уже в документе

    return {
      el, textarea: ta, tray,
      focus: () => ta.focus({ preventScroll: true }),
      setValue,
      get value() { return ta.value; },
      refresh: sync,
      pick,
      setGenerating,
      setAttachAvailable: (ok, reason) => { if (attachBtn) { attachBtn.classList.toggle('is-unavailable', !ok); attachBtn.title = ok ? 'Прикрепить изображение' : reason || ''; } },
      setMicState: setMicMode,
      stop: () => {
        if (voiceInput) { if (voiceInput.onCancel) voiceInput.onCancel(); }
        else if (dict && dict.active) dict.stop();
      },
    };
  };
})(window.WispApp);
