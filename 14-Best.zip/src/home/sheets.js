/* WISP · Home · Sheets
 * Содержимое панелей главного экрана: профиль, тариф, быстрые действия.
 * Каждая панель показывает только то, что реально работает; остальное честно помечено «появится позже».
 * Layer 4: notificationsRow переиспользуется экраном Reminders, imageContent — инструментом Image understanding. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Profile, Capabilities } = App.core;

  const soonPill = (text) => h('span', { class: 'ds-pill ds-pill--off home-soon', text: text || 'Появится позже' });

  /* Быстрые действия: один источник для главного экрана и вкладки Tools */
  /* Layer 4: напоминание, заметка и задача открывают настоящий инструмент (tool), а не панель «появится позже» */
  const ACTIONS = [
    { id: 'reminder', icon: 'bell', label: 'Напоминание', title: 'Напоминания', tool: 'reminders',
      text: 'Скажи, о чём и когда напомнить, и я напишу тебе в нужный момент.' },
    { id: 'note', icon: 'notes', label: 'Заметка', title: 'Заметки', tool: 'notes',
      text: 'Быстро записать мысль, а я помогу разложить заметки по полочкам.' },
    { id: 'task', icon: 'task', label: 'Задача', title: 'Задачи', tool: 'tasks',
      text: 'Дела со сроками и приоритетами. Подскажу, с чего начать и что можно отложить.' },
    { id: 'image', icon: 'image', label: 'Изображение', title: 'Изображения',
      text: 'Покажи картинку, и я помогу её разобрать. Или опиши, что нарисовать.', live: true },
  ];

  function initial(name) {
    const ch = name ? Array.from(name.trim())[0] : '';
    return ch ? ch.toLocaleUpperCase('ru') : '';
  }
  function Avatar(user, size) {
    const letter = initial(user.name);
    const hasPhoto = !!(user && user.avatar);
    return h('span', {
      class: `home-avatar${size === 'large' ? ' home-avatar--large' : ''}${hasPhoto ? ' has-photo' : ''}`,
      'aria-hidden': 'true',
    }, hasPhoto
      ? h('img', { src: user.avatar, alt: '', decoding: 'async' })
      : letter ? h('span', { class: 'home-avatar__letter', text: letter }) : ui.icon('user', 'ds-icon home-avatar__icon'));
  }

  function lead(text) { return h('p', { class: 'home-sheet__lead', text }); }

  /* ── Быстрое действие ── */
  function actionContent(action, ctx) {
    const v = ctx.voice();
    if (action.live) return imageContent(action, ctx);
    const parts = [
      h('div', { class: 'home-sheet__hero' },
        h('span', { class: 'home-sheet__icon' }, ui.icon(action.icon)),
        soonPill()),
      lead(action.text),
      h('p', { class: 'home-sheet__note', text: v.soon + ' Пока здесь ничего не сохраняется.' }),
    ];
    if (action.id === 'reminder') parts.push(notificationsRow(ctx));
    parts.push(h('div', { class: 'home-sheet__actions' }, ui.Button({ label: 'Понятно', variant: 'secondary', onClick: () => ctx.close() })));
    return parts;
  }

  /* Layer 3: картинку уже можно показать WISP в чате. Рисование пока не подключено, и об этом сказано честно. */
  function imageContent(action, ctx) {
    const a = ctx.assistant;
    const s = a && a.session;
    const vision = !!(s && s.models.some((m) => m.vision && m.available && m.allowed));
    const parts = [
      h('div', { class: 'home-sheet__hero' }, h('span', { class: 'home-sheet__icon' }, ui.icon(action.icon))),
      h('p', { class: 'home-sheet__lead', text: 'Прикрепи изображение в чате, и я помогу его разобрать.' }),
      h('p', { class: 'home-sheet__note', text: vision ? 'Создание картинок по описанию появится позже.' : 'Сейчас на сервере нет модели, которая понимает изображения. Создание картинок появится позже.' }),
    ];
    const actions = h('div', { class: 'home-sheet__actions' });
    if (vision) actions.appendChild(ui.Button({ label: 'Прикрепить изображение', onClick: () => ctx.attachInChat() }));
    actions.appendChild(ui.Button({ label: vision ? 'Открыть чат' : 'Понятно', variant: vision ? 'ghost' : 'secondary', onClick: () => (vision ? ctx.openChat() : ctx.close()) }));
    parts.push(actions);
    return parts;
  }

  /* Напоминаниям понадобятся уведомления: это уже можно включить по-настоящему */
  function notificationsRow(ctx) {
    const cap = Capabilities.get('notifications');
    const pill = ui.StatusPill('prompt');
    const reason = h('p', { class: 'home-cap__reason' });
    const btn = ui.Button({ label: cap.action, variant: 'secondary', size: 'small', onClick: ask });
    btn.hidden = true;
    const row = h('section', { class: 'home-cap ds-glass', 'aria-label': cap.title },
      h('div', { class: 'home-cap__head' },
        h('span', { class: 'home-cap__icon' }, ui.icon(cap.icon)),
        h('span', { class: 'home-cap__title', text: cap.title }),
        pill),
      h('p', { class: 'home-cap__why', text: 'Чтобы напоминания приходили вовремя, мне понадобятся уведомления.' }),
      h('div', { class: 'home-cap__foot' }, reason, btn));
    function paint(res) {
      pill.set(res.status);
      reason.textContent = res.reason || '';
      btn.hidden = res.status !== 'prompt' && res.status !== 'skipped';
    }
    async function ask() {
      btn.setBusy(true);
      try {
        const res = await Capabilities.request(cap, { name: ctx.store.user.name });
        ctx.store.setPermission('notifications', res.status);
        paint(res);
        ctx.director.react(res.status === 'granted' ? 'small' : 'blink');
      } finally { btn.setBusy(false); }
    }
    const saved = (ctx.store.user.permissions.notifications || {}).status;
    Capabilities.resolveStatus(cap, saved).then((res) => paint(res.status === 'prompt' && saved === 'skipped' ? { status: 'skipped' } : res));
    return row;
  }

  /* ── Профиль ── */
  function profileContent(ctx) {
    const u = ctx.store.user;
    const personality = Profile.effectivePersonality(ctx.store.profile);
    const plan = Profile.plan(ctx.store.profile);

    const planRow = ui.pressable(h('button', { type: 'button', class: 'home-prow', onClick: () => ctx.openPlan() },
      h('span', { class: 'home-prow__k', text: 'Тариф' }),
      h('span', { class: 'home-prow__v', text: plan.title }),
      ui.icon('chevron', 'ds-icon home-prow__chev')));
    const charRow = h('div', { class: 'home-prow is-static' },
      h('span', { class: 'home-prow__k', text: 'Характер WISP' }),
      h('span', { class: 'home-prow__v', text: personality.title }));

    let armed = 0;
    const reset = ui.Button({
      label: 'Начать знакомство заново', variant: 'ghost',
      onClick: () => {
        if (!armed) {
          reset.setLabel('Нажми ещё раз, чтобы стереть ответы');
          armed = setTimeout(() => { armed = 0; reset.setLabel('Начать знакомство заново'); }, 3200);
          return;
        }
        clearTimeout(armed);
        ctx.reset();
      },
    });
    const edit = ui.Button({ label: 'Изменить ответы', variant: 'secondary', onClick: () => ctx.edit() });
    const settings = ui.Button({ label: 'Настройки', variant: 'ghost', onClick: () => ctx.openSettings && ctx.openSettings() });

    return [
      h('div', { class: 'home-me' },
        Avatar(u, 'large'),
        h('div', { class: 'home-me__text' },
          h('p', { class: 'home-me__name', text: u.name || 'Без имени' }),
          h('p', { class: 'home-me__sub', text: ctx.assistant && ctx.assistant.connected ? 'Анкета хранится на этом устройстве, диалоги — на сервере WISP' : 'Ответы хранятся на этом устройстве' }))),
      h('div', { class: 'home-plist' }, planRow, charRow),
      h('div', { class: 'home-sheet__actions' }, settings, edit, reset),
    ];
  }

  /* ── Тариф ──
   * Источник правды: сервер (GET /api/session). Здесь только показываем то, что он прислал. */
  function planContent(ctx) {
    const a = ctx.assistant;
    const s = a && a.session;
    const plan = Profile.plan(ctx.store.profile);
    const isPlus = plan.id === 'plus';
    const parts = [h('div', { class: 'home-sheet__hero' }, h('span', { class: `home-planmark${isPlus ? ' is-plus' : ''}`, text: plan.title }))];
    if (!s) {
      parts.push(lead(isPlus ? 'У тебя WISP Plus.' : 'Сейчас у тебя Free.'));
      parts.push(h('p', { class: 'home-sheet__note', text: a && a.connected ? 'Тариф и лимиты подтверждает сервер WISP, а он сейчас недоступен.' : 'AI-чат в этой копии WISP не подключён, поэтому лимитов нет.' }));
    } else {
      const u = s.usage;
      const pct = u.limit ? Math.min(100, Math.round((u.used / u.limit) * 100)) : 0;
      parts.push(lead(isPlus ? 'У тебя WISP Plus. Спасибо, что ты с нами.' : 'Сейчас у тебя Free.'));
      parts.push(h('div', { class: 'home-usage ds-glass' },
        h('div', { class: 'home-usage__row' }, h('span', { text: 'Сообщений сегодня' }), h('strong', { text: `${u.used} из ${u.limit}` })),
        h('div', { class: 'home-usage__bar', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(u.limit), 'aria-valuenow': String(u.used), 'aria-label': 'Использовано сообщений' }, h('i', { style: { width: pct + '%' } })),
        h('p', { class: 'home-usage__note', text: `Счётчик обнулится после ${new Date(u.reset_at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}.` })));
      if (!isPlus && s.plans && s.plans.plus) {
        const strong = s.models.some((m) => m.tier === 'plus' && m.available);
        const perks = [`до ${s.plans.plus.daily_requests} сообщений в день вместо ${s.plans.free.daily_requests}`, 'больше контекста: WISP помнит более длинный разговор'];
        if (strong) perks.splice(1, 0, 'более мощные модели');
        parts.push(h('p', { class: 'home-sheet__note', text: `В Plus: ${perks.join(', ')}. Оформить Plus пока нельзя: оплата ещё не подключена.` }));
      } else if (isPlus) {
        parts.push(h('p', { class: 'home-sheet__note', text: 'Управление подпиской появится в следующих обновлениях.' }));
      }
      const idBtn = h('button', { type: 'button', class: 'home-uid', 'aria-label': 'Скопировать ID для поддержки' },
        h('span', { class: 'home-uid__k', text: 'ID для поддержки' }), h('span', { class: 'home-uid__v', text: s.user.id.slice(0, 8) + '…' }), ui.icon('copy', 'ds-icon home-uid__icon'));
      idBtn.addEventListener('click', async () => {
        const ok = await App.chat.Markdown.copyText(s.user.id);
        idBtn.querySelector('.home-uid__v').textContent = ok ? 'скопирован' : s.user.id;
      });
      parts.push(idBtn);
    }
    parts.push(h('div', { class: 'home-sheet__actions' }, ui.Button({ label: 'Понятно', variant: 'secondary', onClick: () => ctx.close() })));
    return parts;
  }

  App.home.Sheets = { ACTIONS, Avatar, actionContent, profileContent, planContent, soonPill, notificationsRow, imageContent };
})(window.WispApp);
