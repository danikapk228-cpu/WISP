/* WISP · Layer 2 · Home
 * Главный экран персонального компаньона: шапка (логотип, тариф, аватар), маскот в центре с приветствием,
 * быстрые действия, строка ввода и нижняя навигация Home / Chat / Memory / Tools.
 * Маскот не перерисовывается: это тот же персонаж Layer 0, его ставит в нужное место MascotDirector.
 * Состояние пользователя одно: ProfileStore. Экран только читает его и подписывается на изменения.
 * Layer 4: вкладка Tools — отдельный экран инструментов (App.tools.ToolsView) со своим стеком экранов;
 * быстрые действия главного экрана и карточки действий в чате открывают нужный инструмент.
 * Layer 5: вкладка Memory — экран долговременной памяти (App.memory.MemoryView), данные только с сервера. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Profile, Assistant } = App.core;
  const { Copy, Sheets, Composer } = App.home;

  const TABS = [
    { id: 'home', label: 'Home', icon: 'home' },
    { id: 'chat', label: 'Chat', icon: 'chat' },
    { id: 'memory', label: 'Memory', icon: 'memory' },
    { id: 'tools', label: 'Tools', icon: 'tools' },
  ];
  const LAST_TAB_KEY = 'wisp:last-tab:v1';
  /* Layer 13: быстрые действия главного экрана — каталог (выбор и порядок задаются в «Интерфейсе») */
  const EXTRA_ACTIONS = [
    { id: 'event', icon: 'calendar', label: 'Событие', title: 'Планы', tool: 'event' },
    { id: 'new_chat', icon: 'compose', label: 'Новый чат', run: 'new_chat' },
    { id: 'memory', icon: 'memory', label: 'Память', run: 'memory' },
    { id: 'history', icon: 'history', label: 'История', run: 'history' },
  ];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  App.home.Home = function ({ root, store, director, onEdit, onReset, assistant: client, chatState, toolsApi, memoryApi, accountApi, profileSync, onOpenAuth, onSignedOut }) {
    const stage = document.querySelector('[data-wisp-entrance]');
    const assistant = client || Assistant.fromDocument();
    const voice = () => Copy.voice(store.profile);
    let tab = 'home';
    let sheet = null, sheetPushed = false, tabPushed = false, reuseEntry = false;
    let settingsView = null;
    let destroyed = false;
    let swallowPops = 0;
    const api = toolsApi || App.core.ToolsAPI(assistant);
    const memApi = memoryApi || App.core.MemoryAPI(assistant);

    /* ── Шапка ── */
    const planBtn = ui.pressable(h('button', { type: 'button', class: 'home-plan', onClick: () => openSheet('plan') }));
    const avatarBtn = ui.pressable(h('button', { type: 'button', class: 'home-avatar-btn', onClick: () => openSheet('profile') }));
    const header = h('header', { class: 'home-header home-enter', dataset: { i: '0' } },
      h('div', { class: 'home-logo', 'aria-label': 'WISP' }, h('span', { class: 'home-logo__spark', 'aria-hidden': 'true' }), h('span', { 'aria-hidden': 'true', text: 'WISP' })),
      h('div', { class: 'home-header__end' }, planBtn, avatarBtn));

    function paintHeader() {
      const u = store.user;
      const plan = Profile.plan(store.profile);
      planBtn.textContent = plan.title;
      planBtn.classList.toggle('is-plus', plan.id === 'plus');
      planBtn.setAttribute('aria-label', plan.id === 'plus' ? 'Тариф Plus' : 'Тариф Free. Узнать о Plus');
      avatarBtn.replaceChildren(Sheets.Avatar(u));
      avatarBtn.setAttribute('aria-label', u.name ? `Профиль: ${u.name}` : 'Профиль');
    }

    /* ── Вкладка Home ── */
    const homeSlot = h('div', { class: 'home-slot', 'aria-hidden': 'true' });
    const hello = h('h1', { class: 'home-hello', tabindex: '-1' });
    const sub = h('p', { class: 'home-sub' });
    const greet = h('div', { class: 'home-greet home-enter', dataset: { i: '1' } }, hello, sub);

    const prefs = () => store.user.preferences;
    const ALL_ACTIONS = Sheets.ACTIONS.concat(EXTRA_ACTIONS);
    function runAction(a) {
      director.react('nod');
      if (a.run === 'new_chat') { selectTab('chat'); chat.newChat(true); return; }
      if (a.run === 'memory') { openMemory(); return; }
      if (a.run === 'history') { selectTab('chat'); chat.openHistory(); return; }
      if (a.tool) openTool(a.tool, { create: true }); else openSheet('action', a);
    }
    const actionBtnOf = new Map(ALL_ACTIONS.map((a) => [a.id, ui.pressable(h('button', {
      type: 'button', class: 'home-action home-enter', dataset: { action: a.id },
      onClick: () => runAction(a),
    }, h('span', { class: 'home-action__icon' }, ui.icon(a.icon)), h('span', { class: 'home-action__label', text: a.label })))]));
    const actions = h('div', { class: 'home-actions', role: 'group', 'aria-label': 'Быстрые действия' });
    let actionsKey = '';
    function paintActions() {
      const ids = prefs().quick_actions.filter((id) => actionBtnOf.has(id));
      const key = ids.join(',');
      if (key === actionsKey) return;
      actionsKey = key;
      const btns = ids.map((id, i) => { const b = actionBtnOf.get(id); b.dataset.i = String(2 + i); b.style.setProperty('--i', String(2 + i)); return b; });
      actions.replaceChildren(...btns);
      actions.style.gridTemplateColumns = `repeat(${Math.max(1, btns.length)}, minmax(0, 1fr))`;
      actions.style.maxWidth = `${Math.max(1, btns.length) * 105}px`;
    }
    paintActions();

    const notice = h('p', { class: 'home-notice', role: 'status', 'aria-live': 'polite' });
    let noticeTimer = 0;
    function setNotice(text, tone, ttl) {
      clearTimeout(noticeTimer);
      if (!text) { notice.classList.remove('is-on'); return; }
      notice.textContent = text;
      notice.dataset.tone = tone || 'info';
      notice.classList.add('is-on');
      if (ttl !== 0) noticeTimer = setTimeout(() => notice.classList.remove('is-on'), ttl || 6000);
    }

    const composer = Composer({
      placeholder: 'Спроси WISP о чём угодно…',
      suggestions: Copy.suggestions(store.user),
      getMicSaved: () => (store.user.permissions.microphone || {}).status,
      onMicStatus: (s) => { if ((store.user.permissions.microphone || {}).status !== s) store.setPermission('microphone', s); },
      onNotice: setNotice,
      /* Layer 3: сообщение с главного экрана открывает новый диалог в чате, ответ приходит туда потоком */
      onSend: async (text) => {
        if (!assistant.connected) {
          director.react('blink');
          setNotice(voice().offline, 'warn');
          return false;                                   // текст остаётся в поле
        }
        if (!navigator.onLine) { director.react('blink'); setNotice(voice().error, 'warn'); return false; }
        setNotice(null);
        selectTab('chat');
        const ok = await chat.sendFromHome(text);
        return ok;
      },
    });
    const composerWrap = h('div', { class: 'home-dock home-enter', dataset: { i: '6' } }, notice, composer.el);

    /* Layer 13: блоки главного экрана (приветствие, действия, поле) — порядок и видимость из «Интерфейса».
     * Маскот всегда сверху: он живёт в свободной области, а не в блоке. */
    const blocks = {
      greeting: h('div', { class: 'home-block home-block--greeting' }, greet),
      actions: h('div', { class: 'home-actions-wrap home-block home-block--actions' }, actions),
      composer: h('div', { class: 'home-block home-block--composer' }, composerWrap),
    };
    const homePanel = h('section', { class: 'home-panel home-panel--home', id: 'home-panel-home', role: 'tabpanel', 'aria-label': 'Home' },
      h('div', { class: 'home-hero' }, homeSlot), blocks.greeting, blocks.actions, blocks.composer);
    function paintBlocks() {
      const p = prefs();
      const hidden = new Set(p.home_hidden);
      p.home_blocks.forEach((id, i) => { if (blocks[id]) blocks[id].style.order = String(i + 1); });
      blocks.greeting.hidden = hidden.has('greeting');
      sub.hidden = hidden.has('subtitle');
      blocks.actions.hidden = hidden.has('actions') || !p.quick_actions.length;
      homePanel.classList.toggle('no-suggest', hidden.has('suggestions'));
      planBtn.hidden = hidden.has('plan_badge');
    }

    /* ── Layer 3: чат ── */
    const chat = App.chat.ChatView({
      root, store, director, assistant, chatState,
      openSheet: (def) => openSheet('custom', def),
      closeSheet: () => closeSheet(),
      onBack: () => selectTab('home'),
      onLayout: () => { if (tab === 'chat' && !destroyed) placeMascot(); },
      onPlan: () => openSheet('plan'),
      openTool: (kind, a) => openTool(kind, a),
      toolsApi: api,
      memoryApi: memApi,
      openMemory: (id) => openMemory(id),
    });
    chat.el.mascotSlot = null;

    /* ── Layer 4: инструменты ── */
    const imageAction = Sheets.ACTIONS.find((a) => a.id === 'image');
    const tools = App.tools.ToolsView({
      root, store, director, assistant, api,
      openSheet: (def) => openSheet('custom', def),
      closeSheet: () => closeSheet(),
      openPlan: () => openSheet('plan'),
      openImage: () => openSheet('action', imageAction),
      onBack: () => selectTab('home'),
      onLayout: () => { if (tab === 'tools' && !destroyed) placeMascot(); },
      history: { push: () => push({ wisp: 'tools-sub' }), back: () => history.back() },
    });
    tools.el.mascotSlot = null;

    /* ── Layer 5: память ── */
    const memory = App.memory.MemoryView({
      root, store, director, assistant, api: memApi,
      openSheet: (def) => openSheet('custom', def),
      closeSheet: () => closeSheet(),
      openPlan: () => openSheet('plan'),
      /* пример из пустого состояния: в чат, текст в поле ввода (отправит сам пользователь) */
      openChat: (text) => { selectTab('chat'); chat.prefill(text); },
      onBack: () => selectTab('home'),
      onLayout: () => { if (tab === 'memory' && !destroyed) placeMascot(); },
    });
    memory.el.mascotSlot = null;
    const panels = {
      home: homePanel,
      chat: chat.el,
      memory: memory.el,
      tools: tools.el,
    };
    homePanel.mascotSlot = homeSlot;
    const panelsEl = h('div', { class: 'home-panels' }, Object.values(panels).filter((p) => p !== chat.el && p !== tools.el && p !== memory.el));

    /* ── Нижняя навигация ── */
    const tabBtns = TABS.map((t) => ui.pressable(h('button', {
      type: 'button', class: 'home-tab', role: 'tab', id: `home-tab-${t.id}`, dataset: { tab: t.id },
      'aria-controls': `home-panel-${t.id}`, 'aria-selected': t.id === tab ? 'true' : 'false', tabindex: t.id === tab ? '0' : '-1',
      'aria-label': t.label,
      onClick: () => selectTab(t.id),
    }, h('span', { class: 'home-tab__icon' }, ui.icon(t.icon)), h('span', { class: 'home-tab__label', text: t.label }))));
    const tabBtnOf = new Map(TABS.map((t, i) => [t.id, tabBtns[i]]));
    const navInner = h('div', { class: 'home-nav__inner', role: 'tablist', 'aria-label': 'Разделы WISP', 'aria-orientation': 'horizontal' }, tabBtns);
    const nav = h('nav', { class: 'home-nav home-enter', dataset: { i: '7' }, 'aria-label': 'Разделы' }, navInner);
    /* Layer 13: порядок и видимость вкладок из «Интерфейса». Home и Chat скрыть нельзя (схема не даст). */
    let visibleTabs = TABS.map((t) => t.id);
    let navKey = '';
    function paintNav() {
      const p = prefs();
      const hidden = new Set(p.nav_hidden);
      const order = p.nav_order.filter((id) => tabBtnOf.has(id) && !hidden.has(id));
      const key = order.join(',');
      if (key !== navKey) {
        navKey = key;
        visibleTabs = order;
        navInner.replaceChildren(...order.map((id) => tabBtnOf.get(id)));
        navInner.style.gridTemplateColumns = `repeat(${order.length}, minmax(0, 1fr))`;
        nav.style.setProperty('--nav-n', String(order.length));
      }
      if (!visibleTabs.includes(tab) && !destroyed && el) selectTab('home');
    }
    nav.addEventListener('keydown', (e) => {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(e.key)) return;
      const list = visibleTabs;
      const fwd = e.key === 'ArrowRight' || e.key === 'ArrowDown';
      const i = Math.max(0, list.indexOf(tab));
      const n = e.key === 'Home' ? 0 : e.key === 'End' ? list.length - 1 : (i + (fwd ? 1 : list.length - 1)) % list.length;
      e.preventDefault();
      selectTab(list[n]);
      tabBtnOf.get(list[n]).focus();
    });

    const el = h('div', { class: 'home ds-root', role: 'main', 'aria-label': 'Главный экран WISP' }, header, panelsEl, chat.el, tools.el, memory.el, nav);
    /* экран инструментов занимает всё до нижней навигации (она остаётся видна) */
    const navRO = window.ResizeObserver ? new ResizeObserver(() => el.style.setProperty('--home-nav-h', nav.offsetHeight + 'px')) : null;
    if (navRO) navRO.observe(nav);
    TABS.forEach((t) => { panels[t.id].setAttribute('aria-labelledby', `home-tab-${t.id}`); });
    el.querySelectorAll('[data-i]').forEach((n) => n.style.setProperty('--i', n.dataset.i));

    /* ── Маскот: измеряем свободную область вкладки и ставим персонажа в её центр ── */
    function measureFor(id) {
      if (id === 'chat') return chat.measure;
      if (id === 'tools') return tools.measure;
      if (id === 'memory') return memory.measure;
      const slot = panels[id].mascotSlot;
      return () => {
        const r = slot.getBoundingClientRect();
        const rr = root.getBoundingClientRect();
        if (!r.height) return null;
        const big = id === 'home';
        const hgt = big
          ? clamp(Math.min(r.height * 0.6, r.width * 0.44), 54, 230)
          : clamp(Math.min(r.height * 0.58, r.width * 0.3), 48, 118);
        return { h: hgt, cy: r.top - rr.top + r.height * (big ? 0.5 : 0.56), cx: r.left - rr.left + r.width / 2 };
      };
    }
    function placeMascot() {
      if (settingsView && settingsView.isOpen) {
        director.setPose('home-tab', settingsView.measure);
        return;
      }
      director.setPose(tab === 'home' ? 'home' : 'home-tab', measureFor(tab));
    }
    const ro = window.ResizeObserver ? new ResizeObserver(() => { if (!destroyed) director.apply(false); }) : null;
    if (ro) { ro.observe(homeSlot); Object.values(panels).forEach((p) => { if (p.mascotSlot) ro.observe(p.mascotSlot); }); ro.observe(chat.el); }

    /* ── Вкладки и история браузера: системный «назад» закрывает панель, затем возвращает на Home ── */
    const push = (state) => { try { history.pushState(state, ''); return true; } catch (e) { return false; } };
    function showTab(id) {
      if (id === tab) return;
      const from = visibleTabs.indexOf(tab), to = visibleTabs.indexOf(id);
      const prev = panels[tab], next = panels[id];
      tab = id;
      tabBtns.forEach((b, i) => { const on = TABS[i].id === id; b.setAttribute('aria-selected', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1; });
      el.dataset.tab = id;
      try { localStorage.setItem(LAST_TAB_KEY, id); } catch (e) { /* без запоминания */ }
      prev.classList.remove('is-active');
      prev.classList.add(to > from ? 'to-left' : 'to-right');
      prev.inert = true; prev.setAttribute('aria-hidden', 'true');
      next.classList.remove('to-left', 'to-right');
      next.classList.add(to > from ? 'from-right' : 'from-left');
      next.inert = false; next.removeAttribute('aria-hidden');
      requestAnimationFrame(() => requestAnimationFrame(() => { next.classList.remove('from-right', 'from-left'); next.classList.add('is-active'); }));
      setTimeout(() => { if (!destroyed && tab === id) placeMascot(); }, 820);
      if (id !== 'home') composer.stop();
      if (id === 'chat') chat.onShow(); else chat.onHide();
      if (id === 'tools') tools.onShow(); else tools.onHide();
      if (id === 'memory') memory.onShow(); else memory.onHide();
      placeMascot();
      ui.haptic(6);
    }
    function selectTab(id) {
      if (id === tab) return;
      /* уходим из инструментов с открытыми экранами: закрываем их и убираем их шаги истории */
      if (tab === 'tools' && tools.depth()) {
        const n = tools.pushedDepth();
        tools.reset();
        if (n) {
          if (id === 'home' && tabPushed) { history.go(-(n + 1)); return; }    // popstate вернёт на Home
          swallowPops += 1;
          history.go(-n);
        }
      }
      if (id === 'home') {
        if (tabPushed) { history.back(); return; }      // popstate вернёт на Home
        showTab('home'); return;
      }
      if (tab === 'home') {
        if (reuseEntry) { reuseEntry = false; tabPushed = true; try { history.replaceState({ wisp: 'home-tab' }, ''); } catch (e) {} }
        else tabPushed = push({ wisp: 'home-tab' });
      }
      showTab(id);
    }

    /* ── Панели ── */
    const SHEETS = {
      profile: () => ({ title: 'Профиль', content: Sheets.profileContent(sheetCtx()) }),
      plan: () => ({ title: Profile.plan(store.profile).id === 'plus' ? 'WISP Plus' : 'Узнать о Plus', content: Sheets.planContent(sheetCtx()) }),
      action: (a) => ({ title: a.title, content: Sheets.actionContent(a, sheetCtx()) }),
      custom: (def) => def,
    };
    function sheetCtx() {
      return {
        store, director, voice,
        close: () => closeSheet(),
        openPlan: () => openSheet('plan'),
        openSettings: () => { closeSheetNow(); openSettings(); },
        openAuth: () => { closeSheetNow(); onOpenAuth && onOpenAuth({ kind: 'login' }); },
        assistant,
        openChat: () => { closeSheetNow(); selectTab('chat'); },
        attachInChat: () => { const ok = chat.pickImage(); closeSheetNow(); selectTab('chat'); return ok; },
        edit: () => leave(onEdit),
        reset: () => leave(onReset),
      };
    }
    function openSheet(kind, arg) {
      const replacing = !!sheet;
      if (sheet) sheet.close({ keepFocus: true, instant: false });
      const def = SHEETS[kind](arg);
      sheet = ui.Sheet({ title: def.title, content: def.content });
      sheet.requestClose = () => closeSheet();
      sheet.mount(root);
      if (!replacing) sheetPushed = push({ wisp: 'home-sheet' });
      composer.stop();
    }
    /* закрыть панель без шага истории (перед переходом в другую вкладку) */
    function closeSheetNow() {
      if (!sheet) return;
      sheet.close({ keepFocus: true }); sheet = null;
      if (sheetPushed) { sheetPushed = false; reuseEntry = true; }     // шаг истории панели станет шагом вкладки
    }
    function closeSheet() {
      if (!sheet) return;
      if (sheetPushed) { history.back(); return; }        // popstate закроет панель
      sheet.close(); sheet = null;
    }
    function openSettings(section) {
      if (destroyed || !settingsView) return;
      const replacing = !!settingsView.isOpen;
      if (!replacing) {
        if (sheetPushed) { sheetPushed = false; reuseEntry = true; }
        else push({ wisp: 'home-settings' });
      }
      settingsView.open(section);
      el.dataset.settings = 'open';
      composer.stop();
      placeMascot();
    }
    function onPop() {
      if (destroyed) return;
      if (swallowPops) { swallowPops -= 1; return; }
      if (sheet) { sheet.close(); sheet = null; sheetPushed = false; return; }
      if (settingsView && settingsView.handlePop()) return;
      if (tab === 'tools' && tools.handlePop()) return;
      if (tab !== 'home') { tabPushed = false; showTab('home'); }
    }
    window.addEventListener('popstate', onPop);

    /* Layer 5: открыть Memory (и подсветить воспоминание) — из карточки или подсказки в чате */
    function openMemory(id) {
      if (destroyed) return;
      closeSheetNow();
      memory.focus(id);
      if (tab !== 'memory') selectTab('memory');
    }

    /* Открыть инструмент: из быстрых действий, из карточки действия в чате, из уведомления */
    const TOOL_OF = { reminder: 'reminders', reminders: 'reminders', task: 'tasks', tasks: 'tasks', note: 'notes', notes: 'notes', event: 'planner', agenda: 'planner', planner: 'planner' };
    function openTool(kind, arg) {
      const id = TOOL_OF[kind];
      if (!id || destroyed) return;
      closeSheetNow();
      const opts = { create: !!(arg && arg.create), date: arg && arg.date && (kind === 'event' || kind === 'agenda') ? arg.date : undefined };
      if (tab === 'tools' && tools.depth()) { tools.push(id, opts); return; }      // уже внутри инструментов: экран поверх
      if (tab !== 'tools') selectTab('tools');
      tools.open(id, opts);
    }

    settingsView = App.settings.SettingsView({
      root, store, director, assistant, accountApi: accountApi || App.settings.AccountAPI(assistant),
      memoryApi: memApi, toolsApi, sync: profileSync,
      openSheet: (def) => openSheet('custom', def),
      closeSheet: () => closeSheet(),
      openPlan: () => openSheet('plan'),
      openMemory: (id) => openMemory(id),
      onEraseLocal: async () => { await store.reset(); await chatState.clear(); },
      onEditProfile: () => { settingsView.close(); leave(onEdit); },
      onSignedOut,
      onOpenAuth,
      onClose: () => { delete el.dataset.settings; placeMascot(); },
      onLayout: () => { if (settingsView && settingsView.isOpen && !destroyed) placeMascot(); },
      history: { push: () => push({ wisp: 'settings-sub' }), back: () => history.back() },
      chat,
    });
    el.appendChild(settingsView.el);

    /* ── Персонализация ── */
    function paintGreeting() {
      const v = voice();
      hello.textContent = v.hello(store.user.name);
      sub.textContent = v.sub;
    }
    const unsubscribe = store.subscribe(() => { if (!destroyed) { paintHeader(); paintGreeting(); paintActions(); paintBlocks(); paintNav(); } });

    /* ── Монтирование ── */
    Object.entries(panels).forEach(([id, p]) => {
      if (id === 'home') p.classList.add('is-active');
      else { p.inert = true; p.setAttribute('aria-hidden', 'true'); }
    });
    el.dataset.tab = 'home';
    paintHeader();
    paintGreeting();
    paintBlocks();
    paintNav();
    root.appendChild(el);
    if (stage) stage.classList.add('is-home');
    placeMascot();
    requestAnimationFrame(() => requestAnimationFrame(() => {
      el.classList.add('is-in');
      placeMascot();
    }));
    /* Layer 13: стартовый экран (Home, Chat, Memory, Tools или последний открытый) */
    const start = (() => {
      let id = prefs().start_tab;
      if (id === 'last') { try { id = localStorage.getItem(LAST_TAB_KEY) || 'home'; } catch (e) { id = 'home'; } }
      return visibleTabs.includes(id) ? id : 'home';
    })();
    if (start !== 'home') requestAnimationFrame(() => { if (!destroyed) selectTab(start); });
    setTimeout(() => {
      if (destroyed) return;
      director.react(Profile.effectivePersonality(store.profile).reaction);
      if (!ui.finePointer()) hello.focus({ preventScroll: true });
    }, ui.reducedMotion() ? 0 : 900);

    function destroy() {
      if (destroyed) return;
      destroyed = true;
      composer.stop();
      chat.destroy();
      tools.destroy();
      memory.destroy();
      if (settingsView) settingsView.destroy();
      if (navRO) navRO.disconnect();
      if (sheet) { sheet.close({ keepFocus: true }); sheet = null; }
      window.removeEventListener('popstate', onPop);
      unsubscribe();
      if (ro) ro.disconnect();
      clearTimeout(noticeTimer);
      if (stage) stage.classList.remove('is-home');
      el.remove();
    }
    function leave(fn) {
      if (destroyed) return;
      if (sheet) { sheet.close({ keepFocus: true }); sheet = null; }
      el.classList.add('is-out');
      setTimeout(() => { destroy(); fn && fn(); }, 380);
    }

    return { el, destroy, selectTab, openSheet, openTool, openMemory, openSettings };
  };
})(window.WispApp);
