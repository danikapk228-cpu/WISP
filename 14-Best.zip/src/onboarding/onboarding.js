/* WISP · Onboarding · Controller
 * Оболочка знакомства: шапка (назад / прогресс / пропустить), смена экранов, история браузера, сохранение шага.
 * Экраны живут в screens/*.js и получают только ctx: данные, действия навигации, маскота, возможности. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Flow } = App.onboarding;

  const TRANSITION_MS = 480;

  class Onboarding {
    constructor({ root, store, progress, director, mode, startStep, onComplete }) {
      this.root = root;
      this.store = store;
      this.progressRepo = progress;
      this.director = director;
      this.mode = mode || 'first';
      this.onComplete = onComplete;
      this.flow = new Flow(startStep || (this.mode === 'edit' ? 'name' : 'welcome'));
      this.current = null;
      this.locked = false;
      this.onPop = this.onPop.bind(this);
    }

    mount() {
      this.backBtn = ui.IconButton({ icon: 'back', label: 'Назад', onClick: () => this.back() });
      this.progressBar = ui.Progress({ total: this.flow.progress().total, label: 'Прогресс знакомства' });
      this.skipBtn = ui.TextButton({ label: 'Пропустить', onClick: () => this.skip() });
      this.header = h('header', { class: 'ob-header' },
        h('div', { class: 'ob-header__side' }, this.backBtn),
        h('div', { class: 'ob-header__mid' }, this.progressBar),
        h('div', { class: 'ob-header__side ob-header__side--end' }, this.skipBtn));
      this.stageEl = h('div', { class: 'ob-stage' });
      this.el = h('div', { class: 'ob ds-root', role: 'main', 'aria-label': 'Знакомство с WISP' }, this.stageEl, this.header);
      this.root.appendChild(this.el);
      // браузерная «назад» (жест на iPhone / кнопка на Android) ведёт на предыдущий шаг
      try { history.pushState({ wisp: 'onboarding' }, ''); } catch (e) {}
      window.addEventListener('popstate', this.onPop);
      this.show('none');
    }

    destroy() {
      window.removeEventListener('popstate', this.onPop);
      if (this.current && this.current.leave) this.current.leave();
      this.el.classList.add('is-out');
      setTimeout(() => this.el.remove(), TRANSITION_MS);
    }

    onPop() {
      if (this.flow.canBack) this.back();
      try { history.pushState({ wisp: 'onboarding' }, ''); } catch (e) {}
    }

    ctx() {
      const self = this;
      return {
        get user() { return self.store.user; },
        mode: self.mode,
        update: (patch) => self.store.update(patch),
        setPermission: (k, s) => self.store.setPermission(k, s),
        canContinue: (id) => Flow.canContinue(id, self.store.user),
        next: () => self.next(),
        back: () => self.back(),
        skip: () => self.skip(),
        finish: () => self.complete(),
        mascot: self.director,
        caps: App.core.Capabilities,
        Profile: App.core.Profile,
      };
    }

    renderHeader() {
      const step = this.flow.step;
      const p = this.flow.progress();
      this.backBtn.classList.toggle('is-hidden', !this.flow.canBack);
      this.backBtn.tabIndex = this.flow.canBack ? 0 : -1;
      this.skipBtn.classList.toggle('is-hidden', !step.skip);
      this.skipBtn.tabIndex = step.skip ? 0 : -1;
      this.progressBar.classList.toggle('is-hidden', !step.progress);
      if (step.progress) this.progressBar.set(p.index);
      this.header.classList.toggle('is-bare', !step.progress && !this.flow.canBack);
    }

    show(dir) {
      const step = this.flow.step;
      const factory = App.screens[step.screen];
      const screen = factory(this.ctx());
      const el = screen.el;
      const prev = this.current;

      this.director.setPose(step.pose);
      this.renderHeader();
      this.progressRepo.save(step.id, this.mode);

      if (dir !== 'none') el.classList.add(dir === 'back' ? 'from-left' : 'from-right');
      this.stageEl.appendChild(el);
      // двойной rAF: стартовое состояние успевает отрисоваться, затем плавный вход
      requestAnimationFrame(() => requestAnimationFrame(() => {
        el.classList.remove('from-left', 'from-right');
        el.classList.add('is-in');
      }));

      if (prev) {
        if (prev.leave) prev.leave();
        prev.el.classList.add('is-leaving', dir === 'back' ? 'to-right' : 'to-left');
        setTimeout(() => prev.el.remove(), TRANSITION_MS);
      }
      this.current = screen;
      setTimeout(() => {
        if (this.current !== screen) return;
        if (screen.enter) screen.enter();
        else if (el.titleEl) el.titleEl.focus({ preventScroll: true });
      }, dir === 'none' ? 120 : 300);
    }

    go(fn, dir) {
      if (this.locked) return;
      const prevIndex = this.flow.index;
      if (!fn()) return;
      this.locked = true;
      setTimeout(() => { this.locked = false; }, 320);
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      try {
        this.show(dir);
      } catch (err) {
        // экран не собрался: остаёмся на текущем шаге, а не в «пустоте»
        console.error('[WISP onboarding] screen failed:', err);
        this.flow.index = prevIndex;
        this.director.setPose(this.flow.step.pose);
        this.renderHeader();
        this.progressRepo.save(this.flow.step.id, this.mode);
      }
    }
    next() { this.go(() => this.flow.next(), 'forward'); }
    back() { this.go(() => this.flow.back(), 'back'); }
    skip() {
      if (this.locked) return;
      if (this.current && this.current.onSkip) this.current.onSkip();
      this.next();
    }

    async complete() {
      if (this.locked) return;
      this.locked = true;
      this.store.update({ onboarding_completed: true });
      await this.store.flush();
      await this.progressRepo.clear();
      this.destroy();
      this.onComplete && this.onComplete();
    }
  }

  App.onboarding.Onboarding = Onboarding;
})(window.WispApp);
