/* WISP · Onboarding · Flow
 * Бизнес-логика знакомства: порядок шагов, что обязательно, когда можно продолжать. Без DOM. */
(function (App) {
  'use strict';

  const STEPS = [
    { id: 'welcome',      screen: 'Welcome',      pose: 'hero',      progress: false, back: false, skip: false },
    { id: 'name',         screen: 'Name',         pose: 'focus',     progress: true,  back: true,  skip: true },
    { id: 'interests',    screen: 'Interests',    pose: 'focus',     progress: true,  back: true,  skip: true },
    { id: 'occupation',   screen: 'Occupation',   pose: 'focus',     progress: true,  back: true,  skip: true },
    { id: 'about',        screen: 'About',        pose: 'focus',     progress: true,  back: true,  skip: true },
    { id: 'personality',  screen: 'Personality',  pose: 'focus',     progress: true,  back: true,  skip: true },
    { id: 'capabilities', screen: 'Capabilities', pose: 'focus',     progress: true,  back: true,  skip: true },
    { id: 'finish',       screen: 'Finish',       pose: 'celebrate', progress: false, back: true,  skip: false },
  ];

  /* Условие «можно продолжить» (иначе шаг можно только пропустить). */
  const CAN_CONTINUE = {
    welcome: () => true,
    name: (u) => !!u.name,
    interests: (u) => u.interests.length > 0,
    occupation: (u) => !!u.occupation,
    about: (u) => u.about.trim().length > 0,
    personality: (u) => !!u.assistant_personality,
    capabilities: () => true,
    finish: () => true,
  };

  const PROGRESS_STEPS = STEPS.filter((s) => s.progress).map((s) => s.id);

  class Flow {
    constructor(startId) {
      const i = STEPS.findIndex((s) => s.id === startId);
      this.index = i < 0 ? 0 : i;
    }
    get step() { return STEPS[this.index]; }
    get isLast() { return this.index === STEPS.length - 1; }
    get canBack() { return this.index > 0 && this.step.back; }
    next() { if (this.index < STEPS.length - 1) { this.index++; return true; } return false; }
    back() { if (this.canBack) { this.index--; return true; } return false; }
    goTo(id) { const i = STEPS.findIndex((s) => s.id === id); if (i >= 0) this.index = i; return i >= 0; }
    progress() { return { index: PROGRESS_STEPS.indexOf(this.step.id), total: PROGRESS_STEPS.length }; }
    static canContinue(id, user) { return (CAN_CONTINUE[id] || (() => true))(user); }
    static has(id) { return STEPS.some((s) => s.id === id); }
  }

  App.onboarding.STEPS = STEPS;
  App.onboarding.Flow = Flow;
})(window.WispApp);
