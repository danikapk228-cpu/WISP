/* Screen 6 · Характер WISP */
(function (App) {
  'use strict';
  const { ui } = App;

  App.screens.Personality = function (ctx) {
    const { Profile } = ctx;
    let current = ctx.user.assistant_personality;
    const cta = ui.Button({ label: 'Продолжить', disabled: !current, onClick: () => ctx.next() });

    const rows = Profile.PERSONALITIES.map((p) => {
      const row = ui.OptionRow({
        title: p.title, desc: p.desc, selected: current === p.id,
        extra: ui.h('p', { class: 'ob-sample', text: `«${p.sample(ctx.user.name)}»` }),
        onSelect: () => {
          if (current !== p.id) ctx.mascot.react(p.reaction);
          current = p.id;
          ctx.update({ assistant_personality: p.id });
          rows.forEach((r) => r.setSelected(r._id === p.id));
          cta.setDisabled(false);
        },
      });
      row._id = p.id;
      return row;
    });
    const group = ui.RadioGroup({ label: 'Характер помощника', rows });
    group.dataset.noStagger = '1';

    const el = ui.ScreenLayout({
      title: 'Каким помощником мне быть?',
      subtitle: 'Выбери характер. Поменять его можно в любой момент.',
      body: group,
      footer: cta,
    });
    el.stagger(rows, 2);
    return { el };
  };
})(window.WispApp);
