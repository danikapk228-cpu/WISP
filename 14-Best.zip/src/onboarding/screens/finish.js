/* Screen 8 · Завершение */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const TEXT = 'Отлично! Теперь я немного больше знаю о тебе. Давай начнём наше знакомство по-настоящему.';

  App.screens.Finish = function (ctx) {
    const { Profile } = ctx;
    const u = ctx.user;
    const chips = [];
    if (u.name) chips.push(u.name);
    u.interests.slice(0, 3).forEach((id) => { const it = Profile.interest(id); if (it) chips.push(it.label); });
    if (u.interests.length > 3) chips.push(`+${u.interests.length - 3}`);
    if (u.assistant_personality) chips.push(Profile.personality(u.assistant_personality).title);

    const cta = ui.Button({ label: 'Начать', onClick: () => { cta.setBusy(true); ctx.finish(); } });
    const hold = h('div', { class: 'ds-hold' }, cta);
    const learned = chips.length
      ? h('div', { class: 'ob-learned ds-hold', 'aria-label': 'Что я запомнил', dataset: { noStagger: '1' } }, chips.map((c) => ui.Chip(c)))
      : null;
    const bubble = ui.SpeechBubble({
      text: TEXT,
      onDone: () => { hold.classList.add('is-shown'); if (learned) learned.classList.add('is-shown'); },
    });
    const rings = h('div', { class: 'ob-rings', 'aria-hidden': 'true' }, h('span'), h('span'));

    const el = ui.ScreenLayout({
      title: 'Знакомство завершено', titleHidden: true, center: true,
      body: [h('div', { class: 'ob-bubble-wrap' }, bubble), learned].filter(Boolean),
      footer: hold,
    });
    el.prepend(rings);
    return {
      el,
      enter() {
        setTimeout(() => { rings.classList.add('is-on'); ctx.mascot.react('celebrate'); }, ui.reducedMotion() ? 0 : 380);
        bubble.start(900);
        setTimeout(() => { hold.classList.add('is-shown'); if (learned) learned.classList.add('is-shown'); }, ui.reducedMotion() ? 0 : 6500);
      },
    };
  };
})(window.WispApp);
