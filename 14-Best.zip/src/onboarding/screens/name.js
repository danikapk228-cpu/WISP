/* Screen 2 · Имя */
(function (App) {
  'use strict';
  const { ui } = App;

  App.screens.Name = function (ctx) {
    const { Profile } = ctx;
    const greet = ui.h('p', { class: 'ob-greet', 'aria-live': 'polite' });
    let reacted = !!ctx.user.name;
    const cta = ui.Button({ label: 'Продолжить', disabled: !ctx.canContinue('name'), onClick: submit });

    function render(raw) {
      const name = Profile.sanitizeName(raw);
      greet.textContent = name ? `Приятно познакомиться, ${name}!` : '';
      greet.classList.toggle('is-on', !!name);
      cta.setDisabled(!name);
    }
    function submit() {
      if (!ctx.canContinue('name')) return;
      ctx.mascot.react('hop');
      ctx.next();
    }
    const field = ui.TextField({
      value: ctx.user.name || '', placeholder: 'Твоё имя', label: 'Имя',
      maxLength: Profile.LIMITS.name, autocomplete: 'given-name',
      onInput: (v) => {
        ctx.update({ name: v });
        render(v);
        if (!reacted && Profile.sanitizeName(v)) { reacted = true; ctx.mascot.react('blink'); }
      },
      onSubmit: submit,
    });
    const input = field.querySelector('input');
    render(ctx.user.name || '');

    const el = ui.ScreenLayout({
      title: 'Как мне тебя называть?',
      subtitle: 'Хочу обращаться к тебе так, как тебе нравится.',
      body: [field, greet],
      footer: cta,
    });
    return {
      el,
      enter() {
        if (ui.finePointer()) input.focus({ preventScroll: true });
        else el.titleEl.focus({ preventScroll: true });
      },
    };
  };
})(window.WispApp);
