/* Screen 3 · Интересы (множественный выбор) */
(function (App) {
  'use strict';
  const { ui } = App;

  App.screens.Interests = function (ctx) {
    const { Profile } = ctx;
    const selected = new Set(ctx.user.interests);
    const cta = ui.Button({ label: 'Продолжить', onClick: () => { ctx.mascot.react('hop'); ctx.next(); } });
    const hint = ui.h('p', { class: 'ob-hint', text: 'Подробнее о своём можно будет рассказать чуть позже.' });
    let lastReact = 0;

    const sync = () => {
      cta.setDisabled(selected.size === 0);
      cta.setCount(selected.size);
      hint.classList.toggle('is-on', selected.has('other'));
    };
    const cards = Profile.INTERESTS.map((it) => ui.ChoiceCard({
      icon: it.icon, label: it.label, selected: selected.has(it.id),
      onToggle: (on) => {
        on ? selected.add(it.id) : selected.delete(it.id);
        ctx.update({ interests: [...selected] });
        sync();
        const now = performance.now();
        if (on && now - lastReact > 650) { lastReact = now; ctx.mascot.react('small'); }
      },
    }));
    const grid = ui.h('div', { class: 'ds-grid', role: 'group', 'aria-label': 'Интересы', dataset: { noStagger: '1' } }, cards);
    sync();

    const name = ctx.user.name;
    const el = ui.ScreenLayout({
      eyebrow: name ? `Приятно познакомиться, ${name}` : null,
      title: 'Что тебе интересно?',
      subtitle: 'Выбери сколько угодно. Так я пойму, о чём нам интересно говорить.',
      body: [grid, hint],
      footer: cta,
    });
    el.stagger(cards, 3);
    return { el };
  };
})(window.WispApp);
