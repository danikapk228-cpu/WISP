/* Screen 7 · Возможности
 * Ничего не запрашивается автоматически: сначала объяснение, запрос только по нажатию. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;

  App.screens.Capabilities = function (ctx) {
    const statuses = {};
    const cards = ctx.caps.LIST.map((cap) => {
      const pill = ui.StatusPill('prompt');
      const reason = h('p', { class: 'ob-cap__reason' });
      const btn = ui.Button({ label: cap.action, variant: 'secondary', size: 'small', onClick: () => ask(view) });
      const foot = h('div', { class: 'ob-cap__foot' });
      const el = h('article', { class: 'ob-cap ds-glass', 'aria-label': cap.title },
        h('div', { class: 'ob-cap__head' },
          h('span', { class: 'ob-cap__icon' }, ui.icon(cap.icon)),
          h('h2', { class: 'ob-cap__title', text: cap.title }),
          pill),
        h('p', { class: 'ob-cap__why', text: cap.why }),
        foot);
      const view = { cap, el, pill, reason, btn, foot };
      return view;
    });

    function paint(view, res) {
      const { cap, pill, reason, btn, foot } = view;
      statuses[cap.id] = res.status;
      pill.set(res.status);
      foot.textContent = '';
      reason.textContent = res.reason || '';
      if (res.reason) foot.appendChild(reason);
      const canAsk = res.status === 'prompt' || (cap.retryable && (res.status === 'granted' || res.status === 'denied'));
      if (canAsk) {
        btn.setLabel(res.status === 'granted' && cap.id === 'voice' ? 'Ещё раз' : cap.action);
        if (!res.reason) foot.appendChild(h('span', { class: 'ob-cap__reason' }));
        foot.appendChild(btn);
      }
    }

    async function ask(v) {
      v.btn.setBusy(true);
      try {
        const res = await ctx.caps.request(v.cap, { name: ctx.user.name });
        ctx.setPermission(v.cap.id, res.status);
        paint(v, res);
        ctx.mascot.react(res.status === 'granted' ? 'small' : 'blink');
      } finally {
        v.btn.setBusy(false);
      }
    }

    // актуальное состояние (пользователь мог поменять разрешения в настройках)
    cards.forEach(async (view) => {
      const saved = (ctx.user.permissions[view.cap.id] || {}).status;
      const res = await ctx.caps.resolveStatus(view.cap, saved);
      paint(view, res);
    });

    // записываем в профиль итог по всем возможностям: нерешённые = «позже»
    function commit() {
      for (const view of cards) {
        const s = statuses[view.cap.id];
        if (!s) continue;
        const saved = (ctx.user.permissions[view.cap.id] || {}).status;
        const finalStatus = s === 'prompt' ? 'skipped' : s;
        if (saved !== finalStatus) ctx.setPermission(view.cap.id, finalStatus);
      }
    }

    const cta = ui.Button({ label: 'Продолжить', onClick: () => { commit(); ctx.next(); } });
    const list = h('div', { class: 'ob-caps', dataset: { noStagger: '1' } }, cards.map((c) => c.el));
    const el = ui.ScreenLayout({
      title: 'Давай подготовим мои возможности',
      subtitle: 'Без тебя я ничего не включаю. Сначала объясню, зачем это нужно, а решать тебе.',
      body: [list, h('p', { class: 'ds-note', text: 'Всё это можно включить или выключить позже.' })],
      footer: cta,
    });
    el.stagger(cards.map((c) => c.el), 2);
    return { el, onSkip: commit };
  };
})(window.WispApp);
