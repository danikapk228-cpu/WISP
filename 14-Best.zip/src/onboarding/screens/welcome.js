/* Screen 1 · Welcome — WISP здоровается */
(function (App) {
  'use strict';
  const { ui } = App;
  const TEXT = 'Привет! Рад познакомиться. Я WISP — твой личный помощник. Давай немного узнаем друг друга?';

  App.screens.Welcome = function (ctx) {
    const cta = ui.Button({ label: 'Давай познакомимся', onClick: () => { ctx.mascot.react('hop'); ctx.next(); } });
    const hold = ui.h('div', { class: 'ds-hold' }, cta);
    const bubble = ui.SpeechBubble({
      text: TEXT,
      onDone: () => { hold.classList.add('is-shown'); ctx.mascot.react('blink'); },
    });
    const el = ui.ScreenLayout({
      title: 'Знакомство с WISP', titleHidden: true, center: true,
      body: ui.h('div', { class: 'ob-bubble-wrap' }, bubble),
      footer: hold,
    });
    return {
      el,
      enter() {
        ctx.mascot.react('small');
        bubble.start(420);
        // кнопка доступна с клавиатуры сразу; визуально появляется после реплики
        setTimeout(() => hold.classList.add('is-shown'), ui.reducedMotion() ? 0 : 6000);
      },
    };
  };
})(window.WispApp);
