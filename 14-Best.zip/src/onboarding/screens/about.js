/* Screen 5 · Расскажи о себе (необязательный) */
(function (App) {
  'use strict';
  const { ui } = App;

  App.screens.About = function (ctx) {
    const { Profile } = ctx;
    const cta = ui.Button({ label: 'Продолжить', disabled: !ctx.canContinue('about'), onClick: () => { ctx.mascot.react('hop'); ctx.next(); } });
    const later = ui.Button({ label: 'Расскажу позже', variant: 'ghost', onClick: () => ctx.skip() });
    let reacted = false;
    const area = ui.TextArea({
      value: ctx.user.about,
      placeholder: 'Расскажи о своих целях, увлечениях, проектах или о том, что мне стоит знать.',
      label: 'О себе', maxLength: Profile.LIMITS.about,
      onInput: (v) => {
        ctx.update({ about: v });
        const has = v.trim().length > 0;
        cta.setDisabled(!has);
        later.hidden = has;
        if (!reacted && v.trim().length > 24) { reacted = true; ctx.mascot.react('blink'); }
      },
    });
    later.hidden = ctx.canContinue('about');
    const ta = area.textarea;
    // клавиатура не должна перекрывать поле
    ta.addEventListener('focus', () => setTimeout(() => ta.scrollIntoView({ block: 'nearest', behavior: ui.reducedMotion() ? 'auto' : 'smooth' }), 320));

    const el = ui.ScreenLayout({
      title: 'Хочу узнать тебя получше.',
      subtitle: 'Это необязательно, но так мне будет проще помогать именно тебе.',
      body: area,
      footer: [cta, later],
    });
    return { el };
  };
})(window.WispApp);
