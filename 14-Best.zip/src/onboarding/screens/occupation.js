/* Screen 4 · Род занятий (одиночный выбор) */
(function (App) {
  'use strict';
  const { ui } = App;

  App.screens.Occupation = function (ctx) {
    const { Profile } = ctx;
    let current = ctx.user.occupation;
    const cta = ui.Button({ label: 'Продолжить', disabled: !current, onClick: () => { ctx.mascot.react('hop'); ctx.next(); } });
    const hint = ui.h('p', { class: 'ob-hint', text: 'Можешь рассказать подробнее на следующем шаге.' });

    const rows = Profile.OCCUPATIONS.map((o) => {
      const row = ui.OptionRow({
        label: o.label, selected: current === o.id, muted: o.id === 'undisclosed',
        onSelect: () => {
          if (current !== o.id) ctx.mascot.react(o.id === 'undisclosed' ? 'blink' : 'small');
          current = o.id;
          ctx.update({ occupation: o.id });
          rows.forEach((r) => r.setSelected(r._id === o.id));
          cta.setDisabled(false);
          hint.classList.toggle('is-on', o.id === 'other');
        },
      });
      row._id = o.id;
      return row;
    });
    hint.classList.toggle('is-on', current === 'other');
    const group = ui.RadioGroup({ label: 'Род занятий', rows });
    group.dataset.noStagger = '1';

    const el = ui.ScreenLayout({
      title: 'Чем ты сейчас занимаешься?',
      subtitle: 'Так я лучше пойму, в каком ритме ты живёшь.',
      body: [group, hint],
      footer: cta,
    });
    el.stagger(rows, 2);
    return { el };
  };
})(window.WispApp);
