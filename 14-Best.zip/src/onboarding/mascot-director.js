/* WISP · Onboarding · MascotDirector
 * Управляет присутствием маскота поверх Layer 0, не трогая его код:
 *  · поза (размер и положение) задаётся transform'ом на .wisp-stage, физика Layer 0 продолжает работать внутри;
 *  · реакции идут через публичный API Layer 0: WISP.hop() / WISP.blink().
 * Пишет CSS-переменные --mascot-cy, --mascot-h, --content-top для раскладки экранов. */
(function (App) {
  'use strict';

  // Из метрик ассетов Layer 0: высота тела / высота спрайта; центр тела совпадает с центром спрайта.
  const BODY_RATIO = 1142 / 1640;
  // Layer 0 ставит «поверхность» на vh·0.5 + 0.46·H, значит центр тела в покое на vh·0.5 − 0.04·H.
  const restCenterY = (vh, H) => vh * 0.5 - 0.04 * H;

  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const HEADER = 60;

  const POSES = {
    hero:      (vh, top) => { const h = clamp(vh * 0.24, 104, 216); return { h, cy: top + HEADER + h * 0.55 + clamp(vh * 0.03, 6, 30) }; },
    focus:     (vh, top) => { const h = clamp(vh * 0.105, 58, 98);  return { h, cy: top + HEADER + h * 0.5 + 2 }; },
    compact:   (vh, top) => { const h = 46;                          return { h, cy: top + HEADER - 6 + h * 0.5 }; },
    celebrate: (vh, top) => { const h = clamp(vh * 0.26, 112, 232); return { h, cy: top + HEADER + h * 0.55 + clamp(vh * 0.05, 8, 48) }; },
    home:      (vh, top) => { const h = clamp(vh * 0.12, 66, 104);  return { h, cy: top + HEADER + h * 0.5 }; },
  };

  class MascotDirector {
    constructor(stage, appRoot) {
      this.stage = stage;
      this.root = appRoot;
      this.actor = stage ? stage.querySelector('.wisp-actor') : null;
      this.pose = 'entrance';
      this.keyboard = false;
      this.probe = document.createElement('div');
      this.probe.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;visibility:hidden;pointer-events:none;padding-top:env(safe-area-inset-top,0px)';
      document.body.appendChild(this.probe);
      const re = () => { cancelAnimationFrame(this.raf); this.raf = requestAnimationFrame(() => requestAnimationFrame(() => this.apply(true))); };
      window.addEventListener('resize', re);
      window.addEventListener('orientationchange', re);
    }
    get api() { return window.WISP || null; }
    safeTop() { return parseFloat(getComputedStyle(this.probe).paddingTop) || 0; }

    /* measure (необязательно): (vh, safeTop) → { h, cy[, cx] } в координатах корня приложения.
     * Так главный экран ставит маскота в свою область, а не в фиксированную позу. */
    setPose(pose, measure) { this.pose = pose; this.measure = typeof measure === 'function' ? measure : null; this.apply(false); }
    setKeyboard(open) { if (this.keyboard === open) return; this.keyboard = open; this.apply(false); }

    apply(instant) {
      const st = this.stage;
      const vhRoot = this.root.clientHeight || window.innerHeight;
      const top = this.safeTop();
      const name = this.keyboard && (this.pose === 'focus' || this.pose === 'hero') ? 'compact' : this.pose;
      const t = (this.measure && this.measure(vhRoot, top)) || (POSES[name] || POSES.focus)(vhRoot, top);
      // переменные раскладки: контент начинается под маскотом и его искрами
      this.root.style.setProperty('--mascot-cy', t.cy.toFixed(1) + 'px');
      this.root.style.setProperty('--mascot-h', t.h.toFixed(1) + 'px');
      this.root.style.setProperty('--content-top', Math.round(t.cy + t.h * 0.72 + 14) + 'px');
      this.center = t;
      if (!st || !this.actor || this.pose === 'entrance') return;
      const H0 = this.actor.offsetHeight * BODY_RATIO;
      if (!H0) return;
      const cy0 = restCenterY(st.clientHeight, H0);
      const s = t.h / H0;
      // точка покоя маскота внутри сцены: по ней слои после Layer 0 рисуют своё свечение
      st.style.setProperty('--wisp-rest-cy', cy0.toFixed(1) + 'px');
      st.style.setProperty('--wisp-rest-h', H0.toFixed(1) + 'px');
      const off = this.root._vvOffset || 0;
      st.classList.add('is-posed');
      st.classList.toggle('is-instant', !!instant);
      st.style.transformOrigin = `50% ${cy0.toFixed(1)}px`;
      // [Layer 4 hook] необязательный t.cx: горизонтальная точка (по умолчанию маскот по центру, как раньше)
      const dx = typeof t.cx === 'number' ? t.cx - st.clientWidth / 2 : 0;
      st.style.transform = `translate3d(${dx.toFixed(1)}px, ${(t.cy + off - cy0).toFixed(1)}px, 0) scale(${s.toFixed(4)})`;
    }

    /* Реакции маскота. Сила подобрана так, чтобы не перебивать интерфейс. */
    react(kind) {
      const w = this.api;
      /* Layer 13: «Реакции маскота» выключены — персонаж не прыгает в ответ на действия (моргание остаётся) */
      const P = App.settings && App.settings.Prefs;
      if (P && P.get().mascot_react === false && kind !== 'blink' && kind !== 'calm') return;
      if (App.settings && App.settings.Sound && (kind === 'joy' || kind === 'celebrate')) App.settings.Sound.play('success');
      if (!w || !w.hop) return;
      const later = (fn, ms) => setTimeout(fn, ms);
      switch (kind) {
        case 'small': w.hop(0.5); break;
        case 'hop': w.hop(0.85); break;
        case 'joy': w.hop(1.15); break;
        case 'nod': w.hop(0.35); break;
        case 'calm': w.blink(false); break;
        case 'blink': w.blink(false); break;
        case 'double': w.hop(0.7); later(() => w.hop(0.7), 760); break;
        case 'celebrate': w.hop(1.35); later(() => w.hop(0.8), 980); later(() => w.blink(true), 1900); break;
        default: break;
      }
    }
  }

  App.onboarding.MascotDirector = MascotDirector;
})(window.WispApp);
