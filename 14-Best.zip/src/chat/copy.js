/* WISP · Chat · Copy
 * Тексты чата: пустой экран и состояния в характере WISP. Ошибки сформулированы честно и коротко:
 * что случилось и что можно сделать. */
(function (App) {
  'use strict';

  const VOICES = {
    friendly: {
      title: (n) => (n ? `О чём поговорим, ${n}?` : 'О чём поговорим?'),
      sub: 'Спрашивай что угодно. Я рядом.',
      interrupted: 'Ой, я сбился на полуслове.',
      failed: 'Не получилось ответить.',
      empty: 'Я задумался и ничего не написал.',
    },
    calm: {
      title: (n) => (n ? `Я слушаю, ${n}` : 'Я слушаю'),
      sub: 'Расскажи, что у тебя на уме.',
      interrupted: 'Ответ прервался. Можно продолжить.',
      failed: 'Ответить не получилось.',
      empty: 'Ответ получился пустым.',
    },
    business: {
      title: (n) => (n ? `${n}, слушаю.` : 'Слушаю.'),
      sub: 'Опиши задачу.',
      interrupted: 'Ответ прерван.',
      failed: 'Ошибка генерации.',
      empty: 'Пустой ответ.',
    },
    humor: {
      title: (n) => (n ? `${n}, выкладывай!` : 'Выкладывай!'),
      sub: 'Вопросы, идеи, безумные планы: всё принимается.',
      interrupted: 'Я запнулся на самом интересном месте.',
      failed: 'Мысль убежала. Бывает.',
      empty: 'Я многозначительно промолчал. Случайно.',
    },
    adaptive: {
      title: (n) => (n ? `Чем помочь, ${n}?` : 'Чем помочь?'),
      sub: 'Коротко или подробно — как тебе удобнее.',
      interrupted: 'Ответ прервался.',
      failed: 'Не получилось ответить.',
      empty: 'Ответ получился пустым.',
    },
  };

  function voice(profile) {
    const p = App.core.Profile.effectivePersonality(profile);
    return VOICES[p.id] || VOICES.adaptive;
  }

  const time = (t) => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

  /* Ошибка → { title, text, action } для карточки под сообщением */
  function error(code, data, v) {
    const d = data || {};
    switch (code) {
      case 'offline': return { title: 'Нет интернета', text: 'Сообщение не отправлено. Повтори, когда связь вернётся.', action: 'retry' };
      case 'network': return { title: 'Нет связи с сервером', text: 'Сообщение не отправлено. Попробуй ещё раз.', action: 'retry' };
      case 'timeout': return { title: 'Слишком долго', text: 'Сервер не ответил вовремя. Попробуй ещё раз.', action: 'retry' };
      case 'not_connected': return { title: 'AI не подключён', text: 'Эта копия WISP открыта без сервера.', action: null };
      case 'request_ambiguous': return { title: 'Сообщение могло сохраниться', text: 'Проверь историю чатов перед повторной отправкой.', action: null };
      case 'connection_lost': return { title: v.interrupted, text: 'Связь прервалась посреди ответа. Твоё сообщение сохранено.', action: 'regenerate' };
      case 'interrupted': return { title: v.interrupted, text: 'Ответ не был закончен.', action: 'regenerate' };
      case 'cancelled': return { title: 'Отправка отменена', text: null, action: 'retry' };
      case 'stopped': return { title: 'Остановлено', text: null, action: 'regenerate' };
      case 'limit_daily': return { title: 'Лимит на сегодня исчерпан', text: d.reset_at ? `Новые сообщения можно будет отправить после ${time(d.reset_at)}.` : 'Попробуй завтра.', action: 'plan' };
      case 'rate_limited': return { title: 'Слишком часто', text: d.retry_after ? `Подожди ${d.retry_after} с и попробуй снова.` : 'Подожди немного и попробуй снова.', action: 'retry' };
      case 'busy': return { title: 'Я ещё отвечаю', text: 'Дождись конца ответа или останови его.', action: 'retry' };
      case 'plan_required': return { title: 'Эта модель в Plus', text: 'Выбери другую модель в меню.', action: 'models' };
      case 'model_unavailable': return { title: 'Модель недоступна', text: 'Выбери другую модель в меню или попробуй позже.', action: 'models' };
      case 'model_no_vision': return { title: 'Модель не видит картинки', text: 'Выбери модель с поддержкой изображений.', action: 'models' };
      case 'too_long': return { title: 'Слишком длинное сообщение', text: d.limit ? `Максимум ${d.limit} символов. Сократи и отправь снова.` : 'Сократи и отправь снова.', action: 'edit' };
      case 'too_many_images': return { title: 'Слишком много картинок', text: d.limit ? `Можно до ${d.limit} за раз.` : null, action: 'edit' };
      case 'image_too_large': case 'bad_image': return { title: 'Картинка не подошла', text: 'Попробуй другое изображение.', action: 'edit' };
      case 'empty_reply': return { title: v.empty, text: null, action: 'regenerate' };
      case 'provider_auth': return { title: v.failed, text: 'AI-сервис не принял ключ сервера. Это нужно исправить в настройках сервера.', action: null };
      case 'provider_rate_limited': case 'provider_busy': return { title: 'AI-сервис перегружен', text: 'Попробуй через минуту.', action: 'regenerate' };
      case 'content_filtered': return { title: 'Без ответа', text: 'AI-сервис отказался отвечать на этот запрос.', action: null };
      case 'unauthorized': return { title: 'Сессия устарела', text: 'Обнови страницу.', action: null };
      default: return { title: v.failed, text: d.message && d.message.length < 120 ? d.message : 'Попробуй ещё раз.', action: 'regenerate' };
    }
  }

  App.chat.Copy = { voice, error, time, VOICES };
})(window.WispApp);
