/* WISP · Chat · Message
 * Одно сообщение. Пользователь справа (стеклянная капля), WISP слева: текст без «пузыря»,
 * со светящимся следом слева, как от самого огонька. Действия спрятаны в компактное меню:
 * на телефоне по касанию сообщения, на компьютере по кнопке «…» при наведении.
 * msg: { key, id?, role, content, status, error_code, created_at, attachments[], actions[], errorData? }
 * Layer 4: actions — что сервер реально выполнил по просьбе модели (напоминание, задача…). Показываются
 * карточками над текстом ответа; нажатие открывает инструмент. Карточка = подтверждение из базы, не из текста модели.
 * status: complete | streaming | interrupted | error | empty | pending | failed
 * Layer 5: действия памяти (kind: memory) — «Запомнил», «Обновил», предложение «Запомнить?» с кнопками.
 * Текст и статус карточки приходят с сервера (таблица memories), а не из ответа модели.
 * memory_used — какие воспоминания WISP видел, отвечая: маленькая кнопка «Память · N» под ответом. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Markdown, Copy } = App.chat;

  App.chat.MessageView = function (initial, ctx) {
    let msg = initial;
    let flags = {};
    let rendered = { content: null, streaming: null };
    const isUser = msg.role === 'user';

    const media = h('div', { class: 'cm__media', hidden: true });
    const actionsEl = h('div', { class: 'cm__acts', hidden: true, role: 'list', 'aria-label': 'Действия WISP' });
    const content = h('div', { class: isUser ? 'cm__bubble' : 'cm__md' });
    const thinking = h('div', { class: 'cm__thinking', hidden: true, 'aria-hidden': 'true' }, h('i'), h('i'), h('i'));
    const note = h('div', { class: 'cm__note', hidden: true });
    const time = h('time', { class: 'cm__time' });
    const state = h('span', { class: 'cm__state' });
    const quick = h('div', { class: 'cm__quick' });
    const more = ui.pressable(h('button', { type: 'button', class: 'cm__btn cm__more', 'aria-label': 'Действия с сообщением', 'aria-haspopup': 'menu', 'aria-expanded': 'false' }, ui.icon('more')));
    if (isUser) more.dataset.align = 'right';
    const memChip = isUser ? null : ui.pressable(h('button', { type: 'button', class: 'cm__mem', hidden: true, onClick: (e) => { e.stopPropagation(); if (ctx.memory) ctx.memory.showUsed(msg); } }));
    const meta = h('div', { class: 'cm__meta' }, time, state, memChip, quick, more);
    const body = h('div', { class: 'cm__body' }, media, actionsEl, content, thinking);
    const el = h('article', { class: `cm ${isUser ? 'cm--user' : 'cm--wisp'} is-new`, 'aria-label': isUser ? 'Твоё сообщение' : 'Ответ WISP' },
      isUser ? null : h('span', { class: 'cm__trail', 'aria-hidden': 'true' }), body, note, meta);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove('is-new')));

    more.addEventListener('click', (e) => { e.stopPropagation(); openMenu(more); });
    /* касание по сообщению на телефоне: меню (если это не ссылка, кнопка, код или выделение текста) */
    body.addEventListener('click', (e) => {
      if (ui.finePointer()) return;
      if (e.target.closest('a, button, pre, .md-table, img')) return;
      const sel = window.getSelection && window.getSelection();
      if (sel && String(sel).trim()) return;
      openMenu(isUser ? content : body);
    });

    function quickBtn(icon, label, kind) {
      return ui.pressable(h('button', { type: 'button', class: 'cm__btn', 'aria-label': label, title: label, onClick: (e) => { e.stopPropagation(); ctx.onAction(kind, msg, e.currentTarget); } }, ui.icon(icon)));
    }

    function menuItems() {
      const sent = !!msg.id;
      const items = [];
      if (msg.content) items.push({ icon: 'copy', label: 'Копировать', onSelect: () => ctx.onAction('copy', msg) });
      if (isUser) {
        if (msg.status === 'failed') items.push({ icon: 'refresh', label: 'Отправить ещё раз', onSelect: () => ctx.onAction('retry', msg) });
        if ((flags.isLastUser && sent && !flags.generating) || msg.status === 'failed') items.push({ icon: 'edit', label: 'Изменить', onSelect: () => ctx.onAction('edit', msg) });
      } else if (flags.isLastAssistant && !flags.generating && msg.status !== 'streaming') {
        items.push({ icon: 'refresh', label: 'Ответить заново', onSelect: () => ctx.onAction('regenerate', msg) });
      }
      if (!flags.generating || msg.status === 'failed') {
        items.push({
          icon: 'trash', label: 'Удалить', danger: true,
          confirm: isUser && flags.hasReply ? 'Удалить вместе с ответом?' : 'Точно удалить?',
          onSelect: () => ctx.onAction('delete', msg),
        });
      }
      return items;
    }
    function openMenu(anchor) {
      const items = menuItems();
      if (!items.length) return;
      ui.haptic(6);
      App.chat.Menu.open({ anchor, container: ctx.menuHost(), items, label: isUser ? 'Действия с твоим сообщением' : 'Действия с ответом WISP' });
    }

    function paintMedia() {
      const atts = msg.attachments || [];
      media.hidden = !atts.length;
      if (!atts.length) { media.replaceChildren(); return; }
      if (media.childElementCount === atts.length && media.dataset.sig === atts.map((a) => a.url || a.key).join('|')) return;
      media.dataset.sig = atts.map((a) => a.url || a.key).join('|');
      media.classList.toggle('is-multi', atts.length > 1);
      media.replaceChildren(...atts.map((a, i) => {
        const img = h('img', { class: 'cm__img', alt: atts.length > 1 ? `Изображение ${i + 1}` : 'Изображение', decoding: 'async', loading: 'lazy', src: a.url || a.dataUrl });
        if (a.width && a.height) { img.width = a.width; img.height = a.height; }
        return ui.pressable(h('button', { type: 'button', class: 'cm__imgbtn', 'aria-label': 'Открыть изображение', onClick: (e) => { e.stopPropagation(); ctx.openImage(a); } }, img));
      }));
    }

    function paintActions() {
      const acts = msg.actions || [];
      actionsEl.hidden = !acts.length;
      const sig = JSON.stringify(acts.map((a) => ({
        id: a.id, status: a.status, op: a.op, memory_status: a.memory_status,
        pending_status: a.pending_status, pending: a.pending && [a.pending.status, a.pending.expires_at, a.pending.items],
        live: a.live, items: a.items,
      })));
      if (actionsEl.dataset.sig === sig) return;
      actionsEl.dataset.sig = sig;
      actionsEl.replaceChildren(...acts.map((a) => actionCard(a, ctx)));
    }

    function paintContent() {
      const streaming = msg.status === 'streaming';
      const P = App.settings && App.settings.Prefs;
      const mode = P ? `${P.get().chat_markdown}|${P.get().chat_code_hl}` : '';
      if (rendered.content === msg.content && rendered.streaming === streaming && rendered.mode === mode) return;
      rendered = { content: msg.content, streaming, mode };
      if (!msg.content) { content.replaceChildren(); content.hidden = true; }
      else {
        content.hidden = false;
        content.replaceChildren(Markdown.render(msg.content, { caret: streaming }));
      }
      thinking.hidden = !(streaming && !msg.content);
    }

    function paintNote() {
      const v = ctx.voice();
      let info = null;
      const code = msg.error_code;
      if (isUser && (msg.status === 'failed' || msg.status === 'interrupted')) info = Copy.error(code, msg.errorData, v);
      else if (!isUser && (msg.status === 'error' || msg.status === 'empty' || msg.status === 'interrupted')) {
        info = Copy.error(msg.status === 'empty' ? 'empty_reply' : code || (msg.status === 'interrupted' ? 'interrupted' : 'provider_error'), msg.errorData, v);
        if (!flags.isLastAssistant) info = { title: info.title, text: null, action: null, compact: true };
      }
      note.hidden = !info;
      el.dataset.status = msg.status;
      if (!info) { note.replaceChildren(); return; }
      const actions = [];
      const btn = (label, kind, primary) => ui.pressable(h('button', { type: 'button', class: `cm__action${primary ? ' is-primary' : ''}`, onClick: (e) => { e.stopPropagation(); ctx.onAction(kind, msg); } }, label));
      if (!flags.generating) {
        if (info.action === 'retry' && isUser) actions.push(btn('Повторить', 'retry', true));
        if (info.action === 'regenerate' && !isUser) actions.push(btn('Повторить', 'regenerate', true));
        if (info.action === 'models') actions.push(btn('Выбрать модель', 'models', true));
        if (info.action === 'plan') actions.push(btn('Подробнее', 'plan', false));
        if (isUser && msg.status === 'failed') actions.push(btn('Изменить', 'edit', false));
      }
      note.className = `cm__note${info.compact ? ' is-compact' : ''}${msg.status === 'interrupted' && code === 'stopped' ? ' is-quiet' : ''}`;
      note.replaceChildren(
        h('span', { class: 'cm__note-icon', 'aria-hidden': 'true' }, ui.icon(code === 'offline' ? 'wifiOff' : 'alert')),
        h('div', { class: 'cm__note-text' },
          h('p', { class: 'cm__note-title', text: info.title }),
          info.text ? h('p', { class: 'cm__note-sub', text: info.text }) : null),
        actions.length ? h('div', { class: 'cm__note-actions' }, actions) : null);
    }

    function paintMeta() {
      const t = msg.created_at || Date.now();
      time.textContent = Copy.time(t);
      time.dateTime = new Date(t).toISOString();
      time.hidden = !flags.showTime && msg.status !== 'failed';
      state.textContent = msg.status === 'pending' ? 'отправляю…' : msg.status === 'failed' ? 'не отправлено' : '';
      state.hidden = !state.textContent;
      const showQuick = !isUser && flags.isLastAssistant && !flags.generating && msg.status !== 'streaming' && !!msg.content;
      quick.replaceChildren(...(showQuick ? [quickBtn('copy', 'Копировать ответ', 'copy'), quickBtn('refresh', 'Ответить заново', 'regenerate')] : []));
      if (memChip) {
        const used = (msg.memory_used || []).length;
        memChip.hidden = !used || !ctx.memory;
        if (used) {
          memChip.replaceChildren(ui.icon('memory'), `Память · ${used}`);
          memChip.setAttribute('aria-label', `WISP учёл ${used} ${App.tools.plural(used, 'воспоминание', 'воспоминания', 'воспоминаний')}. Показать`);
        }
      }
      more.hidden = msg.status === 'streaming' || msg.status === 'pending';
      meta.classList.toggle('is-visible', showQuick || !time.hidden || !state.hidden || (memChip && !memChip.hidden));
    }

    function update(next, f) {
      if (next) msg = next;
      if (f) flags = f;
      paintMedia();
      paintActions();
      paintContent();
      paintNote();
      paintMeta();
      el.classList.toggle('is-group-end', !!flags.showTime);
    }
    update(msg, ctx.flagsFor ? ctx.flagsFor(msg) : {});

    return { el, update, get msg() { return msg; }, contentEl: content };
  };

  const ICONS = { reminder: 'bell', task: 'task', note: 'notes', event: 'calendar', agenda: 'calendar', tasks: 'task', reminders: 'bell', notes: 'search', search: 'search', memory: 'memory' };
  const RECORD_KINDS = new Set(['reminder', 'task', 'note', 'event']);
  const Format = App.tools && App.tools.Format;
  function recordTitle(kind, live, fallback) {
    if (!live) return fallback || 'Запись недоступна';
    return live.title || live.content || live.excerpt || fallback || 'Без названия';
  }
  function recordMeta(kind, live) {
    if (!live) return 'Запись удалена или недоступна';
    const day = (d) => Format && d ? Format.dayLabel(d) : d;
    if (kind === 'task') return [live.done ? 'Выполнена' : 'Активна', live.due_date ? `Срок: ${day(live.due_date)}` : null, live.priority ? `Приоритет: ${live.priority}` : null].filter(Boolean).join(' · ');
    if (kind === 'reminder') return [live.done ? 'Выполнено' : 'Активно', live.remind_at && Format ? Format.when(live.remind_at) : [day(live.date), live.time].filter(Boolean).join(', ')].filter(Boolean).join(' · ');
    if (kind === 'event') return ['Запланировано', [day(live.date), live.start_time, live.end_time ? `до ${live.end_time}` : null].filter(Boolean).join(', ')].filter(Boolean).join(' · ');
    if (kind === 'note') return live.updated_at && Format ? `Изменено ${Format.ago(live.updated_at)}` : 'Заметка';
    if (kind === 'memory') return live.category || 'Память';
    return live.date ? day(live.date) : '';
  }
  function recordEntry(item, ctx, { controls = true } = {}) {
    const kind = item.kind;
    const live = item.live;
    const title = recordTitle(kind, live, item.title);
    const sub = recordMeta(kind, live);
    const icon = ui.icon(ICONS[kind] || 'spark');
    const main = h('span', { class: 'cm-act__entry-main' },
      h('span', { class: 'cm-act__entry-title', text: title }),
      sub ? h('span', { class: 'cm-act__entry-sub', text: sub }) : null);
    const canManage = controls && live && RECORD_KINDS.has(kind) && item.record_id;
    const buttons = canManage && (ctx.editRecord || ctx.deleteRecord)
      ? h('span', { class: 'cm-act__entry-actions' },
        ctx.editRecord ? ui.Button({ label: 'Изменить', variant: 'secondary', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.editRecord(item); } }) : null,
        ctx.deleteRecord ? ui.Button({ label: 'Удалить', variant: 'ghost', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.deleteRecord(item); } }) : null)
      : null;
    return h('div', { class: `cm-act__entry${live ? '' : ' is-gone'}`, role: 'listitem' }, icon, main, buttons);
  }
  function describeMemory(a) {
    if (a.status !== 'ok') return { title: 'Не запомнил', sub: a.error || 'Память не изменилась' };
    const st = a.memory_status;
    const text = a.content || null;
    if (a.op === 'forgotten') return { title: 'Забыл', sub: [text] };
    if (st === 'dismissed') return { title: 'Не стал запоминать', sub: [] };
    if (st === 'gone' || st === 'forgotten') return { title: 'Больше не в памяти', sub: [] };
    if (st === 'pending') return a.sensitive || a.op === 'needs_consent'
      ? { title: 'Это личное. Сохранить в память?', sub: [text, a.label ? `(${a.label})` : null] }
      : { title: 'Запомнить?', sub: [text] };
    if (a.op === 'updated') return { title: 'Обновил в памяти', sub: [text] };
    if (a.op === 'unchanged' || a.op === 'known') return { title: 'Уже помню', sub: [text] };
    return { title: 'Запомнил', sub: [text] };
  }
  function describe(a) {
    if (a.kind === 'memory') return describeMemory(a);
    const F = App.tools && App.tools.Format;
    const day = (d) => (F ? F.dayLabel(d) : d);
    if (a.status !== 'ok') return { title: 'Не получилось', sub: a.error || 'Действие не выполнено' };
    if (a.kind === 'reminder') return { title: 'Напоминание создано', sub: [a.title, a.remind_at && F ? F.when(a.remind_at) : `${a.date} ${a.time}`] };
    if (a.kind === 'task' && a.op === 'completed') return { title: 'Задача выполнена', sub: [a.title] };
    if (a.kind === 'task') return { title: 'Задача добавлена', sub: [a.title, a.due_date ? `срок: ${day(a.due_date).toLowerCase()}` : null, a.priority === 'high' ? 'High' : null] };
    if (a.kind === 'note') return { title: 'Заметка сохранена', sub: [a.title] };
    if (a.kind === 'event') return { title: 'Добавлено в план', sub: [a.title, `${day(a.date)}, ${a.time}${a.end_time ? '–' + a.end_time : ''}`] };
    if (a.kind === 'agenda') return { title: 'Посмотрел планы', sub: [day(a.date), a.count ? `записей: ${a.count}` : 'пусто'] };
    if (a.kind === 'tasks') return { title: 'Посмотрел задачи', sub: [`найдено: ${a.count}`] };
    if (a.kind === 'reminders') return { title: 'Посмотрел напоминания', sub: [`найдено: ${a.count}`] };
    if (a.kind === 'notes') return { title: 'Поиск в заметках', sub: [a.query ? `«${a.query}»` : null, `найдено: ${a.count}`] };
    if (a.kind === 'search') return { title: 'Поиск по данным', sub: [a.query ? `«${a.query}»` : null, `найдено: ${a.count}`] };
    return { title: 'Готово', sub: [] };
  }
  /* Layer 5: карточка памяти. Предложение — с кнопками «Запомнить» / «Не надо», остальное открывает Memory. */
  function memoryCard(a, ctx) {
    const d = describeMemory(a);
    const ok = a.status === 'ok';
    const pending = ok && a.memory_status === 'pending';
    const gone = ok && (a.memory_status === 'gone' || a.memory_status === 'forgotten' || a.memory_status === 'dismissed' || a.op === 'forgotten');
    const sub = [].concat(d.sub).filter(Boolean).join(' ');
    const canOpen = ok && !pending && !gone && ctx.memory && a.memory_id;
    const el = h(canOpen ? 'button' : 'div', { class: `cm-act cm-act--mem${ok ? '' : ' is-error'}${pending ? ' is-pending' : ''}${pending && a.sensitive ? ' is-sensitive' : ''}${gone ? ' is-gone' : ''}`, role: 'listitem', type: canOpen ? 'button' : null },
      h('span', { class: 'cm-act__icon', 'aria-hidden': 'true' }, ui.icon(ok ? 'memory' : 'alert'), ok && !pending && !gone ? h('i', { class: 'cm-act__ok' }, ui.icon('check')) : null),
      h('span', { class: 'cm-act__main' }, h('span', { class: 'cm-act__title', text: d.title }), sub ? h('span', { class: 'cm-act__sub', text: sub }) : null),
      canOpen ? ui.icon('chevron', 'ds-icon cm-act__chev') : null);
    if (canOpen) { ui.pressable(el); el.addEventListener('click', (e) => { e.stopPropagation(); ctx.memory.open(a.memory_id); }); }
    if (pending && ctx.memory) {
      const yes = ui.Button({ label: a.sensitive ? 'Сохранить' : 'Запомнить', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.memory.confirm(a, yes); } });
      const no = ui.Button({ label: 'Не надо', variant: 'ghost', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.memory.dismiss(a, no); } });
      el.appendChild(h('span', { class: 'cm-act__btns' }, yes, no));
    }
    return el;
  }
  function pendingCard(a, ctx) {
    const p = a.pending || {};
    const status = a.pending_status || p.status || (a.op === 'done' ? 'done' : a.op === 'cancelled' ? 'cancelled' : a.op === 'failed' ? 'failed' : 'pending');
    const pending = status === 'pending' && (!p.expires_at || p.expires_at > Date.now());
    const states = { pending: 'Ждёт подтверждения', done: 'Выполнено', cancelled: 'Отменено', expired: 'Срок подтверждения истёк', failed: 'Не выполнено', executing: 'Выполняется', gone: 'Состояние недоступно' };
    const items = p.items || a.items || [];
    const controls = pending && ctx.actions ? h('span', { class: 'cm-act__btns' },
      ui.Button({ label: a.button_only || p.button_only ? 'Подтвердить' : 'Подтвердить', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.actions.confirm(a, e.currentTarget); } }),
      ui.Button({ label: 'Отмена', variant: 'ghost', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.actions.cancel(a, e.currentTarget); } })) : null;
    const sub = [states[status] || status, a.count ? `записей: ${a.count}` : null, p.expires_at ? `до ${new Date(p.expires_at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}` : null, p.error || a.error].filter(Boolean).join(' · ');
    return h('article', { class: `cm-act cm-act--confirm${pending ? ' is-pending' : ''}${status === 'failed' ? ' is-error' : ''}`, role: 'listitem' },
      h('span', { class: 'cm-act__icon', 'aria-hidden': 'true' }, ui.icon(pending ? 'alert' : status === 'done' ? 'check' : 'trash')),
      h('span', { class: 'cm-act__main' },
        h('span', { class: 'cm-act__title', text: a.title || p.title || 'Подтвердить действие' }),
        sub ? h('span', { class: 'cm-act__sub', text: sub }) : null),
      items.length ? h('span', { class: 'cm-act__entries', role: 'list' }, items.slice(0, 8).map((it) => recordEntry(it, ctx, { controls: false }))) : null,
      controls);
  }
  function actionCard(a, ctx) {
    if (a.kind === 'memory') return memoryCard(a, ctx);
    if (a.kind === 'confirm') return pendingCard(a, ctx);
    const d = describe(a);
    const ok = a.status === 'ok';
    const isList = ['agenda', 'search', 'tasks', 'notes', 'reminders'].includes(a.kind) && Array.isArray(a.items);
    if (isList) {
      const items = a.items || [];
      const sub = [a.query ? `«${a.query}»` : null, `${a.count || items.length} ${a.kind === 'agenda' ? 'записей' : 'результатов'}`, a.days > 1 ? `${a.days} дн.` : null].filter(Boolean).join(' · ');
      return h('article', { class: `cm-act cm-act--list${ok ? '' : ' is-error'} is-read`, role: 'listitem' },
        h('span', { class: 'cm-act__icon', 'aria-hidden': 'true' }, ui.icon(ok ? ICONS[a.kind] || 'search' : 'alert')),
        h('span', { class: 'cm-act__main' },
          h('span', { class: 'cm-act__title', text: d.title }),
          sub ? h('span', { class: 'cm-act__sub', text: sub }) : null),
        items.length ? h('span', { class: 'cm-act__entries', role: 'list' }, items.slice(0, 14).map((it) => recordEntry(it, ctx))) : h('span', { class: 'cm-act__sub cm-act__empty', text: ok ? 'Совпадений нет' : d.sub }) );
    }
    if (RECORD_KINDS.has(a.kind) && a.record_id) {
      const live = a.live;
      const item = { kind: a.kind, record_id: a.record_id, live, title: a.title };
      const sub = live ? recordMeta(a.kind, live) : 'Запись удалена или недоступна';
      return h('article', { class: `cm-act cm-act--record${ok ? '' : ' is-error'}${live ? '' : ' is-gone'}`, role: 'listitem' },
        h('span', { class: 'cm-act__icon', 'aria-hidden': 'true' }, ui.icon(ok ? ICONS[a.kind] || 'spark' : 'alert'), ok && live ? h('i', { class: 'cm-act__ok' }, ui.icon('check')) : null),
        h('span', { class: 'cm-act__main' },
          h('span', { class: 'cm-act__title', text: recordTitle(a.kind, live, a.title || d.title) }),
          sub ? h('span', { class: 'cm-act__sub', text: sub }) : null),
        live ? h('span', { class: 'cm-act__entry-actions' },
          ctx.editRecord ? ui.Button({ label: 'Изменить', variant: 'secondary', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.editRecord(item); } }) : null,
          ctx.deleteRecord ? ui.Button({ label: 'Удалить', variant: 'ghost', size: 'small', onClick: (e) => { e.stopPropagation(); ctx.deleteRecord(item); } }) : null) : null);
    }
    const sub = [].concat(d.sub).filter(Boolean).join(' · ');
    return h('article', { class: `cm-act${ok ? '' : ' is-error'}${a.op === 'read' ? ' is-read' : ''}`, role: 'listitem' },
      h('span', { class: 'cm-act__icon', 'aria-hidden': 'true' }, ui.icon(ok ? ICONS[a.kind] || 'spark' : 'alert'), ok && a.op !== 'read' ? h('i', { class: 'cm-act__ok' }, ui.icon('check')) : null),
      h('span', { class: 'cm-act__main' }, h('span', { class: 'cm-act__title', text: d.title }), sub ? h('span', { class: 'cm-act__sub', text: sub }) : null));
  }
  App.chat.MessageView.describeAction = describe;
})(window.WispApp);
