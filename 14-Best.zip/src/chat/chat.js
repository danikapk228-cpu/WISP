/* WISP · Layer 3 · Chat
 * Разговор с WISP: верхняя панель (назад, WISP + состояние, новый диалог, меню), лента сообщений,
 * строка ввода с голосом и картинками. Ответ приходит потоком с сервера и рисуется по мере получения.
 * Маскот тот же, что в Layer 0: в пустом чате он в центре, с первым сообщением «взлетает» в шапку.
 *
 * Источник правды по истории — сервер (диалоги привязаны к сессии пользователя). Локально хранится только
 * состояние интерфейса: последний открытый диалог и черновики (Storage.ChatStateRepository).
 * Layer 5: карточки памяти в ответах («Запомнил», «Запомнить?») и кнопка «Память · N» — что WISP учёл. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  const { Profile } = App.core;
  const { Markdown, Copy, MessageView, Images, Menu } = App.chat;

  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  let seq = 0;
  const localKey = () => `l${Date.now().toString(36)}${(++seq).toString(36)}`;
  const DAY = 86400000;
  const RECORD_KINDS = new Set(['reminder', 'task', 'note', 'event']);

  function dayLabel(t) {
    const d = new Date(t); const now = new Date();
    const start = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const diff = Math.round((start(now) - start(d)) / DAY);
    if (diff === 0) return 'Сегодня';
    if (diff === 1) return 'Вчера';
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
  }
  function relTime(t) {
    const d = new Date(t); const now = new Date();
    const diff = Math.round((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / DAY);
    if (diff === 0) return Copy.time(t);
    if (diff === 1) return 'вчера';
    if (diff < 7) return d.toLocaleDateString('ru-RU', { weekday: 'short' });
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : '2-digit' });
  }
  const fromServer = (m) => ({ ...m, key: m.id, attachments: (m.attachments || []).map((a) => ({ ...a, key: a.id })) });

  App.chat.ChatView = function ({ root, store, director, assistant, chatState, openSheet, closeSheet, onBack, onLayout, onPlan, openTool, toolsApi, memoryApi, openMemory }) {
    const voice = () => Copy.voice(store.profile);
    /* Layer 13: настройки чата (раздел «Чат») читаются в момент использования — меняются без перезапуска */
    const cp = () => store.user.preferences;
    const sound = (k) => { if (App.settings && App.settings.Sound) App.settings.Sound.play(k); };
    const setDraft = (key, text) => { if (cp().chat_drafts !== false) chatState.setDraft(key, text); };
    const getDraft = (key) => (cp().chat_drafts !== false ? chatState.draft(key) : '');
    let conv = null;                    // { id, title, model, … } | null для нового диалога
    let messages = [];
    const views = new Map();
    let generating = null;              // { ctrl, msg, kind }
    let editing = null;                 // { msg }
    let attachments = [];               // { key, status, dataUrl, width, height, error }
    let selectedModel = null;
    let loading = false;
    let loadError = null;
    let pinned = true;
    let shown = false;
    let restored = false;
    let online = navigator.onLine !== false;
    let destroyed = false;
    let voiceBusy = false;
    let composer = null;
    const voiceApi = App.voice && App.voice.API ? App.voice.API(assistant) : null;
    const voiceSupport = App.voice && App.voice.Recorder ? App.voice.Recorder.support() : { ok: false, reason: 'Голосовой ввод недоступен.' };
    const setMicPermission = (s) => { if ((store.user.permissions.microphone || {}).status !== s) store.setPermission('microphone', s); };
    const voiceRecorder = voiceSupport.ok ? App.voice.Recorder.create({
      onState: (s) => {
        if (!composer || voiceBusy) return;
        composer.setMicState(s === 'listening' ? 'listening' : s === 'starting' ? 'starting' : s === 'stopping' ? 'processing' : 'idle');
      },
    }) : null;

    /* ── Верхняя панель ── */
    const backBtn = ui.IconButton({ icon: 'back', label: 'Назад', onClick: () => onBack() });
    backBtn.classList.add('chat-bar__btn');
    const slot = h('span', { class: 'chat-bar__slot', 'aria-hidden': 'true' });
    const statusDot = h('i', { class: 'chat-status__dot' });
    const statusText = h('span', { class: 'chat-status__text' });
    const titleEl = h('span', { class: 'chat-bar__title' });
    const idBlock = h('div', { class: 'chat-bar__id' }, slot,
      h('div', { class: 'chat-bar__names' },
        h('h2', { class: 'chat-bar__name', tabindex: '-1' }, 'WISP', h('span', { class: 'ds-sr', text: ': чат' })),
        h('p', { class: 'chat-status', role: 'status', 'aria-live': 'polite' }, statusDot, statusText, titleEl)));
    const newBtn = ui.IconButton({ icon: 'compose', label: 'Новый диалог', onClick: () => newChat(true) });
    const moreBtn = ui.IconButton({ icon: 'more', label: 'Меню чата', onClick: () => openMenuSheet() });
    newBtn.classList.add('chat-bar__btn'); moreBtn.classList.add('chat-bar__btn');
    const bar = h('header', { class: 'chat-bar' }, backBtn, idBlock, h('div', { class: 'chat-bar__end' }, newBtn, moreBtn));

    /* ── Лента ── */
    const emptySlot = h('div', { class: 'chat-empty__slot', 'aria-hidden': 'true' });
    const emptyTitle = h('h3', { class: 'chat-empty__title' });
    const emptySub = h('p', { class: 'chat-empty__sub' });
    const emptyChips = h('div', { class: 'chat-empty__chips', role: 'group', 'aria-label': 'С чего начать' });
    const emptyCard = h('div', { class: 'chat-empty__card', hidden: true });
    const empty = h('div', { class: 'chat-empty' }, emptySlot, h('div', { class: 'chat-empty__text' }, emptyTitle, emptySub), emptyCard, emptyChips);
    const list = h('div', { class: 'chat-list' });
    const loader = h('div', { class: 'chat-loading', hidden: true, 'aria-hidden': 'true' }, h('i'), h('i'), h('i'));
    const inner = h('div', { class: 'chat-inner' }, empty, loader, list);
    const scroller = h('div', { class: 'chat-scroll', role: 'log', 'aria-label': 'Сообщения', 'aria-live': 'off' }, inner);
    const downBtn = ui.pressable(h('button', { type: 'button', class: 'chat-down', 'aria-label': 'К последнему сообщению', hidden: true, onClick: () => scrollToEnd(true) }, ui.icon('arrowDown')));
    const live = h('div', { class: 'ds-sr', 'aria-live': 'polite' });

    /* ── Низ: баннер, правка, вложения, ввод ── */
    const banner = h('div', { class: 'chat-banner', role: 'status', hidden: true });
    const editBar = h('div', { class: 'chat-editbar', hidden: true },
      ui.icon('edit', 'ds-icon chat-editbar__icon'),
      h('span', { class: 'chat-editbar__text', text: 'Изменение сообщения' }),
      h('button', { type: 'button', class: 'chat-editbar__cancel', onClick: () => cancelEdit(), text: 'Отмена' }));
    const notice = h('p', { class: 'home-notice chat-notice', role: 'status', 'aria-live': 'polite' });
    let noticeTimer = 0;
    function setNotice(text, tone, ttl) {
      clearTimeout(noticeTimer);
      if (!text) { notice.classList.remove('is-on'); return; }
      notice.textContent = text;
      notice.dataset.tone = tone || 'info';
      notice.classList.add('is-on');
      if (ttl !== 0) noticeTimer = setTimeout(() => notice.classList.remove('is-on'), ttl || 5000);
    }

    async function toggleVoice() {
      if (!voiceRecorder || !voiceApi || voiceBusy) return;
      if (generating) { setNotice('Дождись ответа WISP или останови его.', 'warn'); return; }
      if (editing) { setNotice('Сначала сохрани или отмени правку сообщения.', 'warn'); return; }
      if (voiceRecorder.state === 'listening') {
        voiceBusy = true;
        composer.setMicState('processing');
        setNotice('Распознаю запись…', 'info', 0);
        const recording = await voiceRecorder.stop('user');
        if (!recording) { voiceBusy = false; composer.setMicState('idle'); setNotice(null); return; }
        if (!recording.heard || !recording.blob || !recording.blob.size) {
          voiceBusy = false; composer.setMicState('idle');
          setNotice('Не расслышал речь. Попробуй ещё раз.', 'warn');
          return;
        }
        const r = await voiceApi.transcribe(recording.blob, { durationMs: recording.durationMs });
        voiceBusy = false;
        composer.setMicState('idle');
        if (!r.ok) { setNotice(App.voice.errorText(r.error), 'warn', 5200); return; }
        const transcript = String(r.text || '').trim();
        if (!transcript) { setNotice('Не расслышал речь. Попробуй ещё раз.', 'warn'); return; }
        setMicPermission('granted');
        setNotice(null);
        if (!send(transcript, { input: 'voice', preserveDraft: true, attachments: [] })) setNotice('Не получилось отправить распознанную речь.', 'warn');
        return;
      }
      const why = blockReason();
      if (why) { setNotice(why, 'warn'); return; }
      const started = await voiceRecorder.start();
      if (!started.ok) {
        composer.setMicState('idle');
        if (started.code === 'denied') setMicPermission('denied');
        else if (started.code === 'no-device') setMicPermission('unavailable');
        setNotice(started.reason || 'Не получилось включить микрофон.', 'warn');
        return;
      }
      setMicPermission('granted');
      setNotice('Слушаю… Нажми ещё раз, чтобы отправить.', 'info', 0);
    }
    function cancelVoice() {
      if (voiceRecorder && voiceRecorder.state !== 'idle') voiceRecorder.cancel();
      voiceBusy = false;
      if (composer) composer.setMicState(voiceSupport.ok ? 'idle' : 'unavailable', voiceSupport.reason);
      setNotice(null);
    }
    composer = App.home.Composer({
      placeholder: 'Сообщение для WISP…',
      label: 'Сообщение для WISP',
      suggestions: [],
      getMicSaved: () => (store.user.permissions.microphone || {}).status,
      onMicStatus: setMicPermission,
      onNotice: setNotice,
      voiceInput: { onToggle: toggleVoice, onCancel: cancelVoice, unavailable: !voiceSupport.ok, reason: voiceSupport.reason },
      attach: { onPick: addFiles, canAttach },
      canSendEmpty: () => attachments.length > 0 && attachments.every((a) => a.status === 'ready'),
      onInput: (text) => { if (!editing) setDraft(draftKey(), text); },
      onSend: (text) => (editing ? submitEdit(text) : send(text)),
      onStop: () => stop(),
    });
    const dock = h('div', { class: 'chat-dock' }, notice, banner, editBar, composer.el);

    const el = h('section', { class: 'home-panel chat', id: 'home-panel-chat', role: 'tabpanel', 'aria-label': 'Чат с WISP' },
      bar, h('div', { class: 'chat-main' }, scroller, downBtn), dock, live);

    /* ── Маскот: в пустом чате в центре, в разговоре в шапке ── */
    const isEmpty = () => !messages.length && !loading;
    function measure() {
      const rr = root.getBoundingClientRect();
      if (isEmpty()) {
        const r = emptySlot.getBoundingClientRect();
        if (r.height > 40) {
          const hgt = clamp(Math.min(r.height * 0.7, r.width * 0.36), 52, 150);
          return { h: hgt, cy: r.top - rr.top + r.height * 0.52 };
        }
      }
      const r = slot.getBoundingClientRect();
      if (!r.height) return null;
      return { h: 30, cy: r.top - rr.top + r.height / 2 };
    }
    let lastEmpty = null;
    function syncEmpty() {
      const e = isEmpty();
      empty.hidden = !e;
      el.classList.toggle('is-empty', e);
      if (e !== lastEmpty) { lastEmpty = e; if (shown) requestAnimationFrame(() => onLayout()); }
    }

    /* ── Состояние подключения ── */
    function phase() {
      if (!assistant.connected) return 'no_endpoint';
      if (!online) return 'offline';
      if (assistant.state === 'connecting' || assistant.state === 'idle') return 'connecting';
      if (assistant.state === 'server_down') return 'server_down';
      if (assistant.session && !assistant.session.ai_connected) return 'no_ai';
      return 'ready';
    }
    function paintStatus() {
      const p = phase();
      let text, tone;
      if (generating) { text = generating.msg.content ? 'пишет…' : 'думает…'; tone = 'busy'; }
      else if (p === 'ready') { text = 'на связи'; tone = 'on'; }
      else if (p === 'connecting') { text = 'подключаюсь…'; tone = 'busy'; }
      else if (p === 'offline') { text = 'нет сети'; tone = 'off'; }
      else if (p === 'server_down') { text = 'нет связи с сервером'; tone = 'off'; }
      else if (p === 'no_ai') { text = 'AI не подключён'; tone = 'off'; }
      else { text = 'не подключён'; tone = 'off'; }
      statusText.textContent = text;
      statusDot.dataset.tone = tone;
      titleEl.textContent = conv && conv.title && !generating ? ` · ${conv.title}` : '';
      el.classList.toggle('is-generating', !!generating);
      newBtn.disabled = false;
    }

    function paintEmpty() {
      const v = voice();
      emptyTitle.textContent = v.title(store.user.name);
      emptySub.textContent = v.sub;
      const p = phase();
      let card = null;
      if (loadError) card = { icon: 'alert', title: 'Не получилось открыть диалог', text: 'Проверь соединение и попробуй ещё раз.', action: ['Повторить', () => loadConversation(loadError.id)] };
      else if (p === 'no_endpoint') card = { icon: 'alert', title: 'AI не подключён', text: 'Эта копия WISP открыта без сервера. Запусти сервер WISP и открой приложение по его адресу.' };
      else if (p === 'server_down') card = { icon: 'alert', title: 'Нет связи с сервером WISP', text: 'Сервер не отвечает. Сообщения не потеряются: отправишь, когда связь вернётся.', action: ['Проверить снова', () => assistant.bootstrap(true)] };
      else if (p === 'no_ai') card = { icon: 'alert', title: 'AI ещё не подключён', text: 'Сервер работает, но на нём нет ключа ни одного AI-провайдера.' };
      else if (p === 'offline') card = { icon: 'wifiOff', title: 'Нет интернета', text: 'Как только связь вернётся, можно будет продолжить.' };
      emptyCard.hidden = !card;
      if (card) {
        emptyCard.replaceChildren(
          h('span', { class: 'chat-empty__card-icon' }, ui.icon(card.icon)),
          h('div', null, h('p', { class: 'chat-empty__card-title', text: card.title }), h('p', { class: 'chat-empty__card-text', text: card.text })),
          card.action ? ui.Button({ label: card.action[0], variant: 'secondary', size: 'small', onClick: card.action[1] }) : null);
      }
      const chips = p === 'ready' && !loadError && cp().chat_starters !== false ? App.home.Copy.suggestions(store.user) : [];
      emptyChips.replaceChildren(...chips.map((text) => ui.pressable(h('button', { type: 'button', class: 'home-suggest__chip', text, onClick: () => { ui.haptic(8); send(text); } }))));
      emptyChips.hidden = !chips.length;
    }

    /* Баннер над строкой ввода: нет сети / лимит */
    function paintBanner() {
      const s = assistant.session;
      let content = null;
      if (!online) content = [ui.icon('wifiOff', 'ds-icon chat-banner__icon'), h('span', { text: 'Нет интернета. Сообщение останется в поле.' })];
      else if (s && s.usage && s.usage.remaining === 0) {
        content = [ui.icon('alert', 'ds-icon chat-banner__icon'), h('span', { text: `Лимит на сегодня исчерпан. Обновится после ${Copy.time(s.usage.reset_at)}.` }),
          h('button', { type: 'button', class: 'chat-banner__link', text: 'Тариф', onClick: () => onPlan() })];
      } else if (s && s.usage && s.usage.remaining <= 3 && s.usage.limit > 3) {
        content = [h('span', { text: `Сегодня осталось сообщений: ${s.usage.remaining}` })];
      }
      banner.hidden = !content;
      banner.classList.toggle('is-quiet', !!content && online && s && s.usage.remaining > 0);
      if (content) banner.replaceChildren(...content);
    }

    function paintAll() { paintStatus(); paintEmpty(); paintBanner(); paintAttach(); syncEmpty(); }

    /* ── Модель ── */
    function models() { return (assistant.session && assistant.session.models) || []; }
    function usable(m) { return m && m.available && m.allowed; }
    function currentModel() {
      const all = models();
      const pick = (id) => all.find((m) => m.id === id);
      const cand = pick(selectedModel) || (conv && pick(conv.model)) || pick(assistant.session && assistant.session.default_model);
      if (usable(cand)) return cand;
      return all.find(usable) || null;
    }
    function canAttach() {
      const m = currentModel();
      if (m && !m.vision) return 'Эта модель не понимает изображения. Выбери другую в меню «…».';
      const max = (assistant.session && assistant.session.plan.max_images_per_message) || 1;
      if (attachments.length >= max) return `Можно прикрепить до ${max} изображений за раз.`;
      if (editing) return 'При изменении сообщения картинки остаются прежними.';
      return true;
    }
    function paintAttach() {
      const r = canAttach();
      composer.setAttachAvailable(r === true || /до \d+ изображений/.test(r), typeof r === 'string' ? r : '');
    }

    /* ── Вложения ── */
    async function addFiles(files) {
      const max = (assistant.session && assistant.session.plan.max_images_per_message) || 1;
      const room = Math.max(0, max - attachments.length);
      if (files.length > room) setNotice(`Можно прикрепить до ${max} изображений за раз.`, 'warn');
      for (const f of files.slice(0, room)) {
        const a = { key: localKey(), status: 'loading' };
        attachments.push(a);
        paintTray();
        try {
          Object.assign(a, await Images.prepare(f), { status: 'ready' });
        } catch (e) {
          attachments = attachments.filter((x) => x !== a);
          setNotice(e.reason || 'Не получилось открыть изображение.', 'warn');
        }
        paintTray();
      }
    }
    function paintTray() {
      const t = composer.tray;
      t.hidden = !attachments.length;
      t.replaceChildren(...attachments.map((a) => h('div', { class: `chat-thumb${a.status === 'loading' ? ' is-loading' : ''}` },
        a.dataUrl ? h('img', { src: a.dataUrl, alt: 'Прикреплённое изображение' }) : null,
        h('button', { type: 'button', class: 'chat-thumb__x', 'aria-label': 'Убрать изображение', onClick: () => { attachments = attachments.filter((x) => x !== a); paintTray(); } }, ui.icon('close')))));
      composer.refresh();
      paintAttach();
    }

    /* ── Лента: построение и флаги ── */
    function flagsFor(m) {
      const i = messages.indexOf(m);
      const last = messages[messages.length - 1];
      let lastUser = null;
      for (let k = messages.length - 1; k >= 0; k--) if (messages[k].role === 'user' && messages[k].status !== 'failed') { lastUser = messages[k]; break; }
      const next = messages[i + 1];
      const tmode = cp().chat_time;
      const showTime = tmode === 'always' ? true : tmode === 'never' ? m.status === 'failed'
        : !next || next.role !== m.role || (next.created_at || 0) - (m.created_at || 0) > 5 * 60000 || m.status === 'failed';
      return {
        isLastUser: m === lastUser,
        isLastAssistant: m === last && m.role === 'assistant',
        hasReply: !!(next && next.role === 'assistant'),
        generating: !!generating,
        showTime,
      };
    }
    const msgCtx = {
      voice, flagsFor,
      onAction: (kind, m, btn) => onAction(kind, m, btn),
      openImage: (a) => openImage(a),
      menuHost: () => root,
      openTool: openTool ? (kind, a) => openTool(kind, a) : null,
      editRecord: (item) => editActionRecord(item),
      deleteRecord: (item) => deleteActionRecord(item),
      actions: {
        confirm: (a, btn) => resolvePendingAction(a, btn, true),
        cancel: (a, btn) => resolvePendingAction(a, btn, false),
      },
      memory: memoryApi ? {
        open: (id) => openMemory && openMemory(id),
        confirm: (a, btn) => memoryDecision(a, btn, true),
        dismiss: (a, btn) => memoryDecision(a, btn, false),
        showUsed: (m) => showMemoryUsed(m),
      } : null,
    };
    /* «Запомнить» / «Не надо» прямо в чате: сервер подтверждает, карточка меняется по его ответу */
    async function memoryDecision(a, btn, yes) {
      btn.setBusy(true);
      const r = yes ? await memoryApi.confirm(a.memory_id, a.sensitive ? { confirm_sensitive: true } : {}) : await memoryApi.dismiss(a.memory_id);
      btn.setBusy(false);
      if (!r.ok) {
        if (r.status === 404) { a.memory_status = 'gone'; refreshFlags(); return; }
        setNotice(App.tools.Kit.errorText(r.error), 'warn', 5200); director.react('blink'); return;
      }
      if (yes) { a.memory_status = 'active'; a.op = r.data.op === 'updated' ? 'updated' : 'saved'; a.content = r.data.memory.content; a.memory_id = r.data.memory.id; director.react('small'); }
      else { a.memory_status = 'dismissed'; }
      ui.haptic(yes ? 12 : 6);
      live.textContent = yes ? 'Запомнил.' : 'Хорошо, не буду запоминать.';
      refreshFlags();
    }
    function updateActionLive(kind, id, liveRecord) {
      for (const m of messages) for (const a of m.actions || []) {
        if (a.kind === kind && a.record_id === id) {
          a.live = liveRecord;
          if (!liveRecord) a.deleted = true;
        }
        for (const item of a.items || []) {
          if (item.kind === kind && item.record_id === id) {
            item.live = liveRecord;
            if (!liveRecord) item.deleted = true;
          }
        }
      }
      refreshFlags();
    }
    function recordApi(kind) {
      return toolsApi && RECORD_KINDS.has(kind) ? toolsApi[`${kind}s`] || toolsApi[kind] : null;
    }
    async function editActionRecord(item) {
      const kind = item && item.kind, id = item && item.record_id;
      const api = recordApi(kind);
      if (!api || !api.get || !api.update || !id) { setNotice('Эту запись нельзя изменить здесь.', 'warn'); return; }
      setNotice('Загружаю запись…', 'info', 0);
      const r = await api.get(id);
      if (!r.ok) { setNotice(App.tools.Kit.errorText(r.error), 'warn'); return; }
      const key = kind === 'reminder' ? 'reminder' : kind;
      let record = r.data[key];
      if (!record) { setNotice('Запись уже недоступна.', 'warn'); refreshActionCards(); return; }
      setNotice(null);
      const Kit = App.tools.Kit, F = App.tools.Format;
      const err = h('p', { class: 'tl-form__err', role: 'alert' });
      const saveBtn = ui.Button({ label: 'Сохранить', onClick: () => save() });
      const form = [];
      const footer = [saveBtn];
      let statusBtn = null;
      const addStatusButton = (done) => {
        statusBtn = ui.Button({
          label: done ? 'Вернуть в активные' : 'Отметить выполненным',
          variant: 'secondary',
          onClick: async () => {
            statusBtn.setBusy(true);
            const next = await api.update(id, { done: !record.done });
            statusBtn.setBusy(false);
            if (!next.ok) { err.textContent = Kit.errorText(next.error); return; }
            record = next.data[key];
            updateActionLive(kind, id, record);
            statusBtn.setLabel(record.done ? 'Вернуть в активные' : 'Отметить выполненным');
            director.react(record.done ? 'small' : 'nod');
          },
        });
        footer.push(statusBtn);
      };
      if (kind === 'task') {
        const title = Kit.Input({ value: record.title, placeholder: 'Что нужно сделать', maxLength: 200, label: 'Название' });
        const desc = Kit.Area({ value: record.description, placeholder: 'Описание (необязательно)', maxLength: 4000, rows: 3, label: 'Описание' });
        const due = Kit.Input({ type: 'date', value: record.due_date || '', label: 'Срок' });
        const priorities = [{ id: 'low', label: 'Low' }, { id: 'medium', label: 'Medium' }, { id: 'high', label: 'High' }];
        const priority = Kit.Segmented({ label: 'Приоритет', value: record.priority || 'medium', options: priorities, small: true });
        form.push(Kit.Field('Название', title), Kit.Field('Описание', desc), Kit.Field('Срок', due),
          h('div', { class: 'tl-field' }, h('span', { class: 'tl-field__label', text: 'Приоритет' }), priority));
        addStatusButton(!!record.done);
        saveBtn._save = () => ({ title: title.value.trim(), description: desc.value, due_date: due.value || null, priority: priority.get() });
      } else if (kind === 'reminder') {
        const title = Kit.Input({ value: record.title, placeholder: 'О чём напомнить', maxLength: 120, label: 'Название' });
        const desc = Kit.Area({ value: record.description, placeholder: 'Подробности (необязательно)', maxLength: 1000, rows: 2, label: 'Описание' });
        const date = Kit.Input({ type: 'date', value: record.date || F.key(new Date(record.remind_at)), label: 'Дата' });
        const time = Kit.Input({ type: 'time', value: record.time || F.hm(new Date(record.remind_at)), label: 'Время' });
        form.push(Kit.Field('О чём напомнить', title), h('div', { class: 'tl-form__row' }, Kit.Field('Дата', date), Kit.Field('Время', time)), Kit.Field('Описание', desc));
        addStatusButton(!!record.done);
        saveBtn._save = () => {
          const body = { title: title.value.trim(), description: desc.value };
          if (date.value !== record.date || time.value !== record.time) { body.date = date.value; body.time = time.value; }
          return body;
        };
      } else if (kind === 'note') {
        const max = assistant.session && assistant.session.tools && assistant.session.tools.note_max_chars || 10000;
        const title = Kit.Input({ value: record.title, placeholder: 'Заголовок', maxLength: 200, label: 'Заголовок' });
        const content = Kit.Area({ value: record.content, placeholder: 'Текст заметки', maxLength: max, rows: 6, label: 'Текст заметки' });
        form.push(Kit.Field('Заголовок', title), Kit.Field('Текст', content));
        saveBtn._save = () => ({ title: title.value.trim(), content: content.value });
      } else if (kind === 'event') {
        const title = Kit.Input({ value: record.title, placeholder: 'Название события', maxLength: 120, label: 'Название' });
        const date = Kit.Input({ type: 'date', value: record.date, label: 'Дата' });
        const start = Kit.Input({ type: 'time', value: record.start_time, label: 'Начало' });
        const end = Kit.Input({ type: 'time', value: record.end_time || '', label: 'Конец' });
        const note = Kit.Area({ value: record.note, placeholder: 'Заметка (необязательно)', maxLength: 1000, rows: 2, label: 'Заметка' });
        form.push(Kit.Field('Название', title), Kit.Field('Дата', date), h('div', { class: 'tl-form__row' }, Kit.Field('Начало', start), Kit.Field('Конец', end)), Kit.Field('Заметка', note));
        saveBtn._save = () => ({ title: title.value.trim(), date: date.value, start_time: start.value, end_time: end.value || null, note: note.value });
      }
      form.push(err);
      async function save() {
        if (saveBtn.classList.contains('is-busy')) return;
        const body = saveBtn._save();
        if (!body.title) { err.textContent = 'Название не должно быть пустым.'; return; }
        if ((kind === 'reminder' && (!body.date && !record.date || !body.time && !record.time)) ||
            (kind === 'event' && (!body.date || !body.start_time))) { err.textContent = 'Заполни дату и время.'; return; }
        saveBtn.setBusy(true);
        const saved = await api.update(id, body);
        saveBtn.setBusy(false);
        if (!saved.ok) { err.textContent = Kit.errorText(saved.error); return; }
        record = saved.data[key];
        updateActionLive(kind, id, record);
        closeSheet();
        setNotice('Изменения сохранены.', 'info', 2400);
        director.react('nod');
      }
      openSheet({ title: `Изменить: ${record.title || 'запись'}`, content: [
        h('div', { class: 'tl-form' }, form),
        h('div', { class: 'home-sheet__actions' }, footer),
      ] });
    }
    async function deleteActionRecord(item) {
      const kind = item && item.kind, id = item && item.record_id;
      const api = recordApi(kind);
      if (!api || !api.remove || !id) { setNotice('Эту запись нельзя удалить здесь.', 'warn'); return; }
      const title = item.live && (item.live.title || item.live.content) || item.title || 'эту запись';
      const noun = { reminder: 'напоминание', task: 'задачу', note: 'заметку', event: 'событие' }[kind] || 'запись';
      const err = h('p', { class: 'tl-form__err', role: 'alert' });
      const del = ui.Button({ label: 'Удалить', variant: 'danger', onClick: async () => {
        del.setBusy(true);
        const r = await api.remove(id);
        del.setBusy(false);
        if (!r.ok) { err.textContent = App.tools.Kit.errorText(r.error); return; }
        updateActionLive(kind, id, null);
        closeSheet();
        setNotice('Запись удалена.', 'info', 2600);
      } });
      openSheet({ title: `Удалить ${noun}?`, content: [
        h('p', { class: 'home-sheet__lead', text: `«${title}» будет удалена.` }),
        h('p', { class: 'home-sheet__note', text: 'Это действие нельзя отменить.' }),
        err,
        h('div', { class: 'home-sheet__actions' }, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }
    function resolvePendingAction(a, btn, confirm) {
      if (!a || !a.pending_id || !assistant) return;
      btn.setBusy(true);
      const request = confirm ? assistant.confirmAction(a.pending_id) : assistant.cancelAction(a.pending_id);
      request.then((r) => {
        btn.setBusy(false);
        const p = r.ok ? r.data.action : r.error && r.error.action;
        if (p) { a.pending = p; a.pending_status = p.status; }
        else if (!r.ok) { setNotice(App.tools.Kit.errorText(r.error), 'warn', 5200); director.react('blink'); }
        if (r.ok) {
          setNotice(confirm ? 'Действие подтверждено.' : 'Действие отменено.', 'info', 2600);
          director.react(confirm ? 'small' : 'nod');
        }
        refreshFlags();
        refreshActionCards();
      }).catch(() => {
        btn.setBusy(false);
        setNotice('Не удалось связаться с сервером. Попробуй ещё раз.', 'warn');
      });
    }
    let actionRefreshPromise = null;
    async function refreshActionCards() {
      if (actionRefreshPromise || destroyed || !assistant.connected || !conv || !messages.length) return actionRefreshPromise;
      actionRefreshPromise = (async () => {
        const refs = [];
        const pending = [];
        for (const m of messages) for (const a of m.actions || []) {
          if (RECORD_KINDS.has(a.kind) && a.record_id) refs.push({ kind: a.kind, id: a.record_id });
          for (const it of a.items || []) if (it && RECORD_KINDS.has(it.kind) && it.record_id) refs.push({ kind: it.kind, id: it.record_id });
          const state = a.pending_status || (a.pending && a.pending.status) || (a.op === 'pending' ? 'pending' : null);
          if (a.kind === 'confirm' && a.pending_id && state === 'pending') pending.push(a);
        }
        const unique = [...new Map(refs.map((r) => [`${r.kind}:${r.id}`, r])).values()];
        const records = new Map();
        for (let i = 0; i < unique.length; i += 100) {
          const r = await assistant.actionRecords(unique.slice(i, i + 100));
          if (r.ok) for (const [key, value] of Object.entries(r.data.records || {})) records.set(key, value);
        }
        for (const m of messages) for (const a of m.actions || []) {
          if (RECORD_KINDS.has(a.kind) && a.record_id && records.has(`${a.kind}:${a.record_id}`)) {
            a.live = records.get(`${a.kind}:${a.record_id}`);
            if (!a.live) a.deleted = true;
          }
          for (const it of a.items || []) {
            const key = `${it.kind}:${it.record_id}`;
            if (it && it.record_id && records.has(key)) {
              it.live = records.get(key);
              if (!it.live) it.deleted = true;
            }
          }
        }
        await Promise.all([...new Set(pending)].map(async (a) => {
          const r = await assistant.getAction(a.pending_id);
          if (r.ok && r.data.action) { a.pending = r.data.action; a.pending_status = r.data.action.status; }
        }));
        refreshFlags();
      })().finally(() => { actionRefreshPromise = null; });
      return actionRefreshPromise;
    }
    function showMemoryUsed(m) {
      const items = m.memory_used || [];
      const cats = Object.fromEntries(((App.memory && App.memory.CATS) || []).map((c) => [c.id, c]));
      openSheet({ title: 'Что я учёл из памяти', content: [
        h('p', { class: 'home-sheet__note', text: 'Эти воспоминания были у меня перед глазами, когда я отвечал. Использую их, только если они к месту.' }),
        h('div', { class: 'mm-used', role: 'list' }, items.map((x) => h('article', { class: 'mm-card', role: 'listitem' },
          h('div', { class: 'mm-card__main' },
            h('span', { class: 'mm-card__cat' }, ui.icon((cats[x.category] || { icon: 'spark' }).icon, 'ds-icon mm-card__caticon'), (cats[x.category] || { label: 'Other' }).label),
            h('span', { class: 'mm-card__text', text: x.content }))))),
        h('div', { class: 'home-sheet__actions' },
          ui.Button({ label: 'Открыть Memory', variant: 'secondary', onClick: () => { closeSheet(); setTimeout(() => openMemory && openMemory(items[0] && items[0].id), 60); } }),
          ui.Button({ label: 'Понятно', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }
    function viewFor(m) {
      let v = views.get(m.key);
      if (!v) { v = MessageView(m, msgCtx); views.set(m.key, v); }
      return v;
    }
    function renderList() {
      const keep = new Set(messages.map((m) => m.key));
      for (const [k, v] of views) if (!keep.has(k)) { v.el.remove(); views.delete(k); }
      const nodes = [];
      let lastDay = null;
      for (const m of messages) {
        const day = dayLabel(m.created_at || Date.now());
        if (day !== lastDay) { nodes.push(h('div', { class: 'chat-day', role: 'separator', text: day })); lastDay = day; }
        nodes.push(viewFor(m).el);
      }
      list.replaceChildren(...nodes);
      refreshFlags();
      syncEmpty();
    }
    function refreshFlags() { for (const m of messages) { const v = views.get(m.key); if (v) v.update(m, flagsFor(m)); } }
    let paintRaf = 0;
    function paintMessageSoon(m) {
      if (paintRaf) return;
      paintRaf = requestAnimationFrame(() => {
        paintRaf = 0;
        const v = views.get(m.key);
        if (v) v.update(m, flagsFor(m));
        if (follow()) scrollToEnd(false);
      });
    }
    /* Автопрокрутка: smart — следить, пока пользователь внизу; always — всегда к новому; off — только по кнопке */
    function follow() {
      const mode = cp().chat_scroll;
      if (mode === 'always') return true;
      if (mode === 'off') return false;
      return pinned;
    }

    /* ── Прокрутка ── */
    function atEnd() { return scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 72; }
    function scrollToEnd(smooth) {
      pinned = true;
      if (smooth && !ui.reducedMotion()) scroller.scrollTo({ top: scroller.scrollHeight, behavior: 'smooth' });
      else scroller.scrollTop = scroller.scrollHeight;
      downBtn.hidden = true;
    }
    scroller.addEventListener('scroll', () => {
      pinned = atEnd();
      downBtn.hidden = pinned || !messages.length;
    }, { passive: true });
    const ro = window.ResizeObserver ? new ResizeObserver(() => { if (pinned && cp().chat_scroll !== 'off') scroller.scrollTop = scroller.scrollHeight; }) : null;
    if (ro) { ro.observe(scroller); ro.observe(inner); }

    /* ── Загрузка диалога ── */
    async function loadConversation(id) {
      if (!id) return;
      abortGeneration();
      loading = true; loadError = null;
      messages = []; renderList();
      loader.hidden = false;
      paintAll();
      const r = await assistant.getConversation(id);
      if (destroyed) return;
      loading = false;
      loader.hidden = true;
      if (r.ok) {
        conv = r.data.conversation;
        messages = r.data.messages.map(fromServer);
        selectedModel = null;
        chatState.setLast(conv.id);
        composer.setValue(getDraft(conv.id));
      } else if (r.status === 404) {
        conv = null; messages = [];
        chatState.setLast(null);
      } else {
        loadError = { id };
      }
      renderList();
      paintAll();
      if (r.ok) refreshActionCards();
      requestAnimationFrame(() => scrollToEnd(false));
    }

    function newChat(focus) {
      if (generating) stop();
      cancelEdit();
      conv = null; messages = []; selectedModel = null; loadError = null;
      attachments = []; paintTray();
      chatState.setLast(null);
      composer.setValue(getDraft('new'));
      renderList();
      paintAll();
      if (focus) { ui.haptic(8); director.react('nod'); if (ui.finePointer()) composer.focus(); }
    }
    const draftKey = () => (conv ? conv.id : 'new');

    /* ── Отправка ── */
    function blockReason() {
      const p = phase();
      if (p === 'no_endpoint') return 'AI не подключён: эта копия WISP открыта без сервера.';
      if (p === 'offline') return 'Нет интернета. Сообщение осталось в поле.';
      if (p === 'connecting') return 'Ещё подключаюсь к серверу. Секунду…';
      if (p === 'server_down') return 'Нет связи с сервером WISP. Сообщение осталось в поле.';
      if (p === 'no_ai') return 'На сервере не подключён ни один AI-провайдер.';
      if (!currentModel()) return 'Нет доступной модели для твоего тарифа.';
      return null;
    }

    async function send(text, opts) {
      const o = opts || {};
      if (generating) return false;
      if (attachments.some((a) => a.status === 'loading')) { setNotice('Изображение ещё готовится…', 'info'); return false; }
      const why = blockReason();
      if (why) {
        setNotice(why, 'warn');
        director.react('blink');
        if (phase() === 'server_down') assistant.bootstrap(true);
        return false;
      }
      const atts = o.attachments || attachments.filter((a) => a.status === 'ready').map((a) => ({ key: a.key, dataUrl: a.dataUrl, width: a.width, height: a.height }));
      if (!text && !atts.length) return false;
      const model = currentModel();
      const userMsg = { key: localKey(), role: 'user', content: text, status: 'pending', created_at: Date.now(), attachments: atts };
      messages.push(userMsg);
      if (!o.attachments) { attachments = []; paintTray(); }
      if (!o.preserveDraft) chatState.setDraft(draftKey(), '');
      sound('send');
      startStream('send', userMsg, (handlers) => assistant.sendMessage({
        conversationId: conv && conv.id, content: text, attachments: atts, model: model.id, profile: store.profile, input: o.input,
      }, handlers));
      return true;
    }

    function regenerate() {
      if (generating || !conv) return;
      const why = blockReason();
      if (why) { setNotice(why, 'warn'); return; }
      const last = messages[messages.length - 1];
      if (last && last.role === 'assistant') messages.pop();
      const model = currentModel();
      startStream('regenerate', null, (handlers) => assistant.regenerate({ conversationId: conv.id, model: model.id, profile: store.profile }, handlers));
    }

    function beginEdit(m) {
      if (m.status === 'failed') {
        // сообщение не дошло до сервера: возвращаем текст в поле
        messages = messages.filter((x) => x !== m);
        renderList();
        composer.setValue(m.content || '');
        if (m.attachments && m.attachments.length) { attachments = m.attachments.map((a) => ({ ...a, key: localKey(), status: 'ready' })); paintTray(); }
        composer.focus();
        return;
      }
      editing = { msg: m };
      editBar.hidden = false;
      el.classList.add('is-editing');
      composer.setValue(m.content || '');
      composer.focus();
      paintAttach();
    }
    function cancelEdit() {
      if (!editing) return;
      editing = null;
      editBar.hidden = true;
      el.classList.remove('is-editing');
      composer.setValue(getDraft(draftKey()));
      paintAttach();
    }
    async function submitEdit(text) {
      const target = editing && editing.msg;
      if (!target || generating || !conv) return false;
      const why = blockReason();
      if (why) { setNotice(why, 'warn'); return false; }
      if (!text && !(target.attachments || []).length) { setNotice('Сообщение не может быть пустым.', 'warn'); return false; }
      const prev = { content: target.content, tail: messages.slice(messages.indexOf(target) + 1) };
      editing = null; editBar.hidden = true; el.classList.remove('is-editing');
      target.content = text;
      messages = messages.slice(0, messages.indexOf(target) + 1);
      const model = currentModel();
      startStream('edit', target, (handlers) => assistant.editAndRegenerate({ conversationId: conv.id, messageId: target.id, content: text, model: model.id, profile: store.profile }, handlers), prev);
      return true;
    }

    /* Общий цикл потоковой генерации */
    async function startStream(kind, userMsg, run, rollback) {
      const reply = { key: localKey(), role: 'assistant', content: '', status: 'streaming', created_at: Date.now(), attachments: [] };
      messages.push(reply);
      const ctrl = new AbortController();
      generating = { ctrl, msg: reply, kind };
      composer.setGenerating(true);
      renderList();
      paintStatus();
      scrollToEnd(false);
      let firstDelta = true;

      const result = await run({
        signal: ctrl.signal,
        onStart: (d) => {
          conv = d.conversation;
          chatState.setLast(conv.id);
          if (d.user_message && userMsg) Object.assign(userMsg, fromServer(d.user_message), { key: userMsg.key, attachments: userMsg.attachments.map((a, i) => ({ ...a, ...(d.user_message.attachments[i] || {}) })) });
          if (d.assistant_message) { reply.id = d.assistant_message.id; reply.created_at = d.assistant_message.created_at; }
          if (d.memory && Array.isArray(d.memory.used)) reply.memory_used = d.memory.used;
          if (userMsg) views.get(userMsg.key) && views.get(userMsg.key).update(userMsg, flagsFor(userMsg));
          paintStatus();
        },
        onDelta: (t) => {
          if (firstDelta) { firstDelta = false; director.react('small'); paintStatus(); }
          reply.content += t;
          paintMessageSoon(reply);
        },
        /* Layer 4: сервер выполнил действие и сохранил его — показываем карточку и обновляем инструменты */
        onTool: (a) => {
          reply.actions = [...(reply.actions || []), a];
          paintMessageSoon(reply);
          if (a.kind === 'memory') { if (memoryApi) memoryApi.notify({ action: a }); }
          else if (toolsApi) toolsApi.notify(a.kind, { action: a });
          director.react(a.status === 'ok' ? 'small' : 'blink');
          const d = MessageView.describeAction(a);
          live.textContent = `${d.title}: ${[].concat(d.sub).filter(Boolean).join(', ')}`;
        },
        onDone: (d) => {
          Object.assign(reply, fromServer(d.message), { key: reply.key });
          if (d.conversation) conv = d.conversation;
        },
        onError: (d) => {
          const saved = d.message_saved ? fromServer(d.message_saved) : {};
          Object.assign(reply, saved, { key: reply.key, status: saved.status || 'error', error_code: d.code, errorData: d });
          director.react('blink');
        },
      });
      if (destroyed) return;
      generating = null;
      composer.setGenerating(false);

      switch (result.phase) {
        case 'done':
          live.textContent = `WISP ответил: ${reply.content.slice(0, 600)}`;
          break;
        case 'error':
          break;
        case 'aborted':
          if (reply.id || reply.content) Object.assign(reply, { status: 'interrupted', error_code: 'stopped' });
          else messages = messages.filter((x) => x !== reply);
          if (!reply.id && userMsg && userMsg.status === 'pending') { userMsg.status = 'failed'; userMsg.error_code = 'cancelled'; }
          break;
        case 'interrupted':
          if (result.error && result.error.code === 'request_ambiguous' && userMsg) {
            messages = messages.filter((x) => x !== reply);
            Object.assign(userMsg, { status: 'interrupted', error_code: 'request_ambiguous', errorData: result.error });
          } else Object.assign(reply, { status: 'interrupted', error_code: 'connection_lost' });
          director.react('blink');
          break;
        case 'rejected':
        case 'unsent': {
          messages = messages.filter((x) => x !== reply);
          const err = result.error || { code: 'network' };
          if (kind === 'send' && userMsg) {
            Object.assign(userMsg, { status: 'failed', error_code: err.code, errorData: err });
          } else if (kind === 'edit' && rollback) {
            // сервер не принял правку: возвращаем как было
            userMsg.content = rollback.content;
            messages.push(...rollback.tail);
            setNotice(Copy.error(err.code, err, voice()).title + '. ' + (Copy.error(err.code, err, voice()).text || ''), 'warn');
          } else {
            setNotice(Copy.error(err.code, err, voice()).title + '. ' + (Copy.error(err.code, err, voice()).text || ''), 'warn');
            if (kind === 'regenerate' && conv) { loadConversation(conv.id); return; }
          }
          if (err.code === 'limit_daily' || err.code === 'rate_limited') assistant.refreshSession();
          director.react('blink');
          break;
        }
        default: break;
      }
      renderList();
      paintAll();
      if (follow()) scrollToEnd(false);
      if (conv) refreshActionCards();
      if (result.phase === 'done') sound('receive');
      else if (result.phase !== 'aborted') sound('error');
    }

    function stop() { if (generating) generating.ctrl.abort(); }
    function abortGeneration() { if (generating) generating.ctrl.abort(); }

    function resend(m) {
      if (generating) return;
      messages = messages.filter((x) => x !== m);
      renderList();
      send(m.content, { attachments: m.attachments || [] });
    }

    async function deleteMessage(m) {
      if (!m.id) { messages = messages.filter((x) => x !== m); renderList(); paintAll(); return; }
      if (!conv) return;
      const r = await assistant.deleteMessage(conv.id, m.id);
      if (!r.ok) { setNotice(r.error.code === 'busy' ? 'Сначала дождись конца ответа.' : 'Не получилось удалить сообщение.', 'warn'); return; }
      const ids = new Set(r.data.deleted);
      messages = messages.filter((x) => !ids.has(x.id));
      renderList();
      paintAll();
      setNotice('Сообщение удалено.', 'info', 2400);
    }

    async function onAction(kind, m) {
      if (kind === 'copy') { const ok = await Markdown.copyText(m.content || ''); setNotice(ok ? 'Скопировано.' : 'Не получилось скопировать.', ok ? 'info' : 'warn', 2000); ui.haptic(6); }
      else if (kind === 'regenerate') regenerate();
      else if (kind === 'edit') beginEdit(m);
      else if (kind === 'retry') resend(m);
      else if (kind === 'delete') deleteMessage(m);
      else if (kind === 'plan') onPlan();
      else if (kind === 'models') openMenuSheet(true);
    }

    /* ── Панели: меню, история, переименование, удаление, просмотр картинки ── */
    function row({ icon, label, sub, onClick, danger, end }) {
      return ui.pressable(h('button', { type: 'button', class: `chat-row${danger ? ' is-danger' : ''}`, onClick },
        h('span', { class: 'chat-row__icon' }, ui.icon(icon)),
        h('span', { class: 'chat-row__main' }, h('span', { class: 'chat-row__label', text: label }), sub ? h('span', { class: 'chat-row__sub', text: sub }) : null),
        end || ui.icon('chevron', 'ds-icon chat-row__chev')));
    }

    function usageLine() {
      const s = assistant.session;
      if (!s) return null;
      return h('button', { type: 'button', class: 'chat-usage', onClick: () => onPlan() },
        h('span', { class: `home-planmark chat-usage__plan${s.user.plan === 'plus' ? ' is-plus' : ''}`, text: s.plan.title }),
        h('span', { class: 'chat-usage__text', text: `Сегодня ${s.usage.used} из ${s.usage.limit} сообщений` }),
        ui.icon('chevron', 'ds-icon chat-row__chev'));
    }

    function modelRows() {
      const cur = currentModel();
      const all = models();
      if (!all.length) return [h('p', { class: 'home-sheet__note', text: 'Список моделей появится, когда будет связь с сервером.' })];
      return all.map((m) => {
        const on = cur && cur.id === m.id;
        const off = !usable(m);
        const pill = !m.allowed ? h('span', { class: 'ds-pill ds-pill--on chat-model__pill', text: 'Plus' }) : !m.available ? h('span', { class: 'ds-pill ds-pill--off chat-model__pill', text: 'Не подключена' }) : null;
        const b = ui.pressable(h('button', { type: 'button', class: `ds-row chat-model${off ? ' is-off' : ''}`, role: 'radio', 'aria-checked': on ? 'true' : 'false', 'aria-disabled': off ? 'true' : 'false' },
          h('span', { class: 'ds-row__main' },
            h('span', { class: 'ds-row__label', text: m.label }),
            h('span', { class: 'ds-row__desc', text: [m.description, m.vision ? 'видит изображения' : null].filter(Boolean).join(' · ') })),
          h('span', { class: 'ds-row__end' }, pill || h('span', { class: 'ds-check ds-check--radio', 'aria-hidden': 'true' }))));
        b.addEventListener('click', async () => {
          if (!m.allowed) { setNotice('Эта модель доступна в Plus.', 'warn'); return; }
          if (!m.available) { setNotice('Эта модель не подключена на сервере.', 'warn'); return; }
          selectedModel = m.id;
          ui.haptic(10);
          if (conv) { const r = await assistant.setConversationModel(conv.id, m.id); if (r.ok) conv = r.data.conversation; }
          paintAttach();
          closeSheet();
          setNotice(`Модель: ${m.label}`, 'info', 2200);
        });
        return b;
      });
    }

    function openMenuSheet(focusModels) {
      Menu.close();
      const rows = [
        row({ icon: 'history', label: 'История диалогов', onClick: () => openHistory() }),
        row({ icon: 'compose', label: 'Новый диалог', onClick: () => { closeSheet(); newChat(true); } }),
        conv ? row({ icon: 'edit', label: 'Переименовать диалог', onClick: () => openRename(conv) }) : null,
        conv ? row({ icon: 'trash', label: 'Удалить диалог', danger: true, onClick: () => openDelete(conv) }) : null,
      ];
      const modelsBox = h('div', { class: 'ds-list chat-models', role: 'radiogroup', 'aria-label': 'Модель' }, modelRows());
      const content = [
        usageLine(),
        h('div', { class: 'chat-rows' }, rows),
        h('h3', { class: 'chat-sheet__h', text: 'Модель' }),
        modelsBox,
      ];
      openSheet({ title: conv ? conv.title : 'Чат', content });
      if (focusModels) setTimeout(() => { const f = modelsBox.querySelector('[aria-checked="true"]') || modelsBox.firstChild; if (f && f.scrollIntoView) f.scrollIntoView({ block: 'center' }); }, 420);
    }

    async function openHistory() {
      const listEl = h('div', { class: 'chat-history', 'aria-busy': 'true' }, h('div', { class: 'chat-loading' }, h('i'), h('i'), h('i')));
      openSheet({ title: 'История диалогов', content: [
        ui.Button({ label: 'Новый диалог', variant: 'secondary', onClick: () => { closeSheet(); newChat(true); } }),
        listEl,
      ] });
      let items = [], offset = 0, hasMore = false, loading = false, failed = false;
      const rowFor = (c) => {
        const current = conv && conv.id === c.id;
        const openBtn = ui.pressable(h('button', { type: 'button', class: `chat-hrow__open${current ? ' is-current' : ''}`, 'aria-current': current ? 'true' : null, onClick: () => { closeSheet(); if (!current) loadConversation(c.id); } },
          h('span', { class: 'chat-hrow__title', text: c.title }),
          h('span', { class: 'chat-hrow__time', text: relTime(c.updated_at) })));
        const moreB = ui.pressable(h('button', { type: 'button', class: 'cm__btn chat-hrow__more', 'aria-label': `Действия: ${c.title}`, 'aria-haspopup': 'menu' }, ui.icon('more')));
        moreB.dataset.align = 'right';
        moreB.addEventListener('click', (e) => {
          e.stopPropagation();
          Menu.open({ anchor: moreB, container: root, items: [
            { icon: 'edit', label: 'Переименовать', onSelect: () => openRename(c) },
            { icon: 'trash', label: 'Удалить', danger: true, onSelect: () => openDelete(c) },
          ] });
        });
        const rowEl = h('div', { class: 'chat-hrow' }, openBtn, moreB);
        rowEl._t = c.updated_at;
        return rowEl;
      };
      function paintHistory() {
        if (!items.length && !hasMore) {
          listEl.replaceChildren(h('p', { class: 'chat-history__empty', text: 'Здесь появятся твои разговоры с WISP.' }));
          return;
        }
        const rows = items.map(rowFor);
        const nodes = [];
        if (cp().history_view === 'grouped') {
          let lastG = null;
          rows.forEach((r) => {
            const g = historyGroup(r._t);
            if (g !== lastG) { nodes.push(h('p', { class: 'chat-hgroup', role: 'heading', 'aria-level': '3', text: g })); lastG = g; }
            nodes.push(r);
          });
        } else nodes.push(...rows);
        if (hasMore || failed) nodes.push(ui.Button({
          label: failed ? 'Повторить загрузку' : loading ? 'Загружаю…' : 'Показать ещё',
          variant: 'ghost', onClick: loadMore,
        }));
        listEl.replaceChildren(...nodes);
      }
      async function loadMore() {
        if (loading) return;
        loading = true; failed = false; listEl.setAttribute('aria-busy', 'true');
        const r = await assistant.listConversations(offset);
        loading = false; listEl.removeAttribute('aria-busy');
        if (!r.ok) {
          failed = true;
          if (!items.length) {
            listEl.replaceChildren(
              h('p', { class: 'home-sheet__note', text: r.error.code === 'offline' ? 'Нет интернета. История загрузится, когда связь вернётся.' : 'Не получилось загрузить историю.' }),
              ui.Button({ label: 'Повторить', variant: 'ghost', onClick: loadMore }));
          } else paintHistory();
          return;
        }
        const batch = r.data.conversations || [];
        items.push(...batch);
        offset = Number.isSafeInteger(r.data.next_offset) ? r.data.next_offset : offset + batch.length;
        hasMore = !!r.data.has_more;
        paintHistory();
      }
      await loadMore();
    }
    function historyGroup(t) {
      const d = new Date(t), now = new Date();
      const start = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
      const diff = Math.round((start(now) - start(d)) / DAY);
      if (diff <= 0) return 'Сегодня';
      if (diff === 1) return 'Вчера';
      if (diff < 7) return 'На этой неделе';
      if (diff < 31) return 'В этом месяце';
      return 'Раньше';
    }

    function openRename(c) {
      let value = c.title;
      const save = ui.Button({ label: 'Сохранить', onClick: () => submit() });
      const field = ui.TextField({ value, maxLength: 80, label: 'Название диалога', placeholder: 'Название', onInput: (v) => { value = v; save.setDisabled(!v.trim()); }, onSubmit: () => submit() });
      async function submit() {
        if (!value.trim()) return;
        save.setBusy(true);
        const r = await assistant.renameConversation(c.id, value.trim());
        save.setBusy(false);
        if (!r.ok) { setNotice('Не получилось переименовать.', 'warn'); return; }
        if (conv && conv.id === c.id) conv = r.data.conversation;
        paintStatus();
        closeSheet();
        setNotice('Название сохранено.', 'info', 2000);
      }
      openSheet({ title: 'Переименовать', content: [field, h('div', { class: 'home-sheet__actions' }, save, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() }))] });
      setTimeout(() => { const input = field.querySelector('input'); if (input) { input.focus(); input.select(); } }, 420);
    }

    function openDelete(c) {
      const del = ui.Button({ label: 'Удалить', variant: 'danger', onClick: async () => {
        del.setBusy(true);
        const r = await assistant.deleteConversation(c.id);
        del.setBusy(false);
        if (!r.ok) { setNotice('Не получилось удалить диалог.', 'warn'); return; }
        chatState.setDraft(c.id, '');
        if (conv && conv.id === c.id) newChat(false);
        closeSheet();
        director.react('nod');
        setNotice('Диалог удалён.', 'info', 2400);
      } });
      openSheet({ title: 'Удалить диалог?', content: [
        h('p', { class: 'home-sheet__lead' }, '«', c.title, '» и все сообщения в нём будут удалены.'),
        h('p', { class: 'home-sheet__note', text: 'Это нельзя отменить.' }),
        h('div', { class: 'home-sheet__actions' }, del, ui.Button({ label: 'Отмена', variant: 'ghost', onClick: () => closeSheet() })),
      ] });
    }

    function openImage(a) {
      const img = h('img', { class: 'chat-viewer__img', src: a.url || a.dataUrl, alt: 'Изображение' });
      openSheet({ title: 'Изображение', content: [h('div', { class: 'chat-viewer' }, img)] });
    }

    /* ── Подписки ── */
    const unsubA = assistant.subscribe(() => {
      if (destroyed) return;
      paintAll();
      if (assistant.ready && !restored) restore();
    });
    const unsubS = store.subscribe(() => { if (!destroyed) { paintEmpty(); refreshFlags(); } });
    const unsubTools = toolsApi ? toolsApi.subscribe((e) => {
      if (!destroyed && shown && ['reminder', 'reminders', 'task', 'tasks', 'note', 'notes', 'event', 'events'].includes(e.kind)) refreshActionCards();
    }) : () => {};
    const actionPoll = setInterval(() => { if (shown && !document.hidden) refreshActionCards(); }, 20000);
    const onOnline = () => { online = true; paintAll(); if (assistant.state === 'server_down') assistant.bootstrap(true); };
    const onOffline = () => { online = false; paintAll(); };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    function restore() {
      restored = true;
      const last = chatState.get().last;
      if (last && !conv && !messages.length && cp().chat_restore !== false) loadConversation(last);
      else composer.setValue(getDraft(draftKey()));
    }

    renderList();
    paintAll();
    if (assistant.ready) restore();

    return {
      el,
      measure,
      onShow() {
        shown = true;
        paintAll();
        refreshActionCards();
        requestAnimationFrame(() => { scrollToEnd(false); onLayout(); });
        setTimeout(() => { if (!destroyed && shown) onLayout(); }, 820);
        if (assistant.state === 'server_down') assistant.bootstrap(true);
      },
      onHide() { shown = false; composer.stop(); Menu.close(); },
      /* С главного экрана: новый диалог с этим сообщением (или продолжение текущего — «Чат → Сообщение с Home») */
      sendFromHome(text) {
        if (generating) stop();
        if (cp().chat_home_send !== 'continue' || !conv) newChat(false);
        return send(text);
      },
      newChat(focus) { if (generating) return; newChat(focus !== false); },
      openHistory() { return openHistory(); },
      repaint() { renderList(); paintAll(); },
      /* Layer 5: пример из пустой памяти — новый диалог, текст в поле (отправляет сам пользователь) */
      prefill(text) {
        if (generating) return;
        newChat(false);
        composer.setValue(text || '');
        setTimeout(() => { if (!destroyed) composer.focus(); }, 420);
      },
      pickImage() { return composer.pick(); },
      get connected() { return assistant.connected; },
      destroy() {
        destroyed = true;
        abortGeneration();
        Menu.close();
        unsubA(); unsubS();
        unsubTools();
        clearInterval(actionPoll);
        window.removeEventListener('online', onOnline);
        window.removeEventListener('offline', onOffline);
        if (ro) ro.disconnect();
        clearTimeout(noticeTimer);
        composer.stop();
      },
    };
  };
})(window.WispApp);
