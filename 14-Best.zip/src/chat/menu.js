/* WISP · Chat · Popover menu
 * Компактное стеклянное меню действий рядом с сообщением. Закрывается касанием вне меню, Escape,
 * прокруткой. Клавиатура: стрелки, Home/End, Enter. Пункт с confirm срабатывает со второго нажатия. */
(function (App) {
  'use strict';
  const { ui } = App;
  const { h } = ui;
  let current = null;

  function close() { if (current) { const c = current; current = null; c.destroy(); } }

  function open({ anchor, container, items, label, onClose }) {
    close();
    const buttons = items.filter(Boolean).map((it) => {
      const lab = h('span', { class: 'cmenu__label', text: it.label });
      const b = ui.pressable(h('button', { type: 'button', class: `cmenu__item${it.danger ? ' is-danger' : ''}`, role: 'menuitem' },
        ui.icon(it.icon, 'ds-icon cmenu__icon'), lab));
      let armed = false;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        if (it.confirm && !armed) {
          armed = true; lab.textContent = it.confirm; b.classList.add('is-armed'); ui.haptic(8);
          return;
        }
        close();
        it.onSelect && it.onSelect();
      });
      return b;
    });
    const panel = h('div', { class: 'cmenu ds-root', role: 'menu', 'aria-label': label || 'Действия' }, buttons);
    const host = container || document.body;
    host.appendChild(panel);

    /* позиция: под якорем, если не помещается — над ним; по горизонтали прижимаем к якорю внутри экрана */
    const place = () => {
      const hr = host.getBoundingClientRect();
      const ar = anchor.getBoundingClientRect();
      const pw = panel.offsetWidth, ph = panel.offsetHeight;
      const pad = 10;
      let top = ar.bottom - hr.top + 6;
      if (top + ph > hr.height - pad) top = Math.max(pad, ar.top - hr.top - ph - 6);
      const alignRight = anchor.dataset.align === 'right';
      let left = alignRight ? ar.right - hr.left - pw : ar.left - hr.left;
      left = Math.min(Math.max(pad, left), hr.width - pw - pad);
      panel.style.top = `${Math.round(top)}px`;
      panel.style.left = `${Math.round(left)}px`;
    };
    place();
    requestAnimationFrame(() => panel.classList.add('is-open'));

    const onDown = (e) => { if (!panel.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) close(); };
    const onKey = (e) => {
      const i = buttons.indexOf(document.activeElement);
      if (e.key === 'Escape') { e.preventDefault(); close(); anchor.focus && anchor.focus({ preventScroll: true }); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); buttons[(i + (e.key === 'ArrowDown' ? 1 : buttons.length - 1) + buttons.length) % buttons.length].focus(); }
      if (e.key === 'Home') { e.preventDefault(); buttons[0].focus(); }
      if (e.key === 'End') { e.preventDefault(); buttons[buttons.length - 1].focus(); }
      if (e.key === 'Tab') close();
    };
    const onScroll = (e) => { if (!panel.contains(e.target)) close(); };
    setTimeout(() => {
      document.addEventListener('pointerdown', onDown, true);
      document.addEventListener('scroll', onScroll, true);
    }, 0);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('resize', close);
    if (buttons[0]) buttons[0].focus({ preventScroll: true });
    anchor.setAttribute && anchor.setAttribute('aria-expanded', 'true');

    current = {
      panel,
      destroy() {
        document.removeEventListener('pointerdown', onDown, true);
        document.removeEventListener('scroll', onScroll, true);
        document.removeEventListener('keydown', onKey, true);
        window.removeEventListener('resize', close);
        anchor.setAttribute && anchor.setAttribute('aria-expanded', 'false');
        panel.classList.remove('is-open');
        panel.classList.add('is-closing');
        setTimeout(() => panel.remove(), 180);
        onClose && onClose();
      },
    };
    return current;
  }

  App.chat.Menu = { open, close, get isOpen() { return !!current; } };
})(window.WispApp);
