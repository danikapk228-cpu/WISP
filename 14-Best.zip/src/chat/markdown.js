/* WISP · Chat · Markdown
 * Безопасный рендер Markdown → DOM. Ни одного innerHTML: текст всегда идёт через textContent,
 * поэтому HTML/скрипты из ответа модели или из сообщения пользователя отображаются как текст.
 * Ссылки: только http(s) и mailto, открываются в новой вкладке с rel="noopener noreferrer nofollow".
 * Картинки из Markdown не загружаются (приватность): вместо них ссылка.
 * Поддержка: абзацы, заголовки, **жирный**, *курсив*, ~~зачёркнутый~~, `код`, блоки кода с подсветкой,
 * списки (вложенные, нумерованные, задачи), цитаты, таблицы, горизонтальная линия, переносы строк.
 * Незакрытый блок кода во время потока рисуется как блок кода. */
(function (App) {
  'use strict';
  const { h } = App.ui;

  const MAX_DEPTH = 12;
  const RE = {
    fence: /^ {0,3}(`{3,}|~{3,})\s*([^\s`]*)?.*$/,
    heading: /^ {0,3}(#{1,6})(?:\s+(.*?))?\s*#*\s*$/,
    hr: /^ {0,3}([-*_])(?:\s*\1){2,}\s*$/,
    quote: /^ {0,3}>\s?(.*)$/,
    list: /^(\s*)([-*+•]|\d{1,9}[.)])\s+(.*)$/,
    tableSep: /^\s*\|?\s*:?-{1,}:?\s*(\|\s*:?-{1,}:?\s*)*\|?\s*$/,
  };

  function safeUrl(raw) {
    const s = String(raw || '').trim();
    if (!s) return null;
    try {
      const u = new URL(s);
      if (u.protocol === 'http:' || u.protocol === 'https:' || u.protocol === 'mailto:') return u.href;
    } catch (e) { /* относительные и неизвестные схемы не превращаем в ссылки */ }
    return null;
  }

  /* ── Копирование ── */
  async function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext !== false) { await navigator.clipboard.writeText(text); return true; }
    } catch (e) { /* падаем на запасной способ */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', '');
      ta.style.position = 'fixed'; ta.style.top = '-1000px'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch (e) { return false; }
  }

  /* ── Инлайн ── */
  const WORD = /[0-9A-Za-zА-Яа-яЁё]/;
  function parseInline(text, depth) {
    const out = [];
    let buf = '';
    const flush = () => { if (buf) { out.push(document.createTextNode(buf)); buf = ''; } };
    const d = (depth || 0) + 1;
    if (d > MAX_DEPTH) return [document.createTextNode(text)];
    let i = 0;
    const n = text.length;
    while (i < n) {
      const ch = text[i];
      const rest = text.slice(i);
      const prev = i > 0 ? text[i - 1] : '';
      let m;
      if (ch === '\\' && i + 1 < n && /[\\`*_{}[\]()#+\-.!|~>]/.test(text[i + 1])) { buf += text[i + 1]; i += 2; continue; }
      if (ch === '\n') { flush(); out.push(document.createElement('br')); i++; continue; }
      if (ch === '`') {
        const run = /^`+/.exec(rest)[0];
        const close = text.indexOf(run, i + run.length);
        if (close > 0) {
          let code = text.slice(i + run.length, close).replace(/\n/g, ' ');
          if (/^ .* $/.test(code) && code.trim()) code = code.slice(1, -1);
          flush(); out.push(h('code', { class: 'md-ic', text: code }));
          i = close + run.length; continue;
        }
        buf += run; i += run.length; continue;
      }
      if (ch === '*' || ch === '_') {
        const intraword = ch === '_' && WORD.test(prev);
        if (!intraword && (m = (ch === '*' ? /^\*\*(?=\S)([\s\S]*?\S)\*\*/ : /^__(?=\S)([\s\S]*?\S)__(?![0-9A-Za-zА-Яа-яЁё])/).exec(rest))) {
          flush(); out.push(h('strong', null, parseInline(m[1], d))); i += m[0].length; continue;
        }
        if (!intraword && (m = (ch === '*' ? /^\*([^\s*](?:[^*\n]*?[^\s*])?)\*(?!\*)/ : /^_([^\s_](?:[^_\n]*?[^\s_])?)_(?![0-9A-Za-zА-Яа-яЁё])/).exec(rest))) {
          flush(); out.push(h('em', null, parseInline(m[1], d))); i += m[0].length; continue;
        }
      }
      if (ch === '~' && (m = /^~~(?=\S)([\s\S]*?\S)~~/.exec(rest))) { flush(); out.push(h('del', null, parseInline(m[1], d))); i += m[0].length; continue; }
      if ((ch === '[' || (ch === '!' && text[i + 1] === '[')) && (m = /^!?\[((?:[^\[\]\n]|\[[^\[\]\n]*\])*)\]\(\s*<?([^\s<>]*?)>?(?:\s+(?:"[^"]*"|'[^']*'|\([^)]*\)))?\s*\)/.exec(rest))) {
        const isImage = ch === '!';
        const url = safeUrl(m[2]);
        flush();
        if (url) {
          const label = m[1] || url;
          out.push(h('a', { class: 'md-a', href: url, target: '_blank', rel: 'noopener noreferrer nofollow' },
            isImage ? `Изображение: ${label}` : parseInline(label, d)));
        } else out.push(...parseInline(m[1], d));
        i += m[0].length; continue;
      }
      if (ch === '<' && (m = /^<((?:https?:\/\/|mailto:)[^\s<>]+)>/.exec(rest))) {
        const url = safeUrl(m[1]);
        flush();
        out.push(url ? h('a', { class: 'md-a', href: url, target: '_blank', rel: 'noopener noreferrer nofollow', text: m[1] }) : document.createTextNode(m[0]));
        i += m[0].length; continue;
      }
      if ((ch === 'h' || ch === 'H') && !WORD.test(prev) && (m = /^https?:\/\/[^\s<>"'`]+/i.exec(rest))) {
        let link = m[0];
        // хвостовую пунктуацию не включаем; закрывающую скобку — только если есть парная открывающая
        while (/[.,;:!?…»"')\]]$/.test(link)) {
          const last = link[link.length - 1];
          if (last === ')' && (link.match(/\(/g) || []).length >= (link.match(/\)/g) || []).length) break;
          link = link.slice(0, -1);
        }
        const url = safeUrl(link);
        if (url) {
          flush(); out.push(h('a', { class: 'md-a', href: url, target: '_blank', rel: 'noopener noreferrer nofollow', text: link }));
          i += link.length; continue;
        }
      }
      buf += ch; i++;
    }
    flush();
    return out;
  }

  /* ── Блоки ── */
  const indentOf = (s) => { let n = 0; for (const c of s) { if (c === ' ') n++; else if (c === '\t') n += 4; else break; } return n; };
  const dedent = (s, k) => { let i = 0, n = 0; while (i < s.length && n < k && (s[i] === ' ' || s[i] === '\t')) { n += s[i] === '\t' ? 4 : 1; i++; } return s.slice(i); };
  const isBlank = (s) => !s || !s.trim();
  const splitRow = (line) => {
    let s = line.trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
    const cells = []; let cur = '';
    for (let i = 0; i < s.length; i++) {
      if (s[i] === '\\' && s[i + 1] === '|') { cur += '|'; i++; continue; }
      if (s[i] === '|') { cells.push(cur.trim()); cur = ''; continue; }
      cur += s[i];
    }
    cells.push(cur.trim());
    return cells;
  };
  function startsBlock(line, next) {
    return RE.fence.test(line) || RE.heading.test(line) || RE.hr.test(line) || RE.quote.test(line) || RE.list.test(line) ||
      (line.includes('|') && next != null && RE.tableSep.test(next) && next.includes('-'));
  }

  /* Layer 13: настройки «Чат → Оформление ответов» */
  function chatPrefs() { const P = App.settings && App.settings.Prefs; return P ? P.get() : {}; }
  function codeBlock(code, lang, ctx) {
    const hl = chatPrefs().chat_code_hl === false
      ? { nodes: [document.createTextNode(code)], lang: '', label: lang ? String(lang).slice(0, 24) : '' }
      : App.chat.highlight(code, lang);
    const codeEl = h('code', { class: hl.lang ? `md-code__code lang-${hl.lang}` : 'md-code__code' }, hl.nodes);
    const copy = h('button', { type: 'button', class: 'md-code__copy', 'aria-label': 'Скопировать код' },
      App.ui.icon('copy', 'ds-icon md-code__icon'), h('span', { class: 'md-code__copy-label', text: 'Копировать' }));
    copy.addEventListener('click', async (e) => {
      e.stopPropagation();
      const ok = await copyText(code);
      copy.classList.toggle('is-done', ok);
      copy.lastChild.textContent = ok ? 'Скопировано' : 'Не вышло';
      setTimeout(() => { copy.classList.remove('is-done'); copy.lastChild.textContent = 'Копировать'; }, 1600);
    });
    const el = h('div', { class: 'md-code' },
      h('div', { class: 'md-code__head' }, h('span', { class: 'md-code__lang', text: hl.label || 'код' }), copy),
      h('pre', { class: 'md-code__pre', tabindex: '0' }, codeEl));
    ctx.last = codeEl;
    return el;
  }

  function parseBlocks(lines, ctx, depth) {
    const out = [];
    const d = (depth || 0) + 1;
    if (d > MAX_DEPTH) { const p = h('p', { class: 'md-p' }, lines.join('\n')); ctx.last = p; return [p]; }
    let i = 0;
    const n = lines.length;
    while (i < n) {
      const line = lines[i];
      if (isBlank(line)) { i++; continue; }
      let m;

      if ((m = RE.fence.exec(line))) {
        const fence = m[1];
        const lang = (m[2] || '').replace(/[^\w+#.-]/g, '');
        const ind = indentOf(line);
        const body = [];
        i++;
        let closed = false;
        while (i < n) {
          const l = lines[i];
          const t = l.trim();
          if (t.startsWith(fence[0].repeat(fence.length)) && /^[`~]+$/.test(t) && t[0] === fence[0]) { closed = true; i++; break; }
          body.push(dedent(l, ind));
          i++;
        }
        out.push(codeBlock(body.join('\n'), lang, ctx));
        if (!closed) ctx.openCode = true;
        continue;
      }

      if ((m = RE.heading.exec(line))) {
        const level = Math.min(6, m[1].length);
        const el = h(`h${Math.min(6, level + 2)}`, { class: `md-h md-h${level}` }, parseInline(m[2] || '', d));
        out.push(el); ctx.last = el; i++; continue;
      }

      if (RE.hr.test(line)) { out.push(h('hr', { class: 'md-hr' })); i++; continue; }

      if (RE.quote.test(line)) {
        const body = [];
        while (i < n && (m = RE.quote.exec(lines[i]))) { body.push(m[1]); i++; }
        while (i < n && !isBlank(lines[i]) && !startsBlock(lines[i], lines[i + 1])) { body.push(lines[i]); i++; }   // ленивое продолжение
        out.push(h('blockquote', { class: 'md-quote' }, parseBlocks(body, ctx, d)));
        continue;
      }

      if (line.includes('|') && i + 1 < n && RE.tableSep.test(lines[i + 1]) && lines[i + 1].includes('-')) {
        const head = splitRow(line);
        const aligns = splitRow(lines[i + 1]).map((c) => (/^:-+:$/.test(c) ? 'center' : /^-+:$/.test(c) ? 'right' : /^:-+$/.test(c) ? 'left' : ''));
        i += 2;
        const rows = [];
        while (i < n && !isBlank(lines[i]) && lines[i].includes('|')) { rows.push(splitRow(lines[i])); i++; }
        const cols = head.length;
        const cell = (tag, text, k) => {
          const c = h(tag, null, parseInline(text || '', d));
          if (aligns[k]) c.style.textAlign = aligns[k];
          ctx.last = c;
          return c;
        };
        const table = h('table', { class: 'md-table__t' },
          h('thead', null, h('tr', null, head.map((t, k) => cell('th', t, k)))),
          rows.length ? h('tbody', null, rows.map((r) => h('tr', null, Array.from({ length: cols }, (_, k) => cell('td', r[k], k))))) : null);
        out.push(h('div', { class: 'md-table', tabindex: '0', role: 'region', 'aria-label': 'Таблица' }, table));
        continue;
      }

      if ((m = RE.list.exec(line))) {
        const res = parseList(lines, i, ctx, d);
        out.push(res.el); i = res.next; continue;
      }

      // абзац
      const para = [line.replace(/^ {1,3}/, '')];
      i++;
      while (i < n && !isBlank(lines[i]) && !startsBlock(lines[i], lines[i + 1])) { para.push(lines[i].replace(/^\s+/, '')); i++; }
      const p = h('p', { class: 'md-p' }, parseInline(para.join('\n').replace(/[ \t]+$/gm, ''), d));
      out.push(p); ctx.last = p;
    }
    return out;
  }

  function parseList(lines, start, ctx, d) {
    const first = RE.list.exec(lines[start]);
    const base = indentOf(first[1]);
    const ordered = /\d/.test(first[2]);
    const list = h(ordered ? 'ol' : 'ul', { class: `md-list ${ordered ? 'md-ol' : 'md-ul'}` });
    if (ordered) { const s = parseInt(first[2], 10); if (s !== 1) list.start = s; }
    const items = [];
    let i = start;
    let loose = false;
    const n = lines.length;
    while (i < n) {
      const line = lines[i];
      const m = RE.list.exec(line);
      if (m && indentOf(m[1]) <= base + 1) {
        if (/\d/.test(m[2]) !== ordered) break;
        items.push({ lines: [m[3]], contentIndent: indentOf(m[1]) + m[2].length + 1 });
        i++; continue;
      }
      const cur = items[items.length - 1];
      if (isBlank(line)) {
        let j = i + 1; while (j < n && isBlank(lines[j])) j++;
        if (j >= n) { i = j; break; }
        const nm = RE.list.exec(lines[j]);
        const continues = indentOf(lines[j]) >= cur.contentIndent || (nm && indentOf(nm[1]) <= base + 1 && /\d/.test(nm[2]) === ordered);
        if (!continues) break;
        if (indentOf(lines[j]) >= cur.contentIndent) cur.lines.push('');
        else loose = true;
        i = j; continue;
      }
      if (indentOf(line) > base) { cur.lines.push(dedent(line, Math.min(indentOf(line), cur.contentIndent))); i++; continue; }
      if (!startsBlock(line, lines[i + 1]) && cur.lines[cur.lines.length - 1] !== '') { cur.lines.push(line.trim()); i++; continue; }   // ленивое продолжение
      break;
    }
    for (const it of items) {
      const li = h('li', { class: 'md-li' });
      let text = it.lines;
      const task = /^\[([ xX])\]\s+/.exec(text[0]);
      if (task) {
        li.classList.add('md-task');
        li.appendChild(h('span', { class: `md-check${task[1] !== ' ' ? ' is-on' : ''}`, 'aria-label': task[1] !== ' ' ? 'Выполнено' : 'Не выполнено', role: 'img' }));
        text = [text[0].slice(task[0].length), ...text.slice(1)];
      }
      const simple = !loose && !text.some((l, k) => k > 0 && (isBlank(l) || startsBlock(l, text[k + 1])));
      if (simple) { const span = h('span', { class: 'md-li__t' }, parseInline(text.join('\n'), d)); li.appendChild(span); ctx.last = span; }
      else parseBlocks(text, ctx, d).forEach((node) => li.appendChild(node));
      list.appendChild(li);
    }
    return { el: list, next: i };
  }

  /* text → DocumentFragment. opts.caret: добавить «искру» в конец (идёт генерация) */
  /* «Обычный текст»: разметка не разбирается, текст показывается как написан (переносы строк сохраняются).
   * Блоки кода остаются блоками: читать код одной строкой невозможно, а копирование кода — главное в них. */
  function renderPlain(src, ctx, frag) {
    const parts = src.split(/^(```[^\n]*\n[\s\S]*?(?:\n```|$))/m);
    parts.forEach((part) => {
      const m = /^```([^\n]*)\n([\s\S]*?)(?:\n```)?$/.exec(part);
      if (m) { frag.appendChild(codeBlock(m[2], m[1].trim(), ctx)); ctx.last = null; return; }
      const t = part.replace(/^\n+|\n+$/g, '');
      if (!t) return;
      const para = h('p', { class: 'md-p md-plain', text: t });
      frag.appendChild(para);
      ctx.last = para;
    });
  }
  function render(text, opts) {
    const o = opts || {};
    const frag = document.createDocumentFragment();
    const ctx = { last: null, openCode: false };
    const src = String(text || '').replace(/\r\n?/g, '\n').replace(/\u0000/g, '');
    const plain = o.plain != null ? o.plain : chatPrefs().chat_markdown === 'plain';
    if (plain) renderPlain(src, ctx, frag);
    else parseBlocks(src.split('\n'), ctx, 0).forEach((n) => frag.appendChild(n));
    if (o.caret) {
      const caret = h('span', { class: 'md-caret', 'aria-hidden': 'true' });
      if (ctx.last) ctx.last.appendChild(caret); else frag.appendChild(h('p', { class: 'md-p' }, caret));
    }
    return frag;
  }

  /* Обычный текст ответа (для копирования): Markdown как есть */
  App.chat.Markdown = { render, parseInline, safeUrl, copyText };
})(window.WispApp);
