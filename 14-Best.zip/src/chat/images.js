/* WISP · Chat · Images
 * Подготовка изображения на устройстве: декодирование, уменьшение до 1568 px по длинной стороне,
 * JPEG ~85%. Так картинка весит сотни килобайт, а модели видят её в полном рекомендуемом размере.
 * Сервер всё равно проверяет формат и размер сам. */
(function (App) {
  'use strict';

  const MAX_SIDE = 1568;
  const MAX_BYTES = 2.8 * 1024 * 1024;
  const MAX_SOURCE = 40 * 1024 * 1024;

  function loadImage(file) {
    if (window.createImageBitmap) {
      return createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => createImageBitmap(file)).catch(() => viaImg(file));
    }
    return viaImg(file);
  }
  function viaImg(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode')); };
      img.src = url;
    });
  }
  const blobToDataUrl = (blob) => new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
  const toBlob = (canvas, q) => new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', q));

  /* → { dataUrl, width, height, bytes } или бросает Error с .reason */
  async function prepare(file) {
    const fail = (reason) => { const e = new Error(reason); e.reason = reason; throw e; };
    if (!file || !/^image\//.test(file.type || '') && !/\.(jpe?g|png|gif|webp|heic|heif)$/i.test(file.name || '')) fail('Это не изображение.');
    if (file.size > MAX_SOURCE) fail('Файл слишком большой.');
    let img;
    try { img = await loadImage(file); } catch (e) { fail('Браузер не смог открыть это изображение.'); }
    const w0 = img.width || img.naturalWidth, h0 = img.height || img.naturalHeight;
    if (!w0 || !h0) fail('Браузер не смог открыть это изображение.');
    const k = Math.min(1, MAX_SIDE / Math.max(w0, h0));
    const w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const g = canvas.getContext('2d');
    g.fillStyle = '#ffffff';                 // прозрачность PNG → белый фон, а не чёрный
    g.fillRect(0, 0, w, h);
    g.drawImage(img, 0, 0, w, h);
    if (img.close) img.close();
    let blob = null;
    for (const q of [0.85, 0.72, 0.6]) {
      blob = await toBlob(canvas, q);
      if (blob && blob.size <= MAX_BYTES) break;
    }
    if (!blob || blob.size > MAX_BYTES) fail('Изображение слишком большое даже после сжатия.');
    return { dataUrl: await blobToDataUrl(blob), width: w, height: h, bytes: blob.size };
  }

  App.chat.Images = { prepare, MAX_SIDE };
})(window.WispApp);
