/* WISP · Chat · Syntax highlight
 * Лёгкая подсветка без библиотек: токенизатор для популярных языков строит DOM-узлы (span + textContent).
 * Никакого innerHTML: код из ответа модели не может стать разметкой. */
(function (App) {
  'use strict';

  const words = (s) => new Set(s.split(/\s+/).filter(Boolean));
  const C_LIKE_LIT = 'true false null nullptr nil undefined NaN Infinity None True False self this super';

  const LANGS = {
    js: {
      kw: words('async await break case catch class const continue debugger default delete do else export extends finally for from function get if import in instanceof let new of return set static switch throw try typeof var void while with yield as interface type enum implements private public protected readonly declare namespace abstract keyof satisfies'),
      lit: words(C_LIKE_LIT), line: ['//'], block: [['/*', '*/']], str: ['"', "'", '`'],
    },
    python: {
      kw: words('and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case print'),
      lit: words('True False None self cls'), line: ['#'], block: [], str: ['"""', "'''", '"', "'"],
    },
    bash: {
      kw: words('if then else elif fi for in do done case esac while until function return export local readonly declare unset shift exit source alias sudo echo cd ls cat grep sed awk curl npm npx node git python3 pip mkdir rm cp mv chmod'),
      lit: words('true false'), line: ['#'], block: [], str: ['"', "'"], vars: true,
    },
    css: { kw: words('important media supports keyframes import font-face'), lit: words('inherit initial unset none auto'), line: [], block: [['/*', '*/']], str: ['"', "'"], css: true },
    sql: {
      kw: words('select from where and or not insert into values update set delete create table index view drop alter add column primary key foreign references join left right inner outer full on group by order having limit offset as distinct union all case when then else end exists in is like between returning with begin commit rollback'),
      lit: words('null true false'), line: ['--'], block: [['/*', '*/']], str: ["'", '"'], ci: true,
    },
    go: {
      kw: words('break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var'),
      lit: words('true false nil iota'), line: ['//'], block: [['/*', '*/']], str: ['"', '`', "'"],
    },
    rust: {
      kw: words('as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod move mut pub ref return static struct trait type unsafe use where while'),
      lit: words('true false None Some Ok Err self Self'), line: ['//'], block: [['/*', '*/']], str: ['"'],
    },
    clike: {
      kw: words('abstract auto break case catch char class const continue default delete do double else enum extends extern final finally float for fun goto if implements import include inline int interface long namespace new override package private protected public return short signed sizeof static struct switch template throw throws try typedef typename union unsigned using val var virtual void volatile when while func let guard import protocol extension'),
      lit: words(C_LIKE_LIT), line: ['//'], block: [['/*', '*/']], str: ['"', "'"],
    },
    php: { kw: words('echo function return if else elseif foreach for while class public private protected static new use namespace require include array fn match'), lit: words('true false null'), line: ['//', '#'], block: [['/*', '*/']], str: ['"', "'"], vars: true },
    ruby: { kw: words('def end if elsif else unless while until for in do return class module require yield begin rescue ensure then puts attr_accessor'), lit: words('true false nil self'), line: ['#'], block: [], str: ['"', "'"] },
    yaml: { kw: words(''), lit: words('true false null yes no on off'), line: ['#'], block: [], str: ['"', "'"], yaml: true },
    json: { kw: words(''), lit: words('true false null'), line: [], block: [], str: ['"'], json: true },
  };
  const ALIAS = {
    js: 'js', javascript: 'js', jsx: 'js', ts: 'js', typescript: 'js', tsx: 'js', mjs: 'js', cjs: 'js', node: 'js',
    py: 'python', python: 'python', python3: 'python',
    sh: 'bash', bash: 'bash', shell: 'bash', zsh: 'bash', console: 'bash', terminal: 'bash',
    css: 'css', scss: 'css', less: 'css',
    sql: 'sql', postgres: 'sql', postgresql: 'sql', mysql: 'sql', sqlite: 'sql',
    go: 'go', golang: 'go', rust: 'rust', rs: 'rust',
    c: 'clike', h: 'clike', cpp: 'clike', 'c++': 'clike', hpp: 'clike', cs: 'clike', csharp: 'clike', 'c#': 'clike',
    java: 'clike', kotlin: 'clike', kt: 'clike', swift: 'clike', dart: 'clike', scala: 'clike',
    php: 'php', ruby: 'ruby', rb: 'ruby', yaml: 'yaml', yml: 'yaml', json: 'json', jsonc: 'json',
    html: 'html', xml: 'html', svg: 'html', vue: 'html', svelte: 'html',
  };
  const LABELS = { js: 'JavaScript', python: 'Python', bash: 'Shell', css: 'CSS', sql: 'SQL', go: 'Go', rust: 'Rust', php: 'PHP', ruby: 'Ruby', yaml: 'YAML', json: 'JSON', html: 'HTML' };

  function span(cls, text) { const s = document.createElement('span'); s.className = cls; s.textContent = text; return s; }

  /* Универсальный сканер: комментарии, строки, числа, слова */
  function tokenize(code, L, out) {
    let i = 0, plain = '';
    const n = code.length;
    const flush = () => { if (plain) { out.push(document.createTextNode(plain)); plain = ''; } };
    const push = (cls, t) => { flush(); out.push(span(cls, t)); };
    let braceDepth = 0;
    while (i < n) {
      const ch = code[i];
      // комментарии
      let matched = false;
      for (const lc of L.line) {
        if (code.startsWith(lc, i) && (lc !== '#' || L.yaml || i === 0 || /\s/.test(code[i - 1]))) {
          const end = code.indexOf('\n', i);
          const stop = end < 0 ? n : end;
          push('hl-com', code.slice(i, stop)); i = stop; matched = true; break;
        }
      }
      if (matched) continue;
      for (const [a, b] of L.block) {
        if (code.startsWith(a, i)) {
          const end = code.indexOf(b, i + a.length);
          const stop = end < 0 ? n : end + b.length;
          push('hl-com', code.slice(i, stop)); i = stop; matched = true; break;
        }
      }
      if (matched) continue;
      // строки
      for (const q of L.str) {
        if (code.startsWith(q, i)) {
          let j = i + q.length;
          while (j < n) {
            if (code[j] === '\\') { j += 2; continue; }
            if (code.startsWith(q, j)) { j += q.length; break; }
            if (q.length === 1 && q !== '`' && code[j] === '\n') break;
            j++;
          }
          const t = code.slice(i, Math.min(j, n));
          // ключ JSON / YAML: строка, за которой двоеточие
          const isKey = L.json && /^\s*:/.test(code.slice(j, j + 4));
          push(isKey ? 'hl-prop' : 'hl-str', t); i = Math.min(j, n); matched = true; break;
        }
      }
      if (matched) continue;
      // переменные shell / php
      if (L.vars && ch === '$') {
        const m = /^\$(\{[^}\n]*\}|[A-Za-z_][\w]*|\d|[@#?*!$-])/.exec(code.slice(i, i + 64));
        if (m) { push('hl-lit', m[0]); i += m[0].length; continue; }
      }
      // числа
      if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(code[i + 1] || ''))) {
        if (!/[\w$]/.test(code[i - 1] || '')) {
          const m = /^(0x[\da-fA-F_]+|0b[01_]+|(\d[\d_]*)?\.?\d[\d_]*([eE][+-]?\d+)?)(px|em|rem|vh|vw|ms|s|%|deg|fr|n|u|f|L)?/.exec(code.slice(i, i + 40));
          if (m && m[0]) { push('hl-num', m[0]); i += m[0].length; continue; }
        }
      }
      // CSS: #hex, @правило, свойство
      if (L.css) {
        if (ch === '{') braceDepth++; else if (ch === '}') braceDepth = Math.max(0, braceDepth - 1);
        if (ch === '#' && braceDepth > 0) { const m = /^#[\da-fA-F]{3,8}\b/.exec(code.slice(i, i + 10)); if (m) { push('hl-num', m[0]); i += m[0].length; continue; } }
        if (ch === '@') { const m = /^@[\w-]+/.exec(code.slice(i, i + 40)); if (m) { push('hl-kw', m[0]); i += m[0].length; continue; } }
        if (braceDepth > 0 && /[a-z-]/.test(ch) && !/[\w-]/.test(code[i - 1] || '')) {
          const m = /^(--)?[a-z-][\w-]*(?=\s*:)/i.exec(code.slice(i, i + 60));
          if (m) { push('hl-prop', m[0]); i += m[0].length; continue; }
        }
      }
      // YAML-ключ в начале строки
      if (L.yaml && (i === 0 || code[i - 1] === '\n')) {
        const m = /^(\s*-?\s*)([\w.-]+)(?=\s*:)/.exec(code.slice(i, i + 120));
        if (m) { plain += m[1]; push('hl-prop', m[2]); i += m[0].length; continue; }
      }
      // слова
      if (/[A-Za-z_$@]/.test(ch)) {
        const m = /^[A-Za-z_$@][\w$]*/.exec(code.slice(i, i + 80));
        const w = m[0];
        const key = L.ci ? w.toLowerCase() : w;
        const prev = code[i - 1] || '';
        if (L.kw.has(key) && prev !== '.') push('hl-kw', w);
        else if (L.lit.has(key)) push('hl-lit', w);
        else if (/^\s*\(/.test(code.slice(i + w.length, i + w.length + 3)) && !L.css) push('hl-fn', w);
        else if (/^[A-Z][a-z]/.test(w) && !L.ci && !L.css) push('hl-type', w);
        else plain += w;
        i += w.length;
        continue;
      }
      plain += ch;
      i++;
    }
    flush();
  }

  /* HTML/XML: теги, атрибуты, строки, комментарии */
  function tokenizeHTML(code, out) {
    const re = /(<!--[\s\S]*?(?:-->|$))|(<\/?)([A-Za-z][\w:-]*)|(\s)([A-Za-z_:][\w:.-]*)(?==)|("[^"]*"?|'[^']*'?)|(\/?>)/g;
    let last = 0, m, inTag = false;
    const text = (t) => { if (t) out.push(document.createTextNode(t)); };
    while ((m = re.exec(code))) {
      if (m[1]) { text(code.slice(last, m.index)); out.push(span('hl-com', m[1])); }
      else if (m[2]) { text(code.slice(last, m.index)); out.push(span('hl-punc', m[2])); out.push(span('hl-kw', m[3])); inTag = true; }
      else if (m[5] && inTag) { text(code.slice(last, m.index) + m[4]); out.push(span('hl-prop', m[5])); }
      else if (m[6] && inTag) { text(code.slice(last, m.index)); out.push(span('hl-str', m[6])); }
      else if (m[7] && inTag) { text(code.slice(last, m.index)); out.push(span('hl-punc', m[7])); inTag = false; }
      else { text(code.slice(last, m.index) + m[0]); }
      last = re.lastIndex;
      if (m[0] === '') re.lastIndex++;
    }
    text(code.slice(last));
  }

  /* lang: метка из ```lang. Возвращает { nodes, lang, label } */
  function highlight(code, lang) {
    const key = ALIAS[String(lang || '').toLowerCase()] || null;
    const out = [];
    if (code.length > 60000 || !key) { out.push(document.createTextNode(code)); return { nodes: out, lang: key, label: lang || '' }; }
    if (key === 'html') tokenizeHTML(code, out);
    else tokenize(code, LANGS[key], out);
    return { nodes: out, lang: key, label: LABELS[key] && !lang ? LABELS[key] : (lang || LABELS[key] || '') };
  }

  App.chat = App.chat || {};
  App.chat.highlight = highlight;
})(window.WispApp);
