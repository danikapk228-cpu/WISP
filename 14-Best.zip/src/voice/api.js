/* WISP · Layer 7 · Voice API
 * Клиент голосовых endpoint'ов сервера WISP поверх того же AssistantClient: тот же origin, та же httpOnly-сессия,
 * тот же заголовок X-WISP-Client. Ключей провайдера речи во фронтенде нет и быть не может.
 *   GET  /api/voice              что доступно (распознавание / синтез на сервере, голоса, лимиты)
 *   POST /api/voice/transcribe   тело — запись (Blob) → { text }
 *   POST /api/voice/speech       { text, voice, personality } → аудио
 * Все запросы с тайм-аутом; 401 (пропала cookie) → новая сессия и один повтор. */
(function (App) {
  'use strict';
  App.voice = App.voice || {};

  const HEADERS = { 'X-WISP-Client': '1' };
  const offline = () => navigator.onLine === false;

  const MESSAGES = {
    offline: 'Нет подключения к интернету.',
    network: 'Не удалось связаться с сервером WISP.',
    timeout: 'Сервер слишком долго не отвечал.',
    not_connected: 'Голос сервера недоступен: WISP открыт без сервера.',
    voice_unavailable: 'Голос на сервере WISP не подключён.',
    voice_limit: 'Голосовой лимит на сегодня исчерпан.',
    rate_limited: 'Слишком много голосовых запросов подряд. Подожди немного.',
    audio_empty: 'Запись получилась пустой. Скажи ещё раз.',
    bad_audio: 'Браузер записал звук в формате, который сервер не понимает.',
    too_long: 'Запись слишком длинная.',
    too_large: 'Запись слишком длинная.',
    provider_auth: 'Сервис речи отклонил ключ доступа. Нужна настройка сервера.',
    provider_busy: 'Сервис речи сейчас перегружен. Попробуй чуть позже.',
    provider_rate_limited: 'Сервис речи перегружен запросами. Попробуй чуть позже.',
    provider_error: 'Сервис речи ответил ошибкой.',
    provider_bad_request: 'Сервис речи не принял запрос.',
    content_filtered: 'Сервис речи отказался обрабатывать этот текст.',
    empty_reply: 'Сервис речи вернул пустой ответ.',
  };
  const RETRYABLE = new Set(['offline', 'network', 'timeout', 'provider_busy', 'provider_rate_limited', 'provider_error', 'empty_reply', 'rate_limited']);
  function errorText(err) {
    if (!err) return 'Что-то пошло не так.';
    return MESSAGES[err.code] || err.message || 'Что-то пошло не так.';
  }
  const fail = (code, extra) => ({ ok: false, error: { code, message: MESSAGES[code], retryable: RETRYABLE.has(code), ...(extra || {}) } });

  App.voice.API = function (assistant) {
    let cfg = null, loading = null, loadedAt = 0;
    const listeners = new Set();
    const emit = () => listeners.forEach((fn) => { try { fn(cfg); } catch (e) { /* подписчик не ломает клиента */ } });

    async function raw(method, path, body, headers, timeout, signal, retried) {
      if (!assistant.connected) return { ...fail('not_connected'), status: 0 };
      if (offline()) return { ...fail('offline'), status: 0 };
      const ctrl = new AbortController();
      let timedOut = false;
      const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeout || 20000);
      const onAbort = () => ctrl.abort();
      if (signal) { if (signal.aborted) ctrl.abort(); else signal.addEventListener('abort', onAbort, { once: true }); }
      try {
        const res = await fetch(assistant.base + path, { method, credentials: 'same-origin', headers: { ...HEADERS, ...(headers || {}) }, body, signal: ctrl.signal, cache: 'no-store' });
        if (res.status === 401 && !retried) {
          clearTimeout(timer);
          const s = await assistant.bootstrap(true);
          if (s) return raw(method, path, body, headers, timeout, signal, true);
        }
        return { ok: res.ok, status: res.status, res };
      } catch (e) {
        if (signal && signal.aborted) return { ok: false, status: 0, aborted: true, error: { code: 'aborted', message: 'Отменено.' } };
        return { ...fail(timedOut ? 'timeout' : offline() ? 'offline' : 'network'), status: 0 };
      } finally {
        clearTimeout(timer);
        if (signal) signal.removeEventListener('abort', onAbort);
      }
    }
    async function errorOf(r) {
      if (r.error) return r;
      const data = await r.res.json().catch(() => null);
      const e = (data && data.error) || { code: 'provider_error' };
      return { ok: false, status: r.status, error: { ...e, message: MESSAGES[e.code] || e.message || MESSAGES.provider_error, retryable: e.retryable != null ? !!e.retryable : RETRYABLE.has(e.code) } };
    }

    /* Конфигурация голоса сервера (кешируется на 5 минут; force — перечитать, например после ошибки лимита) */
    function config(force) {
      if (!assistant.connected) return Promise.resolve(null);
      if (cfg && !force && Date.now() - loadedAt < 300000) return Promise.resolve(cfg);
      if (loading) return loading;
      loading = (async () => {
        if (!assistant.ready) await assistant.bootstrap();
        const r = await assistant.request('GET', '/voice');
        loading = null;
        if (r.ok) { cfg = r.data; loadedAt = Date.now(); emit(); }
        return cfg;
      })();
      return loading;
    }

    async function transcribe(blob, { durationMs, signal, timeout } = {}) {
      const type = (blob && blob.type) || 'audio/webm';
      const r = await raw('POST', '/voice/transcribe', blob, { 'Content-Type': type, 'X-WISP-Audio-Ms': String(Math.round(durationMs || 0)) }, timeout || 35000, signal);
      if (!r.ok) {
        const e = await errorOf(r);
        if (e.error.code === 'voice_limit') config(true);
        return e;
      }
      const data = await r.res.json().catch(() => null);
      if (!data || typeof data.text !== 'string') return fail('provider_error');
      if (cfg && data.usage) { cfg = { ...cfg, stt: { ...cfg.stt, ...data.usage } }; emit(); }
      return { ok: true, text: data.text, durationMs: data.duration_ms };
    }

    async function speech(text, { voice, personality, signal, timeout } = {}) {
      const r = await raw('POST', '/voice/speech', JSON.stringify({ text, voice: voice || undefined, personality: personality || undefined }), { 'Content-Type': 'application/json', Accept: 'audio/*' }, timeout || 25000, signal);
      if (!r.ok) {
        const e = await errorOf(r);
        if (e.error.code === 'voice_limit') config(true);
        return e;
      }
      try {
        const blob = await r.res.blob();
        if (!blob.size) return fail('empty_reply');
        if (cfg && cfg.tts) { cfg = { ...cfg, tts: { ...cfg.tts, used: (cfg.tts.used || 0) + text.length, remaining: Math.max(0, (cfg.tts.remaining || 0) - text.length) } }; emit(); }
        return { ok: true, blob, voice: r.res.headers.get('x-wisp-voice') || voice || null };
      } catch (e) {
        if (signal && signal.aborted) return { ok: false, aborted: true, error: { code: 'aborted' } };
        return fail('network');
      }
    }

    return {
      config,
      get cached() { return cfg; },
      get connected() { return assistant.connected; },
      transcribe,
      speech,
      subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    };
  };
  App.voice.errorText = errorText;
})(window.WispApp);
