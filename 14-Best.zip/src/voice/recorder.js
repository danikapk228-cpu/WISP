/* WISP · Layer 7 · Recorder
 * Настоящая запись с микрофона: getUserMedia → MediaRecorder (webm/opus в Chrome и Android, mp4/aac в Safari и iOS).
 *  · микрофон включается только из нажатия пользователя (start вызывается в обработчике click);
 *  · уровень громкости и форма волны — из AnalyserNode по живому сигналу (для визуализации и паузы);
 *  · автоостановка: пауза после речи (silenceMs), тишина с самого начала (noSpeechMs), предел длины (maxMs);
 *  · вкладка скрыта / приложение свёрнуто → запись сразу прекращается: в фоне WISP не слушает;
 *  · после остановки все дорожки микрофона закрываются (индикатор микрофона в системе гаснет);
 *  · запись — Blob в памяти, никуда не сохраняется. Её забирает распознавание и потом отпускает.
 * Результат: { blob, mime, durationMs, reason: user|silence|no-speech|max|hidden|cancel, heard } */
(function (App) {
  'use strict';
  App.voice = App.voice || {};

  const MIME = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4;codecs=mp4a.40.2', 'audio/mp4', 'audio/aac', 'audio/ogg;codecs=opus'];
  const AC = window.AudioContext || window.webkitAudioContext || null;

  function pickMime() {
    if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) return '';
    return MIME.find((m) => { try { return MediaRecorder.isTypeSupported(m); } catch (e) { return false; } }) || '';
  }

  function support() {
    if (window.isSecureContext === false) return { ok: false, code: 'insecure', reason: 'Микрофон работает только по защищённому соединению (https).' };
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return { ok: false, code: 'no-api', reason: 'Этот браузер не даёт доступ к микрофону.' };
    if (!window.MediaRecorder) return { ok: false, code: 'no-recorder', reason: 'Этот браузер не умеет записывать звук (нужен iOS 14.3+ или свежий Chrome/Firefox).' };
    return { ok: true, mime: pickMime() };
  }

  const ERR = {
    denied: 'Доступ к микрофону запрещён. Разреши его в настройках сайта в браузере.',
    'no-device': 'Микрофон не найден.',
    busy: 'Микрофон занят другим приложением.',
    insecure: 'Микрофон работает только по защищённому соединению (https).',
    error: 'Не получилось включить микрофон.',
  };
  function classify(e) {
    const n = e && e.name;
    if (n === 'NotAllowedError' || n === 'PermissionDeniedError') return 'denied';
    if (n === 'NotFoundError' || n === 'OverconstrainedError' || n === 'DevicesNotFoundError') return 'no-device';
    if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') return 'busy';
    if (n === 'SecurityError') return 'insecure';
    return 'error';
  }

  /* opts: { maxMs, silenceMs, noSpeechMs, onState(listening|stopping|idle), onLevel(level 0..1) } */
  function create(opts) {
    const o = { maxMs: 60000, silenceMs: 1500, noSpeechMs: 8000, ...(opts || {}) };
    let stream = null, rec = null, ctx = null, analyser = null, source = null;
    let chunks = [], timer = 0, t0 = 0, state = 'idle';
    let level = 0, floor = 0.012, voiced = 0, heard = false, lastVoice = 0, stopReason = 'user';
    let finish = null;
    const buf = new Uint8Array(1024);

    function setState(s) { state = s; o.onState && o.onState(s); }

    function analyse() {
      if (!analyser) return;
      analyser.getByteTimeDomainData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
      const rms = Math.sqrt(sum / buf.length);
      const t = performance.now();
      const elapsed = t - t0;
      // уровень шума: медленно подстраивается под тихое окружение, быстро — вниз
      if (rms < floor) floor = floor * 0.9 + rms * 0.1; else if (!heard || elapsed < 400) floor = floor * 0.995 + rms * 0.005;
      const thr = Math.max(0.018, floor * 2.6);
      if (rms > thr) { voiced += 50; lastVoice = t; if (voiced >= 150) heard = true; } else voiced = Math.max(0, voiced - 25);
      level = Math.min(1, Math.max(0, (rms - floor) / 0.18));
      o.onLevel && o.onLevel(level);
      if (elapsed > o.maxMs) stop('max');
      else if (heard && t - lastVoice > o.silenceMs) stop('silence');
      else if (!heard && elapsed > o.noSpeechMs) stop('no-speech');
    }

    function cleanup() {
      clearInterval(timer); timer = 0;
      if (stream) stream.getTracks().forEach((tr) => { try { tr.stop(); } catch (e) {} });
      stream = null;
      try { if (source) source.disconnect(); } catch (e) {}
      source = null; analyser = null;
      if (ctx && ctx.close) ctx.close().catch(() => {});
      ctx = null;
      document.removeEventListener('visibilitychange', onHidden);
      window.removeEventListener('pagehide', onHidden);
      level = 0;
      o.onLevel && o.onLevel(0);
    }
    function onHidden(e) { if (document.hidden || (e && e.type === "pagehide")) stop("hidden"); }

    /* Вызывать прямо в обработчике нажатия. Promise: { ok:true } когда запись реально пошла, иначе { ok:false, code, reason }. */
    async function start() {
      if (state !== 'idle') return { ok: false, code: 'busy-state' };
      const s = support();
      if (!s.ok) return { ok: false, code: s.code, reason: s.reason };
      setState('starting');
      // AudioContext создаём синхронно в нажатии: иначе iOS оставит его «на паузе»
      try { ctx = AC ? new AC() : null; if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {}); } catch (e) { ctx = null; }
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
      } catch (e) {
        cleanup(); setState('idle');
        const code = classify(e);
        return { ok: false, code, reason: ERR[code] };
      }
      if (state !== 'starting') { cleanup(); return { ok: false, code: 'cancelled' }; }      // отменили, пока спрашивали разрешение
      try {
        rec = s.mime ? new MediaRecorder(stream, { mimeType: s.mime, audioBitsPerSecond: 48000 }) : new MediaRecorder(stream);
      } catch (e) {
        try { rec = new MediaRecorder(stream); } catch (er) { cleanup(); setState('idle'); return { ok: false, code: 'no-recorder', reason: 'Браузер не смог начать запись.' }; }
      }
      chunks = [];
      rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
      const stopped = new Promise((resolve) => { rec.onstop = resolve; rec.onerror = resolve; });
      finish = (async () => {
        await stopped;
        const durationMs = Math.round(performance.now() - t0);
        const mime = (rec && rec.mimeType) || s.mime || (chunks[0] && chunks[0].type) || 'audio/webm';
        const blob = new Blob(chunks, { type: mime.split(';')[0] });
        chunks = [];
        cleanup();
        rec = null;
        setState('idle');
        return { blob, mime: blob.type, durationMs, reason: stopReason, heard };
      })();
      try {
        if (ctx) {
          source = ctx.createMediaStreamSource(stream);
          analyser = ctx.createAnalyser();
          analyser.fftSize = 1024;
          analyser.smoothingTimeConstant = 0.6;
          source.connect(analyser);                 // только анализ: в динамики ничего не идёт
        }
      } catch (e) { analyser = null; }
      t0 = performance.now(); lastVoice = t0; heard = false; voiced = 0; floor = 0.012; stopReason = 'user';
      rec.start(250);
      // без анализатора (старые браузеры) нечем определить паузу: считаем, что речь есть, и ждём «стоп» или предел
      if (!analyser) heard = true;
      timer = setInterval(() => { if (analyser) analyse(); else if (performance.now() - t0 > o.maxMs) stop('max'); }, 50);
      document.addEventListener('visibilitychange', onHidden);
      window.addEventListener('pagehide', onHidden);
      setState('listening');
      return { ok: true, mime: s.mime };
    }

    /* Остановить запись. Promise с результатом (или null, если записи не было). */
    function stop(reason) {
      if (state === 'starting') { stopReason = reason || 'cancel'; cleanup(); setState('idle'); return Promise.resolve(null); }
      if (state !== 'listening' || !rec) return finish || Promise.resolve(null);
      stopReason = reason || 'user';
      setState('stopping');
      clearInterval(timer); timer = 0;
      try { if (rec.state !== 'inactive') rec.stop(); } catch (e) { /* уже остановлен */ }
      const f = finish;
      if (o.onStop) f.then((r) => r && o.onStop(r));
      return f;
    }

    return {
      start,
      stop,
      cancel: () => stop('cancel'),
      get state() { return state; },
      get level() { return level; },
      get heard() { return heard; },
      get elapsed() { return state === 'listening' ? performance.now() - t0 : 0; },
      /* живая форма волны для визуализации (Uint8Array, 128 = тишина) */
      wave(out) { if (analyser && out) { analyser.getByteTimeDomainData(out); return true; } return false; },
    };
  }

  App.voice.Recorder = { support, create, pickMime, ERR };
})(window.WispApp);
