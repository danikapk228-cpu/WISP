/* WISP · Layer 7 · Speakable text
 * Ответ WISP приходит в Markdown. Вслух читается только смысл: без звёздочек, решёток, адресов ссылок и кода.
 *  · блок кода → «код показал на экране» (один раз на блок);
 *  · ссылка [текст](адрес) → «текст», голый адрес → «ссылка»;
 *  · списки, заголовки, цитаты, таблицы → обычные фразы с паузами.
 * Streamer режет поток ответа на готовые к озвучке фразы, пока ответ ещё печатается: первая фраза уходит
 * в синтез сразу, не дожидаясь конца ответа. Незакрытый блок кода не озвучивается, пока не закроется. */
(function (App) {
  'use strict';
  App.voice = App.voice || {};

  const END = /[.!?…](?:["»”')\]]*)(?=\s|$)/g;
  const CODE_NOTE = 'Код показал на экране.';

  function speakable(md) {
    let s = String(md || '').replace(/\r\n?/g, '\n');
    s = s.replace(/```[\s\S]*?(?:```|$)/g, `\n${CODE_NOTE}\n`);
    s = s.replace(/!\[[^\]]*\]\([^)]*\)/g, '');                               // картинки
    s = s.replace(/\[([^\]]+)\]\((?:[^()]|\([^)]*\))*\)/g, '$1');               // ссылки → текст ссылки
    s = s.replace(/<?https?:\/\/[^\s>)]+>?/g, 'ссылка');                        // голые адреса
    s = s.replace(/`([^`\n]+)`/g, '$1');                                       // инлайн-код
    const lines = s.split('\n').map((raw) => {
      let l = raw.trim();
      if (!l) return '';
      if (/^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(l)) return '';     // разделитель таблицы
      if (l.includes('|') && /^\|.*\|$/.test(l)) l = l.replace(/^\||\|$/g, '').split('|').map((c) => c.trim()).filter(Boolean).join(', ');
      l = l.replace(/^#{1,6}\s+/, '').replace(/^>\s?/, '').replace(/^(?:[-*+•]|\d{1,3}[.)])\s+/, '').replace(/^[-*_]{3,}$/, '');
      l = l.replace(/(\*\*|__)(.+?)\1/g, '$2').replace(/(^|[\s(«"])[*_]([^*_\n]+)[*_](?=[\s).,!?:;»"]|$)/g, '$1$2').replace(/~~(.+?)~~/g, '$1');
      l = l.replace(/[*_]{2,}/g, '').replace(/\s{2,}/g, ' ').trim();
      if (l && !/[.!?…:;,]$/.test(l)) l += '.';                                // пауза между пунктами списка
      return l;
    });
    return lines.filter(Boolean).join(' ').replace(/\s+([.,!?…:;])/g, '$1').replace(/\.{2,}(?!\.)/g, '.').replace(/\s{2,}/g, ' ').trim();
  }

  /* Делит готовый текст на фрагменты для синтеза: по предложениям, не длиннее max. */
  function split(text, max) {
    const out = [];
    const lim = Math.max(80, max || 600);
    let rest = String(text || '').trim();
    while (rest.length > lim) {
      let cut = -1;
      END.lastIndex = 0;
      let m;
      while ((m = END.exec(rest)) && m.index + m[0].length <= lim) cut = m.index + m[0].length;
      if (cut < lim * 0.4) { const c = rest.lastIndexOf(', ', lim); cut = c > lim * 0.4 ? c + 1 : rest.lastIndexOf(' ', lim); }
      if (cut <= 0) cut = lim;
      out.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut).trim();
    }
    if (rest) out.push(rest);
    return out;
  }

  /* Поток: push(весь текст ответа на сейчас) → новые фрагменты, готовые к озвучке; finish() → остаток. */
  function Streamer({ firstMin, min, max } = {}) {
    let done = 0;                 // сколько символов speakable-текста уже отдано
    let pending = '';
    let first = true;
    const fmin = firstMin || 24, nmin = min || 140, lim = max || 600;

    function safeEnd(raw) {
      // не дальше незакрытого ``` и только до конца последнего законченного предложения/абзаца
      const fences = raw.match(/```/g);
      let limit = raw.length;
      if (fences && fences.length % 2 === 1) limit = raw.lastIndexOf('```');
      const part = raw.slice(0, limit);
      let end = -1;
      END.lastIndex = 0;
      let m;
      while ((m = END.exec(part))) end = m.index + m[0].length;
      const para = part.lastIndexOf('\n');
      return Math.max(end, para);
    }
    function take(final) {
      const out = [];
      while (pending) {
        const need = first ? fmin : nmin;
        if (!final && pending.length < need) break;
        let piece;
        if (pending.length <= lim && (final || pending.length >= need)) {
          // ровно по последней границе предложения внутри pending, чтобы не рвать фразу
          piece = pending;
        } else piece = split(pending, lim)[0];
        out.push(piece.trim());
        pending = pending.slice(piece.length).trim();
        first = false;
        if (!final && pending.length < nmin) break;
      }
      return out.filter(Boolean);
    }
    function advance(raw, final) {
      const end = final ? raw.length : safeEnd(raw);
      if (end <= 0) return [];
      const text = speakable(raw.slice(0, end));
      if (text.length > done) { pending = (pending + ' ' + text.slice(done)).trim(); done = text.length; }
      return take(final);
    }
    return {
      push: (raw) => advance(String(raw || ''), false),
      finish: (raw) => advance(String(raw || ''), true),
    };
  }

  App.voice.Text = { speakable, split, Streamer, CODE_NOTE };
})(window.WispApp);
