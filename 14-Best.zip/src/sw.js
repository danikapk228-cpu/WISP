/* WISP · Service Worker (Layer 4)
 * Нужен только для системных уведомлений о напоминаниях (registration.showNotification):
 * Android/Chrome не показывает уведомления без Service Worker. Кешей и перехвата запросов здесь нет,
 * поэтому на работу приложения и сервера он не влияет. Нажатие на уведомление открывает WISP. */
'use strict';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const app = new URL('../', self.registration.scope).href;
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const win = wins.find((w) => w.url.startsWith(app));
    if (win) return win.focus();
    return self.clients.openWindow(app);
  })());
});
