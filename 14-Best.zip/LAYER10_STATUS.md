# WISP · Layer 10 (Subscription & Access): промежуточное состояние, НЕ завершён

## Готово и проверено тестами (сервер) — `tests/subscription.test.js` + 127 прежних
- БД v8 (миграция автоматическая): `entitlements` (периоды Plus), `access_campaigns`, `access_codes` (только HMAC), `access_redemptions`, `audit_log`. Старый `users.plan = 'plus'` переносится один раз бессрочным периодом `legacy`.
- Тариф вычисляется в `sessionGet` при каждом запросе (`plus_active`). `users.plan` — только кеш. Истёкший Plus перестаёт работать сразу.
- `server/subscription/`: `repo.js`, `codes.js` (CSPRNG, алфавит без I/L/O/0/1, 3 группы ≈ 59 бит по умолчанию), `service.js` (атомарная активация, сложение сроков, Founder, блокировка перебора 5/15 мин на пользователя, 20/час на IP, 10/мин частота), `quota.js` (единая сводка лимитов), `features.js` (сравнение Free/Plus только из реальной конфигурации), `billing.js` (контракт оплаты, оплаты нет), `costs.js` (оценка стоимости).
- API: `GET /api/subscription`, `POST /api/subscription/redeem`. Админ по HTTP нет.
- Админ CLI: `npm run admin -- help` (кампании, коды, отключение, привязка, активации, журнал, grant/revoke, costs).
- Новый лимит `plans.json → vision.images_daily` (null = как раньше).
- Мелкие правки прежних слоёв: `lib/auth.js` (тариф из entitlements), `lib/db.js` (setPlan через периоды, mergeUsers переносит периоды), `routes/chat.js` (срок Plus в /api/session, проверка images_daily), `app.js`, `config.js`.

## НЕ сделано
1. Экран Subscription во фронтенде (`src/subscription/*`, `src/core/subscription-api.js`), подключение в `home.js` (кнопка тарифа), таймер обновления тарифа в момент окончания Plus в `app.js`.
2. Браузерные e2e Layer 10, проверка на iPhone, пересборка `dist/wisp.html`.
3. Цены в `server/config/costs.json` пустые: лимиты не менялись, оценка стоимости ждёт реальных цен.
4. Анализ документов, расширенная персонализация Plus, оплата — не реализованы и как преимущества не показываются.
5. По умолчанию коды активируются только в аккаунте, а экранов входа (Layer 9) ещё нет.
