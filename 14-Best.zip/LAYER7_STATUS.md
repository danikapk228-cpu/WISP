# WISP · Layer 7 (Voice Assistant): промежуточное состояние, НЕ завершён

## Готово и проверено тестами (сервер)
- `server/voice/service.js`, `server/routes/voice.js`: настоящий STT (`/audio/transcriptions`) и TTS (`/audio/speech`) через OpenAI-совместимый API.
  - `GET /api/voice`, `POST /api/voice/transcribe` (сырое аудио, формат по сигнатуре: webm/mp4/ogg/wav/mp3/flac), `POST /api/voice/speech` (аудио потоком).
  - Ключ только на сервере; аудио не сохраняется (буфер обнуляется), в лог только размеры и коды.
  - Лимиты тарифа (`plans.json → voice`), возврат лимита при сбое провайдера, тайм-ауты, отмена при обрыве клиента.
  - Манера речи по характеру WISP (`voice.json → personality_instructions`, для gpt-4o-*-tts).
- БД v5: таблица `voice_usage` (только счётчики). Профиль: `voice_replies`, `voice_autoplay`, `voice_rate`, `voice_id` (клиент + сервер).
- Исправлено попутно: серверная нормализация профиля удаляла дефисы (`Анна-Мария` → `АннаМария`).
- `tests/voice.test.js`: 15 проверок; двойник Audio API в `tests/fake-provider.js`.

## Написано, НЕ подключено и НЕ проверено (фронтенд)
- `src/voice/api.js` (клиент голосового API), `src/voice/text.js` (Markdown → речь, поток фраз), `src/voice/recorder.js` (MediaRecorder + анализатор, автостоп по паузе, стоп при сворачивании).

## Осталось сделать
1. `src/voice/input.js` (сервер STT / запасной Web Speech API), `speaker.js` (очередь TTS, одно воспроизведение за раз, разблокировка звука на iOS, запасной speechSynthesis), `wave.js`, `voice-mode.js` + `voice.css`.
2. Composer: микрофон → запись → текст в поле для правки; кнопка Voice Mode в пустом поле.
3. Чат: события ответа для Voice Mode, кнопка ▶/■ у ответов, автоозвучка, `resetAfterClear`.
4. Подключить Layer 6 (по LAYER6_STATUS.md) и добавить экран «Голос» в Settings.
5. E2E в Chromium с фейковым микрофоном, проверка на iPhone, сборка dist.

## Переменные окружения (новые)
WISP_VOICE_API_KEY (или OPENAI_API_KEY), WISP_VOICE_BASE_URL (или OPENAI_BASE_URL), WISP_STT_MODEL, WISP_TTS_MODEL, WISP_STT_LANGUAGE,
WISP_TTS_DEFAULT_VOICE, WISP_TTS_INSTRUCTIONS, WISP_VOICE_TIMEOUT_MS, WISP_VOICE_DISABLED, WISP_STT_DISABLED, WISP_TTS_DISABLED, WISP_VOICE_FILE.
