# WISP: Layer 0–8 · 8.1

Персональный AI-компаньон WISP: появление маскота (Layer 0), первое знакомство (Layer 1) и главный экран (Layer 2).
Без зависимостей и сборщика. Открывается двойным кликом по `index.html` и с любого статического хостинга.

## Запуск
- **Проект:** открыть `index.html`.
- **Один файл:** `dist/wisp.html` (собирается командой `python3 tools/build_single.py`).
- Для уведомлений, микрофона и надёжной памяти нужен https (или localhost). На `file://` и по http браузер честно скажет, что возможность недоступна.
- **Сервер и AI-провайдеры:** настрой `.env.example` → `.env`, затем см. [AI-PROVIDERS.md](AI-PROVIDERS.md). Ключи хранятся только на сервере.

## Структура
```
index.html                      точка входа (разметка Layer 0 без изменений + корень приложения)
src/
  layer0-entrance/              Layer 0: entrance-анимация (механика и визуал не тронуты)
  core/
    namespace.js                общий неймспейс
    profile.js                  схема профиля, справочники, нормализация, toServerPayload()
    storage.js                  адаптер хранилища (localStorage) + репозитории профиля и прогресса
    profile-store.js            состояние профиля в рантайме
    capabilities.js             уведомления / микрофон / надёжная память / голос: проверка и запрос
    dictation.js                голосовой ввод (Web Speech API) с честной доступностью
    assistant.js                интеграция AI через серверный прокси (ключей во фронтенде нет)
  design-system/
    tokens.css                  цвета, типографика, радиусы, движение
    components.css, layout.css  кнопки, стекло, карточки, поля, прогресс, реплика, раскладка экрана
    icons.js, ui.js             иконки и переиспользуемые компоненты
  onboarding/
    flow.js                     порядок шагов и правила (без DOM)
    mascot-director.js          поза и реакции маскота поверх Layer 0
    onboarding.js/.css          оболочка: шапка, переходы, история, сохранение шага
    screens/*.js                8 экранов, каждый отдельный компонент
  home/                         Layer 2: главный экран
    home.js / home.css          шапка, маскот, приветствие, быстрые действия, ввод, навигация, вкладки
    composer.js                 строка ввода: автовысота, отправка, голос, подсказки
    sheets.js                   панели: профиль, тариф, быстрые действия
    copy.js                     фразы в характере WISP, подсказки по интересам и занятию
  app.js                        загрузка: Layer 0 → знакомство или главный экран
tools/build_single.py           сборка в один HTML
```

## Профиль (`localStorage: wisp:profile:v1`)
```json
{
  "schema_version": 1,
  "user": {
    "name": "Гера",
    "interests": ["music", "design"],
    "occupation": "work",
    "about": "…",
    "assistant_personality": "humor",
    "permissions": { "microphone": { "status": "granted", "updated_at": "…" } },
    "onboarding_completed": true,
    "plan": "free"
  },
  "meta": { "created_at": "…", "updated_at": "…", "completed_at": "…" }
}
```
- Статусы разрешений: `granted | denied | prompt | unsupported | unavailable | skipped`.
- Текущий шаг знакомства хранится отдельно (`wisp:onboarding:v1`), это состояние интерфейса, а не данные пользователя.
- **Перенос на сервер:** передать в `ProfileRepository` адаптер с тем же интерфейсом (`read / write / remove`, async). Формат запроса отдаёт `Profile.toServerPayload()`.
- Секретов на клиенте нет. `Profile.normalize()` отбрасывает все неизвестные поля, поэтому токены и ключи в хранилище не попадут.

## Что изменено в Layer 0
Механика, визуал и тайминги не менялись. Добавлены только места с пометкой `[Layer 1 hook]`:
- событие `wisp:settled` на `.wisp-stage`, когда появление закончено;
- `WISP.hop(strength)`, `WISP.blink(double)`: тот же прыжок, что и при тапе по маскоту;
- `WISP.settled`.
Уменьшение и подъём маскота в знакомстве делаются снаружи, transform'ом на сцене (`.wisp-stage.is-posed` в `onboarding.css`).

## Поведение
- Первое открытие: полная entrance-анимация, затем знакомство.
- Знакомство прервано: при следующем открытии продолжается с того же шага, все ответы на месте.
- Знакомство пройдено: после короткого появления сразу главный экран.
- Все вопросы необязательные («Пропустить» в шапке). «Назад» работает и кнопкой, и системным жестом.
- `prefers-reduced-motion`: без прыжков и сдвигов, только мягкие появления.

## Layer 2 · Главный экран
- Маскот тот же, что в Layer 0: `MascotDirector.setPose(pose, measure)` ставит его в центр свободной области вкладки. Свечение и «дыхание» добавлены снаружи (`.wisp-stage.is-home` в `home.css`).
- Приветствие и короткие фразы зависят от характера (`home/copy.js`). Подсказки в поле ввода берутся из занятия и интересов; анкета целиком не показывается.
- **Тариф:** `user.plan` = `free | plus`, по умолчанию `free`. Значение должно приходить с сервера вместе с профилем. Клиент сам Plus не включает, оплаты нет.
- **AI:** `<meta name="wisp-assistant-endpoint" content="/api/assistant">`. Пусто = не подключён, и WISP честно говорит об этом (текст остаётся в поле). Контракт: `POST {message, profile:{name, interests, occupation, about, personality}}` → `{reply}`. Ключ провайдера хранится только на сервере.
- **Голос:** Web Speech API (`ru-RU`). Нет API или доступ запрещён: кнопка приглушена и по нажатию объясняет причину.
- **Навигация:** Home / Chat / Memory / Tools. Chat, Memory, Tools пока заглушки. Системный «назад» закрывает панель, затем возвращает на Home.
- Быстрые действия открывают панели «Появится позже». Ничего не сохраняют. В «Напоминании» можно по-настоящему включить уведомления.

## Layer 3 · AI-чат
Запуск (нужен Node.js ≥ 22.13, без npm-зависимостей):
```
cp .env.example .env      # вписать OPENAI_API_KEY и/или ANTHROPIC_API_KEY / OPENROUTER_API_KEY
npm start                 # http://127.0.0.1:8787  (HOST=0.0.0.0 — чтобы открыть с телефона)
npm test                  # серверные тесты (локальный двойник провайдера, без интернета)
npm run admin -- users    # пользователи;  npm run admin -- plan <id> plus  — выдать Plus
```
- `server/` — Node-сервер: раздаёт фронтенд и API. SQLite (`data/wisp.db`). Ключи только в `.env`.
- `server/config/models.json` — провайдеры и модели (OpenAI-совместимые и Anthropic), тариф модели, зрение, окна. **Проверьте актуальные id моделей у провайдера.**
- `server/config/plans.json` — лимиты Free/Plus (проверяются только сервером).
- `server/prompts/system.md`, `personalities.json` — системная инструкция, правится без перезапуска.
- `server/ai/service.js` + `providers/*` — универсальный AI service; новый провайдер = новый адаптер.
- `server/ai/context.js` — окно контекста, `NullMemoryProvider` — точка подключения Layer 5.
- `src/chat/*` — интерфейс чата, безопасный Markdown (без innerHTML), подсветка кода, меню, картинки.
- Сессия устройства: httpOnly-cookie; аккаунтов пока нет. Диалоги привязаны к пользователю на сервере.
- `dist/wisp.html` и `file://` работают без сервера: чат честно показывает «AI не подключён».

## Layer 4 · Tools & Actions
Вкладка **Tools** открывает экран «Your tools»: Reminders, Tasks, Notes, Daily planner, Image understanding (через загрузку картинок в чате из Layer 3).
Все данные лежат на сервере в той же `data/wisp.db` и привязаны к пользователю сессии. Второй копии на клиенте нет.

- `server/tools/time.js`: часовые пояса без зависимостей (Intl), перевод «дата + время в поясе» в UTC с учётом DST.
- `server/tools/repo.js`: SQL инструментов, в каждом запросе есть `user_id`.
- `server/tools/service.js`: единые правила для REST и AI: проверка ввода, лимиты Free/Plus (`plans.json → tools`), частота изменений.
- `server/tools/ai.js`: определения функций для модели, выполнение, журнал `tool_calls`.
- `server/routes/tools.js`: REST API (`/api/notes`, `/api/tasks`, `/api/reminders`, `/api/events`, `/api/agenda`, `/api/tools/summary`).
- Чат: модель вызывает функции (OpenAI function calling / Anthropic tool use). Сервер проверяет аргументы, берёт пользователя из сессии, пишет в базу и только потом отдаёт модели `{ok:true}`. В чате это видно карточкой действия.
- `src/tools/*`: экраны, `scheduler.js` (уведомления), `src/sw.js` (только для показа уведомлений, без кеша).
- Тесты: `npm test` (server + tools, без интернета).

**Ограничения:** напоминания приходят, пока WISP открыт; закрытое приложение браузер разбудить не даёт, поэтому такие напоминания показываются при следующем открытии как пропущенные. На iPhone уведомления работают только для WISP, добавленного на экран «Домой» (iOS 16.4+). Web Push не реализован. Layer 8 разрешает AI изменять записи, а удаление и массовые изменения выполняются только после явного подтверждения.

## Layer 5 · Memory (долговременная память)
Вкладка **Memory**: «WISP remembers what matters», созвездие-счётчик (каждое воспоминание — огонёк), выключатель памяти, поиск (с учётом форм слов), категории Personal / Preferences / Work & Projects / Goals / People / Other, предложения WISP («Запомнить?»), закреплённые, правка/удаление в нижней панели, даты создания и изменения, экспорт JSON, очистка всей памяти в два касания, пустое состояние с примерами.

**Хранение:** та же `data/wisp.db`, таблицы `memories` и `memory_dismissed` (только отпечаток отклонённого, без текста). Chat History (Layer 3) не дублируется. Миграция v2 → v3 автоматическая при запуске (`server/lib/db.js → migrate`): новые колонки `users.memory_enabled`, `users.memory_suggest`, `messages.memory_used`. Новых переменных окружения нет.

Запись: `id, user_id, category, content, importance (1–3), pinned, sensitive, source (user|explicit|suggested), status (active|pending), replaces_id, conversation_id, created_at, updated_at, last_used_at`.

- `server/memory/text.js` — стеммер (русский Snowball + английский), стоп-слова, темы («инвентарь» и «игра на JavaScript» связаны через темы games/programming), похожесть.
- `server/memory/sensitive.js` — пароли/коды/карты/ключи: никогда; здоровье, финансы, документы/контакты, убеждения, интимное, правовое: только с отдельным согласием.
- `server/memory/extract.js` — «запомни, что…» для моделей без функций, угадывание категории.
- `server/memory/service.js` — вся логика: проверка ввода, лимиты, дедупликация (похожее обновляется), подтверждение/отказ, recall (только относящееся к сообщению + немного закреплённого и правил общения, в пределах лимитов тарифа).
- `server/memory/ai.js` — функции модели `remember`, `suggest_memory`, `forget_memory`, раздел системной инструкции. Модель получает `saved: true` только после записи в базу. Текст фактов не пишется в журнал `tool_calls`.
- `server/routes/memory.js` — REST API (`/api/memories`, `/api/memory/settings`), всё по userId из сессии.
- `src/core/memory-api.js`, `src/memory/*` — экран; `src/chat/*` — карточки памяти и кнопка «Память · N».
- Лимиты: `server/config/plans.json → memory` (Free: 50 фактов, 5 закреплённых, 6+3 в контексте, 1 сообщение для отбора; Plus: 1000, 50, 14+6, 3 последних сообщения).
- Тесты: `npm test` (server + tools + memory). `npm run test:e2e` — браузерный сценарий, нужен Playwright (без него пропускается).

**Ограничения:** отбор релевантного — лексический + тематический словарь, без эмбеддингов: факты вне словаря тем подхватываются только по общим словам. Удаление воспоминания не правит старую переписку в Chat History (удали диалог, если нужно). Предложения без ответа удаляются через 7 дней (Plus — 14). Оплаты нет: Plus выдаётся `npm run admin -- plan <id> plus`.

## Layer 8 · AI Actions
WISP разбирает даты в часовом поясе пользователя, ищет и показывает задачи, напоминания, заметки и события, создаёт и изменяет записи. Удаление, массовые изменения и очистка истории сначала показывают карточку с кнопками подтверждения и отмены. Карточки читают live-состояние записей из сервера и позволяют пользователю открыть правку или удалить запись после отдельного подтверждения.

- `server/actions/*` — разбор намерений, дат, поиск, дедупликация и подтверждение опасных действий.
- `server/routes/actions.js` — live-состояние, подтверждение и отмена.
- Голос в чате использует Layer 7 Recorder и серверное `/api/voice/transcribe`; распознанная фраза уходит в чат как `input: "voice"`. Нужен настроенный STT-провайдер на сервере.
- `client_id` защищает отправку сообщения от дублей при повторном запросе.
- Подробности: [`LAYER8_STATUS.md`](LAYER8_STATUS.md).

**Проверки:** `npm test`; `npm run test:e2e` запускает сценарии браузера на iPhone-вьюпорте и требует Playwright/Chromium. Один HTML пересобирается через `python3 tools/build_single.py`.

Исправлено попутно: фильтр управляющих символов в `server/tools/service.js` и `src/core/profile.js` удалял все дефисы («e-mail» → «email»).

## Layer 12 · Публичный сайт
Отдельный статический сайт-презентация в `site/` (не приложение). Без зависимостей, без внешних запросов, без секретов. Сервер WISP папку `site/` не раздаёт, приложение не тронуто.
```
npm run site          # просмотр: http://127.0.0.1:8080/site/  (отдаёт только site/ и статический фронтенд)
npm run site:assets   # таблица Free/Plus из server/config/plans.json + маскот из Layer 0 + WebP-скриншоты (Pillow)
npm run site:shots    # заново снять скриншоты настоящего интерфейса (Playwright, демо-двойник AI, временная база)
```
- Ссылки (приложение, Telegram, GitHub, почта) — `site/assets/js/config.js`. Пусто = ссылка не показывается.
- На хостинг публикуется **только** `site/` (GitHub Pages, Cloudflare Pages, Netlify, Vercel). Подробности: [`site/README.md`](site/README.md), отчёт: [`LAYER12_REPORT.md`](LAYER12_REPORT.md).

## Layer 13 · Движок тем · этап 2
Добавлена основа для Black, Midnight, Light и Custom: раннее применение палитры до отрисовки, генератор переопределений цветов, роли background/primary/secondary/accent, прозрачность, скругления и свечение. Пересобранный CSS не меняет исходную тёмную тему по умолчанию. Генерация: `python3 tools/build_theme_engine.py`; затем `python3 tools/build_single.py`. Экран выбора тем и редактор ещё не подключены. Подробности: [`LAYER13_REPORT.md`](LAYER13_REPORT.md).
