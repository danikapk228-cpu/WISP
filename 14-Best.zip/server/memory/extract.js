/* WISP · Server · Memory · Extraction helpers
 *  · explicitRequest(text) — пользователь прямо просит запомнить («запомни, что…», «remember that…»).
 *    Это запасной путь для моделей без функций: сервер сам сохраняет факт и только потом модель
 *    узнаёт, что он сохранён. С моделями, которые умеют функции, факт формулирует модель (remember).
 *  · guessCategory(text) — категория по ключевым словам, если модель или клиент её не указали.
 * Сюда не попадает «всё подряд»: только явная просьба. Предложения (suggested) делает модель,
 * а сохраняются они лишь после подтверждения пользователя. */
'use strict';
const { normalize } = require('./text');

const CATEGORIES = ['personal', 'preferences', 'work', 'goals', 'people', 'other'];
const CATEGORY_LABELS = { personal: 'Personal', preferences: 'Preferences', work: 'Work & Projects', goals: 'Goals', people: 'People', other: 'Other' };
const CATEGORY_RU = { personal: 'О пользователе', preferences: 'Предпочтения', work: 'Работа и проекты', goals: 'Цели', people: 'Люди', other: 'Другое' };

/* «Запомни, что …» в начале сообщения или отдельным предложением */
const TRIGGER = /(?:^|[.!?\n]\s*)(?:(?:пожалуйста|wisp|висп|слушай|кстати)[,\s]+)*(?:запомни(?:те)?|запиши (?:себе )?в память|сохрани (?:себе )?в память|добавь в память|имей(?:те)? в виду(?: на будущее)?|не забывай|please remember|remember)(?:\s*,\s*|\s*:\s*|\s+)(?:(?:пожалуйста|please)[,\s]+)?(?:что|that|this:?)?[\s,:]*(.+)$/is;

function explicitRequest(text) {
  const raw = String(text || '').trim();
  if (!raw || raw.length > 2000) return null;
  const m = TRIGGER.exec(raw);
  if (!m) return null;
  // только первое предложение после «запомни»: дальше обычно идёт новый вопрос («…Рекс. И расскажи анекдот»)
  let fact = m[1].split(/\n/)[0].split(/(?<=[.!?…])\s+(?=[\p{Lu}\p{N}«"])/u)[0].trim().replace(/^[«"'„]+|[»"'“]+$/g, '').replace(/[.!\s]+$/, '').trim();
  // «запомни это» без самого факта — нечего запоминать
  if (!fact || /^(это|этот|эту|this|it)$/i.test(fact) || fact.length < 3) return null;
  if (fact.length > 600) fact = fact.slice(0, 600);
  fact = fact.charAt(0).toLocaleUpperCase('ru') + fact.slice(1);
  return { content: fact, category: guessCategory(fact) };
}

const RULES = [
  ['people', /\b(мам[аеуы]|мать|пап[аеуы]|отец|отца|брат|сестр|сын|доч[ьи]|жен[аеуы]|муж\b|мужа|бабушк|дедушк|друг|подруг|девушк|парен|коллег|начальни|ребен|дет[иья]|кот\b|кошк|собак|mom|mother|dad|father|brother|sister|son\b|daughter|wife|husband|friend|girlfriend|boyfriend|colleague|boss|my (?:cat|dog))/i],
  ['goals', /(хочу|хотел[аи]? бы|мечтаю|цель|планирую|собираюсь|надеюсь|стремлюсь|в планах|к \d{4}|в этом году|в следующем году|\bgoal|want to|plan to|planning to|dream|by \d{4})/i],
  ['work', /(проект|работа[юет]|работе|работу|разрабатыва|делаю (?:игру|сайт|приложение|бота)|пишу (?:игру|код|книгу|бота)|стартап|компани|клиент|заказчик|должност|профессия|по профессии|программист|дизайнер|разработчик|менеджер|project|work(?:ing)? (?:on|at|as)|my job|startup|company|building)/i],
  ['preferences', /(предпочита|нравится|нравятся|люблю|обожаю|не люблю|ненавижу|терпеть не могу|удобнее|лучше всего|коротк|подробн|отвечай|пиши мне|обращайся|называй меня|стиль|prefer|i like|i love|i hate|don't like|favorite|favourite)/i],
  ['personal', /(меня зовут|моё имя|мое имя|мне \d+|я родил|я живу|живу в|я из\b|по национальност|мой день рождения|у меня день рождения|я (?:студент|школьник|учусь)|my name|i am \d+|i'm \d+|i live|born in|i'm from|i am from)/i],
];
const B = (re) => new RegExp(re.source.replace(/\\b/g, '(?:(?<![\\p{L}\\p{N}])|(?![\\p{L}\\p{N}]))'), 'iu');
const RULES_U = RULES.map(([c, re]) => [c, B(re)]);
function guessCategory(text) {
  const s = normalize(text);
  for (const [cat, re] of RULES_U) if (re.test(s)) return cat;
  return 'other';
}

module.exports = { explicitRequest, guessCategory, CATEGORIES, CATEGORY_LABELS, CATEGORY_RU };
