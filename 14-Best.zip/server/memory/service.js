/* WISP · Server · Memory · Service
 * Единственная реализация долговременной памяти. Её вызывают REST API экрана Memory, AI-чат (функции
 * remember / suggest_memory / forget_memory) и запасной путь «запомни…» для моделей без функций.
 * Правила одни для всех путей:
 *  · пользователь и тариф — только из серверной сессии (ctx.userId, ctx.plan), никогда из запроса;
 *  · проверка ввода, лимиты тарифа (plans.json → memory), частота изменений;
 *  · похожее воспоминание обновляется, а не дублируется;
 *  · пароли/коды/карты не сохраняются никогда, личные сведения — только с отдельным подтверждением;
 *  · предложения WISP (pending) не используются в ответах, пока пользователь не скажет «да».
 * recall() выбирает для ответа только относящиеся к сообщению воспоминания, а не всю память. */
'use strict';
const { HttpError } = require('../lib/http');
const { MemoryRepo } = require('./repo');
const T = require('./text');
const Sensitive = require('./sensitive');
const { CATEGORIES, CATEGORY_LABELS, guessCategory } = require('./extract');

const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const CONTROL = /[\x00-\x08\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;
const DUPLICATE = 0.6;
const DAY = 86400000;

/* Значения по умолчанию; настоящие лимиты — server/config/plans.json → memory */
const DEFAULT_LIMITS = {
  free: { items_max: 50, pinned_max: 5, item_max_chars: 300, pending_max: 10, pending_ttl_days: 7, context_items: 6, context_core: 3, context_chars: 1200, query_turns: 1, writes_per_minute: 30 },
  plus: { items_max: 1000, pinned_max: 50, item_max_chars: 600, pending_max: 30, pending_ttl_days: 14, context_items: 14, context_core: 6, context_chars: 4000, query_turns: 3, writes_per_minute: 60 },
};

const bad = (field, message) => new HttpError(400, 'bad_input', message, { field });
const notFound = () => new HttpError(404, 'not_found', 'Воспоминание не найдено.');
const has = (o, k) => o && Object.prototype.hasOwnProperty.call(o, k) && o[k] !== undefined;

function contentField(v, max) {
  if (typeof v !== 'string') throw bad('content', 'Текст воспоминания должен быть строкой.');
  const s = v.replace(CONTROL, '').replace(/\s+/g, ' ').trim();
  if (!s) throw bad('content', 'Воспоминание пустое.');
  if (s.length > max) throw bad('content', `Слишком длинно: максимум ${max} символов. Память хранит короткие факты.`);
  return s;
}
function categoryField(v, fallbackText) {
  if (v === undefined || v === null || v === '') return guessCategory(fallbackText || '');
  if (typeof v !== 'string' || !CATEGORIES.includes(v)) throw bad('category', 'Неизвестная категория.');
  return v;
}
function importanceField(v, def) {
  if (v === undefined || v === null) return def;
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1 || n > 3) throw bad('importance', 'Важность: 1, 2 или 3.');
  return n;
}
function boolField(v, field) {
  if (typeof v !== 'boolean') throw bad(field, 'Ожидается true или false.');
  return v;
}

const pub = (m) => m && ({
  id: m.id, category: m.category, content: m.content, importance: m.importance, pinned: !!m.pinned, sensitive: !!m.sensitive,
  source: m.source, status: m.status, replaces_id: m.replaces_id || null,
  created_at: m.created_at, updated_at: m.updated_at, last_used_at: m.last_used_at || null,
});

class MemoryService {
  constructor({ store, config, limits, log }) {
    this.repo = new MemoryRepo(store);
    this.config = config;
    this.rate = limits || null;
    this.log = log || null;
    this.cache = new Map();           // id → { v: updated_at, a: analyze(content) }
  }

  limits(planId) {
    const key = planId === 'plus' ? 'plus' : 'free';
    const p = (this.config.plans && this.config.plans[key]) || {};
    return { ...DEFAULT_LIMITS[key], ...(p.memory || {}) };
  }
  write(ctx) { if (this.rate) this.rate.checkMemoryWrite(ctx.userId, this.limits(ctx.plan).writes_per_minute); }
  limitError(ctx, kind, limit, message) { return new HttpError(403, 'limit_memory', message, { kind, limit, plan: ctx.plan }); }
  checkId(id) { if (typeof id !== 'string' || !ID_RE.test(id)) throw notFound(); return id; }
  own(ctx, id) {
    this.purge(ctx);
    const m = this.repo.get(this.checkId(id), ctx.userId);
    if (!m) throw notFound();
    return m;
  }

  analyzed(m) {
    const hit = this.cache.get(m.id);
    if (hit && hit.v === m.updated_at) return hit.a;
    const a = T.analyze(m.content);
    if (this.cache.size > 20000) this.cache.clear();
    this.cache.set(m.id, { v: m.updated_at, a, userId: m.user_id });
    return a;
  }
  clearUserCache(userId) {
    for (const [id, item] of this.cache) if (item.userId === userId) this.cache.delete(id);
  }
  /* Самое похожее воспоминание пользователя с этим статусом (или null) */
  similar(userId, content, status, exceptId) {
    const a = T.analyze(content);
    const norm = T.normalize(content).replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
    let best = null, score = 0;
    for (const m of this.repo.list(userId, status)) {
      if (m.id === exceptId) continue;
      const s = T.normalize(m.content).replace(/[^\p{L}\p{N}]+/gu, ' ').trim() === norm ? 1 : T.similarity(a, this.analyzed(m));
      if (s > score) { score = s; best = m; }
    }
    return score >= DUPLICATE ? { memory: best, score } : null;
  }
  purge(ctx) { this.repo.purgePending(ctx.userId, Date.now() - this.limits(ctx.plan).pending_ttl_days * DAY); }

  /* ════ Настройки ════ */
  settings(ctx) { return this.repo.settings(ctx.userId); }
  updateSettings(ctx, body) {
    if (has(body, 'enabled')) this.repo.setEnabled(ctx.userId, boolField(body.enabled, 'enabled'));
    if (has(body, 'suggest')) this.repo.setSuggest(ctx.userId, boolField(body.suggest, 'suggest'));
    return this.settings(ctx);
  }

  /* ════ Экран Memory ════ */
  overview(ctx) {
    const L = this.limits(ctx.plan);
    return {
      total: this.repo.count(ctx.userId, 'active'),
      pending_total: this.repo.count(ctx.userId, 'pending'),
      pinned: this.repo.countPinned(ctx.userId),
      by_category: ((bc) => Object.fromEntries(CATEGORIES.map((c) => [c, bc[c] || 0])))(this.repo.byCategory(ctx.userId)),
      limits: { items_max: L.items_max, pinned_max: L.pinned_max, item_max_chars: L.item_max_chars },
      settings: this.settings(ctx),
      categories: CATEGORIES.map((id) => ({ id, label: CATEGORY_LABELS[id] })),
    };
  }
  list(ctx, { q, category } = {}) {
    this.purge(ctx);
    if (category !== undefined && category !== null && category !== '' && category !== 'all' && category !== 'pinned' && !CATEGORIES.includes(category)) throw bad('category', 'Неизвестная категория.');
    let rows = this.repo.list(ctx.userId, 'active');
    if (category === 'pinned') rows = rows.filter((m) => m.pinned);
    else if (category && CATEGORIES.includes(category)) rows = rows.filter((m) => m.category === category);
    const query = typeof q === 'string' ? q.replace(CONTROL, '').trim().slice(0, 100) : '';
    if (query) {
      const needle = T.normalize(query);
      const qs = T.stems(query);
      rows = rows.filter((m) => {
        const hay = T.normalize(`${m.content} ${CATEGORY_LABELS[m.category]}`);
        if (hay.includes(needle)) return true;
        if (!qs.length) return false;
        const ms = this.analyzed(m).stems;
        return qs.every((s) => ms.some((x) => x === s || (s.length >= 4 && x.startsWith(s)) || (x.length >= 4 && s.startsWith(x))));
      });
    }
    const pending = this.repo.list(ctx.userId, 'pending').map(pub);
    return { memories: rows.map(pub), pending, ...this.overview(ctx) };
  }
  get(ctx, id) { return pub(this.own(ctx, id)); }

  /* Ручное добавление с экрана Memory */
  create(ctx, body) {
    const b = body || {};
    const L = this.limits(ctx.plan);
    const content = contentField(b.content, L.item_max_chars);
    const category = categoryField(b.category, content);
    const importance = importanceField(b.importance, 2);
    const pinned = has(b, 'pinned') ? boolField(b.pinned, 'pinned') : false;
    const sens = this.guard(content, b.confirm_sensitive === true);
    this.write(ctx);
    return this.repo.tx(() => {
      const dup = this.similar(ctx.userId, content, 'active');
      if (dup) {
        const cur = dup.memory;
        if (pinned && !cur.pinned) this.checkPinned(ctx, L);
        const m = this.repo.update(cur.id, ctx.userId, { category, content, importance: Math.max(importance, cur.importance), pinned: pinned || !!cur.pinned, sensitive: sens || !!cur.sensitive });
        return { memory: pub(m), op: 'updated', merged_with: cur.id };
      }
      this.checkCount(ctx, L);
      if (pinned) this.checkPinned(ctx, L);
      const m = this.repo.insert(ctx.userId, { category, content, importance, pinned, sensitive: sens, source: 'user', status: 'active' });
      return { memory: pub(m), op: 'created' };
    });
  }
  update(ctx, id, body) {
    const b = body || {};
    const L = this.limits(ctx.plan);
    const cur = this.own(ctx, id);
    const content = has(b, 'content') ? contentField(b.content, L.item_max_chars) : cur.content;
    const category = has(b, 'category') ? categoryField(b.category, content) : cur.category;
    const importance = has(b, 'importance') ? importanceField(b.importance, cur.importance) : cur.importance;
    const pinned = has(b, 'pinned') ? boolField(b.pinned, 'pinned') : !!cur.pinned;
    let sensitive = !!cur.sensitive;
    if (content !== cur.content) sensitive = this.guard(content, b.confirm_sensitive === true);
    this.write(ctx);
    if (pinned && !cur.pinned && cur.status === 'active') this.checkPinned(ctx, L);
    return pub(this.repo.update(cur.id, ctx.userId, { category, content, importance, pinned, sensitive }));
  }
  remove(ctx, id) {
    const cur = this.own(ctx, id);
    this.write(ctx);
    this.repo.remove(cur.id, ctx.userId);
    this.cache.delete(cur.id);
    return { ok: true, id: cur.id };
  }
  /* Очистка всей памяти: только с явным подтверждением в теле запроса */
  clear(ctx, body) {
    if (!body || body.confirm !== 'clear_all') throw new HttpError(400, 'confirm_required', 'Нужно подтверждение: { "confirm": "clear_all" }.');
    this.write(ctx);
    const deleted = this.repo.clear(ctx.userId);
    this.clearUserCache(ctx.userId);
    return { ok: true, deleted };
  }
  /* «Да, запомни» для предложения WISP (и для личных сведений, которые ждут отдельного согласия) */
  confirm(ctx, id, body) {
    const cur = this.own(ctx, id);
    if (cur.status !== 'pending') return { memory: pub(cur), op: 'unchanged' };
    if (cur.sensitive && !(body && body.confirm_sensitive === true)) {
      throw new HttpError(409, 'memory_sensitive', 'Это личные сведения. Подтверди отдельно, что их можно сохранить.', { kinds: Sensitive.check(cur.content).kinds });
    }
    const L = this.limits(ctx.plan);
    this.write(ctx);
    return this.repo.tx(() => {
      const target = cur.replaces_id ? this.repo.get(cur.replaces_id, ctx.userId) : null;
      if (target && target.status === 'active') {
        const m = this.repo.update(target.id, ctx.userId, { category: cur.category, content: cur.content, importance: Math.max(cur.importance, target.importance), pinned: !!target.pinned, sensitive: !!cur.sensitive || !!target.sensitive });
        this.repo.remove(cur.id, ctx.userId);
        return { memory: pub(m), op: 'updated', replaced: cur.id };
      }
      const dup = this.similar(ctx.userId, cur.content, 'active');
      if (dup) {
        const m = this.repo.update(dup.memory.id, ctx.userId, { category: cur.category, content: cur.content, importance: Math.max(cur.importance, dup.memory.importance), pinned: !!dup.memory.pinned, sensitive: !!cur.sensitive || !!dup.memory.sensitive });
        this.repo.remove(cur.id, ctx.userId);
        return { memory: pub(m), op: 'updated', replaced: cur.id };
      }
      this.checkCount(ctx, L);
      if (cur.pinned) this.checkPinned(ctx, L);
      this.repo.activate(cur.id, ctx.userId, !!cur.sensitive);
      return { memory: pub(this.repo.get(cur.id, ctx.userId)), op: 'saved' };
    });
  }
  /* «Не надо»: предложение удаляется, остаётся только отпечаток, чтобы не предлагать то же снова */
  dismiss(ctx, id) {
    const cur = this.own(ctx, id);
    if (cur.status !== 'pending') throw new HttpError(409, 'not_pending', 'Это воспоминание уже сохранено. Удалить его можно в Memory.');
    this.write(ctx);
    this.repo.tx(() => { this.repo.dismiss(ctx.userId, T.fingerprint(cur.content)); this.repo.remove(cur.id, ctx.userId); });
    return { ok: true, id: cur.id };
  }
  export(ctx) {
    this.purge(ctx);
    return {
      exported_at: new Date().toISOString(),
      settings: this.settings(ctx),
      memories: ['active', 'pending'].flatMap((status) => this.repo.list(ctx.userId, status))
        .map((m) => ({ ...pub(m), created_at: new Date(m.created_at).toISOString(), updated_at: new Date(m.updated_at).toISOString(), last_used_at: m.last_used_at ? new Date(m.last_used_at).toISOString() : null })),
    };
  }

  checkCount(ctx, L) {
    if (this.repo.count(ctx.userId, 'active') >= L.items_max) throw this.limitError(ctx, 'items', L.items_max, `Память заполнена (${L.items_max}). Удали ненужное${ctx.plan === 'plus' ? '' : ' или перейди на Plus'}.`);
  }
  checkPinned(ctx, L) {
    if (this.repo.countPinned(ctx.userId) >= L.pinned_max) throw this.limitError(ctx, 'pinned', L.pinned_max, `Можно закрепить до ${L.pinned_max} воспоминаний${ctx.plan === 'plus' ? '' : ' (в Plus больше)'}.`);
  }
  /* Пароли и т.п. — никогда; личные сведения — только с флагом подтверждения. Возвращает флаг sensitive. */
  guard(content, confirmed) {
    const s = Sensitive.check(content);
    if (s.level === 'secret') throw new HttpError(422, 'memory_secret', 'Пароли, коды, номера карт и ключи доступа WISP не запоминает. Храни их в менеджере паролей.');
    if (s.level === 'sensitive' && !confirmed) throw new HttpError(409, 'memory_sensitive', `Похоже на личные сведения (${s.label}). Сохранить их в память?`, { kinds: s.kinds, label: s.label });
    return s.level === 'sensitive';
  }

  /* ════ Из чата ════
   * mode: explicit — пользователь прямо попросил запомнить (сохраняется сразу, личное — только после подтверждения);
   *       suggest  — WISP заметил полезный факт: создаётся предложение (pending), сохраняется после «да».
   * replacesId — устаревшее воспоминание, которое этот факт заменяет (модель видела его в контексте).
   * → { op: saved | updated | unchanged | needs_consent | suggested | known, memory, label? } */
  fromChat(ctx, { content: raw, category: rawCat, importance: rawImp, replacesId }, mode) {
    const L = this.limits(ctx.plan);
    const content = contentField(raw, L.item_max_chars);
    const category = categoryField(rawCat, content);
    const importance = importanceField(rawImp, 2);
    const s = Sensitive.check(content);
    if (s.level === 'secret') throw new HttpError(422, 'memory_secret', 'Пароли, коды, номера карт и ключи WISP не запоминает, даже если попросить.');
    if (mode === 'suggest' && s.level) throw new HttpError(422, 'memory_sensitive', 'Личные сведения WISP сам не предлагает запоминать.');
    const target = replacesId ? this.repo.get(replacesId, ctx.userId) : null;
    this.write(ctx);
    this.purge(ctx);
    return this.repo.tx(() => {
      if (mode === 'explicit') {
        if (s.level === 'sensitive') {
          // явная просьба, но личное: нужно отдельное «да» — ждёт в карточке, в ответах не используется
          const dupP = this.similar(ctx.userId, content, 'pending');
          const m = dupP ? this.repo.update(dupP.memory.id, ctx.userId, { category, content, importance, pinned: false, sensitive: true })
            : this.repo.insert(ctx.userId, { category, content, importance, sensitive: true, source: 'explicit', status: 'pending', replacesId: target && target.status === 'active' ? target.id : null, conversationId: ctx.conversationId });
          return { op: 'needs_consent', memory: pub(m), label: s.label };
        }
        const cur = target && target.status === 'active' ? target : (this.similar(ctx.userId, content, 'active') || {}).memory;
        if (cur) {
          if (T.normalize(cur.content) === T.normalize(content) && cur.category === category) return { op: 'unchanged', memory: pub(cur) };
          const m = this.repo.update(cur.id, ctx.userId, { category, content, importance: Math.max(importance, cur.importance), pinned: !!cur.pinned, sensitive: !!cur.sensitive });
          return { op: 'updated', memory: pub(m) };
        }
        this.checkCount(ctx, L);
        return { op: 'saved', memory: pub(this.repo.insert(ctx.userId, { category, content, importance, source: 'explicit', status: 'active', conversationId: ctx.conversationId })) };
      }
      // suggest
      if (this.repo.isDismissed(ctx.userId, T.fingerprint(content))) throw new HttpError(409, 'memory_dismissed', 'Пользователь уже отказался это запоминать. Не предлагай снова.');
      if (!target) { const known = this.similar(ctx.userId, content, 'active'); if (known) return { op: 'known', memory: pub(known.memory) }; }
      const dupP = this.similar(ctx.userId, content, 'pending');
      if (dupP) return { op: 'suggested', memory: pub(this.repo.update(dupP.memory.id, ctx.userId, { category, content, importance, pinned: false, sensitive: false })) };
      if (this.repo.count(ctx.userId, 'pending') >= L.pending_max) throw new HttpError(403, 'limit_memory', 'Уже много неразобранных предложений. Сначала пусть пользователь их посмотрит.', { kind: 'pending' });
      if (!target && this.repo.count(ctx.userId, 'active') >= L.items_max) throw this.limitError(ctx, 'items', L.items_max, 'Память заполнена, новое предлагать некуда.');
      const m = this.repo.insert(ctx.userId, { category, content, importance, source: 'suggested', status: 'pending', replacesId: target && target.status === 'active' ? target.id : null, conversationId: ctx.conversationId });
      return { op: 'suggested', memory: pub(m) };
    });
  }
  forget(ctx, id) {
    const cur = this.own(ctx, id);
    this.write(ctx);
    this.repo.remove(cur.id, ctx.userId);
    return { op: 'forgotten', memory: pub(cur) };
  }
  /* Текущее состояние воспоминаний по id (для карточек в истории чата). Чужие и удалённые просто отсутствуют. */
  lookup(userId, ids) {
    const out = new Map();
    for (const id of new Set(ids || [])) { if (typeof id === 'string' && ID_RE.test(id)) { const m = this.repo.get(id, userId); if (m) out.set(id, pub(m)); } }
    return out;
  }

  /* ════ Для ответа модели ════
   * query: [{ text, weight }] — последнее сообщение (и, на Plus, несколько предыдущих).
   * Отбор: воспоминания, связанные с сообщением (общие слова с учётом редкости + общие темы),
   * плюс немного «основных» (закреплённые, очень важные, правила общения) — в пределах лимитов тарифа. */
  recall({ userId, plan, query }) {
    const settings = this.repo.settings(userId);
    if (!settings.enabled) return { enabled: false, suggest: false, items: [], total: this.repo.count(userId, 'active') };
    const L = this.limits(plan);
    const rows = this.repo.list(userId, 'active', L.items_max + 100);
    const base = { enabled: true, suggest: settings.suggest, total: rows.length };
    if (!rows.length) return { ...base, items: [] };

    const qw = new Map();
    const qTopics = new Set();
    for (const { text, weight } of (query || []).slice(0, Math.max(1, L.query_turns))) {
      const a = T.analyze(text);
      for (const s of a.stems) qw.set(s, Math.max(qw.get(s) || 0, weight));
      for (const t of a.topics) qTopics.add(t);
    }
    const df = new Map();
    const an = rows.map((m) => { const a = this.analyzed(m); for (const s of a.stems) df.set(s, (df.get(s) || 0) + 1); return a; });
    const N = rows.length;
    const idf = (s) => Math.log(1 + (N + 1) / (df.get(s) || 1));
    const match = (s, q) => s === q || (Math.min(s.length, q.length) >= 5 && (s.startsWith(q) || q.startsWith(s)));

    const scored = rows.map((m, i) => {
      const a = an[i];
      let lex = 0;
      for (const s of a.stems) { let w = 0; for (const [q, qwt] of qw) if (match(s, q)) w = Math.max(w, qwt); lex += w * idf(s); }
      const topic = a.topics.filter((t) => qTopics.has(t)).length;
      const always = a.topics.some((t) => T.ALWAYS_TOPICS.has(t));
      const core = !!m.pinned || m.importance === 3 || always;
      const age = (Date.now() - m.updated_at) / DAY;
      const score = lex + topic * 0.7 + (m.pinned ? 0.4 : 0) + (m.importance - 2) * 0.25 + Math.max(0, 0.2 - age / 365);
      return { m, lex, topic, core, score };
    });
    const picked = [];
    const take = (x, why) => { if (!picked.some((p) => p.m.id === x.m.id)) picked.push({ ...x, why }); };
    scored.filter((x) => x.lex > 0 || x.topic > 0).sort((a, b) => b.score - a.score).slice(0, L.context_items).forEach((x) => take(x, 'relevant'));
    scored.filter((x) => x.core).sort((a, b) => (b.m.pinned - a.m.pinned) || (b.m.importance - a.m.importance) || (b.m.updated_at - a.m.updated_at)).slice(0, L.context_core).forEach((x) => take(x, 'core'));
    let chars = 0;
    const items = [];
    for (const x of picked) {
      if (items.length >= L.context_items + L.context_core) break;
      if (chars + x.m.content.length > L.context_chars && items.length) continue;
      chars += x.m.content.length;
      items.push({ ...pub(x.m), why: x.why });
    }
    items.sort((a, b) => b.updated_at - a.updated_at);        // новые выше: при противоречии модель видит свежее первым
    // короткая стабильная ссылка вместо id: одна и та же между сообщениями, действует только в этом запросе
    const seen = new Set();
    items.forEach((it) => { let n = 4, r; do { r = `m${it.id.replace(/-/g, '').slice(0, n)}`; n += 2; } while (seen.has(r)); seen.add(r); it.ref = r; });
    if (items.length) { try { this.repo.markUsed(userId, items.map((i) => i.id)); } catch (e) { /* не критично */ } }
    return { ...base, items };
  }
}

module.exports = { MemoryService, DEFAULT_LIMITS, pub, CATEGORIES };
