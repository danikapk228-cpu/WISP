/* WISP · Server · Memory · Repository
 * Весь SQL долговременной памяти. В КАЖДОМ запросе есть user_id: чужое воспоминание для пользователя
 * «не существует» (404), даже если известен его id. */
'use strict';
const crypto = require('node:crypto');

const COLS = 'id, user_id, category, content, importance, pinned, sensitive, source, status, replaces_id, conversation_id, created_at, updated_at, last_used_at';

class MemoryRepo {
  constructor(store) {
    this.store = store;
    const db = store.db;
    const q = (sql) => db.prepare(sql);
    this.q = {
      list: q(`SELECT ${COLS} FROM memories WHERE user_id = ? AND status = ? ORDER BY pinned DESC, updated_at DESC, created_at DESC LIMIT ?`),
      get: q(`SELECT ${COLS} FROM memories WHERE id = ? AND user_id = ?`),
      count: q('SELECT COUNT(*) AS n FROM memories WHERE user_id = ? AND status = ?'),
      countPinned: q("SELECT COUNT(*) AS n FROM memories WHERE user_id = ? AND status = 'active' AND pinned = 1"),
      byCategory: q("SELECT category, COUNT(*) AS n FROM memories WHERE user_id = ? AND status = 'active' GROUP BY category"),
      insert: q(`INSERT INTO memories (${COLS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`),
      update: q('UPDATE memories SET category = ?, content = ?, importance = ?, pinned = ?, sensitive = ?, updated_at = ? WHERE id = ? AND user_id = ?'),
      activate: q("UPDATE memories SET status = 'active', sensitive = ?, replaces_id = NULL, updated_at = ? WHERE id = ? AND user_id = ? AND status = 'pending'"),
      remove: q('DELETE FROM memories WHERE id = ? AND user_id = ?'),
      clear: q('DELETE FROM memories WHERE user_id = ?'),
      used: q('UPDATE memories SET last_used_at = ? WHERE id = ? AND user_id = ?'),
      purgePending: q("DELETE FROM memories WHERE user_id = ? AND status = 'pending' AND updated_at < ?"),
      dismissAdd: q('INSERT INTO memory_dismissed (user_id, fingerprint, created_at) VALUES (?, ?, ?) ON CONFLICT(user_id, fingerprint) DO NOTHING'),
      dismissHas: q('SELECT 1 AS x FROM memory_dismissed WHERE user_id = ? AND fingerprint = ?'),
      dismissClear: q('DELETE FROM memory_dismissed WHERE user_id = ?'),
      settings: q('SELECT memory_enabled, memory_suggest FROM users WHERE id = ?'),
      setEnabled: q('UPDATE users SET memory_enabled = ? WHERE id = ?'),
      setSuggest: q('UPDATE users SET memory_suggest = ? WHERE id = ?'),
    };
  }

  tx(fn) { return this.store.transaction(fn); }

  list(userId, status, limit) { return this.q.list.all(userId, status || 'active', limit || 5000); }
  get(id, userId) { return this.q.get.get(id, userId) || null; }
  count(userId, status) { return this.q.count.get(userId, status || 'active').n; }
  countPinned(userId) { return this.q.countPinned.get(userId).n; }
  byCategory(userId) { return Object.fromEntries(this.q.byCategory.all(userId).map((r) => [r.category, r.n])); }

  insert(userId, m) {
    const id = crypto.randomUUID(), t = Date.now();
    this.q.insert.run(id, userId, m.category, m.content, m.importance || 2, m.pinned ? 1 : 0, m.sensitive ? 1 : 0, m.source, m.status || 'active', m.replacesId || null, m.conversationId || null, t, t);
    return this.get(id, userId);
  }
  update(id, userId, m) {
    this.q.update.run(m.category, m.content, m.importance, m.pinned ? 1 : 0, m.sensitive ? 1 : 0, Date.now(), id, userId);
    return this.get(id, userId);
  }
  activate(id, userId, sensitive) { return this.q.activate.run(sensitive ? 1 : 0, Date.now(), id, userId).changes > 0; }
  remove(id, userId) { return this.q.remove.run(id, userId).changes > 0; }
  clear(userId) { return this.tx(() => { const n = this.q.clear.run(userId).changes; this.q.dismissClear.run(userId); return n; }); }
  markUsed(userId, ids) { const t = Date.now(); for (const id of ids) this.q.used.run(t, id, userId); }
  purgePending(userId, olderThan) { return this.q.purgePending.run(userId, olderThan).changes; }

  dismiss(userId, fp) { if (fp) this.q.dismissAdd.run(userId, fp, Date.now()); }
  isDismissed(userId, fp) { return !!(fp && this.q.dismissHas.get(userId, fp)); }

  settings(userId) {
    const r = this.q.settings.get(userId);
    return { enabled: !r || r.memory_enabled !== 0, suggest: !r || r.memory_suggest !== 0 };
  }
  setEnabled(userId, v) { this.q.setEnabled.run(v ? 1 : 0, userId); }
  setSuggest(userId, v) { this.q.setSuggest.run(v ? 1 : 0, userId); }
}

module.exports = { MemoryRepo };
