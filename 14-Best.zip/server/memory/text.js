/* WISP · Server · Memory · Text analysis
 * Без зависимостей и без внешних API: токенизация, стемминг (русский Snowball + лёгкий английский),
 * стоп-слова и небольшие «тематические кластеры». Используется для:
 *  · поиска по памяти («игры» находит «игру»);
 *  · поиска похожих воспоминаний (обновить запись вместо дубликата);
 *  · выбора релевантных воспоминаний для ответа (не вся память в каждый запрос).
 * Кластеры дают «семантику-лайт»: вопрос «как реализовать инвентарь?» и факт «разрабатывает игру
 * на JavaScript» не делят ни одного слова, но оба попадают в темы «игры» и «программирование». */
'use strict';

/* ── Русский стеммер (Snowball / Porter для русского языка) ── */
const RU_VOWELS = 'аеиоуыэюя';
const PERFECTIVE_1 = ['вшись', 'вши', 'в'];                 // после а / я
const PERFECTIVE_2 = ['ывшись', 'ившись', 'ывши', 'ивши', 'ив', 'ыв'];
const REFLEXIVE = ['ся', 'сь'];
const ADJECTIVE = ['ими', 'ыми', 'его', 'ого', 'ему', 'ому', 'ее', 'ие', 'ые', 'ое', 'ей', 'ий', 'ый', 'ой', 'ем', 'им', 'ым', 'ом', 'их', 'ых', 'ую', 'юю', 'ая', 'яя', 'ою', 'ею'];
const PARTICIPLE_1 = ['ем', 'нн', 'вш', 'ющ', 'щ'];           // после а / я
const PARTICIPLE_2 = ['ивш', 'ывш', 'ующ'];
const VERB_1 = ['ла', 'на', 'ете', 'йте', 'ли', 'й', 'л', 'ем', 'н', 'ло', 'но', 'ет', 'ют', 'ны', 'ть', 'ешь', 'нно'];   // после а / я
const VERB_2 = ['ила', 'ыла', 'ена', 'ейте', 'уйте', 'ите', 'или', 'ыли', 'ей', 'уй', 'ил', 'ыл', 'им', 'ым', 'ен', 'ило', 'ыло', 'ено', 'ят', 'ует', 'уют', 'ит', 'ыт', 'ены', 'ить', 'ыть', 'ишь', 'ую', 'ю'];
const NOUN = ['иями', 'ями', 'ами', 'ией', 'иям', 'ием', 'иях', 'ев', 'ов', 'ие', 'ье', 'еи', 'ии', 'ей', 'ой', 'ий', 'ям', 'ем', 'ам', 'ом', 'ах', 'ях', 'ию', 'ью', 'ия', 'ья', 'а', 'е', 'и', 'й', 'о', 'у', 'ы', 'ь', 'ю', 'я'];
const SUPERLATIVE = ['ейше', 'ейш'];
const DERIVATIONAL = ['ость', 'ост'];
const byLen = (a) => [...a].sort((x, y) => y.length - x.length);
const S = { pf1: byLen(PERFECTIVE_1), pf2: byLen(PERFECTIVE_2), rf: byLen(REFLEXIVE), adj: byLen(ADJECTIVE), pt1: byLen(PARTICIPLE_1), pt2: byLen(PARTICIPLE_2), v1: byLen(VERB_1), v2: byLen(VERB_2), n: byLen(NOUN), sup: byLen(SUPERLATIVE), der: byLen(DERIVATIONAL) };

function regions(w) {
  let rv = w.length, r1 = w.length, r2 = w.length;
  for (let i = 0; i < w.length; i++) if (RU_VOWELS.includes(w[i])) { rv = i + 1; break; }
  for (let i = 1; i < w.length; i++) if (!RU_VOWELS.includes(w[i]) && RU_VOWELS.includes(w[i - 1])) { r1 = i + 1; break; }
  for (let i = r1 + 1; i < w.length; i++) if (!RU_VOWELS.includes(w[i]) && RU_VOWELS.includes(w[i - 1])) { r2 = i + 1; break; }
  return { rv, r2 };
}
/* Срезать самое длинное окончание из списка внутри области start; group1 = нужна «а»/«я» перед окончанием */
function cut(w, start, list, group1) {
  for (const s of list) {
    if (!w.endsWith(s) || w.length - s.length < start) continue;
    if (group1) { const p = w[w.length - s.length - 1]; if (p !== 'а' && p !== 'я') continue; }
    return w.slice(0, w.length - s.length);
  }
  return null;
}
function stemRu(word) {
  let w = word.replace(/ё/g, 'е');
  const { rv, r2 } = regions(w);
  if (rv >= w.length) return w;
  // шаг 1
  let x = cut(w, rv, S.pf2) || cut(w, rv, S.pf1, true);
  if (x !== null) w = x;
  else {
    x = cut(w, rv, S.rf); if (x !== null) w = x;
    let y = cut(w, rv, S.adj);
    if (y !== null) { const z = cut(y, rv, S.pt2) || cut(y, rv, S.pt1, true); w = z !== null ? z : y; }
    else {
      y = cut(w, rv, S.v2) || cut(w, rv, S.v1, true);
      if (y !== null) w = y;
      else { y = cut(w, rv, S.n); if (y !== null) w = y; }
    }
  }
  // шаг 2
  if (w.endsWith('и') && w.length - 1 >= rv) w = w.slice(0, -1);
  // шаг 3
  x = cut(w, r2, S.der); if (x !== null) w = x;
  // шаг 4
  if (w.endsWith('нн') && w.length - 1 >= rv) w = w.slice(0, -1);
  else {
    x = cut(w, rv, S.sup);
    if (x !== null) { w = x; if (w.endsWith('нн')) w = w.slice(0, -1); }
    else if (w.endsWith('ь') && w.length - 1 >= rv) w = w.slice(0, -1);
  }
  return w;
}

/* ── Английский: короткий стеммер (множественное число, -ing/-ed/-ly/-er) ── */
function stemEn(w) {
  if (w.length <= 3) return w;
  let s = w;
  if (s.endsWith('ies') && s.length > 4) s = s.slice(0, -3) + 'y';
  else if (s.endsWith('sses')) s = s.slice(0, -2);
  else if (s.endsWith('s') && !s.endsWith('ss') && !s.endsWith('us') && !s.endsWith('is')) s = s.slice(0, -1);
  for (const suf of ['ingly', 'edly', 'ing', 'ed', 'ly', 'ment', 'ness']) {
    if (s.endsWith(suf) && s.length - suf.length >= 3) { s = s.slice(0, -suf.length); break; }
  }
  if (/([^aeiou])\1$/.test(s) && !/(ll|ss|zz)$/.test(s)) s = s.slice(0, -1);
  if (s.endsWith('e') && s.length > 4) s = s.slice(0, -1);
  return s;
}

const STOP = new Set((
  'и в во не что он на я с со как а то все она так его но да ты к у же вы за бы по только ее её мне было вот от меня еще ещё нет о из ему теперь когда даже ну вдруг ли если уже или ни быть был него до вас нибудь опять уж вам ведь там потом себя ничего ей может они тут где есть надо ней для мы тебя их чем была сам чтоб без будто чего раз тоже себе под будет ж тогда кто этот того потому этого какой совсем ним здесь этом один почти мой моя мое моё мои тем чтобы нее неё сейчас были куда зачем всех никогда можно при наконец два об другой хоть после над больше тот через эти нас про всего них какая много разве три эту впрочем хорошо свою этой перед иногда лучше чуть том нельзя такой им более всегда конечно всю между это эта эти твой твоя твои свой своя свои меня мной мою моего моей моему наш наша наши ваш ваша очень просто пожалуйста запомни запомните запомнить запиши помни имей виду будущее пусть что-то который которая которые которых которой' +
  ' the a an and or but if then of to in on at by for with from as is are was were be been being am it its this that these those i me my mine you your yours he she they them their we us our do does did have has had not no so very just please remember that would should could can will about into over than too also'
).split(/\s+/));

const CONTROL = /[\x00-\x08\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;
function normalize(s) {
  return String(s || '').replace(CONTROL, ' ').toLocaleLowerCase('ru').replace(/ё/g, 'е');
}
/* Слова: буквы/цифры, внутри слова допускаются + # . - (c++, c#, node.js, react-native) */
function words(s) {
  return normalize(s).match(/[\p{L}\p{N}][\p{L}\p{N}+#.\-]*[\p{L}\p{N}+#]|[\p{L}\p{N}]/gu) || [];
}
function stem(w) {
  if (/^[а-я]+$/.test(w)) return stemRu(w);
  if (/^[a-z]+$/.test(w)) return stemEn(w);
  return w;
}
/* Набор основ без стоп-слов */
function stems(s) {
  const out = [];
  for (const w of words(s)) {
    if (STOP.has(w) || (w.length < 2 && !/\d/.test(w))) continue;
    const st = stem(w);
    if (st && !out.includes(st)) out.push(st);
  }
  return out;
}

/* ── Темы: префиксы основ. Короткий, проверяемый словарь, а не «магия». ── */
const TOPICS = {
  programming: ['программ', 'код', 'кодин', 'разработ', 'разрабатыв', 'реализ', 'функци', 'класс', 'объект', 'массив', 'переменн', 'баг', 'отладк', 'алгоритм', 'фреймворк', 'библиотек', 'сервер', 'backend', 'бэкенд', 'фронтенд', 'frontend', 'api', 'javascript', 'js', 'typescript', 'ts', 'python', 'java', 'kotlin', 'swift', 'c++', 'c#', 'go', 'rust', 'php', 'ruby', 'node', 'node.js', 'react', 'vue', 'angular', 'html', 'css', 'sql', 'git', 'code', 'program', 'develop', 'implement', 'function', 'bug', 'debug', 'deploy', 'script', 'скрипт', 'приложен', 'app', 'сайт', 'websit', 'базу', 'баз', 'database'],
  games: ['игр', 'игров', 'геймдев', 'gamedev', 'game', 'gaming', 'инвентар', 'inventory', 'уровн', 'level', 'персонаж', 'character', 'босс', 'boss', 'квест', 'quest', 'игрок', 'player', 'геймплей', 'gameplay', 'unity', 'unreal', 'godot', 'phaser', 'спрайт', 'sprite', 'механик', 'mechanic', 'rpg', 'шутер', 'платформер', 'крафт', 'craft', 'лут', 'loot', 'npc'],
  design: ['дизайн', 'design', 'минимал', 'minimal', 'интерфейс', 'interface', 'ui', 'ux', 'цвет', 'color', 'colour', 'палитр', 'шрифт', 'font', 'typograph', 'типограф', 'макет', 'layout', 'figma', 'иконк', 'icon', 'логотип', 'logo', 'анимац', 'animat', 'стил', 'style', 'визуал', 'visual'],
  writing_style: ['ответ', 'answer', 'repli', 'reply', 'коротк', 'краток', 'кратк', 'short', 'brief', 'concis', 'подробн', 'detail', 'тон', 'tone', 'обращ', 'эмодз', 'emoji', 'формат', 'format', 'markdown', 'язык', 'language', 'по-русск', 'english', 'английск', 'шутк', 'юмор', 'humor', 'объясня', 'explain', 'пример', 'example'],
  work: ['работ', 'work', 'job', 'компани', 'company', 'команд', 'team', 'проект', 'project', 'клиент', 'client', 'заказчик', 'стартап', 'startup', 'бизнес', 'business', 'продукт', 'product', 'дедлайн', 'deadline', 'релиз', 'release', 'запуск', 'launch', 'встреч', 'meeting', 'начальник', 'boss', 'коллег', 'colleag', 'должност', 'менеджер', 'manager', 'офис', 'office'],
  study: ['уч', 'уроk', 'урок', 'lesson', 'школ', 'school', 'университет', 'универ', 'university', 'колледж', 'college', 'экзамен', 'exam', 'егэ', 'огэ', 'сессия', 'курс', 'course', 'диплом', 'thesis', 'домашн', 'homework', 'препода', 'teacher', 'студент', 'student', 'изуча', 'learn', 'study'],
  fitness: ['спорт', 'sport', 'трениров', 'workout', 'train', 'бег', 'бега', 'run', 'зал', 'gym', 'фитнес', 'fitness', 'йог', 'yoga', 'плаван', 'swim', 'футбол', 'football', 'soccer', 'вес', 'weight', 'марафон', 'marathon', 'велосипед', 'bike', 'cycl', 'упражнен', 'exercis'],
  music: ['музык', 'music', 'песн', 'song', 'гитар', 'guitar', 'пиани', 'piano', 'бит', 'beat', 'трек', 'track', 'альбом', 'album', 'групп', 'band', 'концерт', 'concert', 'плейлист', 'playlist', 'звук', 'sound', 'ableton', 'fl studio'],
  food: ['еда', 'ед', 'food', 'рецепт', 'recip', 'готов', 'cook', 'ужин', 'dinner', 'завтрак', 'breakfast', 'обед', 'lunch', 'кухн', 'cuisin', 'вегет', 'vegetar', 'веган', 'vegan', 'кофе', 'coffe', 'чай', 'tea', 'сладк', 'мяс', 'meat', 'рыб', 'fish'],
  travel: ['путешеств', 'travel', 'поездк', 'trip', 'отпуск', 'vacation', 'holiday', 'перелет', 'flight', 'отел', 'hotel', 'виз', 'visa', 'страна', 'стран', 'country', 'город', 'city', 'билет', 'ticket'],
  family: ['мам', 'мать', 'mom', 'mother', 'пап', 'отец', 'dad', 'father', 'брат', 'brother', 'сестр', 'sister', 'сын', 'son', 'доч', 'daughter', 'жен', 'wife', 'муж', 'husband', 'бабушк', 'дедушк', 'grand', 'семь', 'family', 'ребен', 'дет', 'child', 'kid', 'друг', 'подруг', 'friend', 'девушк', 'girlfriend', 'парен', 'boyfriend', 'партнер', 'partner', 'кот', 'кошк', 'cat', 'собак', 'dog', 'питом', 'pet'],
  money: ['деньг', 'money', 'бюджет', 'budget', 'покупк', 'purchas', 'купит', 'buy', 'цен', 'price', 'стоим', 'cost', 'эконом', 'save', 'инвест', 'invest'],
  creativity: ['рис', 'draw', 'paint', 'картин', 'art', 'искусств', 'фото', 'photo', 'видео', 'video', 'монтаж', 'edit', 'писат', 'writ', 'книг', 'book', 'роман', 'novel', 'стих', 'poem', 'блог', 'blog', 'канал', 'channel', 'контент', 'content'],
};
/* Темы, которые относятся к любому ответу (как отвечать): такие воспоминания идут в «основной» контекст */
const ALWAYS_TOPICS = new Set(['writing_style']);
const TOPIC_LIST = Object.entries(TOPICS).map(([id, list]) => [id, list.map((p) => normalize(p))]);

function topicsOf(stemList) {
  const out = new Set();
  for (const st of stemList) {
    for (const [id, prefixes] of TOPIC_LIST) {
      if (out.has(id)) continue;
      for (const p of prefixes) {
        // короткие префиксы (≤2) — только точное совпадение, иначе «уч» поймает «учёт», а «го» — что угодно
        if (p.length <= 2 ? st === p : st.startsWith(p) || (st.length >= 4 && p.startsWith(st))) { out.add(id); break; }
      }
    }
  }
  return [...out];
}

function analyze(s) {
  const st = stems(s);
  return { stems: st, topics: topicsOf(st) };
}

/* Похожесть двух текстов для поиска дубликатов: 0…1 */
function similarity(a, b) {
  const A = new Set(a.stems || a), B = new Set(b.stems || b);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  const jaccard = inter / (A.size + B.size - inter);
  const overlap = inter / Math.min(A.size, B.size);
  // короткий факт целиком внутри более полного («Проект WISP» ⊂ «Мой проект называется WISP») — тоже дубликат
  return Math.max(jaccard, Math.min(A.size, B.size) >= 2 ? overlap * 0.9 : 0);
}

/* Ключ «отказа»: чтобы не предлагать снова то, что пользователь уже отклонил (хранится только хеш) */
function fingerprint(s) {
  return stems(s).sort().join(' ');
}

module.exports = { stemRu, stemEn, stem, stems, words, normalize, analyze, topicsOf, similarity, fingerprint, ALWAYS_TOPICS, TOPICS };
