/* WISP · Server · Memory · Sensitive data guard
 * Сервер сам решает, что попадёт в долговременную память, и не доверяет в этом ни модели, ни клиенту.
 *  · secret    — пароли, коды, номера карт, ключи доступа: не сохраняются никогда, даже по просьбе;
 *  · sensitive — здоровье, финансы, документы и контакты, убеждения, интимное, правовые вопросы:
 *                только с отдельным явным подтверждением пользователя (флаг confirm_sensitive);
 *                WISP сам такое не предлагает.
 * Проверка намеренно осторожная: лучше лишний раз спросить, чем молча запомнить лишнее. */
'use strict';
const { normalize } = require('./text');

/* \b в JS не понимает кириллицу: заменяем его на «не буква/цифра» по обе стороны (флаг u) */
const U = (re) => new RegExp(re.source.replace(/\\b/g, '(?:(?<![\\p{L}\\p{N}])|(?![\\p{L}\\p{N}]))'), 'iu');

const SECRET = [
  /парол[ья]|\bpassword|\bpasscode|\bпин[- ]?код|\bпин\b|\bpin[- ]?code|\bpin\b|\bcvv|\bcvc|код из смс|код подтверждения|one[- ]time (?:code|password)|\botp\b|seed[- ]?phrase|сид[- ]?фраз|мнемоническ|секретн(?:ый|ое|ая) (?:ключ|слово|вопрос)|api[- _]?key|апи[- ]?ключ|access[- _]?token|токен доступа|private key|приватный ключ/i,
  /\bsk-[a-z0-9_-]{16,}|\bakia[0-9a-z]{16}\b|\bghp_[a-z0-9]{20,}|\bxox[bpa]-[a-z0-9-]{10,}|\beyj[a-z0-9_-]{10,}\.[a-z0-9_-]{10,}/i,
].map(U);
const SENSITIVE = {
  health: /диагноз|болезн|болею|\bболен\b|заболеван|лекарств|таблетк|препарат|депресс|тревожн(?:ое|ость|ые)? расстройств|расстройств[оа] (?:пищев|личност|сна)|\bпсихиатр|психотерапевт|антидепрессант|беремен|\bвич\b|\bспид\b|онколог|\bрак\b|диабет|инвалидн|аллерги|астм|эпилепс|\bсдвг\b|\badhd\b|аутиз|лечусь|лечени[ея]|diagnos|disease|illness|medicat|depress|anxiety disorder|therap(?:y|ist)|pregnan|\bhiv\b|cancer|diabet|allerg|disabilit|psychiatr/i,
  finance: /зарплат|оклад|доход|\bдолг|долги|кредит|ипотек|задолженност|займ|банкрот|сбережен|счет в банке|счёт в банке|\bсчет\b|\biban\b|salary|income|\bdebt|\bloan|mortgage|bank account|savings/i,
  documents: /паспорт|снилс|\bинн\b|водительск(?:ое|ие) (?:удостоверен|права)|номер (?:телефона|паспорта|карты|счета|счёта|полиса)|мой телефон|my phone|phone number|passport|social security|\bssn\b|по адресу|мой адрес|живу на улиц|проживаю|home address|my address|lives at/i,
  beliefs: /религи|верующ|атеист|молюсь|ориентаци|\bгей\b|лесби|бисексуал|трансгендер|политическ|голосую|голосовал|партии|religio|sexual orientation|\bgay\b|lesbian|bisexual|transgender|political|i vote/i,
  intimate: /\bсекс|интим|sexual|\bsex\b/i,
  legal: /судимост|уголовн|арестов|под следствием|criminal record|arrested|convicted/i,
};
for (const k of Object.keys(SENSITIVE)) SENSITIVE[k] = U(SENSITIVE[k]);
const LABELS = { health: 'здоровье', finance: 'финансы', documents: 'документы и контакты', beliefs: 'убеждения и личная жизнь', intimate: 'интимное', legal: 'правовые вопросы', secret: 'пароли, коды и ключи' };

/* Номер карты: 13–19 цифр (с пробелами/дефисами), проходит алгоритм Луна */
function hasCardNumber(s) {
  const m = String(s).match(/(?:\d[ -]?){13,19}/g) || [];
  return m.some((raw) => {
    const d = raw.replace(/\D/g, '');
    if (d.length < 13 || d.length > 19) return false;
    let sum = 0, alt = false;
    for (let i = d.length - 1; i >= 0; i--) { let n = +d[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; }
    return sum % 10 === 0;
  });
}
const PHONE = /(?:\+?\d[\s()-]?){10,14}\d/;
const EMAIL = /[^\s@]+@[^\s@]+\.[a-z]{2,}/i;

/* → { level: 'secret' | 'sensitive' | null, kinds: [...], label } */
function check(text) {
  const s = normalize(text);
  if (SECRET.some((re) => re.test(s)) || hasCardNumber(s)) return { level: 'secret', kinds: ['secret'], label: LABELS.secret };
  const kinds = Object.keys(SENSITIVE).filter((k) => SENSITIVE[k].test(s));
  if (PHONE.test(s) || EMAIL.test(s)) { if (!kinds.includes('documents')) kinds.push('documents'); }
  if (!kinds.length) return { level: null, kinds: [], label: '' };
  return { level: 'sensitive', kinds, label: kinds.map((k) => LABELS[k]).join(', ') };
}

module.exports = { check, LABELS };
