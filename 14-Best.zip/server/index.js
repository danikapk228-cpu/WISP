#!/usr/bin/env node
/* WISP · Server · Entry
 * Запуск: npm start  (или node server/index.js). Настройки: файл .env в корне проекта, см. .env.example. */
'use strict';
const config = require('./config').load();
const { createApp } = require('./app');

const app = createApp(config);
const { log, ai } = app;

app.server.listen(config.port, config.host, () => {
  log.info(`WISP слушает http://${config.host === '0.0.0.0' ? 'localhost' : config.host}:${config.port}`);
  const models = ai.listFor('plus');
  const on = models.filter((m) => m.available).map((m) => m.id);
  if (on.length) log.info('AI подключён', { models: on.join(',') });
  else log.warn('Ни одна модель не подключена: добавь ключ провайдера в .env (см. .env.example). Чат честно покажет, что AI недоступен.');
});

const stop = (sig) => { log.info(`остановка (${sig})`); app.close().then(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
process.on('SIGINT', () => stop('SIGINT'));
process.on('SIGTERM', () => stop('SIGTERM'));
