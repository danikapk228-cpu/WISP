/* WISP · Server · Application
 * Собирает сервер: конфиг → база → сессии → лимиты → AI service → инструменты (Layer 4) → память (Layer 5)
 * → профиль и настройки (Layer 6) → голос: распознавание и синтез речи (Layer 7) → действия AI (Layer 8)
 * → аккаунты: регистрация, почта, вход, пароли (Layer 9) → тарифы, коды доступа, лимиты (Layer 10) → маршруты.
 * Один процесс отдаёт и фронтенд (index.html + src/), и API: cookie сессии работает только на своём origin. */
'use strict';
const http = require('node:http');
const path = require('node:path');
const { Router, HttpError, sendError, sendJSON, serveStatic, securityHeaders, clientIp } = require('./lib/http');
const db = require('./lib/db');
const { Auth } = require('./lib/auth');
const { Limits } = require('./lib/limits');
const { AIService } = require('./ai/service');
const { PromptStore } = require('./ai/prompt');
const { createLogger } = require('./lib/log');
const chat = require('./routes/chat');
const toolsRoutes = require('./routes/tools');
const memoryRoutes = require('./routes/memory');
const accountRoutes = require('./routes/account');
const voiceRoutes = require('./routes/voice');
const { VoiceService } = require('./voice/service');
const { MemoryService } = require('./memory/service');
const { MemoryToolkit } = require('./memory/ai');
const { ToolsService } = require('./tools/service');
const { AIToolkit } = require('./tools/ai');
const { ActionEngine } = require('./actions/engine');
const actionsRoutes = require('./routes/actions');
const authRoutes = require('./routes/auth');
const { Mailer } = require('./auth/mailer');
const { AccountService } = require('./auth/service');
const { SubscriptionService } = require('./subscription/service');
const { Quota } = require('./subscription/quota');
const { createBilling } = require('./subscription/billing');
const subscriptionRoutes = require('./routes/subscription');

function createApp(config, opts) {
  const o = opts || {};
  const log = o.log || createLogger(config.logLevel);
  const store = o.store || db.open(o.dbFile || path.join(config.dataDir, 'wisp.db'));
  const auth = new Auth({ store, config });
  const limits = new Limits({ store, config });
  const ai = new AIService(config);
  const prompts = new PromptStore(config.promptsDir);
  const tools = new ToolsService({ store, config, limits });
  /* Layer 5: долговременная память. memoryService — данные и правила; memory — то, что чат спрашивает
   * перед ответом (recall). o.memory позволяет подменить источник в тестах (например, сломанный). */
  const memoryService = new MemoryService({ store, config, limits, log });
  const memory = o.memory || memoryService;
  const memoryToolkit = new MemoryToolkit({ memory: memoryService, log });
  /* Layer 8: действия AI — один движок для текста и голоса */
  const toolkit = new AIToolkit({ tools, log, memory: memoryService, store });
  const engine = new ActionEngine({ store, tools, toolkit, memoryToolkit, memoryService, config, log });
  /* Layer 7: голос. Ключ провайдера речи — только в config.voice (сервер) */
  const voice = new VoiceService({ config, store, log });
  /* Layer 9: аккаунты. Письма — только через настроенный транспорт (o.mailer — подмена в тестах) */
  const mailer = o.mailer || new Mailer({ config, log });
  if (!mailer.configured) log.warn(`Письма не настроены (${mailer.reason}): регистрация и восстановление пароля недоступны, вход в существующие аккаунты работает.`);
  const accounts = new AccountService({ store, config, mailer, log, memoryService });
  /* Layer 10: тариф = периоды Plus в базе; коды доступа; сводка лимитов; заготовка под оплату */
  const subscription = new SubscriptionService({ store, config, log });
  const quota = new Quota({ store, config, limits, voice, engine, memoryService, tools });
  const billing = createBilling(config);
  if (o.subscriptionSweep !== false) subscription.start(o.subscriptionSweepMs || 60 * 1000);
  const router = new Router();

  router.add('GET', '/api/health', async (c) => sendJSON(c.res, 200, { ok: true, ai_connected: ai.anyAvailable(), voice: { stt: voice.sttAvailable, tts: voice.ttsAvailable } }));
  const chatApi = chat.register(router, { store, auth, limits, ai, prompts, memory, memoryService, memoryToolkit, log, config, tools, toolkit, engine, subscription, quota });
  actionsRoutes.register(router, { auth, engine, generating: chatApi.generating, limits });
  toolsRoutes.register(router, { store, auth, limits, tools, log });
  memoryRoutes.register(router, { auth, memory: memoryService });
  accountRoutes.register(router, { store, auth, limits, config, ai, log, tools, memory: memoryService });
  authRoutes.register(router, { store, auth, accounts, limits, log, sessionPayload: chatApi.sessionPayload });
  voiceRoutes.register(router, { auth, voice, store });
  subscriptionRoutes.register(router, { auth, subscription, quota, ai, voice, billing });

  const server = http.createServer(async (req, res) => {
    let url;
    try { url = new URL(req.url, 'http://local'); } catch (e) { res.writeHead(400); res.end(); return; }
    const pathname = url.pathname;

    if (!pathname.startsWith('/api/')) {
      if ((req.method === 'GET' || req.method === 'HEAD') && serveStatic(req, res, config.root, pathname)) return;
      securityHeaders(res);
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }

    securityHeaders(res);
    const ip = clientIp(req, config.trustProxy);
    try {
      const m = router.match(req.method, pathname);
      if (!m) throw new HttpError(404, 'not_found', 'Неизвестный адрес API.');
      if (m.methodNotAllowed) throw new HttpError(405, 'method_not_allowed', 'Метод не поддерживается.');
      if (req.method !== 'GET' && req.method !== 'HEAD') auth.checkOrigin(req);
      await m.handler({ req, res, url, params: m.params, ip });
    } catch (e) {
      if (!e.status) log.error('request failed', { path: pathname, error: e && e.message });
      sendError(res, e);
    }
  });
  server.requestTimeout = 120000;

  const purge = setInterval(() => { try { store.purgeSessions(); accounts.purge(); } catch (e) { /* база закрыта */ } }, 6 * 60 * 60 * 1000);
  purge.unref();

  function close() {
    return new Promise((resolve) => {
      clearInterval(purge);
      limits.stop();
      voice.stop();
      engine.stop();
      subscription.stop();
      server.close(() => { if (!o.store) store.close(); resolve(); });
      server.closeAllConnections && server.closeAllConnections();
    });
  }

  return { server, store, ai, limits, tools, memory: memoryService, voice, engine, accounts, mailer, auth, subscription, quota, close, log };
}

module.exports = { createApp };
