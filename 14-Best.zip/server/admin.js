#!/usr/bin/env node
/* WISP · Server · Admin CLI
 * Администрирование — только здесь, на сервере (нужен доступ к машине и к data/wisp.db). Публичной админ-панели
 * и HTTP-маршрутов администрирования нет намеренно: «роль администратора» = доступ к серверу.
 * Оплаты в проекте пока нет: Plus выдаётся кодами доступа или вручную.
 *
 * Пользователи и тариф
 *   users [N]                                    последние пользователи (id, действующий тариф, почта)
 *   sub <userId|email>                           тариф, срок, периоды Plus, активации кодов
 *   grant <userId|email> --days N | --lifetime   выдать Plus (дни добавляются к концу текущего Plus)
 *   revoke <userId|email> [--reason текст]       отозвать Plus (данные пользователя не трогаются)
 *   plan <userId> plus|free                      как раньше: plus = бессрочно, free = отозвать всё
 *
 * Коды доступа (открытый код показывается ОДИН раз — при создании; в базе только HMAC)
 *   campaign create --name "Early access" --type plus_7|plus_30|plus_90|founder
 *                   [--count 100] [--uses 1] [--label PLUS|EARLY] [--groups 3] [--expires 2026-12-31]
 *                   [--bind <userId|email>] [--note "…"] [--out codes.csv]
 *   campaign list | campaign show <id> | campaign disable <id> [--reason …] | campaign enable <id>
 *   codes add <campaignId> [--count N] [--uses N] [--bind <userId|email>] [--expires дата] [--out файл]
 *   code disable <codeId> | code enable <codeId> | code find <WISP-…>
 *   redemptions [--campaign id] [--user id|email] [--limit N]
 *   audit [--action 'access_code.*'] [--user id] [--limit N]
 *   sweep                                       отметить закончившиеся периоды (сервер делает это сам раз в минуту)
 *   costs                                       оценка стоимости тарифов по server/config/costs.json */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const config = require('./config').load();
const db = require('./lib/db');
const { SubscriptionService, KINDS } = require('./subscription/service');
const Costs = require('./subscription/costs');

const argv = process.argv.slice(2);
const store = db.open(path.join(config.dataDir, 'wisp.db'));
const log = { info() {}, warn: (m) => console.error('! ' + m), error: (m) => console.error('! ' + m) };
const sub = new SubscriptionService({ store, config, log });
const ACTOR = 'admin:cli';
const fmt = (t) => (t ? new Date(t).toISOString().replace('T', ' ').slice(0, 16) + ' UTC' : '—');

/* --key value / --flag; позиционные аргументы отдельно */
function parse(list) {
  const pos = [], opt = {};
  for (let i = 0; i < list.length; i++) {
    const a = list[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const v = list[i + 1];
      if (v === undefined || v.startsWith('--')) opt[k] = true; else { opt[k] = v; i++; }
    } else pos.push(a);
  }
  return { pos, opt };
}
function date(v) {
  if (v === undefined || v === true) return null;
  const s = String(v);
  const t = /^\d{4}-\d{2}-\d{2}$/.test(s) ? Date.parse(s + 'T23:59:59Z') : Date.parse(s);
  if (!Number.isFinite(t)) throw new Error(`Не понял дату: ${s} (формат 2026-12-31)`);
  return t;
}
function int(v, name) {
  if (v === undefined) return undefined;
  const n = Number(v);
  if (!Number.isInteger(n)) throw new Error(`--${name}: нужно целое число`);
  return n;
}
function user(ref) {
  if (!ref) throw new Error('Укажи пользователя: id или email.');
  const u = String(ref).includes('@') ? store.getUserByEmail(String(ref).trim().toLowerCase()) : store.getUser(String(ref));
  if (!u) throw new Error('Пользователь не найден.');
  return u;
}
function printCodes(res, out) {
  const { campaign, codes } = res;
  console.log(`Кампания ${campaign.id} · ${campaign.name} · ${KINDS[campaign.kind].title} · активаций на код: ${campaign.uses_per_code}${campaign.redeem_until ? ' · коды до ' + fmt(campaign.redeem_until) : ''}`);
  if (!codes.length) return;
  if (out) {
    const file = path.resolve(String(out));
    const csv = 'code_id,code\n' + codes.map((c) => `${c.id},${c.code}`).join('\n') + '\n';
    fs.writeFileSync(file, csv, { mode: 0o600, flag: 'wx' });
    console.log(`Коды (${codes.length}) записаны в ${file} (права 600). Больше их нигде нет: в базе только HMAC.`);
  } else {
    console.log(`Коды (${codes.length}). Сохрани их сейчас: повторно показать нельзя.`);
    for (const c of codes) console.log(`  ${c.code}   ${c.id}`);
  }
}
function state(u) {
  const st = sub.state(u.id);
  return st.plan === 'plus' ? (st.lifetime ? 'Plus · бессрочно' : `Plus до ${fmt(st.expires_at)}`) : 'Free';
}

const HELP = ((lines) => lines.slice(lines.findIndex((l) => l.includes('Пользователи и тариф'))).map((l) => l.slice(3)).join('\n'))(
  fs.readFileSync(__filename, 'utf8').split('\n').filter((l) => l.startsWith(' * ') || l === ' *'));

try {
  const [cmd, sub1, ...rest] = argv;
  const { pos, opt } = parse(argv.slice(1));
  switch (cmd) {
    case 'users': {
      const rows = store.listUsers(Number(pos[0]) || 50);
      if (!rows.length) console.log('Пользователей пока нет.');
      for (const r of rows) console.log(`${r.id}  ${r.plan.padEnd(4)}  ${(r.email || 'гость').padEnd(30)}  диалогов: ${String(r.conversations).padStart(3)}  был: ${fmt(r.last_seen_at)}`);
      break;
    }
    case 'plan': {
      const [id, plan] = pos;
      if (!id || !['free', 'plus'].includes(plan)) throw new Error('Использование: plan <userId> free|plus');
      const u = user(id);
      store.setPlan(u.id, plan, ACTOR);
      console.log(`Готово: ${u.id} → ${state(u)}. Сервер применяет тариф к следующему же запросу.`);
      break;
    }
    case 'sub': {
      const u = user(pos[0]);
      console.log(`${u.id}  ${u.email || 'гость'}  →  ${state(u)}`);
      for (const e of sub.repo.entitlementsOf(u.id)) console.log(`  период ${e.source.padEnd(11)} ${fmt(e.starts_at)} → ${e.expires_at ? fmt(e.expires_at) : 'бессрочно'}${e.revoked_at ? `  отозван ${fmt(e.revoked_at)} (${e.revoked_reason || ''})` : ''}`);
      for (const r of sub.history(u.id)) console.log(`  код    ${r.title} · ${fmt(r.at)}`);
      break;
    }
    case 'grant': {
      const u = user(pos[0]);
      if (!opt.lifetime && opt.days === undefined) throw new Error('Укажи --days N или --lifetime');
      sub.grant(u.id, { days: opt.lifetime ? undefined : int(opt.days, 'days'), lifetime: !!opt.lifetime, source: 'admin', actor: ACTOR, details: opt.note ? { note: String(opt.note).slice(0, 200) } : null });
      console.log(`Готово: ${u.id} → ${state(u)}`);
      break;
    }
    case 'revoke': {
      const u = user(pos[0]);
      const n = sub.revoke(u.id, { actor: ACTOR, reason: opt.reason ? String(opt.reason).slice(0, 200) : 'admin' });
      console.log(`Отозвано периодов: ${n}. ${u.id} → ${state(u)}. Чаты, память, задачи и заметки не тронуты.`);
      break;
    }
    case 'campaign': {
      const p = parse(rest);
      if (sub1 === 'create') {
        const bind = p.opt.bind ? user(p.opt.bind).id : null;
        const res = sub.createCampaign({
          name: p.opt.name, kind: p.opt.type, label: p.opt.label === true ? null : p.opt.label, groups: int(p.opt.groups, 'groups'),
          count: bind ? 1 : int(p.opt.count, 'count'), usesPerCode: int(p.opt.uses, 'uses'), redeemUntil: date(p.opt.expires),
          note: p.opt.note === true ? null : p.opt.note, bindUserId: bind, actor: ACTOR,
        });
        printCodes(res, p.opt.out);
      } else if (sub1 === 'list') {
        const rows = sub.repo.campaigns(200);
        if (!rows.length) console.log('Кампаний пока нет.');
        for (const c of rows) {
          const st = c.disabled_at ? 'отключена' : c.redeem_until && c.redeem_until <= Date.now() ? 'истекла' : 'активна';
          console.log(`${c.id}  ${st.padEnd(9)}  ${c.kind.padEnd(8)}  кодов: ${c.codes} (свободных ${c.codes_left})  активаций: ${c.redemptions}  ${c.name}`);
        }
      } else if (sub1 === 'show') {
        const info = sub.campaignInfo(p.pos[0]);
        if (!info) throw new Error('Кампания не найдена.');
        const c = info.campaign;
        console.log(`${c.id} · ${c.name} · ${KINDS[c.kind].title}`);
        console.log(`  создана ${fmt(c.created_at)} (${c.created_by}) · коды до ${fmt(c.redeem_until)} · активаций на код ${c.uses_per_code} · вид WISP-${c.label ? c.label + '-' : ''}${Array(c.groups_n).fill('XXXX').join('-')}`);
        if (c.disabled_at) console.log(`  отключена ${fmt(c.disabled_at)}${c.disabled_reason ? ': ' + c.disabled_reason : ''}`);
        if (c.note) console.log(`  заметка: ${c.note}`);
        for (const k of info.codes) console.log(`  ${k.id}  ${k.uses}/${k.max_uses}${k.disabled_at ? '  отключён' : ''}${k.bound_user_id ? '  только для ' + k.bound_user_id : ''}${k.expires_at ? '  до ' + fmt(k.expires_at) : ''}`);
      } else if (sub1 === 'disable' || sub1 === 'enable') {
        const r = sub.setCampaignEnabled(p.pos[0], sub1 === 'enable', { actor: ACTOR, reason: p.opt.reason === true ? null : p.opt.reason });
        console.log(r.changed ? `Кампания ${r.campaign.id} ${sub1 === 'enable' ? 'включена' : 'отключена'}.` : 'Ничего не изменилось.');
      } else throw new Error('campaign create | list | show | disable | enable');
      break;
    }
    case 'codes': {
      if (sub1 !== 'add') throw new Error('codes add <campaignId> [--count N]');
      const p = parse(rest);
      const bind = p.opt.bind ? user(p.opt.bind).id : null;
      const res = sub.addCodes(p.pos[0], { count: bind ? 1 : int(p.opt.count, 'count') || 1, usesPerCode: int(p.opt.uses, 'uses'), bindUserId: bind, expiresAt: date(p.opt.expires), actor: ACTOR });
      printCodes(res, p.opt.out);
      break;
    }
    case 'code': {
      const p = parse(rest);
      if (sub1 === 'disable' || sub1 === 'enable') {
        const r = sub.setCodeEnabled(p.pos[0], sub1 === 'enable', { actor: ACTOR });
        console.log(r.changed ? `Код ${r.code.id} ${sub1 === 'enable' ? 'включён' : 'отключён'}.` : 'Ничего не изменилось.');
      } else if (sub1 === 'find') {
        const r = sub.lookupCode(p.pos.join(' '));
        if (!r) console.log('Такого кода нет.');
        else console.log(`${r.code.id} · кампания ${r.campaign.id} (${r.campaign.name}) · ${r.code.uses}/${r.code.max_uses}${r.code.disabled_at || r.campaign.disabled_at ? ' · отключён' : ''}`);
      } else throw new Error('code disable | enable | find');
      break;
    }
    case 'redemptions': {
      const rows = sub.repo.redemptions({ campaignId: opt.campaign ? (sub.repo.findCampaign(opt.campaign) || {}).id || opt.campaign : null, userId: opt.user ? user(opt.user).id : null, limit: int(opt.limit, 'limit') || 100 });
      if (!rows.length) console.log('Активаций нет.');
      for (const r of rows) console.log(`${fmt(r.created_at)}  ${r.kind.padEnd(8)}  ${(r.user_id || 'удалён').padEnd(36)}  ${(r.email || '').padEnd(28)}  ${r.code_id}  ${r.campaign_name}  → ${r.expires_at ? fmt(r.expires_at) : 'бессрочно'}`);
      break;
    }
    case 'audit': {
      const rows = sub.repo.auditList({ action: opt.action === true ? null : opt.action, who: opt.user ? 'user:' + user(opt.user).id : null, limit: int(opt.limit, 'limit') || 50 });
      for (const r of rows) console.log(`${fmt(r.at)}  ${r.result.padEnd(6)}  ${r.action.padEnd(24)}  ${String(r.actor).padEnd(42)}  ${r.target || ''}  ${r.reason || ''}`);
      break;
    }
    case 'sweep': {
      const r = sub.sweep();
      console.log(`Закончившихся периодов: ${r.periods}. Вернулись на Free: ${r.users.length}.`);
      break;
    }
    case 'costs': console.log(Costs.report(config)); break;
    default: console.log(HELP);
  }
} catch (e) {
  console.error(e.message);
  process.exitCode = 1;
} finally {
  store.close();
}
