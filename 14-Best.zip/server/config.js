/* WISP · Server · Config
 * Единственное место, где сервер читает окружение и конфигурацию.
 * Секреты (API-ключи провайдеров) берутся только из переменных окружения / файла .env на сервере
 * и никогда не уходят клиенту: наружу отдаётся только publicModel() без ключей и адресов. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

/* Мини-загрузчик .env (без зависимостей). Уже заданные переменные окружения не перезаписываются. */
function loadEnvFile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch (e) { return; }
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2].trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    else v = v.replace(/\s+#.*$/, '');
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}

function readJSON(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

const bool = (v, def) => (v === undefined || v === '' ? def : /^(1|true|yes|on)$/i.test(String(v)));
const int = (v, def) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : def; };
/* Layer 6: публичные ссылки «О приложении» — только https, иначе ссылка не показывается */
const httpsUrl = (v) => { try { const u = new URL(String(v || '').trim()); return u.protocol === 'https:' ? u.href : null; } catch (e) { return null; } };
const appVersion = () => { try { return String(readJSON(path.join(ROOT, 'package.json')).version || ''); } catch (e) { return ''; } };

function load(overrides) {
  const o = overrides || {};
  if (!o.skipEnvFile) loadEnvFile(path.join(ROOT, '.env'));
  const src = { ...process.env, ...(o.env || {}) };
  const E = (k) => src[k];

  const modelsFile = E('WISP_MODELS_FILE') ? path.resolve(ROOT, E('WISP_MODELS_FILE')) : path.join(__dirname, 'config', 'models.json');
  const plansFile = E('WISP_PLANS_FILE') ? path.resolve(ROOT, E('WISP_PLANS_FILE')) : path.join(__dirname, 'config', 'plans.json');
  const modelsCfg = readJSON(modelsFile);
  const plans = readJSON(plansFile);

  /* Провайдеры: ключ, адрес и формат auth-заголовка читаются только на сервере из models.json/env */
  const providers = {};
  for (const [id, p] of Object.entries(modelsCfg.providers || {})) {
    const apiKey = p.api_key_env ? (E(p.api_key_env) || '') : '';
    const baseUrl = (p.base_url_env && E(p.base_url_env)) || p.base_url || '';
    const headers = p.headers && typeof p.headers === 'object' ? { ...p.headers } : {};
    if (p.headers_env && typeof p.headers_env === 'object') {
      for (const [header, envName] of Object.entries(p.headers_env)) {
        if (typeof envName === 'string' && E(envName)) headers[header] = E(envName);
      }
    }
    providers[id] = {
      id,
      type: p.type,                                     // 'openai' (Chat Completions и совместимые) | 'anthropic' (Messages API)
      baseUrl: baseUrl.replace(/\/+$/, ''),
      apiKey,
      keyOptional: !!p.key_optional,                    // локальные модели (Ollama, LM Studio) часто без ключа
      maxTokensParam: p.max_tokens_param || 'max_tokens',
      streamUsage: !!p.stream_usage,
      headers,
      apiKeyHeader: typeof p.api_key_header === 'string' && p.api_key_header ? p.api_key_header : 'Authorization',
      apiKeyPrefix: p.api_key_prefix === undefined ? 'Bearer ' : String(p.api_key_prefix),
      apiKeyEnv: p.api_key_env || null,
    };
  }

  const models = (modelsCfg.models || []).map((m) => ({
    id: String(m.id),
    label: String(m.label || m.id),
    description: m.description ? String(m.description) : '',
    provider: String(m.provider),
    model: String(m.model),
    tier: m.tier === 'plus' ? 'plus' : 'free',
    vision: !!m.vision,
    tools: m.tools !== false,                          // Layer 4: умеет вызывать функции (напоминания, задачи…)
    contextTokens: int(m.context_tokens, 16000),
    maxOutputTokens: int(m.max_output_tokens, 1024),
    temperature: typeof m.temperature === 'number' ? m.temperature : null,
  }));

  return {
    root: ROOT,
    port: int(E('PORT'), 8787),
    host: E('HOST') || '127.0.0.1',
    dataDir: path.resolve(ROOT, E('WISP_DATA_DIR') || 'data'),
    trustProxy: bool(E('WISP_TRUST_PROXY'), false),
    cookieSecure: E('WISP_COOKIE_SECURE') === undefined || E('WISP_COOKIE_SECURE') === '' ? 'auto' : bool(E('WISP_COOKIE_SECURE'), false),
    allowedOrigins: (E('WISP_ALLOWED_ORIGINS') || '').split(',').map((s) => s.trim()).filter(Boolean),
    promptsDir: E('WISP_PROMPTS_DIR') ? path.resolve(ROOT, E('WISP_PROMPTS_DIR')) : path.join(__dirname, 'prompts'),
    logLevel: E('WISP_LOG_LEVEL') || 'info',
    upstreamTimeoutMs: int(E('WISP_UPSTREAM_TIMEOUT_MS'), 45000),   // ожидание первого байта от провайдера
    idleTimeoutMs: int(E('WISP_IDLE_TIMEOUT_MS'), 60000),           // пауза между частями потока
    sessionsPerIpPerHour: int(E('WISP_SESSIONS_PER_IP_HOUR'), 20),
    requestsPerIpPerMinute: int(E('WISP_REQUESTS_PER_IP_MINUTE'), 40),
    /* Layer 6 · «О приложении»: не секреты, отдаются клиенту как есть (GET /api/app). Пусто = строка не показывается. */
    app: {
      name: 'WISP',
      version: appVersion(),
      developer: (E('WISP_DEVELOPER') || '').trim().slice(0, 80) || null,
      telegram: httpsUrl(E('WISP_TELEGRAM_URL')),
      website: httpsUrl(E('WISP_WEBSITE_URL')),
      privacy: httpsUrl(E('WISP_PRIVACY_URL')),
      support: (E('WISP_SUPPORT_EMAIL') || '').trim().match(/^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/i) ? E('WISP_SUPPORT_EMAIL').trim() : null,
    },
    providers,
    models,
    defaultModel: modelsCfg.default_model || {},
    plans,
    voice: voiceConfig(E),
    /* Layer 9 · аккаунты и письма */
    production: String(E('NODE_ENV') || '').toLowerCase() === 'production',
    publicUrl: publicUrl(E('WISP_PUBLIC_URL')),
    accounts: {
      guestMode: bool(E('WISP_GUEST_MODE'), true),                              // «Продолжить без аккаунта»
      sessionTtlDays: int(E('WISP_SESSION_TTL_DAYS'), 30),                       // сессия аккаунта без активности
      sessionMaxDays: int(E('WISP_SESSION_MAX_DAYS'), 90),                       // абсолютный срок: потом снова вход
      verifyTtlHours: int(E('WISP_VERIFY_TTL_HOURS'), 24),
      resetTtlMinutes: int(E('WISP_RESET_TTL_MINUTES'), 30),
      unverifiedTtlDays: int(E('WISP_UNVERIFIED_TTL_DAYS'), 7),                  // неподтверждённый аккаунт удаляется
    },
    mail: mailConfig(E),
    /* Layer 10 · тарифы и коды доступа. Секрет кодов — только на сервере, клиенту не отдаётся. */
    subscription: {
      codeSecret: (E('WISP_ACCESS_CODE_SECRET') || '').trim(),
      codesForGuests: bool(E('WISP_ACCESS_CODES_GUESTS'), false),            // по умолчанию коды — только в аккаунте
      warnRatio: ratio(E('WISP_QUOTA_WARN_RATIO'), 0.8),                      // «скоро лимит» с этой доли
      billingProvider: (E('WISP_BILLING_PROVIDER') || '').trim().toLowerCase(),
    },
  };
}

const ratio = (v, def) => { const n = parseFloat(v); return Number.isFinite(n) && n > 0 && n < 1 ? n : def; };

/* Адрес, по которому пользователи открывают WISP: из него строятся ссылки в письмах. Только http(s), без пути-хвоста. */
function publicUrl(v) {
  try {
    const u = new URL(String(v || '').trim());
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    return (u.origin + u.pathname).replace(/\/+$/, '');
  } catch (e) { return null; }
}

function mailConfig(E) {
  const port = int(E('WISP_SMTP_PORT'), 587);
  const secureEnv = E('WISP_SMTP_SECURE');
  return {
    transport: (E('WISP_MAIL_TRANSPORT') || '').trim().toLowerCase() || null,      // smtp | resend | outbox | memory
    from: (E('WISP_MAIL_FROM') || '').trim(),
    timeoutMs: int(E('WISP_MAIL_TIMEOUT_MS'), 20000),
    resendKey: E('WISP_RESEND_API_KEY') || '',
    smtp: {
      host: (E('WISP_SMTP_HOST') || '').trim(),
      port,
      secure: secureEnv === undefined || secureEnv === '' ? port === 465 : bool(secureEnv, false),
      user: E('WISP_SMTP_USER') || '',
      pass: E('WISP_SMTP_PASS') || '',
      requireTLS: bool(E('WISP_SMTP_REQUIRE_TLS'), true),
      rejectUnauthorized: bool(E('WISP_SMTP_TLS_VERIFY'), true),
      ehlo: (E('WISP_SMTP_EHLO') || '').trim() || null,
    },
  };
}

/* Layer 7 · Voice: распознавание и синтез речи через OpenAI-совместимый Audio API (/audio/transcriptions, /audio/speech).
 * Ключ — WISP_VOICE_API_KEY или (по умолчанию) OPENAI_API_KEY. Ключ и адрес остаются на сервере, клиенту уходит только
 * «доступно / недоступно», список голосов и лимиты. WISP_VOICE_DISABLED=1 — выключить голос сервера целиком. */
function voiceConfig(E) {
  const file = E('WISP_VOICE_FILE') ? path.resolve(ROOT, E('WISP_VOICE_FILE')) : path.join(__dirname, 'config', 'voice.json');
  let cfg = {};
  try { cfg = readJSON(file); } catch (e) { cfg = {}; }
  const stt = cfg.stt || {};
  const tts = cfg.tts || {};
  const disabled = bool(E('WISP_VOICE_DISABLED'), false);
  const apiKey = disabled ? '' : (E('WISP_VOICE_API_KEY') || E('OPENAI_API_KEY') || '');
  const baseUrl = (E('WISP_VOICE_BASE_URL') || E('OPENAI_BASE_URL') || 'https://api.openai.com/v1').replace(/\/+$/, '');
  const voices = (Array.isArray(tts.voices) ? tts.voices : [])
    .filter((v) => v && /^[a-z0-9_-]{1,40}$/i.test(String(v.id)))
    .map((v) => ({ id: String(v.id), label: String(v.label || v.id).slice(0, 40), desc: String(v.desc || '').slice(0, 80) }));
  const ttsModel = String(E('WISP_TTS_MODEL') || tts.model || 'gpt-4o-mini-tts');
  const instrEnv = E('WISP_TTS_INSTRUCTIONS');
  return {
    apiKey,
    baseUrl,
    timeoutMs: int(E('WISP_VOICE_TIMEOUT_MS'), 30000),
    stt: {
      enabled: !!apiKey && !bool(E('WISP_STT_DISABLED'), false),
      model: String(E('WISP_STT_MODEL') || stt.model || 'gpt-4o-mini-transcribe'),
      language: (E('WISP_STT_LANGUAGE') || '').trim().slice(0, 8) || null,      // пусто = язык определяет модель
      prompt: String(stt.prompt || '').slice(0, 400),
    },
    tts: {
      enabled: !!apiKey && !bool(E('WISP_TTS_DISABLED'), false) && voices.length > 0,
      model: ttsModel,
      // инструкции о манере речи понимают только gpt-4o-*-tts; для tts-1 их не отправляем
      instructions: instrEnv !== undefined && instrEnv !== '' ? bool(instrEnv, false) : (tts.instructions !== false && /gpt-4o/i.test(ttsModel)),
      format: tts.format === 'wav' || tts.format === 'aac' || tts.format === 'opus' ? tts.format : 'mp3',
      voices,
      defaultVoice: voices.some((v) => v.id === (E('WISP_TTS_DEFAULT_VOICE') || tts.default_voice)) ? (E('WISP_TTS_DEFAULT_VOICE') || tts.default_voice) : (voices[0] ? voices[0].id : null),
    },
    personalityInstructions: cfg.personality_instructions && typeof cfg.personality_instructions === 'object' ? cfg.personality_instructions : {},
  };
}

module.exports = { load, loadEnvFile, ROOT };
