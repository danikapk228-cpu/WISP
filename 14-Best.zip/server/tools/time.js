/* WISP · Server · Tools · Time
 * Даты и часовые пояса без зависимостей (Intl). Все «настенные» дата и время пользователя
 * (2026-11-09 10:00 в Europe/Moscow) переводятся в UTC здесь и только здесь, в том числе при переходе на летнее время. */
'use strict';

const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
const TIME_RE = /^([01]?\d|2[0-3]):([0-5]\d)$/;
const TZ_RE = /^[A-Za-z][A-Za-z0-9_+\-/]{0,63}$/;
const fmtCache = new Map();

function isValidTimeZone(tz) {
  if (typeof tz !== 'string' || !TZ_RE.test(tz)) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch (e) { return false; }
}

/* 'YYYY-MM-DD' → { y, m, d } или null (проверяется настоящий календарь: 2026-02-30 не пройдёт) */
function parseDate(s) {
  const m = DATE_RE.exec(String(s || '').trim());
  if (!m) return null;
  const y = +m[1], mo = +m[2], d = +m[3];
  if (y < 2000 || y > 2100 || mo < 1 || mo > 12 || d < 1) return null;
  const dim = new Date(Date.UTC(y, mo, 0)).getUTCDate();
  if (d > dim) return null;
  return { y, m: mo, d };
}
/* 'H:MM' | 'HH:MM' → 'HH:MM' или null */
function parseTime(s) {
  const m = TIME_RE.exec(String(s || '').trim());
  if (!m) return null;
  return `${m[1].padStart(2, '0')}:${m[2]}`;
}

function formatter(tz) {
  let f = fmtCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short' });
    fmtCache.set(tz, f);
  }
  return f;
}
/* Настенные часы в поясе tz для момента ms */
function zonedParts(ms, tz) {
  const out = {};
  for (const p of formatter(tz).formatToParts(new Date(ms))) out[p.type] = p.value;
  const hour = +out.hour === 24 ? 0 : +out.hour;
  return { y: +out.year, m: +out.month, d: +out.day, hour, minute: +out.minute, second: +out.second, weekday: out.weekday };
}
function offsetAt(ms, tz) {
  const p = zonedParts(ms, tz);
  return Date.UTC(p.y, p.m - 1, p.d, p.hour, p.minute, p.second) - Math.floor(ms / 1000) * 1000;
}

/* Настенные дата+время в поясе tz → UTC ms. Для несуществующего времени (весенний перевод часов)
 * результат сдвигается вперёд на величину перевода, для повторяющегося (осенью) берётся первое. */
function zonedToUtc(date, time, tz) {
  const d = typeof date === 'string' ? parseDate(date) : date;
  const t = parseTime(time);
  if (!d || !t) return null;
  const [hh, mm] = t.split(':').map(Number);
  const guess = Date.UTC(d.y, d.m - 1, d.d, hh, mm);
  const o1 = offsetAt(guess, tz);
  let ts = guess - o1;
  const o2 = offsetAt(ts, tz);
  if (o2 !== o1) {
    const alt = guess - o2;
    ts = offsetAt(alt, tz) === o2 ? Math.min(ts, alt) : Math.max(ts, guess - o2);
  }
  return ts;
}

const pad = (n) => String(n).padStart(2, '0');
function dateKey(p) { return `${p.y}-${pad(p.m)}-${pad(p.d)}`; }
function todayIn(tz, now) { return dateKey(zonedParts(now == null ? Date.now() : now, tz)); }
function addDays(date, n) {
  const d = parseDate(date);
  const t = new Date(Date.UTC(d.y, d.m - 1, d.d + n));
  return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}`;
}
function daysBetween(a, b) {
  const A = parseDate(a), B = parseDate(b);
  return Math.round((Date.UTC(B.y, B.m - 1, B.d) - Date.UTC(A.y, A.m - 1, A.d)) / 86400000);
}
function localDateOf(ms, tz) { return dateKey(zonedParts(ms, tz)); }
function localTimeOf(ms, tz) { const p = zonedParts(ms, tz); return `${pad(p.hour)}:${pad(p.minute)}`; }

const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const WEEKDAYS = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
/* 'YYYY-MM-DD' → «понедельник, 9 ноября» (для текста модели и подтверждений) */
function humanDate(date) {
  const d = parseDate(date);
  if (!d) return String(date);
  const wd = new Date(Date.UTC(d.y, d.m - 1, d.d)).getUTCDay();
  return `${WEEKDAYS[wd]}, ${d.d} ${MONTHS[d.m - 1]}${d.y !== new Date().getUTCFullYear() ? ' ' + d.y : ''}`;
}
/* Сейчас у пользователя: «воскресенье, 8 ноября 2026, 15:57 (Europe/Moscow, UTC+03:00)» */
function nowLine(tz, now) {
  const ms = now == null ? Date.now() : now;
  const p = zonedParts(ms, tz);
  const off = offsetAt(ms, tz) / 60000;
  const sign = off >= 0 ? '+' : '-';
  const abs = Math.abs(off);
  const wd = new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay();
  return `${WEEKDAYS[wd]}, ${p.d} ${MONTHS[p.m - 1]} ${p.y}, ${pad(p.hour)}:${pad(p.minute)} (${tz}, UTC${sign}${pad(Math.floor(abs / 60))}:${pad(abs % 60)})`;
}

module.exports = { isValidTimeZone, parseDate, parseTime, zonedParts, offsetAt, zonedToUtc, todayIn, addDays, daysBetween, localDateOf, localTimeOf, humanDate, nowLine, dateKey };
