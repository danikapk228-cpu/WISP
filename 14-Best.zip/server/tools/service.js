/* WISP · Server · Tools · Service
 * Единственная реализация инструментов Layer 4. Её вызывают и REST API экрана Tools, и AI-чат (tool calls),
 * поэтому правила одни и те же: проверка входных данных, лимиты тарифа, перевод времени в UTC, владелец записи.
 *
 * ctx = { userId, plan, tz, source }  · userId и plan берутся только из серверной сессии, никогда из запроса.
 * Ошибки: HttpError(status, code, message[, extra]) — REST отдаёт их как JSON, AI получает текст ошибки. */
'use strict';
const { HttpError } = require('../lib/http');
const { ToolsRepo } = require('./repo');
const T = require('./time');

const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const CONTROL = /[\x00-\x08\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;
const PRIORITIES = ['low', 'medium', 'high'];
const PAST_GRACE_MS = 60 * 1000;
const MAX_AHEAD_DAYS = 3 * 366;

/* Лимиты по умолчанию; реальные значения задаются в server/config/plans.json → tools */
const DEFAULT_LIMITS = {
  free: { notes_max: 100, note_max_chars: 10000, tasks_max: 200, reminders_active_max: 10, events_per_day_max: 10, planner_days_ahead: 14, writes_per_minute: 60 },
  plus: { notes_max: 5000, note_max_chars: 50000, tasks_max: 5000, reminders_active_max: 500, events_per_day_max: 50, planner_days_ahead: 365, writes_per_minute: 120 },
};

const bad = (field, message) => new HttpError(400, 'bad_input', message, { field });
const notFound = (what) => new HttpError(404, 'not_found', `${what} не найден${what === 'Заметка' || what === 'Задача' ? 'а' : what === 'Событие' || what === 'Напоминание' ? 'о' : ''}.`);

/* Текст: только строка, без управляющих символов, обрезка пробелов, предел длины */
function text(v, field, { max, required, multiline, label }) {
  if (v === undefined || v === null) v = '';
  if (typeof v !== 'string') throw bad(field, `Поле «${label || field}» должно быть текстом.`);
  let s = v.replace(CONTROL, '').replace(/\r\n?/g, '\n');
  s = multiline ? s.replace(/[ \t]+$/gm, '').replace(/^\n+|\s+$/g, '') : s.replace(/\s+/g, ' ').trim();
  if (required && !s) throw bad(field, `Заполни поле «${label || field}».`);
  if (s.length > max) throw bad(field, `Поле «${label || field}» слишком длинное (максимум ${max} символов).`);
  return s;
}
function dateField(v, field, { required, label } = {}) {
  if (v === undefined || v === null || v === '') { if (required) throw bad(field, `Укажи ${label || 'дату'}.`); return null; }
  if (typeof v !== 'string' || !T.parseDate(v)) throw bad(field, 'Дата должна быть в формате ГГГГ-ММ-ДД.');
  return v.trim();
}
function timeField(v, field, { required, label } = {}) {
  if (v === undefined || v === null || v === '') { if (required) throw bad(field, `Укажи ${label || 'время'}.`); return null; }
  const t = typeof v === 'string' ? T.parseTime(v) : null;
  if (!t) throw bad(field, 'Время должно быть в формате ЧЧ:ММ.');
  return t;
}
function boolField(v, field) {
  if (typeof v !== 'boolean') throw bad(field, 'Ожидается true или false.');
  return v;
}
const checkId = (id, what) => { if (typeof id !== 'string' || !ID_RE.test(id)) throw notFound(what); return id; };
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k) && o[k] !== undefined;
const searchKey = (title, content) => `${title}\n${content}`.toLocaleLowerCase('ru');

/* ── Публичный вид записей ── */
const pubNote = (n) => ({ id: n.id, title: n.title, content: n.content, source: n.source, created_at: n.created_at, updated_at: n.updated_at });
const pubTask = (t) => ({ id: t.id, title: t.title, description: t.description, due_date: t.due_date || null, priority: t.priority, done: !!t.done, completed_at: t.completed_at || null, source: t.source, created_at: t.created_at, updated_at: t.updated_at });
const pubReminder = (r) => ({ id: r.id, title: r.title, description: r.description, remind_at: r.remind_at, date: r.local_date, time: r.local_time, timezone: r.tz, done: !!r.done, done_at: r.done_at || null, notified_at: r.notified_at || null, source: r.source, created_at: r.created_at, updated_at: r.updated_at });
const pubEvent = (e) => ({ id: e.id, title: e.title, note: e.note, date: e.date, start_time: e.start_time, end_time: e.end_time || null, source: e.source, created_at: e.created_at, updated_at: e.updated_at });

class ToolsService {
  constructor({ store, config, limits }) {
    this.repo = new ToolsRepo(store);
    this.store = store;
    this.config = config;
    this.rate = limits || null;
  }

  limits(planId) {
    const key = planId === 'plus' ? 'plus' : 'free';
    const p = (this.config.plans && this.config.plans[key]) || {};
    return { ...DEFAULT_LIMITS[key], ...(p.tools || {}) };
  }
  limitError(ctx, kind, limit, message) {
    return new HttpError(403, 'limit_tools', message, { kind, limit, plan: ctx.plan });
  }
  /* Частота изменений: защита от скриптов и зацикленной модели (одно окно для REST и AI) */
  write(ctx) {
    if (!this.rate || this.inBulk) return;
    this.rate.checkToolWrite(ctx.userId, this.limits(ctx.plan).writes_per_minute);
  }
  tz(ctx, raw) {
    if (raw !== undefined && raw !== null && raw !== '') {
      if (!T.isValidTimeZone(raw)) throw bad('timezone', 'Неизвестный часовой пояс.');
      return raw;
    }
    return ctx.tz && T.isValidTimeZone(ctx.tz) ? ctx.tz : 'UTC';
  }

  /* Layer 8: массовое действие после подтверждения — одна проверка частоты и одна транзакция на всё */
  bulk(ctx, fn) {
    this.write(ctx);
    return this.repo.tx(() => {
      this.inBulk = true;
      try { return fn(); } finally { this.inBulk = false; }
    });
  }

  /* ════ Заметки ════ */
  listNotes(ctx, { q } = {}) {
    const query = typeof q === 'string' ? q.replace(CONTROL, '').trim().slice(0, 100).toLocaleLowerCase('ru') : '';
    return this.repo.listNotes(ctx.userId, { q: query, limit: 500 }).map(pubNote);
  }
  getNote(ctx, id) {
    const n = this.repo.getNote(checkId(id, 'Заметка'), ctx.userId);
    if (!n) throw notFound('Заметка');
    return pubNote(n);
  }
  createNote(ctx, body) {
    const L = this.limits(ctx.plan);
    const title = text(body.title, 'title', { max: 200, label: 'Заголовок' });
    const content = text(body.content, 'content', { max: L.note_max_chars, multiline: true, label: 'Текст' });
    if (!title && !content) throw bad('content', 'Заметка пустая.');
    this.write(ctx);
    return this.repo.tx(() => {
      if (this.repo.countNotes(ctx.userId) >= L.notes_max) throw this.limitError(ctx, 'notes', L.notes_max, `Достигнут лимит заметок (${L.notes_max}). В Plus их больше.`);
      return pubNote(this.repo.insertNote(ctx.userId, { title, content, search: searchKey(title, content), source: ctx.source }));
    });
  }
  updateNote(ctx, id, body) {
    const L = this.limits(ctx.plan);
    const cur = this.repo.getNote(checkId(id, 'Заметка'), ctx.userId);
    if (!cur) throw notFound('Заметка');
    const title = has(body, 'title') ? text(body.title, 'title', { max: 200, label: 'Заголовок' }) : cur.title;
    const content = has(body, 'content') ? text(body.content, 'content', { max: L.note_max_chars, multiline: true, label: 'Текст' }) : cur.content;
    this.write(ctx);
    return pubNote(this.repo.updateNote(cur.id, ctx.userId, { title, content, search: searchKey(title, content) }));
  }
  deleteNote(ctx, id) {
    this.write(ctx);
    if (!this.repo.deleteNote(checkId(id, 'Заметка'), ctx.userId)) throw notFound('Заметка');
    return { ok: true };
  }

  /* ════ Задачи ════ */
  listTasks(ctx, { filter } = {}) {
    const f = ['active', 'completed'].includes(filter) ? filter : 'all';
    return this.repo.listTasks(ctx.userId, { filter: f, limit: 1000 }).map(pubTask);
  }
  getTask(ctx, id) {
    const t = this.repo.getTask(checkId(id, 'Задача'), ctx.userId);
    if (!t) throw notFound('Задача');
    return pubTask(t);
  }
  readTask(body, cur) {
    const out = {
      title: has(body, 'title') || !cur ? text(body.title, 'title', { max: 200, required: true, label: 'Название' }) : cur.title,
      description: has(body, 'description') || !cur ? text(body.description, 'description', { max: 4000, multiline: true, label: 'Описание' }) : cur.description,
      due_date: has(body, 'due_date') || !cur ? dateField(body.due_date, 'due_date') : cur.due_date,
      priority: cur ? cur.priority : 'medium',
    };
    if (has(body, 'priority')) {
      if (!PRIORITIES.includes(body.priority)) throw bad('priority', 'Приоритет: low, medium или high.');
      out.priority = body.priority;
    }
    return out;
  }
  createTask(ctx, body) {
    const L = this.limits(ctx.plan);
    const t = this.readTask(body, null);
    this.write(ctx);
    return this.repo.tx(() => {
      if (this.repo.countTasks(ctx.userId) >= L.tasks_max) throw this.limitError(ctx, 'tasks', L.tasks_max, `Достигнут лимит задач (${L.tasks_max}). Удали выполненные или перейди на Plus.`);
      return pubTask(this.repo.insertTask(ctx.userId, { ...t, source: ctx.source }));
    });
  }
  updateTask(ctx, id, body) {
    const cur = this.repo.getTask(checkId(id, 'Задача'), ctx.userId);
    if (!cur) throw notFound('Задача');
    const t = this.readTask(body, cur);
    let done = !!cur.done, completed_at = cur.completed_at || null;
    if (has(body, 'done')) {
      done = boolField(body.done, 'done');
      if (done && !cur.done) completed_at = Date.now();
      if (!done) completed_at = null;
    }
    this.write(ctx);
    return pubTask(this.repo.updateTask(cur.id, ctx.userId, { ...t, done, completed_at }));
  }
  deleteTask(ctx, id) {
    this.write(ctx);
    if (!this.repo.deleteTask(checkId(id, 'Задача'), ctx.userId)) throw notFound('Задача');
    return { ok: true };
  }

  /* ════ Напоминания ════ */
  listReminders(ctx, { status } = {}) {
    const s = ['active', 'done'].includes(status) ? status : 'all';
    return this.repo.listReminders(ctx.userId, { status: s, limit: 1000 }).map(pubReminder);
  }
  getReminder(ctx, id) {
    const r = this.repo.getReminder(checkId(id, 'Напоминание'), ctx.userId);
    if (!r) throw notFound('Напоминание');
    return pubReminder(r);
  }
  /* Дата + время + пояс → момент в UTC. Прошедшее время для активного напоминания не принимаем. */
  schedule(date, time, tz) {
    const at = T.zonedToUtc(date, time, tz);
    if (at == null) throw bad('time', 'Не получилось понять дату и время.');
    if (at > Date.now() + MAX_AHEAD_DAYS * 86400000) throw bad('date', 'Слишком далёкая дата.');
    return { remind_at: at, local_date: T.localDateOf(at, tz), local_time: T.localTimeOf(at, tz), tz };
  }
  createReminder(ctx, body) {
    const L = this.limits(ctx.plan);
    const title = text(body.title, 'title', { max: 120, required: true, label: 'Название' });
    const description = text(body.description, 'description', { max: 1000, multiline: true, label: 'Описание' });
    const date = dateField(body.date, 'date', { required: true });
    const time = timeField(body.time, 'time', { required: true });
    const tz = this.tz(ctx, body.timezone);
    const when = this.schedule(date, time, tz);
    if (when.remind_at < Date.now() - PAST_GRACE_MS) throw new HttpError(422, 'in_past', 'Это время уже прошло. Выбери момент в будущем.', { field: 'time' });
    this.write(ctx);
    return this.repo.tx(() => {
      if (this.repo.activeReminders(ctx.userId) >= L.reminders_active_max) {
        throw this.limitError(ctx, 'reminders', L.reminders_active_max, `На Free можно держать до ${L.reminders_active_max} активных напоминаний. Отметь выполненные или удали лишние.`);
      }
      return pubReminder(this.repo.insertReminder(ctx.userId, { title, description, ...when, source: ctx.source }));
    });
  }
  updateReminder(ctx, id, body) {
    const L = this.limits(ctx.plan);
    const cur = this.repo.getReminder(checkId(id, 'Напоминание'), ctx.userId);
    if (!cur) throw notFound('Напоминание');
    const next = {
      title: has(body, 'title') ? text(body.title, 'title', { max: 120, required: true, label: 'Название' }) : cur.title,
      description: has(body, 'description') ? text(body.description, 'description', { max: 1000, multiline: true, label: 'Описание' }) : cur.description,
      remind_at: cur.remind_at, local_date: cur.local_date, local_time: cur.local_time, tz: cur.tz,
      done: !!cur.done, done_at: cur.done_at || null, notified_at: cur.notified_at || null,
    };
    const reschedule = has(body, 'date') || has(body, 'time') || has(body, 'timezone');
    if (reschedule) {
      const date = has(body, 'date') ? dateField(body.date, 'date', { required: true }) : cur.local_date;
      const time = has(body, 'time') ? timeField(body.time, 'time', { required: true }) : cur.local_time;
      const tz = has(body, 'timezone') ? this.tz(ctx, body.timezone) : cur.tz;
      Object.assign(next, this.schedule(date, time, tz));
      if (next.remind_at !== cur.remind_at) next.notified_at = null;     // новое время = новое уведомление
    }
    if (has(body, 'done')) {
      next.done = boolField(body.done, 'done');
      if (next.done && !cur.done) next.done_at = Date.now();
      if (!next.done) next.done_at = null;
    }
    const becomesActive = !next.done && (cur.done || reschedule);
    if (becomesActive && next.remind_at < Date.now() - PAST_GRACE_MS) {
      throw new HttpError(422, 'in_past', 'Это время уже прошло. Выбери момент в будущем.', { field: 'time' });
    }
    this.write(ctx);
    return this.repo.tx(() => {
      if (cur.done && !next.done && this.repo.activeReminders(ctx.userId) >= L.reminders_active_max) {
        throw this.limitError(ctx, 'reminders', L.reminders_active_max, `Активных напоминаний уже ${L.reminders_active_max}: это предел тарифа.`);
      }
      return pubReminder(this.repo.updateReminder(cur.id, ctx.userId, next));
    });
  }
  markNotified(ctx, id) {
    const cur = this.repo.getReminder(checkId(id, 'Напоминание'), ctx.userId);
    if (!cur) throw notFound('Напоминание');
    const first = this.repo.markNotified(cur.id, ctx.userId);
    return { first, reminder: pubReminder(this.repo.getReminder(cur.id, ctx.userId)) };
  }
  deleteReminder(ctx, id) {
    this.write(ctx);
    if (!this.repo.deleteReminder(checkId(id, 'Напоминание'), ctx.userId)) throw notFound('Напоминание');
    return { ok: true };
  }

  /* ════ Планировщик дня ════ */
  readEvent(ctx, body, cur) {
    const L = this.limits(ctx.plan);
    const out = {
      title: has(body, 'title') || !cur ? text(body.title, 'title', { max: 120, required: true, label: 'Название' }) : cur.title,
      note: has(body, 'note') || !cur ? text(body.note, 'note', { max: 1000, multiline: true, label: 'Заметка' }) : cur.note,
      date: has(body, 'date') || !cur ? dateField(body.date, 'date', { required: true }) : cur.date,
      start_time: has(body, 'start_time') || !cur ? timeField(body.start_time, 'start_time', { required: true, label: 'время начала' }) : cur.start_time,
      end_time: has(body, 'end_time') || !cur ? timeField(body.end_time, 'end_time') : cur.end_time,
    };
    if (out.end_time && out.end_time <= out.start_time) throw bad('end_time', 'Конец должен быть позже начала.');
    const today = T.todayIn(this.tz(ctx));
    const ahead = T.daysBetween(today, out.date);
    if (ahead < -366) throw bad('date', 'Слишком давняя дата.');
    if (ahead > L.planner_days_ahead && (!cur || out.date !== cur.date)) {
      throw this.limitError(ctx, 'planner_days', L.planner_days_ahead, ctx.plan === 'plus'
        ? `Планировать можно на ${L.planner_days_ahead} дней вперёд.`
        : `На Free планировщик смотрит на ${L.planner_days_ahead} дней вперёд. В Plus — на год.`);
    }
    return out;
  }
  listEvents(ctx, { date } = {}) {
    const d = dateField(date, 'date') || T.todayIn(this.tz(ctx));
    return { date: d, events: this.repo.eventsOn(ctx.userId, d).map(pubEvent) };
  }
  /* Layer 8: события вокруг сегодняшнего дня (для поиска по всем данным): месяц назад … год вперёд */
  listEventsAround(ctx) {
    const today = T.todayIn(this.tz(ctx));
    return this.repo.eventsRange(ctx.userId, T.addDays(today, -31), T.addDays(today, 366), 500).map(pubEvent);
  }
  exportAll(ctx) {
    const userId = ctx.userId;
    return {
      notes: this.repo.listNotes(userId, { q: '', limit: -1 }).map(pubNote),
      tasks: this.repo.listTasks(userId, { filter: 'all', limit: -1 }).map(pubTask),
      reminders: this.repo.listReminders(userId, { status: 'all', limit: -1 }).map(pubReminder),
      events: this.repo.eventsRange(userId, '0000-01-01', '9999-12-31', -1).map(pubEvent),
    };
  }
  getEvent(ctx, id) {
    const e = this.repo.getEvent(checkId(id, 'Событие'), ctx.userId);
    if (!e) throw notFound('Событие');
    return pubEvent(e);
  }
  createEvent(ctx, body) {
    const L = this.limits(ctx.plan);
    const e = this.readEvent(ctx, body, null);
    this.write(ctx);
    return this.repo.tx(() => {
      if (this.repo.countEventsOn(ctx.userId, e.date) >= L.events_per_day_max) {
        throw this.limitError(ctx, 'events', L.events_per_day_max, `На этот день уже ${L.events_per_day_max} событий: это предел тарифа.`);
      }
      return pubEvent(this.repo.insertEvent(ctx.userId, { ...e, source: ctx.source }));
    });
  }
  updateEvent(ctx, id, body) {
    const L = this.limits(ctx.plan);
    const cur = this.repo.getEvent(checkId(id, 'Событие'), ctx.userId);
    if (!cur) throw notFound('Событие');
    const e = this.readEvent(ctx, body, cur);
    this.write(ctx);
    return this.repo.tx(() => {
      if (e.date !== cur.date && this.repo.countEventsOn(ctx.userId, e.date) >= L.events_per_day_max) {
        throw this.limitError(ctx, 'events', L.events_per_day_max, `На этот день уже ${L.events_per_day_max} событий: это предел тарифа.`);
      }
      return pubEvent(this.repo.updateEvent(cur.id, ctx.userId, e));
    });
  }
  deleteEvent(ctx, id) {
    this.write(ctx);
    if (!this.repo.deleteEvent(checkId(id, 'Событие'), ctx.userId)) throw notFound('Событие');
    return { ok: true };
  }

  /* ════ День целиком: события + задачи со сроком + напоминания (для планировщика и для AI) ════ */
  agenda(ctx, { date, timezone } = {}) {
    const tz = this.tz(ctx, timezone);
    const today = T.todayIn(tz);
    const d = dateField(date, 'date') || today;
    const from = T.zonedToUtc(d, '00:00', tz);
    const to = T.zonedToUtc(T.addDays(d, 1), '00:00', tz);
    return {
      date: d, timezone: tz, is_today: d === today,
      events: this.repo.eventsOn(ctx.userId, d).map(pubEvent),
      tasks: this.repo.tasksDue(ctx.userId, d).map(pubTask),
      reminders: this.repo.remindersBetween(ctx.userId, from, to).map(pubReminder),
      overdue_tasks: d === today ? this.repo.overdueTasks(ctx.userId, today) : 0,
    };
  }

  /* Короткая сводка для сетки инструментов */
  summary(ctx, { timezone } = {}) {
    const tz = this.tz(ctx, timezone);
    const today = T.todayIn(tz);
    const active = this.repo.listReminders(ctx.userId, { status: 'active', limit: 1 });
    return {
      today, timezone: tz,
      notes: this.repo.countNotes(ctx.userId),
      tasks_active: this.repo.activeTasks(ctx.userId),
      tasks_today: this.repo.tasksDue(ctx.userId, today).length,
      reminders_active: this.repo.activeReminders(ctx.userId),
      next_reminder: active[0] ? pubReminder(active[0]) : null,
      events_today: this.repo.countEventsOn(ctx.userId, today),
      limits: this.limits(ctx.plan),
    };
  }
}

module.exports = { ToolsService, DEFAULT_LIMITS, pubNote, pubTask, pubReminder, pubEvent, ID_RE };
