/* WISP · Server · Tools · AI toolkit (Layer 4 → Layer 8)
 * Структурированные tool calls для модели. Модель только ПРОСИТ действие: аргументы проверяет сервер
 * (тот же ToolsService, что и у экрана Tools), пользователь берётся из сессии, результат пишется в базу,
 * и только после успешной записи модель получает { ok: true }. Ошибка → { ok: false, error } и честный ответ.
 *
 * Layer 8 · AI Actions:
 *  · полный набор действий: создать / посмотреть / изменить / удалить для напоминаний, задач, заметок, событий,
 *    поиск по всем данным пользователя, очистка истории чатов;
 *  · «when» — слова пользователя о дате и времени («завтра в 10», «в пятницу»): сервер разбирает их сам (actions/dates.js)
 *    в часовом поясе пользователя и не даёт модели ошибиться в днях недели;
 *  · Clarify — не хватает обязательных данных или дата неоднозначна: действие НЕ выполняется, модель получает вопрос;
 *  · опасные действия (удаление, массовые изменения, очистка истории) здесь только готовятся (prepare) —
 *    выполняет их commit() после подтверждения пользователя (server/actions/engine.js).
 * Политику (что безопасно, что требует подтверждения, лимиты тарифа, повторы) решает ActionEngine. */
'use strict';
const { HttpError } = require('../lib/http');
const T = require('./time');
const D = require('../actions/dates');
const { memoryNote } = require('../memory/ai');
const { searchAll } = require('../actions/search');

const MAX_CALLS_PER_ROUND = 5;

const S = (description, extra) => ({ type: 'string', description, ...(extra || {}) });
const IDS = (description) => ({ type: 'array', items: { type: 'string' }, description });
const WHEN = S('Дата и/или время СЛОВАМИ ПОЛЬЗОВАТЕЛЯ, как он сказал: «завтра в 10 утра», «в пятницу вечером», «через неделю». Сервер сам переведёт в дату его часового пояса. Передавай всегда, когда пользователь назвал момент.');

const DEFINITIONS = [
  /* ── Reminders ── */
  {
    name: 'create_reminder',
    description: 'Создать напоминание на конкретный момент. Для «напомни…». Обязательно нужно: о чём напомнить и когда (день и время). Если чего-то нет — НЕ выдумывай: можно вызвать без этого поля, сервер вернёт вопрос, или сразу коротко спроси сам.',
    parameters: { type: 'object', properties: {
      title: S('О чём напомнить, коротко и по делу: «Позвонить другу». Без даты и времени в тексте.'),
      when: WHEN,
      date: S('Дата YYYY-MM-DD (если уверен; иначе только when)'),
      time: S('Время HH:MM, 24 часа (если уверен; иначе только when)'),
      description: S('Подробности, если пользователь их дал'),
    }, required: [] },
  },
  {
    name: 'list_reminders',
    description: 'Список напоминаний пользователя (с id). Нужен, чтобы перенести, изменить или удалить конкретное напоминание.',
    parameters: { type: 'object', properties: {
      status: S('Какие', { enum: ['active', 'done', 'all'] }),
      query: S('Слова из названия, если пользователь назвал напоминание'),
    }, required: [] },
  },
  {
    name: 'update_reminder',
    description: 'Изменить одно напоминание: перенести на другой день/время, переименовать, отметить выполненным. reminder_id бери только из list_reminders / get_agenda / прошлых действий.',
    parameters: { type: 'object', properties: {
      reminder_id: S('id напоминания'),
      when: WHEN, date: S('Новая дата YYYY-MM-DD'), time: S('Новое время HH:MM'),
      title: S('Новое название'), done: { type: 'boolean', description: 'true — выполнено' },
    }, required: ['reminder_id'] },
  },
  {
    name: 'delete_reminders',
    description: 'Удалить одно или несколько напоминаний. ОПАСНОЕ действие: сервер не удалит сразу, а покажет пользователю карточку подтверждения.',
    parameters: { type: 'object', properties: { reminder_ids: IDS('id напоминаний') }, required: ['reminder_ids'] },
  },
  /* ── Tasks ── */
  {
    name: 'create_task',
    description: 'Добавить задачу в список дел. Для «создай задачу», «добавь в дела», «надо сделать…». Если из названия непонятно, что именно делать («подготовиться» — к чему?), спроси.',
    parameters: { type: 'object', properties: {
      title: S('Название задачи: что сделать'),
      description: S('Описание, если есть'),
      when: WHEN,
      due_date: S('Срок YYYY-MM-DD, только если пользователь его назвал'),
      priority: S('Приоритет', { enum: ['low', 'medium', 'high'] }),
    }, required: [] },
  },
  {
    name: 'list_tasks',
    description: 'Список задач пользователя (с id).',
    parameters: { type: 'object', properties: { filter: S('Какие задачи', { enum: ['active', 'completed', 'all'] }), query: S('Слова из названия') }, required: [] },
  },
  {
    name: 'update_task',
    description: 'Изменить одну задачу: название, описание, срок, приоритет, выполнена ли. task_id — из list_tasks / get_agenda / прошлых действий.',
    parameters: { type: 'object', properties: {
      task_id: S('id задачи'), title: S('Новое название'), description: S('Новое описание'),
      when: WHEN, due_date: S('Новый срок YYYY-MM-DD или пустая строка, чтобы убрать срок'),
      priority: S('Приоритет', { enum: ['low', 'medium', 'high'] }), done: { type: 'boolean', description: 'true — выполнена, false — вернуть в работу' },
    }, required: ['task_id'] },
  },
  {
    name: 'complete_task',
    description: 'Отметить задачу выполненной. task_id бери только из результата list_tasks или get_agenda.',
    parameters: { type: 'object', properties: { task_id: S('id задачи') }, required: ['task_id'] },
  },
  {
    name: 'bulk_update_tasks',
    description: 'Изменить сразу несколько задач (перенести срок, приоритет, отметить выполненными). Если задач больше одной — сервер сначала спросит подтверждение у пользователя.',
    parameters: { type: 'object', properties: {
      task_ids: IDS('id задач'), when: WHEN, due_date: S('Новый срок YYYY-MM-DD'),
      priority: S('Приоритет', { enum: ['low', 'medium', 'high'] }), done: { type: 'boolean' },
    }, required: ['task_ids'] },
  },
  {
    name: 'delete_tasks',
    description: 'Удалить задачи: перечисленные по id или все выполненные (completed: true). ОПАСНОЕ действие: сервер покажет карточку подтверждения и ничего не удалит без согласия пользователя.',
    parameters: { type: 'object', properties: { task_ids: IDS('id задач'), completed: { type: 'boolean', description: 'true — все выполненные задачи' } }, required: [] },
  },
  /* ── Notes ── */
  {
    name: 'create_note',
    description: 'Сохранить заметку или идею. Для «запиши», «сохрани заметку», «запиши идею». Пиши текст от лица пользователя, без лишних слов.',
    parameters: { type: 'object', properties: {
      title: S('Короткий заголовок (необязательно)'),
      content: S('Текст заметки'),
    }, required: [] },
  },
  {
    name: 'search_notes',
    description: 'Найти заметки пользователя по словам (с учётом форм слов: «игры» найдёт «игру»).',
    parameters: { type: 'object', properties: { query: S('Что искать') }, required: ['query'] },
  },
  {
    name: 'update_note',
    description: 'Изменить заметку: новый заголовок, новый текст или дописать в конец (append). note_id — из поиска или прошлых действий.',
    parameters: { type: 'object', properties: { note_id: S('id заметки'), title: S('Новый заголовок'), content: S('Новый текст целиком'), append: S('Текст, который дописать в конец') }, required: ['note_id'] },
  },
  {
    name: 'delete_notes',
    description: 'Удалить одну или несколько заметок. ОПАСНОЕ действие: только через карточку подтверждения.',
    parameters: { type: 'object', properties: { note_ids: IDS('id заметок') }, required: ['note_ids'] },
  },
  /* ── Planner ── */
  {
    name: 'create_event',
    description: 'Добавить событие в планировщик дня (встреча, тренировка, дело на конкретное время).',
    parameters: { type: 'object', properties: {
      title: S('Название события'), when: WHEN,
      date: S('Дата YYYY-MM-DD'), start_time: S('Начало HH:MM'), end_time: S('Конец HH:MM, если известен'), note: S('Заметка к событию'),
    }, required: [] },
  },
  {
    name: 'get_agenda',
    description: 'Что у пользователя запланировано: события планировщика, задачи со сроком и напоминания. Для «что у меня сегодня/завтра/на неделе». days — сколько дней подряд показать.',
    parameters: { type: 'object', properties: { date: S('Первый день YYYY-MM-DD'), when: WHEN, days: { type: 'integer', minimum: 1, maximum: 31, description: 'Сколько дней (1 — один день)' } }, required: [] },
  },
  {
    name: 'update_event',
    description: 'Изменить событие планировщика: перенести, переименовать, поменять время. event_id — из get_agenda или прошлых действий.',
    parameters: { type: 'object', properties: {
      event_id: S('id события'), title: S('Новое название'), when: WHEN,
      date: S('Новая дата YYYY-MM-DD'), start_time: S('Новое начало HH:MM'), end_time: S('Новый конец HH:MM'), note: S('Заметка'),
    }, required: ['event_id'] },
  },
  {
    name: 'delete_events',
    description: 'Удалить события планировщика. ОПАСНОЕ действие: только через карточку подтверждения.',
    parameters: { type: 'object', properties: { event_ids: IDS('id событий') }, required: ['event_ids'] },
  },
  /* ── Search ── */
  {
    name: 'search_everything',
    description: 'Поиск по ВСЕМ данным пользователя сразу: заметки, задачи, напоминания, события и долговременная память. Для «какие у меня были идеи для игр?», «что я записывал про отпуск?». Показывай только то, что вернул сервер.',
    parameters: { type: 'object', properties: {
      query: S('Что искать, ключевыми словами'),
      types: { type: 'array', items: { type: 'string', enum: ['notes', 'tasks', 'reminders', 'events', 'memory'] }, description: 'Где искать (по умолчанию везде)' },
    }, required: ['query'] },
  },
  /* ── History ── */
  {
    name: 'clear_chat_history',
    description: 'Очистить ВСЮ историю чатов с WISP (заметки, задачи, напоминания и память остаются). ОПАСНОЕ действие: только через карточку подтверждения, подтвердить можно только кнопкой.',
    parameters: { type: 'object', properties: {}, required: [] },
  },
];

/* Подтверждение/отмена ожидающего действия словами пользователя («да», «нет»). Предлагаются модели, только когда
 * в этом диалоге есть ожидающее подтверждения действие. Сервер сам проверяет, что «да» сказал пользователь. */
const CONFIRM_DEFINITIONS = [
  {
    name: 'confirm_action',
    description: 'Пользователь ответил «да» на вопрос о подтверждении опасного действия (удаление и т.п.). Передай ref из списка ожидающих. Сервер выполнит действие, только если последнее сообщение пользователя — явное согласие.',
    parameters: { type: 'object', properties: { ref: S('ref ожидающего действия, например p1a2b3c4d') }, required: ['ref'] },
  },
  {
    name: 'cancel_action',
    description: 'Пользователь передумал («нет», «отмена») — отменить ожидающее действие по ref.',
    parameters: { type: 'object', properties: { ref: S('ref ожидающего действия') }, required: ['ref'] },
  },
];
const NAMES = new Set(DEFINITIONS.map((d) => d.name));

/* Kind карточки для каждого действия */
const KIND = {
  create_reminder: 'reminder', update_reminder: 'reminder', list_reminders: 'reminders', delete_reminders: 'confirm',
  create_task: 'task', update_task: 'task', complete_task: 'task', list_tasks: 'tasks', bulk_update_tasks: 'tasks', delete_tasks: 'confirm',
  create_note: 'note', update_note: 'note', search_notes: 'notes', delete_notes: 'confirm',
  create_event: 'event', update_event: 'event', get_agenda: 'agenda', delete_events: 'confirm',
  search_everything: 'search', clear_chat_history: 'confirm',
};

const clip = (s, n) => (s && s.length > n ? s.slice(0, n - 1) + '…' : s || '');
const when = (date, time) => `${T.humanDate(date)}${time ? ', ' + time : ''}`;
const slimTask = (t) => ({ id: t.id, title: t.title, due_date: t.due_date, priority: t.priority, done: t.done });
const slimRem = (r) => ({ id: r.id, title: r.title, date: r.date, time: r.time, done: r.done, when: when(r.date, r.time) });
const slimEvent = (e) => ({ id: e.id, title: e.title, date: e.date, start_time: e.start_time, end_time: e.end_time });
const has = (o, k) => o[k] !== undefined && o[k] !== null;
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14) ? b : c; };

/* Не хватает данных или дата неоднозначна: действие не выполняется, модель получает вопрос для пользователя */
class Clarify extends Error {
  constructor(question, missing) { super(question); this.question = question; this.missing = missing || []; }
}

/* «Подготовиться», «позвонить» без объекта — непонятно, что именно. Вопрос — в духе живого собеседника. */
const VAGUE = {
  подготовиться: 'К чему подготовиться?', готовиться: 'К чему готовиться?', сделать: 'Что именно сделать?', купить: 'Что купить?',
  позвонить: 'Кому позвонить?', написать: 'Кому или что написать?', сходить: 'Куда сходить?', встретиться: 'С кем встретиться?',
  заняться: 'Чем заняться?', прочитать: 'Что прочитать?', посмотреть: 'Что посмотреть?', отправить: 'Что и кому отправить?',
  забрать: 'Что забрать?', оплатить: 'Что оплатить?', записаться: 'Куда записаться?', ответить: 'Кому ответить?',
  дело: 'Какое дело?', задача: 'Какая задача?', задачу: 'Какую задачу?', что: 'О чём именно?', это: 'О чём именно?', кое: 'О чём именно?',
  prepare: 'Prepare for what?', call: 'Call whom?', buy: 'Buy what?', do: 'Do what exactly?',
};
function vagueQuestion(title) {
  const words = D.norm(title).replace(/[^\p{L}\p{N}\s-]+/gu, ' ').split(/\s+/).filter((w) => w && !['мне', 'надо', 'нужно', 'бы', 'что-то', 'кое-что', 'to', 'something'].includes(w));
  if (!words.length) return 'О чём именно?';
  if (words.length === 1 && VAGUE[words[0]]) return VAGUE[words[0]];
  if (/^(что-то|кое-что|something)$/u.test(D.norm(title))) return 'О чём именно?';
  return null;
}
const str = (v) => (typeof v === 'string' ? v.trim() : '');

/* «when» и неформальные значения полей → дата/время сервера. fields: { date: 'date' | 'due_date', time: 'time' | 'start_time' | null } */
function applyWhen(a, ctx, fields) {
  const out = { ...a };
  const df = fields.date, tf = fields.time;
  const phrase = str(a.when);
  // модель иногда кладёт «завтра» прямо в date — тоже понимаем
  const rawDate = has(a, df) ? String(a[df]) : '';
  const rawTime = tf && has(a, tf) ? String(a[tf]) : '';
  const texts = [phrase, rawDate && !T.parseDate(rawDate) ? rawDate : '', rawTime && !T.parseTime(rawTime) ? rawTime : ''].filter(Boolean).join(' ');
  if (texts) {
    const r = D.resolve(texts, ctx.tz, ctx.now);
    if (r.ambiguous) throw new Clarify(r.ambiguous.question, [r.ambiguous.field]);
    if (r.date && (r.date_kind || !T.parseDate(rawDate))) out[df] = r.date;
    if (tf && r.time && (r.time_kind === 'exact' || r.time_kind === 'relative' || !T.parseTime(rawTime))) out[tf] = r.time;
    if (tf && r.time && r.time_kind === 'part_of_day' && !T.parseTime(rawTime)) out[tf] = r.time;
  }
  delete out.when;
  return out;
}

function pick(args, keys) {
  const out = {};
  for (const k of keys) if (args[k] !== undefined && args[k] !== null) out[k] = args[k];
  return out;
}
function idList(v, max, what) {
  const list = Array.isArray(v) ? v : typeof v === 'string' && v ? [v] : [];
  const ids = [...new Set(list.filter((x) => typeof x === 'string').map((x) => x.trim()).filter(Boolean))];
  if (!ids.length) throw new Clarify(`Какие ${what} именно? Назови их, и я найду.`, ['ids']);
  if (ids.length > max) throw new HttpError(403, 'limit_bulk', `За один раз можно изменить не больше ${max} записей.`);
  return ids;
}

class AIToolkit {
  constructor({ tools, log, memory, store }) {
    this.tools = tools;
    this.log = log;
    this.memory = memory || null;              // MemoryService — для поиска по памяти
    this.store = store || null;
  }
  definitions() { return DEFINITIONS; }
  confirmDefinitions() { return CONFIRM_DEFINITIONS; }
  has(name) { return NAMES.has(name); }
  kindOf(name) { return KIND[name] || 'tool'; }

  /* Инструкция для модели: текущий момент у пользователя и правила честности (Layer 8 дополняет её в engine) */
  promptSection({ tz, now, enabled }) {
    const line = `Сейчас у пользователя: ${T.nowLine(tz, now)}.`;
    if (!enabled) {
      return [line, 'В этом разговоре у тебя нет доступа к инструментам WISP (напоминания, задачи, заметки, планировщик). Никогда не говори, что что-то создал, записал или напомнишь: предложи сделать это в разделе Tools.'].join('\n');
    }
    return [
      'Инструменты WISP: у тебя есть функции, которые по-настоящему создают, показывают, меняют и удаляют напоминания, задачи, заметки и события в приложении пользователя, ищут по его данным.',
      `- ${line} «Сегодня», «завтра», «в пятницу», «через час» считай от этого момента; дату и время передавай в часовом поясе пользователя.`,
      '- Если пользователь просит напомнить, создать задачу, записать что-то, запланировать, перенести, удалить или спрашивает о своих планах и записях, вызывай подходящую функцию, а не просто отвечай текстом.',
      '- Говори «создал», «записал», «напомню», «перенёс», «удалил» только если функция вернула ok: true. Если вернулась ошибка, честно скажи, что не получилось, и почему. Не притворяйся, что действие выполнено.',
      '- Если для действия не хватает данных, не придумывай: коротко уточни. Одна просьба — одно действие, без дубликатов.',
      '- После действия ответь коротко: что сделано и когда. Карточку с деталями пользователь видит сам — не повторяй её целиком. Не показывай пользователю id.',
    ].join('\n');
  }

  /* Выполнить вызов модели (безопасные действия). ctx: { userId, plan, tz, now, limits } из сессии.
   * Возвращает { ok, forModel, action } или { clarify } (действие не выполнено, нужен вопрос пользователю). */
  execute(name, rawArgs, ctx) {
    const c = { ...ctx, source: 'ai' };
    const args = rawArgs && typeof rawArgs === 'object' && !Array.isArray(rawArgs) ? rawArgs : null;
    try {
      if (!NAMES.has(name)) throw new HttpError(400, 'unknown_tool', 'Такой функции нет.');
      if (!args) throw new HttpError(400, 'bad_input', 'Аргументы функции не разобраны: нужен JSON-объект.');
      return this.run(name, args, c);
    } catch (e) { return this.failure(name, e); }
  }
  failure(name, e) {
    if (e instanceof Clarify) {
      return { ok: false, clarify: true, forModel: { ok: false, executed: false, needs_clarification: true, question: e.question, missing: e.missing, note: 'Действие НЕ выполнено. Задай пользователю этот вопрос одной короткой фразой.' }, action: { tool: name, kind: KIND[name] || 'tool', op: 'clarify', question: e.question, missing: e.missing } };
    }
    const message = e instanceof HttpError ? e.message : 'Внутренняя ошибка сервера при выполнении действия.';
    const code = e instanceof HttpError ? e.code : 'server_error';
    if (!(e instanceof HttpError)) { this.log && this.log.error('tool failed', { tool: name, error: e && e.message }); if (e && /SQLITE_BUSY|database is locked/i.test(e.message || '')) e.transient = true; }
    return { ok: false, transient: !!(e && e.transient), forModel: { ok: false, error: message }, action: { tool: name, kind: KIND[name] || 'tool', op: 'failed', error: message, code } };
  }

  /* ── Обязательные данные: спрашиваем, а не выдумываем ── */
  require(name, a) {
    if (name === 'create_reminder') {
      const miss = [];
      if (!str(a.title)) miss.push('title');
      if (!str(a.date) && !str(a.time)) miss.push('date', 'time');
      else if (!str(a.time)) miss.push('time');
      else if (!str(a.date)) miss.push('date');
      if (miss.length) {
        const q = miss.includes('title') && miss.includes('time') ? 'О чём напомнить и во сколько?'
          : miss.includes('title') ? 'О чём напомнить?'
            : miss.includes('date') && miss.includes('time') ? 'Когда напомнить: в какой день и во сколько?'
              : miss.includes('time') ? 'Во сколько напомнить?' : 'На какой день поставить напоминание?';
        throw new Clarify(q, miss);
      }
      const v = vagueQuestion(a.title);
      if (v) throw new Clarify(v, ['title']);
    }
    if (name === 'create_task') {
      if (!str(a.title)) throw new Clarify('Какую задачу добавить?', ['title']);
      const v = vagueQuestion(a.title);
      if (v) throw new Clarify(v, ['title']);
    }
    if (name === 'create_note' && !str(a.content) && !str(a.title)) throw new Clarify('Что записать?', ['content']);
    if (name === 'create_event') {
      const miss = [];
      if (!str(a.title)) miss.push('title');
      if (!str(a.date)) miss.push('date');
      if (!str(a.start_time)) miss.push('start_time');
      if (miss.length) throw new Clarify(miss[0] === 'title' ? 'Что запланировать и когда?' : miss.length === 2 ? 'На какой день и во сколько?' : miss[0] === 'date' ? 'На какой день?' : 'Во сколько начало?', miss);
    }
  }

  run(name, a, c) {
    const S = this.tools;
    switch (name) {
      case 'create_reminder': {
        const b = applyWhen(a, c, { date: 'date', time: 'time' });
        this.require(name, b);
        const r = S.createReminder(c, pick(b, ['title', 'date', 'time', 'description']));
        return ok({ reminder: { id: r.id, title: r.title, date: r.date, time: r.time, timezone: r.timezone, when: when(r.date, r.time) } },
          { tool: name, kind: 'reminder', op: 'created', record_id: r.id, title: r.title, remind_at: r.remind_at, date: r.date, time: r.time });
      }
      case 'list_reminders': {
        const status = ['active', 'done', 'all'].includes(a.status) ? a.status : 'active';
        let list = S.listReminders(c, { status });
        const q = str(a.query);
        if (q) list = searchAll(list.map((r) => ({ kind: 'reminder', rec: r, title: r.title, body: r.description })), q, 50).map((x) => x.rec);
        return ok({ status, total: list.length, reminders: list.slice(0, 50).map(slimRem) },
          { tool: name, kind: 'reminders', op: 'read', status, query: clip(q, 60) || null, count: list.length, items: list.slice(0, 8).map((r) => ({ kind: 'reminder', record_id: r.id })) });
      }
      case 'update_reminder': {
        const b = applyWhen(a, c, { date: 'date', time: 'time' });
        const patch = pick(b, ['title', 'date', 'time', 'done']);
        if (!Object.keys(patch).length) throw new Clarify('Что изменить в напоминании: время, день или текст?', ['change']);
        const id = String(a.reminder_id || '');
        const before = S.getReminder(c, id);
        // «перенеси на пятницу» без времени: время остаётся прежним
        const r = S.updateReminder(c, id, patch);
        const moved = before.remind_at !== r.remind_at;
        return ok({ reminder: slimRem(r), moved, previous: moved ? when(before.date, before.time) : null },
          { tool: name, kind: 'reminder', op: has(patch, 'done') && Object.keys(patch).length === 1 ? (r.done ? 'completed' : 'reopened') : moved ? 'moved' : 'updated', record_id: r.id, title: r.title, remind_at: r.remind_at, date: r.date, time: r.time, from: moved ? { date: before.date, time: before.time } : null });
      }
      case 'create_task': {
        const b = applyWhen(a, c, { date: 'due_date', time: null });
        this.require(name, b);
        const t = S.createTask(c, pick(b, ['title', 'description', 'due_date', 'priority']));
        return ok({ task: { ...slimTask(t), due: t.due_date ? T.humanDate(t.due_date) : null } },
          { tool: name, kind: 'task', op: 'created', record_id: t.id, title: t.title, due_date: t.due_date, priority: t.priority });
      }
      case 'list_tasks': {
        const filter = ['active', 'completed', 'all'].includes(a.filter) ? a.filter : 'active';
        let list = S.listTasks(c, { filter });
        const q = str(a.query);
        if (q) list = searchAll(list.map((t) => ({ kind: 'task', rec: t, title: t.title, body: t.description })), q, 50).map((x) => x.rec);
        return ok({ filter, total: list.length, tasks: list.slice(0, 50).map(slimTask) },
          { tool: name, kind: 'tasks', op: 'read', filter, query: clip(q, 60) || null, count: list.length, items: list.slice(0, 8).map((t) => ({ kind: 'task', record_id: t.id })) });
      }
      case 'update_task': {
        const b = applyWhen(a, c, { date: 'due_date', time: null });
        if (b.due_date === '') b.due_date = null;
        const patch = {};
        for (const k of ['title', 'description', 'priority', 'done']) if (has(b, k)) patch[k] = b[k];
        if (Object.prototype.hasOwnProperty.call(b, 'due_date') && b.due_date !== undefined) patch.due_date = b.due_date;
        if (!Object.keys(patch).length) throw new Clarify('Что изменить в задаче?', ['change']);
        const t = S.updateTask(c, String(a.task_id || ''), patch);
        const op = Object.keys(patch).length === 1 && has(patch, 'done') ? (t.done ? 'completed' : 'reopened') : 'updated';
        return ok({ task: slimTask(t) }, { tool: name, kind: 'task', op, record_id: t.id, title: t.title, due_date: t.due_date, priority: t.priority });
      }
      case 'complete_task': {
        const t = S.updateTask(c, String(a.task_id || ''), { done: true });
        return ok({ task: slimTask(t) }, { tool: name, kind: 'task', op: 'completed', record_id: t.id, title: t.title });
      }
      case 'bulk_update_tasks': {
        // сюда попадает только одна задача: несколько — через подтверждение (prepare/commit)
        const ids = idList(a.task_ids, 1, 'задачи');
        const res = this.run('update_task', { ...a, task_id: ids[0] }, c);
        return res;
      }
      case 'create_note': {
        this.require(name, a);
        const n = S.createNote(c, pick(a, ['title', 'content']));
        return ok({ note: { id: n.id, title: n.title, saved_chars: n.content.length } },
          { tool: name, kind: 'note', op: 'created', record_id: n.id, title: n.title || clip(n.content.split('\n')[0], 60) });
      }
      case 'search_notes': {
        const q = typeof a.query === 'string' ? a.query : '';
        if (!q.trim()) throw new Clarify('Что поискать в заметках?', ['query']);
        const list = searchAll(S.listNotes(c, {}).map((n) => ({ kind: 'note', rec: n, title: n.title, body: n.content })), q, 10).map((x) => x.rec);
        return ok({ total: list.length, notes: list.map((n) => ({ id: n.id, title: n.title, excerpt: clip(n.content, 400), updated_at: new Date(n.updated_at).toISOString() })) },
          { tool: name, kind: 'notes', op: 'read', query: clip(q, 60), count: list.length, items: list.slice(0, 8).map((n) => ({ kind: 'note', record_id: n.id })) });
      }
      case 'update_note': {
        const id = String(a.note_id || '');
        const cur = S.getNote(c, id);
        const patch = pick(a, ['title', 'content']);
        if (str(a.append)) patch.content = `${has(patch, 'content') ? patch.content : cur.content}${cur.content ? '\n' : ''}${a.append}`;
        if (!Object.keys(patch).length) throw new Clarify('Что изменить в заметке?', ['change']);
        const n = S.updateNote(c, id, patch);
        return ok({ note: { id: n.id, title: n.title, saved_chars: n.content.length } },
          { tool: name, kind: 'note', op: 'updated', record_id: n.id, title: n.title || clip(n.content.split('\n')[0], 60) });
      }
      case 'create_event': {
        const b = applyWhen(a, c, { date: 'date', time: 'start_time' });
        this.require(name, b);
        const e = S.createEvent(c, pick(b, ['title', 'date', 'start_time', 'end_time', 'note']));
        return ok({ event: { ...slimEvent(e), when: when(e.date, e.start_time) } },
          { tool: name, kind: 'event', op: 'created', record_id: e.id, title: e.title, date: e.date, time: e.start_time, end_time: e.end_time });
      }
      case 'update_event': {
        const b = applyWhen(a, c, { date: 'date', time: 'start_time' });
        const patch = pick(b, ['title', 'date', 'start_time', 'end_time', 'note']);
        if (!Object.keys(patch).length) throw new Clarify('Что изменить в событии?', ['change']);
        const id = String(a.event_id || '');
        const before = S.getEvent(c, id);
        // перенос начала без нового конца: длительность сохраняется
        if (has(patch, 'start_time') && !has(patch, 'end_time') && before.end_time) {
          const dur = toMin(before.end_time) - toMin(before.start_time);
          const end = toMin(patch.start_time) + dur;
          patch.end_time = end < 24 * 60 ? fromMin(end) : null;
        }
        const e = S.updateEvent(c, id, patch);
        const moved = before.date !== e.date || before.start_time !== e.start_time;
        return ok({ event: slimEvent(e), moved }, { tool: name, kind: 'event', op: moved ? 'moved' : 'updated', record_id: e.id, title: e.title, date: e.date, time: e.start_time, end_time: e.end_time, from: moved ? { date: before.date, time: before.start_time } : null });
      }
      case 'get_agenda': {
        const b = applyWhen(a, c, { date: 'date', time: null });
        const max = (c.limits && c.limits.agenda_days_max) || 7;
        const days = Math.max(1, Math.min(max, Number.isInteger(b.days) ? b.days : Number(b.days) || 1));
        const first = S.agenda(c, pick(b, ['date']));
        const all = [first];
        for (let i = 1; i < days; i++) all.push(S.agenda(c, { date: T.addDays(first.date, i) }));
        const items = [];
        const dayOut = all.map((g) => {
          for (const e of g.events) items.push({ kind: 'event', record_id: e.id, date: g.date });
          for (const r of g.reminders) items.push({ kind: 'reminder', record_id: r.id, date: g.date });
          for (const t of g.tasks) items.push({ kind: 'task', record_id: t.id, date: g.date });
          return {
            date: g.date, day: T.humanDate(g.date), is_today: g.is_today,
            events: g.events.map(slimEvent),
            tasks_due: g.tasks.map(slimTask),
            reminders: g.reminders.map((r) => ({ id: r.id, title: r.title, time: T.localTimeOf(r.remind_at, g.timezone), done: r.done })),
          };
        });
        const count = items.length;
        const forModel = days === 1
          ? { date: dayOut[0].date, day: dayOut[0].day, is_today: dayOut[0].is_today, events: dayOut[0].events, tasks_due: dayOut[0].tasks_due, reminders: dayOut[0].reminders, overdue_tasks: first.overdue_tasks }
          : { from: first.date, days, overdue_tasks: first.overdue_tasks, schedule: dayOut };
        return ok(forModel, { tool: name, kind: 'agenda', op: 'read', date: first.date, days, count, overdue: first.overdue_tasks || 0, items: items.slice(0, 14) });
      }
      case 'search_everything': {
        const q = str(a.query);
        if (!q) throw new Clarify('Что поискать?', ['query']);
        const types = Array.isArray(a.types) && a.types.length ? a.types.filter((t) => ['notes', 'tasks', 'reminders', 'events', 'memory'].includes(t)) : ['notes', 'tasks', 'reminders', 'events', 'memory'];
        const limit = (c.limits && c.limits.search_results) || 8;
        const docs = [];
        if (types.includes('notes')) for (const n of S.listNotes(c, {})) docs.push({ kind: 'note', rec: n, title: n.title, body: n.content });
        if (types.includes('tasks')) for (const t of S.listTasks(c, { filter: 'all' })) docs.push({ kind: 'task', rec: t, title: t.title, body: t.description });
        if (types.includes('reminders')) for (const r of S.listReminders(c, { status: 'all' })) docs.push({ kind: 'reminder', rec: r, title: r.title, body: r.description });
        if (types.includes('events')) for (const e of S.listEventsAround(c)) docs.push({ kind: 'event', rec: e, title: e.title, body: e.note });
        let memoryOff = false;
        if (types.includes('memory') && this.memory) {
          const st = this.memory.settings({ userId: c.userId });
          if (st.enabled) for (const m of this.memory.repo.list(c.userId, 'active')) docs.push({ kind: 'memory', rec: m, title: '', body: m.content });
          else memoryOff = true;
        }
        const found = searchAll(docs, q, limit);
        const view = (x) => {
          const r = x.rec;
          if (x.kind === 'note') return { type: 'note', id: r.id, title: r.title || clip(r.content.split('\n')[0], 60), excerpt: clip(r.content, 300) };
          if (x.kind === 'task') return { type: 'task', id: r.id, title: r.title, due_date: r.due_date, done: r.done };
          if (x.kind === 'reminder') return { type: 'reminder', id: r.id, title: r.title, when: when(r.date, r.time), done: r.done };
          if (x.kind === 'event') return { type: 'event', id: r.id, title: r.title, when: when(r.date, r.start_time) };
          return { type: 'memory', content: clip(r.content, 300) };
        };
        return ok({ query: q, total: found.length, results: found.map(view), memory_off: memoryOff || undefined, note: found.length ? undefined : 'Ничего не найдено. Так и скажи, не придумывай.' },
          { tool: name, kind: 'search', op: 'read', query: clip(q, 60), count: found.length, items: found.map((x) => ({ kind: x.kind, record_id: x.rec.id })) });
      }
      default: throw new HttpError(400, 'unknown_tool', 'Такой функции нет.');
    }
  }

  /* ════ Опасные действия: подготовка (без изменений в базе) ════
   * → { title, verb, items: [{kind, id}], payload } — что именно будет сделано. Цели проверяются здесь же:
   *   чужие и несуществующие записи не попадают в список (для пользователя их «нет»). */
  prepare(name, rawArgs, ctx) {
    const a = rawArgs && typeof rawArgs === 'object' && !Array.isArray(rawArgs) ? rawArgs : {};
    const S = this.tools;
    const max = (ctx.limits && ctx.limits.bulk_max) || 20;
    const own = (ids, get, kind) => {
      const found = [], missing = [];
      for (const id of ids) { try { found.push(get(id)); } catch (e) { if (e instanceof HttpError && e.status === 404) missing.push(id); else throw e; } }
      if (!found.length) throw new HttpError(404, 'not_found', `Не нашёл ${kind === 'task' ? 'таких задач' : kind === 'note' ? 'таких заметок' : kind === 'reminder' ? 'таких напоминаний' : 'таких событий'}. Сначала посмотри список.`);
      return { found, missing };
    };
    switch (name) {
      case 'delete_tasks': {
        let found;
        if (a.completed === true && !(Array.isArray(a.task_ids) && a.task_ids.length)) {
          found = S.listTasks(ctx, { filter: 'completed' });
          if (!found.length) throw new HttpError(404, 'nothing', 'Выполненных задач нет — удалять нечего.');
          if (found.length > max) throw new HttpError(403, 'limit_bulk', `Выполненных задач ${found.length}, а за раз можно удалить ${max}.`);
        } else found = own(idList(a.task_ids, max, 'задачи'), (id) => S.getTask(ctx, id), 'task').found;
        const n = found.length;
        return { title: n === 1 ? `Удалить задачу «${clip(found[0].title, 60)}»?` : `Удалить ${n} ${plural(n, 'задачу', 'задачи', 'задач')}${a.completed === true ? ' (выполненные)' : ''}?`, verb: 'Удалить', count: n, items: found.map((t) => ({ kind: 'task', id: t.id })), payload: { ids: found.map((t) => t.id) } };
      }
      case 'delete_notes': {
        const { found } = own(idList(a.note_ids, max, 'заметки'), (id) => S.getNote(ctx, id), 'note');
        const n = found.length;
        return { title: n === 1 ? `Удалить заметку «${clip(found[0].title || found[0].content.split('\n')[0], 60)}»?` : `Удалить ${n} ${plural(n, 'заметку', 'заметки', 'заметок')}?`, verb: 'Удалить', count: n, items: found.map((x) => ({ kind: 'note', id: x.id })), payload: { ids: found.map((x) => x.id) } };
      }
      case 'delete_reminders': {
        const { found } = own(idList(a.reminder_ids, max, 'напоминания'), (id) => S.getReminder(ctx, id), 'reminder');
        const n = found.length;
        return { title: n === 1 ? `Удалить напоминание «${clip(found[0].title, 60)}»?` : `Удалить ${n} ${plural(n, 'напоминание', 'напоминания', 'напоминаний')}?`, verb: 'Удалить', count: n, items: found.map((x) => ({ kind: 'reminder', id: x.id })), payload: { ids: found.map((x) => x.id) } };
      }
      case 'delete_events': {
        const { found } = own(idList(a.event_ids, max, 'события'), (id) => S.getEvent(ctx, id), 'event');
        const n = found.length;
        return { title: n === 1 ? `Удалить из плана «${clip(found[0].title, 60)}»?` : `Удалить ${n} ${plural(n, 'событие', 'события', 'событий')} из плана?`, verb: 'Удалить', count: n, items: found.map((x) => ({ kind: 'event', id: x.id })), payload: { ids: found.map((x) => x.id) } };
      }
      case 'bulk_update_tasks': {
        const b = applyWhen(a, ctx, { date: 'due_date', time: null });
        const patch = pick(b, ['due_date', 'priority', 'done']);
        if (!Object.keys(patch).length) throw new Clarify('Что изменить в этих задачах: срок, приоритет или отметить выполненными?', ['change']);
        // проверяем значения заранее, чтобы подтверждение не закончилось ошибкой
        S.readTask(patch, { title: 'x', description: '', due_date: null, priority: 'medium' });
        if (has(patch, 'done') && typeof patch.done !== 'boolean') throw new HttpError(400, 'bad_input', 'done: true или false.');
        const { found } = own(idList(b.task_ids, max, 'задачи'), (id) => S.getTask(ctx, id), 'task');
        const n = found.length;
        const what = has(patch, 'due_date') ? `перенести на ${T.humanDate(patch.due_date)}` : has(patch, 'done') ? (patch.done ? 'отметить выполненными' : 'вернуть в работу') : `поставить приоритет ${patch.priority}`;
        return { title: `${what.charAt(0).toUpperCase() + what.slice(1)}: ${n} ${plural(n, 'задачу', 'задачи', 'задач')}?`, verb: 'Применить', count: n, items: found.map((t) => ({ kind: 'task', id: t.id })), payload: { ids: found.map((t) => t.id), patch } };
      }
      case 'clear_chat_history': {
        const n = this.store ? this.store.stats(ctx.userId).conversations : 0;
        return { title: `Очистить всю историю чатов (${n} ${plural(n, 'диалог', 'диалога', 'диалогов')})?`, verb: 'Очистить', count: n, items: [], payload: {}, buttonOnly: true, note: 'Заметки, задачи, напоминания и память останутся.' };
      }
      default: throw new HttpError(400, 'unknown_tool', 'Такой функции нет.');
    }
  }

  /* Выполнить подготовленное опасное действие (после подтверждения). Записи, удалённые за это время, пропускаются. */
  commit(name, payload, ctx) {
    const S = this.tools;
    const R = S.repo;
    const ids = (payload && payload.ids) || [];
    const del = (fn) => S.bulk(ctx, () => { let n = 0; for (const id of ids) if (fn(id, ctx.userId)) n++; return { done: n, skipped: ids.length - n }; });
    switch (name) {
      case 'delete_tasks': return del((id, u) => R.deleteTask(id, u));
      case 'delete_notes': return del((id, u) => R.deleteNote(id, u));
      case 'delete_reminders': return del((id, u) => R.deleteReminder(id, u));
      case 'delete_events': return del((id, u) => R.deleteEvent(id, u));
      case 'bulk_update_tasks': return S.bulk(ctx, () => {
        let n = 0, skipped = 0;
        for (const id of ids) { try { S.updateTask(ctx, id, payload.patch); n++; } catch (e) { if (e instanceof HttpError && e.status === 404) skipped++; else throw e; } }
        return { done: n, skipped };
      });
      default: throw new HttpError(400, 'unknown_tool', 'Такой функции нет.');
    }
  }
}

const toMin = (t) => { const [h, m] = String(t).split(':').map(Number); return h * 60 + m; };
const fromMin = (n) => `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}`;

function ok(forModel, action) { return { ok: true, forModel: { ok: true, ...forModel }, action }; }

/* Короткая пометка о выполненных действиях для истории, которую увидит модель в следующих репликах */
function actionsNote(actions) {
  const lines = (actions || []).map((a) => {
    const r = a.result || a;
    if (r.op === 'failed') return `не удалось (${r.tool}): ${r.error}`;
    if (r.op === 'clarify') return null;
    if (r.kind === 'memory') return memoryNote(r);
    if (r.kind === 'confirm') {
      const st = r.pending_status || 'pending';
      if (st === 'pending') return `ждёт подтверждения пользователя: «${r.title}» (ref ${r.ref}); НЕ выполнено`;
      if (st === 'done') return `подтверждено пользователем и выполнено: «${r.title}»`;
      if (st === 'cancelled') return `пользователь отменил: «${r.title}»`;
      if (st === 'expired') return `не подтверждено вовремя, не выполнено: «${r.title}»`;
      return `не выполнено: «${r.title}»`;
    }
    if (r.kind === 'reminder' && r.op === 'moved') return `напоминание «${r.title}» перенесено на ${r.date} ${r.time}`;
    if (r.kind === 'reminder' && r.op === 'completed') return `напоминание «${r.title}» отмечено выполненным`;
    if (r.kind === 'reminder' && r.op === 'updated') return `напоминание «${r.title}» изменено`;
    if (r.kind === 'reminder') return `создано напоминание «${r.title}» на ${r.date} ${r.time}`;
    if (r.kind === 'task' && r.op === 'completed') return `задача «${r.title}» отмечена выполненной`;
    if (r.kind === 'task' && r.op === 'updated') return `задача «${r.title}» изменена`;
    if (r.kind === 'task' && r.op === 'reopened') return `задача «${r.title}» возвращена в работу`;
    if (r.kind === 'task') return `создана задача «${r.title}»${r.due_date ? ' со сроком ' + r.due_date : ''}`;
    if (r.kind === 'note' && r.op === 'updated') return `заметка «${r.title}» изменена`;
    if (r.kind === 'note') return `сохранена заметка «${r.title}»`;
    if (r.kind === 'event' && r.op === 'moved') return `событие «${r.title}» перенесено на ${r.date} ${r.time}`;
    if (r.kind === 'event' && r.op === 'updated') return `событие «${r.title}» изменено`;
    if (r.kind === 'event') return `в планировщик добавлено «${r.title}» ${r.date} ${r.time}`;
    if (r.op === 'read') return `прочитаны данные (${r.tool})`;
    return null;
  }).filter(Boolean);
  return lines.length ? `[Действия WISP в этом ответе: ${lines.join('; ')}]` : '';
}

module.exports = { AIToolkit, DEFINITIONS, CONFIRM_DEFINITIONS, MAX_CALLS_PER_ROUND, actionsNote, Clarify, KIND, applyWhen, vagueQuestion };
