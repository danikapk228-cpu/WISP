/* WISP · Server · Tools · Repository
 * Все SQL-запросы Layer 4. Каждый запрос содержит user_id из сессии: чужая запись для пользователя
 * просто «не существует» (404), даже если известен её id. Своей базы у инструментов нет: это та же data/wisp.db. */
'use strict';
const crypto = require('node:crypto');

const uid = () => crypto.randomUUID();
const now = () => Date.now();
const bool = (v) => (v ? 1 : 0);

const NOTE_COLS = 'id, title, content, source, created_at, updated_at';
const TASK_COLS = 'id, title, description, due_date, priority, done, completed_at, source, created_at, updated_at';
const REM_COLS = 'id, title, description, remind_at, local_date, local_time, tz, done, done_at, notified_at, source, created_at, updated_at';
const EV_COLS = 'id, title, note, date, start_time, end_time, source, created_at, updated_at';

/* LIKE без спецсимволов: % и _ из запроса ищутся буквально */
const likeArg = (s) => '%' + String(s).replace(/[\\%_]/g, (c) => '\\' + c) + '%';

class ToolsRepo {
  constructor(store) {
    this.store = store;
    const db = store.db;
    const q = (sql) => db.prepare(sql);
    this.q = {
      noteList: q(`SELECT ${NOTE_COLS} FROM notes WHERE user_id = ? ORDER BY updated_at DESC LIMIT ?`),
      noteSearch: q(`SELECT ${NOTE_COLS} FROM notes WHERE user_id = ? AND search LIKE ? ESCAPE '\\' ORDER BY updated_at DESC LIMIT ?`),
      noteGet: q(`SELECT ${NOTE_COLS} FROM notes WHERE id = ? AND user_id = ?`),
      noteCount: q('SELECT COUNT(*) AS n FROM notes WHERE user_id = ?'),
      noteInsert: q('INSERT INTO notes (id, user_id, title, content, search, source, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
      noteUpdate: q('UPDATE notes SET title = ?, content = ?, search = ?, updated_at = ? WHERE id = ? AND user_id = ?'),
      noteDelete: q('DELETE FROM notes WHERE id = ? AND user_id = ?'),

      taskAll: q(`SELECT ${TASK_COLS} FROM tasks WHERE user_id = ? ORDER BY done ASC, CASE WHEN done = 1 THEN -completed_at END ASC, due_date IS NULL, due_date ASC, CASE priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, created_at DESC LIMIT ?`),
      taskByDone: q(`SELECT ${TASK_COLS} FROM tasks WHERE user_id = ? AND done = ? ORDER BY CASE WHEN done = 1 THEN -completed_at END ASC, due_date IS NULL, due_date ASC, CASE priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, created_at DESC LIMIT ?`),
      taskDue: q(`SELECT ${TASK_COLS} FROM tasks WHERE user_id = ? AND done = 0 AND due_date = ? ORDER BY CASE priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, created_at`),
      taskOverdue: q('SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND done = 0 AND due_date IS NOT NULL AND due_date < ?'),
      taskGet: q(`SELECT ${TASK_COLS} FROM tasks WHERE id = ? AND user_id = ?`),
      taskCount: q('SELECT COUNT(*) AS n FROM tasks WHERE user_id = ?'),
      taskActive: q('SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND done = 0'),
      taskInsert: q('INSERT INTO tasks (id, user_id, title, description, due_date, priority, done, completed_at, source, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 0, NULL, ?, ?, ?)'),
      taskUpdate: q('UPDATE tasks SET title = ?, description = ?, due_date = ?, priority = ?, done = ?, completed_at = ?, updated_at = ? WHERE id = ? AND user_id = ?'),
      taskDelete: q('DELETE FROM tasks WHERE id = ? AND user_id = ?'),

      remByDone: q(`SELECT ${REM_COLS} FROM reminders WHERE user_id = ? AND done = ? ORDER BY CASE WHEN done = 1 THEN -done_at ELSE remind_at END ASC LIMIT ?`),
      remAll: q(`SELECT ${REM_COLS} FROM reminders WHERE user_id = ? ORDER BY done ASC, remind_at ASC LIMIT ?`),
      remDay: q(`SELECT ${REM_COLS} FROM reminders WHERE user_id = ? AND remind_at >= ? AND remind_at < ? ORDER BY remind_at`),
      remGet: q(`SELECT ${REM_COLS} FROM reminders WHERE id = ? AND user_id = ?`),
      remActive: q('SELECT COUNT(*) AS n FROM reminders WHERE user_id = ? AND done = 0'),
      remInsert: q('INSERT INTO reminders (id, user_id, title, description, remind_at, local_date, local_time, tz, done, done_at, notified_at, source, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, NULL, NULL, ?, ?, ?)'),
      remUpdate: q('UPDATE reminders SET title = ?, description = ?, remind_at = ?, local_date = ?, local_time = ?, tz = ?, done = ?, done_at = ?, notified_at = ?, updated_at = ? WHERE id = ? AND user_id = ?'),
      remNotified: q('UPDATE reminders SET notified_at = ? WHERE id = ? AND user_id = ? AND notified_at IS NULL'),
      remDelete: q('DELETE FROM reminders WHERE id = ? AND user_id = ?'),

      evDay: q(`SELECT ${EV_COLS} FROM events WHERE user_id = ? AND date = ? ORDER BY start_time, created_at`),
      evDayCount: q('SELECT COUNT(*) AS n FROM events WHERE user_id = ? AND date = ?'),
      evRange: q('SELECT date, COUNT(*) AS n FROM events WHERE user_id = ? AND date >= ? AND date <= ? GROUP BY date'),
      evBetween: q(`SELECT ${EV_COLS} FROM events WHERE user_id = ? AND date >= ? AND date <= ? ORDER BY date, start_time LIMIT ?`),
      evGet: q(`SELECT ${EV_COLS} FROM events WHERE id = ? AND user_id = ?`),
      evInsert: q('INSERT INTO events (id, user_id, title, note, date, start_time, end_time, source, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'),
      evUpdate: q('UPDATE events SET title = ?, note = ?, date = ?, start_time = ?, end_time = ?, updated_at = ? WHERE id = ? AND user_id = ?'),
      evDelete: q('DELETE FROM events WHERE id = ? AND user_id = ?'),

      callInsert: q('INSERT INTO tool_calls (id, user_id, message_id, name, args, status, result, created_at, fingerprint) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'),
      callRecent: q("SELECT id, result, created_at FROM tool_calls WHERE user_id = ? AND fingerprint = ? AND status = 'ok' AND created_at >= ? ORDER BY created_at DESC LIMIT 1"),
      callWritesSince: q("SELECT COUNT(*) AS n FROM tool_calls WHERE user_id = ? AND status = 'ok' AND write = 1 AND created_at >= ?"),
      callMarkWrite: q('UPDATE tool_calls SET write = 1 WHERE id = ?'),
      callsForConv: q('SELECT t.id, t.message_id, t.name, t.status, t.result, t.created_at FROM tool_calls t JOIN messages m ON m.id = t.message_id WHERE m.conversation_id = ? AND t.user_id = ? ORDER BY t.created_at ASC, t.rowid ASC'),
    };
  }

  tx(fn) { return this.store.transaction(fn); }

  /* ── Заметки ── */
  listNotes(userId, { q, limit }) {
    return q ? this.q.noteSearch.all(userId, likeArg(q), limit) : this.q.noteList.all(userId, limit);
  }
  getNote(id, userId) { return this.q.noteGet.get(id, userId) || null; }
  countNotes(userId) { return this.q.noteCount.get(userId).n; }
  insertNote(userId, { title, content, search, source }) {
    const id = uid(), t = now();
    this.q.noteInsert.run(id, userId, title, content, search, source || 'user', t, t);
    return this.getNote(id, userId);
  }
  updateNote(id, userId, { title, content, search }) {
    this.q.noteUpdate.run(title, content, search, now(), id, userId);
    return this.getNote(id, userId);
  }
  deleteNote(id, userId) { return this.q.noteDelete.run(id, userId).changes > 0; }

  /* ── Задачи ── */
  listTasks(userId, { filter, limit }) {
    if (filter === 'active') return this.q.taskByDone.all(userId, 0, limit);
    if (filter === 'completed') return this.q.taskByDone.all(userId, 1, limit);
    return this.q.taskAll.all(userId, limit);
  }
  tasksDue(userId, date) { return this.q.taskDue.all(userId, date); }
  overdueTasks(userId, date) { return this.q.taskOverdue.get(userId, date).n; }
  getTask(id, userId) { return this.q.taskGet.get(id, userId) || null; }
  countTasks(userId) { return this.q.taskCount.get(userId).n; }
  activeTasks(userId) { return this.q.taskActive.get(userId).n; }
  insertTask(userId, t) {
    const id = uid(), ts = now();
    this.q.taskInsert.run(id, userId, t.title, t.description, t.due_date, t.priority, t.source || 'user', ts, ts);
    return this.getTask(id, userId);
  }
  updateTask(id, userId, t) {
    this.q.taskUpdate.run(t.title, t.description, t.due_date, t.priority, bool(t.done), t.completed_at, now(), id, userId);
    return this.getTask(id, userId);
  }
  deleteTask(id, userId) { return this.q.taskDelete.run(id, userId).changes > 0; }

  /* ── Напоминания ── */
  listReminders(userId, { status, limit }) {
    if (status === 'active') return this.q.remByDone.all(userId, 0, limit);
    if (status === 'done') return this.q.remByDone.all(userId, 1, limit);
    return this.q.remAll.all(userId, limit);
  }
  remindersBetween(userId, from, to) { return this.q.remDay.all(userId, from, to); }
  getReminder(id, userId) { return this.q.remGet.get(id, userId) || null; }
  activeReminders(userId) { return this.q.remActive.get(userId).n; }
  insertReminder(userId, r) {
    const id = uid(), t = now();
    this.q.remInsert.run(id, userId, r.title, r.description, r.remind_at, r.local_date, r.local_time, r.tz, r.source || 'user', t, t);
    return this.getReminder(id, userId);
  }
  updateReminder(id, userId, r) {
    this.q.remUpdate.run(r.title, r.description, r.remind_at, r.local_date, r.local_time, r.tz, bool(r.done), r.done_at, r.notified_at, now(), id, userId);
    return this.getReminder(id, userId);
  }
  markNotified(id, userId) { return this.q.remNotified.run(now(), id, userId).changes > 0; }
  deleteReminder(id, userId) { return this.q.remDelete.run(id, userId).changes > 0; }

  /* ── События планировщика ── */
  eventsOn(userId, date) { return this.q.evDay.all(userId, date); }
  countEventsOn(userId, date) { return this.q.evDayCount.get(userId, date).n; }
  eventCounts(userId, from, to) { return this.q.evRange.all(userId, from, to); }
  eventsRange(userId, from, to, limit) { return this.q.evBetween.all(userId, from, to, limit || 500); }
  getEvent(id, userId) { return this.q.evGet.get(id, userId) || null; }
  insertEvent(userId, e) {
    const id = uid(), t = now();
    this.q.evInsert.run(id, userId, e.title, e.note, e.date, e.start_time, e.end_time, e.source || 'user', t, t);
    return this.getEvent(id, userId);
  }
  updateEvent(id, userId, e) {
    this.q.evUpdate.run(e.title, e.note, e.date, e.start_time, e.end_time, now(), id, userId);
    return this.getEvent(id, userId);
  }
  deleteEvent(id, userId) { return this.q.evDelete.run(id, userId).changes > 0; }

  /* ── Журнал действий AI (что сервер реально выполнил по запросу модели) ── */
  logCall(userId, messageId, { name, args, status, result, fingerprint, write }) {
    const id = uid();
    this.q.callInsert.run(id, userId, messageId || null, name, JSON.stringify(args || {}).slice(0, 8000), status, safeJSON(result), now(), fingerprint || null);
    if (write && status === 'ok') this.q.callMarkWrite.run(id);
    return id;
  }
  /* Layer 8: то же действие с теми же аргументами недавно уже выполнено (повтор запроса, «ответить заново») */
  recentCall(userId, fingerprint, sinceMs) {
    const r = this.q.callRecent.get(userId, fingerprint, sinceMs);
    if (!r) return null;
    try { return { id: r.id, result: JSON.parse(r.result), created_at: r.created_at }; } catch (e) { return null; }
  }
  /* Layer 8: сколько изменений сделал AI за период (дневной лимит действий тарифа) */
  writesSince(userId, sinceMs) { return this.q.callWritesSince.get(userId, sinceMs).n; }
  callsForConversation(conversationId, userId) {
    return this.q.callsForConv.all(conversationId, userId).map((r) => {
      let result = {};
      try { result = JSON.parse(r.result); } catch (e) { /* повреждённая запись */ }
      return { id: r.id, message_id: r.message_id, name: r.name, status: r.status, result, created_at: r.created_at };
    });
  }
}

/* Результат действия в журнале: JSON до 8000 символов. Не обрезаем посреди JSON (иначе карточка потеряется):
 * сначала укорачиваем списки, потом длинные строки. */
function safeJSON(v) {
  let s = JSON.stringify(v || {});
  if (s.length <= 8000) return s;
  const o = { ...(v || {}) };
  if (Array.isArray(o.items)) { o.items = o.items.slice(0, 10); s = JSON.stringify(o); }
  if (s.length <= 8000) return s;
  for (const k of Object.keys(o)) if (typeof o[k] === 'string' && o[k].length > 300) o[k] = o[k].slice(0, 299) + '…';
  s = JSON.stringify(o);
  return s.length <= 8000 ? s : JSON.stringify({ tool: o.tool, kind: o.kind, op: o.op, truncated: true });
}

module.exports = { ToolsRepo, likeArg };
