/* WISP · Server · Layer 10 · Access code format
 * Вид кода: WISP-[МЕТКА-]XXXX-XXXX[-XXXX…], например WISP-PLUS-7KQM-H3TD-X9RA, WISP-EARLY-…, WISP-XXXX-XXXX.
 *  · символы тела: 31 знак без похожих (нет I, L, O, 0, 1) → log2(31) ≈ 4.95 бита на символ;
 *  · каждый символ — crypto.randomInt (CSPRNG, без смещения по модулю);
 *  · по умолчанию 3 группы = 12 символов ≈ 59 бит. Минимум 2 группы (≈ 40 бит) — только вместе с лимитами перебора.
 *    Формат «WISP-PLUS-XXXX» (одна группа, ≈ 20 бит, ~900 тыс. вариантов) не генерируется: такой код подбирается.
 *  · в базе хранится только HMAC-SHA256(секрет сервера, каноническая форма). Без секрета утёкшая база не даёт ни кодов,
 *    ни возможности проверить догадку офлайн. Открытый код существует только в выводе команды генерации. */
'use strict';
const crypto = require('node:crypto');

const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const GROUP = 4;
const BODY_RE = new RegExp(`^[${ALPHABET}]{${GROUP}}$`);
const LABEL_RE = /^[A-Z]{2,10}$/;
const MAX_INPUT = 80;

function randomGroup() {
  let s = '';
  for (let i = 0; i < GROUP; i++) s += ALPHABET[crypto.randomInt(ALPHABET.length)];
  return s;
}

/* Новый открытый код */
function generate({ label, groups }) {
  const n = Math.max(2, Math.min(5, groups || 3));
  const parts = ['WISP'];
  if (label) parts.push(label);
  for (let i = 0; i < n; i++) parts.push(randomGroup());
  return parts.join('-');
}

/* Каноническая форма из того, что ввёл человек: регистр, пробелы, любые тире и подчёркивания не важны.
 * Возвращает строку или null (не похоже на код WISP — до базы дело не доходит). */
function canonical(input) {
  if (typeof input !== 'string') return null;
  const raw = input.normalize('NFKC').trim().toUpperCase();
  if (!raw || raw.length > MAX_INPUT) return null;
  const parts = raw.split(/[\s\-_\u2010-\u2015\u2212.]+/).filter(Boolean);
  if (parts.length < 3 || parts[0] !== 'WISP') return null;
  const rest = parts.slice(1);
  let label = null;
  // метка — необязательная первая часть из букв, если после неё остаётся хотя бы 2 группы тела
  if (rest.length >= 3 && LABEL_RE.test(rest[0]) && (!BODY_RE.test(rest[0]) || rest.slice(1).every((g) => BODY_RE.test(g)))) {
    label = rest[0];
  }
  const body = label ? rest.slice(1) : rest;
  if (body.length < 2 || body.length > 5 || !body.every((g) => BODY_RE.test(g))) return null;
  return ['WISP', ...(label ? [label] : []), ...body].join('-');
}

function hash(secret, canonicalCode) {
  return crypto.createHmac('sha256', secret).update('wisp-access-code:v1:' + canonicalCode).digest('hex');
}

/* Короткий отпечаток для журнала (не позволяет восстановить код) */
const fingerprint = (h) => String(h || '').slice(0, 12);

/* Метка в коде: 2–10 латинских букв (PLUS, EARLY, FOUNDER…) */
function validLabel(label) { return label == null || LABEL_RE.test(String(label)); }

module.exports = { ALPHABET, generate, canonical, hash, fingerprint, validLabel, GROUP };
