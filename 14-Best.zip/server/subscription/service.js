/* WISP · Server · Layer 10 · Subscription service
 * Тариф пользователя и коды доступа. Всё решает сервер:
 *  · тариф = действующий период в entitlements (см. repo.js); то, что присылает клиент, нигде не читается;
 *  · активация кода — одна транзакция BEGIN IMMEDIATE: проверка кода, кампании, срока, привязки, повторов,
 *    атомарное списание активации (UPDATE … WHERE uses < max_uses), запись активации, новый период, журнал;
 *  · перебор: неудачные попытки считаются на пользователя и на IP в SQLite (переживают перезапуск), плюс общий
 *    лимит частоты; при блокировке даже верный код не проверяется до конца блокировки;
 *  · истечение: Plus заканчивается в момент expires_at (проверка при каждом запросе), фоновая задача только
 *    записывает «вернулся на Free» в журнал и обновляет кеш. Данные пользователя не трогаются никогда.
 * Типы: plus_7, plus_30, plus_90 — дни Plus (добавляются к концу текущего Plus, а не сгорают); founder — бессрочно. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { HttpError } = require('../lib/http');
const { Throttle } = require('../auth/throttle');
const { SubscriptionRepo } = require('./repo');
const Codes = require('./codes');

const MIN = 60 * 1000;
const DAY = 24 * 60 * MIN;
const KINDS = {
  plus_7: { days: 7, title: 'Plus на 7 дней' },
  plus_30: { days: 30, title: 'Plus на 30 дней' },
  plus_90: { days: 90, title: 'Plus на 90 дней' },
  founder: { days: null, title: 'Founder: бессрочный Plus' },
};
const RULES = {
  redeemUser: { max: 5, windowMs: 15 * MIN, lockMs: 15 * MIN },     // неверные коды одного пользователя
  redeemIp: { max: 20, windowMs: 60 * MIN, lockMs: 60 * MIN },      // один адрес перебирает с разных аккаунтов
  redeemRate: { max: 10, windowMs: 1 * MIN, lockMs: 1 * MIN },      // любые попытки (в том числе верные) — частота
};
const MAX_CODES_PER_BATCH = 10000;

const ipHash = (ip) => crypto.createHash('sha256').update('wisp-ip:' + String(ip || '')).digest('hex').slice(0, 24);

/* Секрет HMAC для кодов. Production: только из WISP_ACCESS_CODE_SECRET. Разработка: если переменной нет, секрет
 * один раз создаётся в data/access-code.secret (права 600) — его же прочитает команда admin. */
function resolveSecret(config, log) {
  const s = config.subscription || {};
  if (s.codeSecret) return s.codeSecret.length >= 32 ? { secret: s.codeSecret } : { secret: null, reason: 'WISP_ACCESS_CODE_SECRET короче 32 символов' };
  if (config.production) return { secret: null, reason: 'в production нужен WISP_ACCESS_CODE_SECRET' };
  const file = path.join(config.dataDir, 'access-code.secret');
  try {
    const v = fs.readFileSync(file, 'utf8').trim();
    if (v.length >= 32) return { secret: v, file };
  } catch (e) { /* создадим */ }
  try {
    fs.mkdirSync(config.dataDir, { recursive: true });
    const v = crypto.randomBytes(32).toString('base64url');
    fs.writeFileSync(file, v + '\n', { mode: 0o600, flag: 'wx' });
    if (log) log.warn(`Создан секрет кодов доступа: ${file}. Для production задай WISP_ACCESS_CODE_SECRET.`);
    return { secret: v, file };
  } catch (e) {
    try { const v = fs.readFileSync(file, 'utf8').trim(); if (v.length >= 32) return { secret: v, file }; } catch (er) { /* нет */ }
    return { secret: null, reason: 'не удалось создать data/access-code.secret' };
  }
}

const deny = (status, code, message, extra) => new HttpError(status, code, message, extra);
const MESSAGES = {
  code_format: 'Код выглядит иначе. Он начинается с WISP-, например WISP-PLUS-XXXX-XXXX-XXXX.',
  code_invalid: 'Такого кода нет. Проверь символы и попробуй ещё раз.',
  code_expired: 'Срок действия этого кода закончился.',
  code_disabled: 'Этот код отключён.',
  code_exhausted: 'У этого кода закончились активации.',
  code_already_redeemed: 'Ты уже активировал этот код.',
  code_campaign_used: 'Код из этой серии ты уже активировал.',
  already_lifetime: 'У тебя уже бессрочный Plus. Код не понадобится, он не потрачен.',
};
const STATUS = { code_format: 400, code_invalid: 400, code_expired: 410, code_disabled: 410, code_exhausted: 409, code_already_redeemed: 409, code_campaign_used: 409, already_lifetime: 409 };
/* Какие отказы считаются попыткой перебора (неверный ввод). «Уже активирован» и «бессрочный» — это настоящий код. */
const COUNTS_AS_FAILURE = new Set(['code_format', 'code_invalid', 'code_expired', 'code_disabled', 'code_exhausted']);

class SubscriptionService {
  constructor({ store, config, log }) {
    this.store = store;
    this.config = config;
    this.log = log || { info() {}, warn() {}, error() {} };
    this.repo = new SubscriptionRepo(store);
    this.throttle = new Throttle(store);
    const sec = resolveSecret(config, this.log);
    this.secret = sec.secret;
    this.secretReason = sec.reason || null;
    if (!this.secret && log) log.warn(`Коды доступа выключены: ${sec.reason}.`);
    const s = config.subscription || {};
    this.allowGuests = !!s.codesForGuests;
    this.timer = null;
  }

  get codesAvailable() { return !!this.secret; }

  /* Фоновая отметка закончившихся периодов (журнал + кеш). Plus перестаёт действовать и без неё. */
  start(intervalMs) {
    this.sweep();
    this.timer = setInterval(() => this.sweep(), intervalMs || MIN);
    this.timer.unref();
  }
  stop() { clearInterval(this.timer); }
  sweep() {
    try {
      const r = this.repo.sweepEnded(Date.now());
      for (const u of r.users) this.log.info('plus ended, back to free', { user: u });
      return r;
    } catch (e) { return { periods: 0, users: [] }; }
  }

  /* ════ Тариф ════ */
  state(userId, t) { return this.repo.state(userId, t); }
  isPlus(userId) { return this.repo.isPlus(userId, Date.now()); }

  /* Выдать Plus (admin / будущая оплата). days → добавляется к концу текущего Plus; lifetime → бессрочно. */
  grant(userId, { days, lifetime, source, sourceRef, actor, details }) {
    if (!this.store.getUser(userId)) throw new Error('Пользователь не найден.');
    return this.repo.tx(() => {
      const t = Date.now();
      const st = this.repo.state(userId, t);
      if (lifetime) return this.repo.grant({ userId, source: source || 'admin', sourceRef, startsAt: t, expiresAt: null, actor, details });
      if (!Number.isInteger(days) || days < 1 || days > 3660) throw new Error('days: от 1 до 3660');
      const start = st.plan === 'plus' && st.expires_at ? st.expires_at : t;
      return this.repo.grant({ userId, source: source || 'admin', sourceRef, startsAt: start, expiresAt: start + days * DAY, actor, details });
    });
  }
  revoke(userId, { actor, reason }) { return this.repo.revokeAll(userId, { actor, reason }); }

  /* Контракт для будущего платёжного провайдера: один оплаченный период = одна запись с уникальной ссылкой
   * (например «stripe:in_123»). Повтор вебхука не создаёт второй период, а обновляет границы. Отмена/возврат → revoke. */
  applyExternalPeriod({ userId, source, sourceRef, startsAt, expiresAt, actor }) {
    if (source !== 'payment') throw new Error('source must be payment');
    if (!sourceRef) throw new Error('sourceRef required');
    return this.repo.tx(() => {
      const cur = this.repo.bySourceRef(source, sourceRef);
      if (cur) {
        if (cur.user_id !== userId) throw new Error('sourceRef belongs to another user');
        this.repo.updatePeriod(cur.id, startsAt, expiresAt);
        this.store.cachePlan(userId, this.repo.isPlus(userId, Date.now()) ? 'plus' : 'free');
        this.repo.audit({ actor: actor || 'billing', action: 'subscription.period_update', target: 'user:' + userId, result: 'ok', reason: source, details: { entitlement: cur.id, starts_at: startsAt, expires_at: expiresAt } });
        return cur.id;
      }
      return this.repo.grant({ userId, source, sourceRef, startsAt, expiresAt, actor: actor || 'billing' });
    });
  }
  revokeExternalPeriod({ source, sourceRef, reason, actor }) {
    const cur = this.repo.bySourceRef(source, sourceRef);
    if (!cur) return false;
    const ok = this.repo.revoke(cur.id, reason || 'refund');
    this.store.cachePlan(cur.user_id, this.repo.isPlus(cur.user_id, Date.now()) ? 'plus' : 'free');
    this.repo.audit({ actor: actor || 'billing', action: 'subscription.period_revoke', target: 'user:' + cur.user_id, result: 'ok', reason: reason || 'refund', details: { entitlement: cur.id } });
    return ok;
  }

  /* ════ Активация кода ════ */
  redeemPolicy(session) {
    if (!this.codesAvailable) return { can: false, reason: 'codes_unavailable' };
    if (session.kind !== 'account' && !this.allowGuests) return { can: false, reason: 'account_required' };
    return { can: true, reason: null };
  }

  redeem({ session, code, ip }) {
    const userId = session.userId;
    const ih = ipHash(ip);
    const actor = 'user:' + userId;
    const policy = this.redeemPolicy(session);
    if (policy.reason === 'codes_unavailable') throw deny(503, 'codes_unavailable', 'Активация кодов на этом сервере не настроена.');
    if (policy.reason === 'account_required') {
      this.repo.audit({ actor, action: 'access_code.redeem', result: 'denied', reason: 'account_required', ipHash: ih });
      throw deny(403, 'account_required', 'Коды доступа активируются в аккаунте: так Plus не потеряется вместе с устройством.');
    }
    const uKey = 'code:u:' + userId, ipKey = 'code:ip:' + ih;
    for (const k of [uKey, ipKey]) {
      const c = this.throttle.check(k);
      if (!c.ok) {
        this.repo.audit({ actor, action: 'access_code.redeem', result: 'denied', reason: 'locked', ipHash: ih });
        throw deny(429, 'code_locked', `Слишком много неверных попыток. Попробуй через ${Math.ceil(c.retryAfter / 60)} мин.`, { retry_after: c.retryAfter });
      }
    }
    if (!this.throttle.hit('code:rate:' + userId, RULES.redeemRate)) {
      throw deny(429, 'rate_limited', 'Слишком часто. Подожди минуту.', { retry_after: 60 });
    }

    const fail = (reason, extra) => {
      let locked = false;
      if (COUNTS_AS_FAILURE.has(reason)) {
        const a = this.throttle.fail(uKey, RULES.redeemUser);
        const b = this.throttle.fail(ipKey, RULES.redeemIp);
        locked = a.locked || b.locked;
      }
      this.repo.audit({ actor, action: 'access_code.redeem', result: 'denied', reason, ipHash: ih, target: extra && extra.target, details: extra && extra.details });
      const left = COUNTS_AS_FAILURE.has(reason) ? Math.max(0, RULES.redeemUser.max - ((this.store.throttleGet(uKey) || {}).count || 0)) : null;
      return deny(STATUS[reason], reason, MESSAGES[reason], { ...(left != null ? { attempts_left: left } : {}), ...(locked ? { locked: true } : {}) });
    };

    const canon = Codes.canonical(code);
    if (!canon) throw fail('code_format');
    const h = Codes.hash(this.secret, canon);
    const fp = Codes.fingerprint(h);

    let outcome;
    try {
      outcome = this.repo.tx(() => {
        const t = Date.now();
        const c = this.repo.codeByHash(h);
        if (!c) return { reason: 'code_invalid' };
        // код, привязанный к другому человеку, для остальных «не существует»
        if (c.bound_user_id && c.bound_user_id !== userId) return { reason: 'code_invalid' };
        const cmp = this.repo.campaign(c.campaign_id);
        if (!cmp) return { reason: 'code_invalid' };
        const target = 'code:' + c.id;
        if (cmp.disabled_at || c.disabled_at) return { reason: 'code_disabled', target };
        const until = c.expires_at || cmp.redeem_until;
        if (until && until <= t) return { reason: 'code_expired', target };
        if (this.repo.redeemedByUser(c.id, userId)) return { reason: 'code_already_redeemed', target };
        if (this.repo.campaignUsedByUser(cmp.id, userId)) return { reason: 'code_campaign_used', target };
        const st = this.repo.state(userId, t);
        if (st.lifetime) return { reason: 'already_lifetime', target };
        if (!this.repo.useCode(c.id)) return { reason: 'code_exhausted', target };
        const kind = KINDS[cmp.kind];
        const startsAt = kind.days == null ? t : (st.plan === 'plus' && st.expires_at ? st.expires_at : t);
        const expiresAt = kind.days == null ? null : startsAt + kind.days * DAY;
        const redemptionId = crypto.randomUUID();
        const entId = this.repo.grant({ userId, source: 'access_code', sourceRef: redemptionId, startsAt, expiresAt, actor, details: { code: c.id, campaign: cmp.id, kind: cmp.kind } });
        this.repo.q.redInsert.run(redemptionId, c.id, cmp.id, userId, entId, cmp.kind, startsAt, expiresAt, t);
        this.repo.audit({ actor, action: 'access_code.redeem', target, result: 'ok', reason: cmp.kind, ipHash: ih, details: { campaign: cmp.id, fp, entitlement: entId } });
        return { ok: true, kind: cmp.kind, startsAt, expiresAt, campaign: cmp };
      });
    } catch (e) {
      // UNIQUE-ограничения — последний рубеж от гонки двух одинаковых запросов одного пользователя
      if (/UNIQUE/i.test(String(e && e.message))) throw fail('code_already_redeemed');
      this.repo.audit({ actor, action: 'access_code.redeem', result: 'error', reason: 'server_error', ipHash: ih });
      throw e;
    }
    if (!outcome.ok) throw fail(outcome.reason, { target: outcome.target, details: { fp } });
    this.throttle.reset(uKey);
    this.log.info('access code redeemed', { user: userId, kind: outcome.kind });
    return {
      ok: true,
      kind: outcome.kind,
      title: KINDS[outcome.kind].title,
      added_days: KINDS[outcome.kind].days,
      lifetime: KINDS[outcome.kind].days == null,
      starts_at: outcome.startsAt,
      expires_at: outcome.expiresAt,
    };
  }

  history(userId) {
    return this.repo.redemptionsOfUser(userId, 20).map((r) => ({
      id: r.id, kind: r.kind, title: (KINDS[r.kind] || {}).title || r.kind, label: r.label || null,
      at: r.created_at, starts_at: r.starts_at, expires_at: r.expires_at,
    }));
  }

  /* ════ Администрирование (только server/admin.js — публичного API нет) ════ */
  requireSecret() { if (!this.secret) throw new Error(`Коды доступа выключены: ${this.secretReason}.`); }

  createCampaign({ name, kind, label, groups, count, usesPerCode, redeemUntil, note, bindUserId, actor }) {
    this.requireSecret();
    if (!KINDS[kind]) throw new Error('Тип: plus_7 | plus_30 | plus_90 | founder');
    const nm = String(name || '').trim().slice(0, 80);
    if (!nm) throw new Error('Нужно название кампании (--name).');
    const lb = label ? String(label).toUpperCase() : null;
    if (!Codes.validLabel(lb)) throw new Error('Метка: 2–10 латинских букв (PLUS, EARLY…).');
    const g = groups == null ? 3 : Number(groups);
    if (!Number.isInteger(g) || g < 2 || g > 5) throw new Error('Групп в коде: от 2 до 5 (по умолчанию 3).');
    const n = count == null ? 1 : Number(count);
    if (!Number.isInteger(n) || n < 0 || n > MAX_CODES_PER_BATCH) throw new Error(`Кодов за раз: от 0 до ${MAX_CODES_PER_BATCH}.`);
    const uses = usesPerCode == null ? 1 : Number(usesPerCode);
    if (!Number.isInteger(uses) || uses < 1 || uses > 1000000) throw new Error('Активаций на код: от 1.');
    if (bindUserId && (n !== 1 || uses !== 1)) throw new Error('Привязанный к пользователю код — один код на одну активацию.');
    if (redeemUntil != null && (!Number.isFinite(redeemUntil) || redeemUntil <= Date.now())) throw new Error('Срок кодов должен быть в будущем.');
    return this.repo.tx(() => {
      const cmp = this.repo.createCampaign({ name: nm, kind, label: lb, groups: g, usesPerCode: uses, redeemUntil: redeemUntil || null, note: note ? String(note).slice(0, 300) : null, actor: actor || 'admin:cli' });
      const codes = this.insertCodes(cmp, n, { bindUserId, maxUses: uses });
      this.repo.audit({ actor: actor || 'admin:cli', action: 'campaign.create', target: 'campaign:' + cmp.id, result: 'ok', reason: kind,
        details: { name: nm, codes: n, uses_per_code: uses, redeem_until: redeemUntil || null, label: lb, groups: g, bound: bindUserId ? 'user:' + bindUserId : null } });
      return { campaign: cmp, codes };
    });
  }

  addCodes(campaignId, { count, bindUserId, usesPerCode, expiresAt, actor }) {
    this.requireSecret();
    const cmp = this.repo.findCampaign(campaignId);
    if (!cmp) throw new Error('Кампания не найдена.');
    if (cmp.disabled_at) throw new Error('Кампания отключена.');
    const n = Number(count || 1);
    if (!Number.isInteger(n) || n < 1 || n > MAX_CODES_PER_BATCH) throw new Error(`Кодов за раз: от 1 до ${MAX_CODES_PER_BATCH}.`);
    const uses = usesPerCode == null ? cmp.uses_per_code : Number(usesPerCode);
    if (bindUserId && (n !== 1 || uses !== 1)) throw new Error('Привязанный к пользователю код — один код на одну активацию.');
    return this.repo.tx(() => {
      const codes = this.insertCodes(cmp, n, { bindUserId, maxUses: uses, expiresAt });
      this.repo.audit({ actor: actor || 'admin:cli', action: 'campaign.codes_add', target: 'campaign:' + cmp.id, result: 'ok', details: { codes: n, uses_per_code: uses, bound: bindUserId ? 'user:' + bindUserId : null } });
      return { campaign: cmp, codes };
    });
  }

  insertCodes(cmp, n, { bindUserId, maxUses, expiresAt }) {
    const out = [];
    for (let i = 0; i < n; i++) {
      for (let attempt = 0; ; attempt++) {
        const plain = Codes.generate({ label: cmp.label, groups: cmp.groups_n });
        const h = Codes.hash(this.secret, Codes.canonical(plain));
        if (this.repo.codeByHash(h)) { if (attempt > 5) throw new Error('collision'); continue; }
        const id = this.repo.insertCode({ campaignId: cmp.id, codeHash: h, maxUses, boundUserId: bindUserId || null, expiresAt: expiresAt || null });
        out.push({ id, code: plain });
        break;
      }
    }
    return out;
  }

  campaignInfo(idOrPrefix) {
    const cmp = this.repo.findCampaign(idOrPrefix);
    if (!cmp) return null;
    const list = this.repo.campaigns(100000).find((c) => c.id === cmp.id) || cmp;
    return { campaign: list, codes: this.repo.codesOf(cmp.id, 5000) };
  }
  setCampaignEnabled(idOrPrefix, enabled, { actor, reason } = {}) {
    const cmp = this.repo.findCampaign(idOrPrefix);
    if (!cmp) throw new Error('Кампания не найдена.');
    const changed = enabled ? this.repo.enableCampaign(cmp.id) : this.repo.disableCampaign(cmp.id, reason);
    this.repo.audit({ actor: actor || 'admin:cli', action: enabled ? 'campaign.enable' : 'campaign.disable', target: 'campaign:' + cmp.id, result: 'ok', reason: reason || null, details: { changed } });
    return { campaign: this.repo.campaign(cmp.id), changed };
  }
  setCodeEnabled(idOrPrefix, enabled, { actor } = {}) {
    const c = this.repo.findCode(idOrPrefix);
    if (!c) throw new Error('Код не найден.');
    const changed = enabled ? this.repo.enableCode(c.id) : this.repo.disableCode(c.id);
    this.repo.audit({ actor: actor || 'admin:cli', action: enabled ? 'code.enable' : 'code.disable', target: 'code:' + c.id, result: 'ok', details: { changed } });
    return { code: this.repo.code(c.id), changed };
  }
  /* Найти код по открытому значению (например, пользователь прислал его в поддержку) */
  lookupCode(plain) {
    this.requireSecret();
    const canon = Codes.canonical(plain);
    if (!canon) return null;
    const c = this.repo.codeByHash(Codes.hash(this.secret, canon));
    return c ? { code: c, campaign: this.repo.campaign(c.campaign_id) } : null;
  }
}

module.exports = { SubscriptionService, KINDS, RULES, resolveSecret, ipHash };
