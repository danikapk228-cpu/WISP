/* WISP · Server · Layer 10 · Subscription repository
 * Весь SQL тарифов и кодов доступа. Таблицы создаёт server/lib/db.js (SCHEMA, миграция v8).
 *  · entitlements — периоды Plus. Действующий тариф = есть период, который начался, не истёк и не отозван;
 *  · access_campaigns / access_codes / access_redemptions — коды доступа (только HMAC кода);
 *  · audit_log — журнал операций.
 * Все запросы, касающиеся пользователя, содержат user_id. Методы, меняющие несколько таблиц, вызываются внутри
 * store.transaction() (BEGIN IMMEDIATE): одна активация — одно списание и один период, даже при гонке запросов. */
'use strict';
const crypto = require('node:crypto');

const now = () => Date.now();
const uid = () => crypto.randomUUID();
const SHORT = 'abcdefghjkmnpqrstuvwxyz23456789';
const shortId = (prefix, n) => prefix + Array.from({ length: n || 10 }, () => SHORT[crypto.randomInt(SHORT.length)]).join('');

const ACTIVE = `revoked_at IS NULL AND starts_at <= $t AND (expires_at IS NULL OR expires_at > $t)`;
const ENT_COLS = 'id, user_id, plan, source, source_ref, starts_at, expires_at, revoked_at, revoked_reason, created_at';

class SubscriptionRepo {
  constructor(store) {
    this.store = store;
    const db = store.db;
    const q = (sql) => db.prepare(sql);
    this.q = {
      /* ── entitlements ── */
      isPlus: q(`SELECT EXISTS (SELECT 1 FROM entitlements WHERE user_id = $u AND plan = 'plus' AND ${ACTIVE}) AS on_`),
      entCurrentAndFuture: q(`SELECT ${ENT_COLS} FROM entitlements WHERE user_id = $u AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > $t) ORDER BY starts_at ASC`),
      entAll: q(`SELECT ${ENT_COLS} FROM entitlements WHERE user_id = ? ORDER BY created_at DESC LIMIT ?`),
      entInsert: q('INSERT INTO entitlements (id, user_id, plan, source, source_ref, starts_at, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
      entBySourceRef: q(`SELECT ${ENT_COLS} FROM entitlements WHERE source = ? AND source_ref = ?`),
      entUpdatePeriod: q('UPDATE entitlements SET starts_at = ?, expires_at = ?, revoked_at = NULL, revoked_reason = NULL WHERE id = ?'),
      entRevokeAll: q(`UPDATE entitlements SET revoked_at = $t, revoked_reason = $r WHERE user_id = $u AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > $t)`),
      entRevoke: q('UPDATE entitlements SET revoked_at = ?, revoked_reason = ? WHERE id = ? AND revoked_at IS NULL'),
      /* закончившиеся периоды, о которых ещё не записано в журнал (для автоматического возврата на Free) */
      entEnded: q(`SELECT id, user_id, expires_at FROM entitlements WHERE ended_logged_at IS NULL AND revoked_at IS NULL AND expires_at IS NOT NULL AND expires_at <= ? LIMIT 500`),
      entMarkLogged: q('UPDATE entitlements SET ended_logged_at = ? WHERE id = ?'),

      /* ── кампании ── */
      cmpInsert: q('INSERT INTO access_campaigns (id, name, kind, label, groups_n, uses_per_code, redeem_until, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'),
      cmpGet: q('SELECT * FROM access_campaigns WHERE id = ?'),
      cmpFind: q("SELECT * FROM access_campaigns WHERE id LIKE ? ESCAPE '\\' LIMIT 2"),
      cmpList: q(`SELECT c.*,
                    (SELECT COUNT(*) FROM access_codes k WHERE k.campaign_id = c.id) AS codes,
                    (SELECT COUNT(*) FROM access_codes k WHERE k.campaign_id = c.id AND k.disabled_at IS NULL AND k.uses < k.max_uses) AS codes_left,
                    (SELECT COUNT(*) FROM access_redemptions r WHERE r.campaign_id = c.id) AS redemptions
                  FROM access_campaigns c ORDER BY c.created_at DESC LIMIT ?`),
      cmpDisable: q('UPDATE access_campaigns SET disabled_at = ?, disabled_reason = ? WHERE id = ? AND disabled_at IS NULL'),
      cmpEnable: q('UPDATE access_campaigns SET disabled_at = NULL, disabled_reason = NULL WHERE id = ? AND disabled_at IS NOT NULL'),

      /* ── коды ── */
      codeInsert: q('INSERT INTO access_codes (id, campaign_id, code_hash, max_uses, bound_user_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'),
      codeByHash: q('SELECT * FROM access_codes WHERE code_hash = ?'),
      codeGet: q('SELECT * FROM access_codes WHERE id = ?'),
      codeFind: q("SELECT * FROM access_codes WHERE id LIKE ? ESCAPE '\\' LIMIT 2"),
      codesOf: q('SELECT id, max_uses, uses, bound_user_id, expires_at, disabled_at, created_at FROM access_codes WHERE campaign_id = ? ORDER BY created_at ASC, id ASC LIMIT ?'),
      /* атомарное списание активации: условие в самом UPDATE, а не в отдельной проверке */
      codeUse: q('UPDATE access_codes SET uses = uses + 1 WHERE id = ? AND uses < max_uses AND disabled_at IS NULL'),
      codeDisable: q('UPDATE access_codes SET disabled_at = ? WHERE id = ? AND disabled_at IS NULL'),
      codeEnable: q('UPDATE access_codes SET disabled_at = NULL WHERE id = ? AND disabled_at IS NOT NULL'),

      /* ── активации ── */
      redInsert: q('INSERT INTO access_redemptions (id, code_id, campaign_id, user_id, entitlement_id, kind, starts_at, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'),
      redByCodeUser: q('SELECT id FROM access_redemptions WHERE code_id = ? AND user_id = ?'),
      redByCampaignUser: q('SELECT id FROM access_redemptions WHERE campaign_id = ? AND user_id = ?'),
      redOfUser: q(`SELECT r.id, r.kind, r.starts_at, r.expires_at, r.created_at, c.label FROM access_redemptions r
                    JOIN access_campaigns c ON c.id = r.campaign_id WHERE r.user_id = ? ORDER BY r.created_at DESC LIMIT ?`),
      redList: q(`SELECT r.id, r.code_id, r.campaign_id, r.user_id, r.kind, r.starts_at, r.expires_at, r.created_at, c.name AS campaign_name, u.email
                  FROM access_redemptions r JOIN access_campaigns c ON c.id = r.campaign_id LEFT JOIN users u ON u.id = r.user_id
                  WHERE ($c IS NULL OR r.campaign_id = $c) AND ($u IS NULL OR r.user_id = $u)
                  ORDER BY r.created_at DESC LIMIT $n`),

      /* ── журнал ── */
      auditInsert: q('INSERT INTO audit_log (at, actor, action, target, result, reason, ip_hash, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
      auditList: q(`SELECT id, at, actor, action, target, result, reason, details FROM audit_log
                    WHERE ($a IS NULL OR action LIKE $a) AND ($who IS NULL OR actor = $who OR target = $who) ORDER BY id DESC LIMIT $n`),
    };
  }

  tx(fn) { return this.store.transaction(fn); }

  /* ════ Журнал ════ */
  audit({ actor, action, target, result, reason, ipHash, details }) {
    this.q.auditInsert.run(now(), actor || 'system', action, target || null, result || 'ok', reason || null, ipHash || null, details ? JSON.stringify(details) : null);
  }
  auditList({ action, who, limit } = {}) {
    return this.q.auditList.all({ a: action ? action.replace(/\*/g, '%') : null, who: who || null, n: limit || 50 })
      .map((r) => ({ ...r, details: r.details ? safeJSON(r.details) : null }));
  }

  /* ════ Периоды Plus ════ */
  isPlus(userId, t) { return !!this.q.isPlus.get({ u: userId, t: t || now() }).on_; }

  /* Состояние подписки: непрерывная цепочка периодов, начиная с текущего момента.
   * expires_at — когда Plus закончится, если ничего не продлевать; lifetime — бессрочно. */
  state(userId, t) {
    const at = t || now();
    const rows = this.q.entCurrentAndFuture.all({ u: userId, t: at });
    const active = rows.filter((r) => r.starts_at <= at);
    if (!active.length) {
      const next = rows[0] || null;
      return { plan: 'free', status: 'free', lifetime: false, started_at: null, expires_at: null, source: null, scheduled_from: next ? next.starts_at : null };
    }
    let end = at, lifetime = false;
    const sorted = rows.slice().sort((a, b) => a.starts_at - b.starts_at);
    for (const r of sorted) {
      if (r.starts_at > end + 1000) break;                     // разрыв: следующий период не продолжает текущий
      if (r.expires_at == null) { lifetime = true; break; }
      if (r.expires_at > end) end = r.expires_at;
    }
    const current = active.find((r) => r.expires_at == null) || active.slice().sort((a, b) => (b.expires_at || 0) - (a.expires_at || 0))[0];
    return {
      plan: 'plus',
      status: lifetime ? 'lifetime' : 'active',
      lifetime,
      started_at: Math.min(...active.map((r) => r.starts_at)),
      expires_at: lifetime ? null : end,
      source: current.source,
      scheduled_from: null,
    };
  }

  /* Новый период. starts_at/expires_at уже посчитаны вызывающим (см. AccessCodes.redeem / Entitlements.grant). */
  grant({ userId, source, sourceRef, startsAt, expiresAt, actor, details }) {
    const id = uid(), t = now();
    this.q.entInsert.run(id, userId, 'plus', source, sourceRef || null, startsAt, expiresAt == null ? null : expiresAt, t);
    this.store.cachePlan(userId, this.isPlus(userId, t) ? 'plus' : 'free');
    this.audit({ actor: actor || 'system', action: 'subscription.grant', target: 'user:' + userId, result: 'ok', reason: source,
      details: { entitlement: id, starts_at: startsAt, expires_at: expiresAt == null ? null : expiresAt, ...(details || {}) } });
    return id;
  }
  bySourceRef(source, ref) { return this.q.entBySourceRef.get(source, ref) || null; }
  updatePeriod(id, startsAt, expiresAt) { this.q.entUpdatePeriod.run(startsAt, expiresAt == null ? null : expiresAt, id); }
  revoke(id, reason) { return this.q.entRevoke.run(now(), reason || null, id).changes > 0; }
  revokeAll(userId, { actor, reason } = {}) {
    const t = now();
    const n = this.q.entRevokeAll.run({ t, r: reason || null, u: userId }).changes;
    this.store.cachePlan(userId, this.isPlus(userId, t) ? 'plus' : 'free');
    this.audit({ actor: actor || 'system', action: 'subscription.revoke', target: 'user:' + userId, result: 'ok', reason: reason || null, details: { periods: n } });
    return n;
  }
  entitlementsOf(userId, limit) { return this.q.entAll.all(userId, limit || 50); }
  /* Закончившиеся периоды: отметить, обновить кеш, записать в журнал «вернулся на Free» */
  sweepEnded(t) {
    const at = t || now();
    const rows = this.q.entEnded.all(at);
    const users = new Set();
    for (const r of rows) { this.q.entMarkLogged.run(at, r.id); users.add(r.user_id); }
    const back = [];
    for (const u of users) {
      if (this.isPlus(u, at)) continue;
      this.store.cachePlan(u, 'free');
      this.audit({ actor: 'system', action: 'subscription.expired', target: 'user:' + u, result: 'ok', reason: 'period_ended' });
      back.push(u);
    }
    return { periods: rows.length, users: back };
  }

  /* ════ Кампании и коды ════ */
  createCampaign({ name, kind, label, groups, usesPerCode, redeemUntil, note, actor }) {
    const id = shortId('cmp_', 8), t = now();
    this.q.cmpInsert.run(id, name, kind, label || null, groups, usesPerCode, redeemUntil || null, note || null, actor || 'admin:cli', t);
    return this.campaign(id);
  }
  campaign(id) { return this.q.cmpGet.get(id) || null; }
  /* id целиком или его начало (удобно в CLI). Неоднозначное начало = не найдено. */
  findCampaign(idOrPrefix) {
    const exact = this.campaign(idOrPrefix);
    if (exact) return exact;
    const rows = this.q.cmpFind.all(likePrefix(idOrPrefix));
    return rows.length === 1 ? rows[0] : null;
  }
  campaigns(limit) { return this.q.cmpList.all(limit || 100); }
  disableCampaign(id, reason) { return this.q.cmpDisable.run(now(), reason || null, id).changes > 0; }
  enableCampaign(id) { return this.q.cmpEnable.run(id).changes > 0; }

  insertCode({ campaignId, codeHash, maxUses, boundUserId, expiresAt }) {
    const id = shortId('code_', 10);
    this.q.codeInsert.run(id, campaignId, codeHash, maxUses, boundUserId || null, expiresAt || null, now());
    return id;
  }
  codeByHash(hash) { return this.q.codeByHash.get(hash) || null; }
  code(id) { return this.q.codeGet.get(id) || null; }
  findCode(idOrPrefix) {
    const exact = this.code(idOrPrefix);
    if (exact) return exact;
    const rows = this.q.codeFind.all(likePrefix(idOrPrefix));
    return rows.length === 1 ? rows[0] : null;
  }
  codesOf(campaignId, limit) { return this.q.codesOf.all(campaignId, limit || 1000); }
  useCode(id) { return this.q.codeUse.run(id).changes > 0; }
  disableCode(id) { return this.q.codeDisable.run(now(), id).changes > 0; }
  enableCode(id) { return this.q.codeEnable.run(id).changes > 0; }

  redeemedByUser(codeId, userId) { return !!this.q.redByCodeUser.get(codeId, userId); }
  campaignUsedByUser(campaignId, userId) { return !!this.q.redByCampaignUser.get(campaignId, userId); }
  insertRedemption({ codeId, campaignId, userId, entitlementId, kind, startsAt, expiresAt }) {
    const id = uid();
    this.q.redInsert.run(id, codeId, campaignId, userId, entitlementId || null, kind, startsAt, expiresAt == null ? null : expiresAt, now());
    return id;
  }
  redemptionsOfUser(userId, limit) { return this.q.redOfUser.all(userId, limit || 20); }
  redemptions({ campaignId, userId, limit } = {}) { return this.q.redList.all({ c: campaignId || null, u: userId || null, n: limit || 100 }); }
}

function likePrefix(s) { return String(s || '').replace(/[\\%_]/g, (m) => '\\' + m) + '%'; }
function safeJSON(s) { try { return JSON.parse(s); } catch (e) { return null; } }

module.exports = { SubscriptionRepo, shortId };
