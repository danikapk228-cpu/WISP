/* WISP · Server · Layer 10 · Quota (централизованные лимиты)
 * Одно место, где собраны все лимиты тарифа и их использование:
 *  · ai       — сообщения AI за сутки (usage_daily, Layer 3);
 *  · voice    — распознавание речи и озвучка за сутки (voice_usage, Layer 7);
 *  · memory   — сколько фактов хранится (memories, Layer 5);
 *  · actions  — изменения, сделанные AI за сутки (tool_calls.write, Layer 8);
 *  · images   — изображения, отправленные на анализ за сутки (attachments, Layer 3).
 * Числа берутся только из server/config/plans.json (или WISP_PLANS_FILE) — те же, что применяют сервисы слоёв.
 * Проверки по-прежнему выполняют сами слои; здесь — сводка для экрана Subscription и новый лимит images_daily.
 * Сутки — по UTC, как во всех лимитах WISP. */
'use strict';
const { HttpError } = require('../lib/http');
const { dayKey, nextReset } = require('../lib/limits');

const startOfUtcDay = (t) => { const d = new Date(t || Date.now()); d.setUTCHours(0, 0, 0, 0); return d.getTime(); };

class Quota {
  constructor({ store, config, limits, voice, engine, memoryService, tools }) {
    this.store = store;
    this.config = config;
    this.limits = limits;
    this.voice = voice;
    this.engine = engine;
    this.memoryService = memoryService;
    this.tools = tools;
    this.warnRatio = (config.subscription && config.subscription.warnRatio) || 0.8;
    this.q = {
      imagesSince: store.db.prepare('SELECT COUNT(*) AS n FROM attachments WHERE user_id = ? AND created_at >= ?'),
    };
  }

  /* Лимиты тарифа целиком (для сравнения Free / Plus). Только числа из конфигурации, ничего не придумывается. */
  planLimits(planId) {
    const p = this.limits.plan(planId);
    return {
      title: p.title,
      daily_requests: p.daily_requests,
      per_minute: p.per_minute,
      history_tokens: p.history_tokens,
      max_output_tokens: p.max_output_tokens,
      max_input_chars: p.max_input_chars,
      max_images_per_message: p.max_images_per_message,
      images_daily: p.vision && Number.isInteger(p.vision.images_daily) ? p.vision.images_daily : null,
      tools: this.tools ? this.tools.limits(planId) : null,
      memory: this.memoryService ? this.memoryService.limits(planId) : null,
      voice: this.voice ? this.voice.limits(planId) : null,
      actions: this.engine ? this.engine.limits(planId) : null,
    };
  }

  imagesToday(userId) { return this.q.imagesSince.get(userId, startOfUtcDay()).n; }

  /* Layer 10: необязательный дневной лимит изображений (plans.json → vision.images_daily; null = без отдельного лимита) */
  checkImages(session, count) {
    const L = this.planLimits(session.plan);
    if (L.images_daily == null || !count) return;
    const used = this.imagesToday(session.userId);
    if (used + count > L.images_daily) {
      throw new HttpError(429, 'limit_images', `Лимит анализа изображений на сегодня исчерпан (${L.images_daily}).`, { limit: L.images_daily, used, reset_at: nextReset(), plan: session.plan });
    }
  }

  meter(id, label, unit, used, limit, period, extra) {
    const lim = Number.isFinite(limit) ? limit : null;
    const ratio = lim ? Math.min(1, used / lim) : 0;
    return {
      id, label, unit, used,
      limit: lim,
      remaining: lim == null ? null : Math.max(0, lim - used),
      ratio: Math.round(ratio * 1000) / 1000,
      period,                                         // day — обновляется в reset_at; total — хранится, не обновляется
      reset_at: period === 'day' ? nextReset() : null,
      warn: lim != null && ratio >= this.warnRatio && used < lim,
      exhausted: lim != null && used >= lim,
      available: true,
      ...(extra || {}),
    };
  }

  /* Использование для экрана Subscription (userId и тариф — из сессии) */
  meters(session) {
    const { userId, plan } = session;
    const L = this.planLimits(plan);
    const out = [];
    const ai = this.limits.usage(userId, plan);
    out.push(this.meter('ai', 'Сообщения WISP', 'сообщений', ai.used, ai.limit, 'day'));
    if (this.voice) {
      const v = this.voice.status(userId, plan);
      out.push(this.meter('voice_stt', 'Распознавание речи', 'запросов', v.stt.used, v.stt.limit, 'day', v.stt.available ? null : { available: false, note: 'Голос не подключён на сервере' }));
      out.push(this.meter('voice_tts', 'Озвучка ответов', 'символов', v.tts.used, v.tts.limit, 'day', v.tts.available ? null : { available: false, note: 'Озвучка не подключена на сервере' }));
    }
    if (this.engine && this.tools) {
      const used = this.tools.repo.writesSince(userId, startOfUtcDay());
      out.push(this.meter('actions', 'Действия AI', 'изменений', used, L.actions.writes_per_day, 'day'));
    }
    if (this.memoryService) {
      const used = this.memoryService.repo.count(userId, 'active');
      out.push(this.meter('memory', 'Память', 'фактов', used, L.memory.items_max, 'total'));
    }
    const img = this.imagesToday(userId);
    out.push(this.meter('images', 'Анализ изображений', 'изображений', img, L.images_daily, 'day',
      L.images_daily == null ? { note: `Без отдельного лимита: до ${L.max_images_per_message} в сообщении, в пределах сообщений WISP` } : null));
    return out;
  }
}

module.exports = { Quota, startOfUtcDay, dayKey };
