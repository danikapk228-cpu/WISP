/* WISP · Server · Layer 10 · Cost estimate
 * Оценка стоимости тарифа ДО изменения лимитов: npm run admin -- costs
 * Цены провайдеров меняются, поэтому в проекте их нет: заполни server/config/costs.json (или WISP_COSTS_FILE)
 * по актуальным страницам цен. Пока цены пустые, оценка честно пишет «нет цены», а не придумывает число.
 *
 * Худший случай за месяц (пользователь выбирает весь лимит каждый день):
 *   AI    = daily_requests × days × (вход × цена_входа + выход × цена_выхода), модель по умолчанию для тарифа;
 *           вход ≈ history_tokens + max_input_chars / 4, выход = max_output_tokens (или средние из assumptions);
 *   голос = stt_daily × stt_max_seconds / 60 × цена_минуты × days + tts_chars_daily × days × цена / 1e6;
 *   инфраструктура = infrastructure_per_user_month.
 * «Типичный» = худший × typical_usage_share. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');

function loadCosts(config) {
  const file = process.env.WISP_COSTS_FILE ? path.resolve(config.root, process.env.WISP_COSTS_FILE) : path.join(__dirname, '..', 'config', 'costs.json');
  try { return { file, data: JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch (e) { return { file, data: null, error: e.message }; }
}

const num = (v) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : null);

function estimate(config, costs, planId) {
  const p = config.plans[planId] || {};
  const A = (costs && costs.assumptions) || {};
  const days = num(A.days_per_month) || 30;
  const modelId = (config.defaultModel || {})[planId] || (config.defaultModel || {}).free;
  const price = ((costs && costs.models) || {})[modelId] || {};
  const inTok = num(A.avg_input_tokens_per_request) ?? ((p.history_tokens || 0) + Math.round((p.max_input_chars || 0) / 4));
  const outTok = num(A.avg_output_tokens_per_request) ?? (p.max_output_tokens || 0);
  const reqMonth = (p.daily_requests || 0) * days;
  const lines = [];
  let total = 0, missing = [];
  const pin = num(price.input_per_mtok), pout = num(price.output_per_mtok);
  if (pin == null || pout == null) missing.push(`цена модели ${modelId}`);
  else { const v = reqMonth * (inTok * pin + outTok * pout) / 1e6; total += v; lines.push(['AI', v, `${reqMonth} запросов × (${inTok} вх + ${outTok} вых) токенов, модель ${modelId}`]); }
  const V = p.voice || {};
  const vp = (costs && costs.voice) || {};
  if (V.stt_daily) {
    const pm = num(vp.stt_per_minute);
    if (pm == null) missing.push('цена распознавания речи');
    else { const v = V.stt_daily * (V.stt_max_seconds || 60) / 60 * pm * days; total += v; lines.push(['STT', v, `${V.stt_daily}/день × до ${V.stt_max_seconds} с`]); }
  }
  if (V.tts_chars_daily) {
    const pc = num(vp.tts_per_mchars);
    if (pc == null) missing.push('цена озвучки');
    else { const v = V.tts_chars_daily * days * pc / 1e6; total += v; lines.push(['TTS', v, `${V.tts_chars_daily} символов/день`]); }
  }
  const infra = num(costs && costs.infrastructure_per_user_month);
  if (infra == null) missing.push('инфраструктура на пользователя');
  else { total += infra; lines.push(['Инфраструктура', infra, 'в месяц']); }
  const share = num(A.typical_usage_share) ?? 0.15;
  return { plan: planId, model: modelId, currency: (costs && costs.currency) || 'USD', lines, worst: total, typical: total * share, share, missing };
}

function report(config) {
  const { file, data, error } = loadCosts(config);
  const out = [];
  out.push(`Файл цен: ${file}${error ? ` (не прочитан: ${error})` : ''}`);
  for (const plan of ['free', 'plus']) {
    if (!config.plans[plan]) continue;
    const e = estimate(config, data, plan);
    out.push('');
    out.push(`${config.plans[plan].title || plan} · модель по умолчанию: ${e.model}`);
    for (const [k, v, why] of e.lines) out.push(`  ${k.padEnd(15)} ${v.toFixed(2).padStart(9)} ${e.currency}/мес  (${why})`);
    if (e.missing.length) out.push(`  нет данных: ${e.missing.join(', ')} — оценка неполная`);
    if (!e.lines.length) out.push('  оценка невозможна: заполни цены в файле выше. Лимиты без неё не меняй.');
    else out.push(`  худший случай ≈ ${e.worst.toFixed(2)} ${e.currency}/мес · типичный (${Math.round(e.share * 100)}%) ≈ ${e.typical.toFixed(2)} ${e.currency}/мес${e.missing.length ? ' (без недостающих статей)' : ''}`);
  }
  return out.join('\n');
}

module.exports = { estimate, report, loadCosts };
