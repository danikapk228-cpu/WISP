/* WISP · Server · Layer 10 · Billing (заготовка под будущую оплату)
 * Оплата в WISP НЕ подключена: нет цен, нет checkout, нет вебхуков. Экран честно говорит «оплата пока не подключена».
 * Здесь только контракт, чтобы провайдер (Stripe, ЮKassa, App Store, …) подключался без переписывания тарифов:
 *
 *   class Provider {
 *     id                                   // 'stripe' | 'yookassa' | …
 *     get available()                      // ключи настроены
 *     async createCheckout({ userId, email, priceId, returnUrl }) → { url }
 *     async verifyWebhook(req, rawBody)     → событие провайдера или throw (подпись обязательна)
 *     mapEvent(event) → null | { type: 'period', userId, ref, startsAt, expiresAt }
 *                           | { type: 'revoke', ref, reason }
 *   }
 *
 * Что делает сервер с событием (уже реализовано и проверено тестами в SubscriptionService):
 *   period → subscription.applyExternalPeriod({ source: 'payment', sourceRef: `${id}:${ref}`, … })
 *            один оплаченный период = одна запись entitlements; повтор вебхука обновляет её, а не создаёт вторую;
 *   revoke → subscription.revokeExternalPeriod({ source: 'payment', sourceRef, reason })   (возврат, отмена).
 * Тариф по-прежнему вычисляется из entitlements, поэтому коды доступа, ручная выдача и оплата складываются сами.
 * Маршруты /api/billing/* появятся вместе с провайдером: сейчас их нет, чтобы не было «фиктивной оплаты». */
'use strict';

class NoBilling {
  get id() { return null; }
  get available() { return false; }
  publicInfo() { return { available: false, provider: null, reason: 'Оплата пока не подключена' }; }
}

function createBilling(config) {
  const name = (config.subscription && config.subscription.billingProvider) || '';
  if (name) {
    // Провайдер указан, но его адаптера в проекте ещё нет: не делаем вид, что оплата работает.
    return Object.assign(new NoBilling(), { publicInfo: () => ({ available: false, provider: null, reason: `Провайдер «${name}» ещё не реализован` }) });
  }
  return new NoBilling();
}

module.exports = { createBilling, NoBilling };
