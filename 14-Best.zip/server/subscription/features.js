/* WISP · Server · Layer 10 · Features (сравнение Free и Plus)
 * Сравнение строится из настоящей конфигурации сервера и того, что подключено прямо сейчас:
 *  · числа — из plans.json (те же, что применяют слои);
 *  · модели — только подключённые (есть ключ провайдера); если мощных моделей нет, Plus не обещает их;
 *  · голос и зрение — только если на сервере есть провайдер / модель с vision.
 * То, чего в WISP ещё нет (анализ документов, отдельная персонализация Plus, оплата), отдаётся списком upcoming
 * и на экране помечено как «ещё не готово», а не как преимущество. */
'use strict';

const fmt = (n) => (Number.isFinite(n) ? n.toLocaleString('ru-RU') : '—');
const thousands = (n) => (n >= 1000 ? `${Math.round(n / 1000)} тыс.` : String(n));

function plural(n, one, few, many) {
  const a = Math.abs(n) % 100, b = a % 10;
  if (a > 10 && a < 20) return many;
  if (b > 1 && b < 5) return few;
  if (b === 1) return one;
  return many;
}

function compare({ quota, ai, voice }) {
  const F = quota.planLimits('free'), P = quota.planLimits('plus');
  const models = ai.listFor('plus').filter((m) => m.available);
  const freeModels = models.filter((m) => m.tier === 'free');
  const plusOnly = models.filter((m) => m.tier === 'plus');
  const visionFree = freeModels.some((m) => m.vision);
  const visionPlus = models.some((m) => m.vision);
  const sttOn = !!(voice && voice.sttAvailable), ttsOn = !!(voice && voice.ttsAvailable);
  const row = (id, label, free, plus, opts) => ({ id, label, free, plus, ...(opts || {}) });
  const cell = (text, o) => ({ text, available: true, ...(o || {}) });
  const off = (text) => ({ text, available: false });
  const rows = [];

  rows.push(row('chat', 'AI-чат',
    cell(`${fmt(F.daily_requests)} ${plural(F.daily_requests, 'сообщение', 'сообщения', 'сообщений')} в день`),
    cell(`${fmt(P.daily_requests)} ${plural(P.daily_requests, 'сообщение', 'сообщения', 'сообщений')} в день`, { better: P.daily_requests > F.daily_requests })));

  if (!models.length) {
    rows.push(row('models', 'Модели AI', off('AI не подключён на сервере'), off('AI не подключён на сервере')));
  } else {
    rows.push(row('models', 'Модели AI',
      freeModels.length ? cell(freeModels.map((m) => m.label).join(', ')) : off('Нет подключённых моделей Free'),
      plusOnly.length
        ? cell(`+ ${plusOnly.map((m) => m.label).join(', ')}`, { better: true })
        : cell('Те же модели: более мощные на сервере пока не подключены', { better: false })));
  }

  rows.push(row('context', 'Длина разговора',
    cell(`~${thousands(F.history_tokens)} токенов истории, ответ до ${fmt(F.max_output_tokens)}`),
    cell(`~${thousands(P.history_tokens)} токенов истории, ответ до ${fmt(P.max_output_tokens)}`, { better: P.history_tokens > F.history_tokens })));

  if (F.memory && P.memory) {
    rows.push(row('memory', 'Память',
      cell(`${fmt(F.memory.items_max)} фактов, в ответе до ${F.memory.context_items}`),
      cell(`${fmt(P.memory.items_max)} фактов, в ответе до ${P.memory.context_items}`, { better: P.memory.items_max > F.memory.items_max })));
  }
  if (F.tools && P.tools) {
    rows.push(row('tools', 'Заметки, задачи, напоминания',
      cell(`${fmt(F.tools.notes_max)} заметок · ${fmt(F.tools.tasks_max)} задач · ${fmt(F.tools.reminders_active_max)} активных напоминаний`),
      cell(`${fmt(P.tools.notes_max)} заметок · ${fmt(P.tools.tasks_max)} задач · ${fmt(P.tools.reminders_active_max)} активных напоминаний`, { better: P.tools.notes_max > F.tools.notes_max })));
    rows.push(row('planner', 'Планировщик',
      cell(`на ${F.tools.planner_days_ahead} ${plural(F.tools.planner_days_ahead, 'день', 'дня', 'дней')} вперёд`),
      cell(`на ${P.tools.planner_days_ahead} ${plural(P.tools.planner_days_ahead, 'день', 'дня', 'дней')} вперёд`, { better: P.tools.planner_days_ahead > F.tools.planner_days_ahead })));
  }
  if (F.voice && P.voice) {
    const vt = (L) => [sttOn ? `${fmt(L.stt_daily)} распознаваний в день, запись до ${L.stt_max_seconds} с` : null, ttsOn ? `озвучка ${thousands(L.tts_chars_daily)} символов` : null].filter(Boolean).join(' · ');
    rows.push(sttOn || ttsOn
      ? row('voice', 'Голос', cell(vt(F)), cell(vt(P), { better: P.voice.stt_daily > F.voice.stt_daily }))
      : row('voice', 'Голос', off('Голос не подключён на сервере'), off('Голос не подключён на сервере')));
  }
  if (F.actions && P.actions) {
    rows.push(row('actions', 'Действия AI',
      cell(`${fmt(F.actions.writes_per_day)} в день, до ${F.actions.bulk_max} записей за раз`),
      cell(`${fmt(P.actions.writes_per_day)} в день, до ${P.actions.bulk_max} записей за раз`, { better: P.actions.writes_per_day > F.actions.writes_per_day })));
  }
  const imgText = (L) => `до ${L.max_images_per_message} в сообщении${L.images_daily != null ? `, ${L.images_daily} в день` : ''}`;
  rows.push(row('images', 'Анализ изображений',
    visionFree ? cell(imgText(F)) : off('Нет модели с распознаванием изображений'),
    visionPlus ? cell(imgText(P), { better: P.max_images_per_message > F.max_images_per_message || (!visionFree && visionPlus) }) : off('Нет модели с распознаванием изображений')));
  rows.push(row('personalization', 'Персонализация',
    cell('Характер WISP, имя, интересы'),
    cell(F.memory && P.memory && P.memory.context_items > F.memory.context_items ? 'То же + больше фактов о тебе в каждом ответе' : 'Характер WISP, имя, интересы', { better: !!(F.memory && P.memory && P.memory.context_items > F.memory.context_items) })));

  return rows;
}

/* Чего в WISP пока нет. Не преимущество Plus, а честный список «ещё не готово». */
const UPCOMING = [
  { id: 'documents', label: 'Анализ документов (PDF, тексты)' },
  { id: 'personalization_plus', label: 'Свои инструкции и расширенная персонализация' },
  { id: 'payments', label: 'Оформление Plus оплатой' },
];

function highlights(rows, plan) {
  const pick = plan === 'plus' ? rows.filter((r) => r.plus.available && r.plus.better) : rows.filter((r) => r.free.available);
  return pick.slice(0, 4).map((r) => ({ id: r.id, label: r.label, text: (plan === 'plus' ? r.plus : r.free).text }));
}

module.exports = { compare, highlights, UPCOMING, plural };
