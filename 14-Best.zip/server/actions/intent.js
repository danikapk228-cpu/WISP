/* WISP · Server · Actions · Intent (Layer 8)
 * Быстрое правило-ориентированное распознавание намерения по последнему сообщению пользователя (RU + EN).
 * Это ПОДСКАЗКА, а не решение: окончательно действие выбирает модель через функции, а сервер всё равно
 * проверяет каждый вызов. Подсказка нужна, чтобы:
 *  · напомнить модели, какое действие, вероятно, нужно и чего не хватает («напомни мне завтра» → о чём?);
 *  · заметить, что модель ответила «создал», не вызвав функцию (честность, см. engine.claimGuard);
 *  · показать в интерфейсе, что WISP сейчас делает («Ставлю напоминание…»), и для журнала.
 *
 * detect(text, { tz, now }) → { category, op, confidence, missing[], dangerous, when }
 *   category: reminders | notes | tasks | planner | memory | search | general
 *   op: create | read | update | delete | complete | confirm | cancel | chat */
'use strict';
const { resolve, norm } = require('./dates');

const W = (re) => new RegExp(`(?<![а-яa-z])(?:${re})`, 'u');
const RX = {
  confirmYes: /^(?:да|ага|угу|давай|подтверждаю|подтверди|удаляй|удали|стирай|очищай|конечно|точно|верно|ок|окей|хорошо|yes|yep|yeah|sure|confirm|ok|okay|do it|go ahead)(?![а-яa-z])/u,
  confirmNo: /^(?:нет|не надо|не нужно|не удаляй|отмена|отмени|стоп|no|nope|cancel|don't|do not)(?![а-яa-z])/u,
  remind: W('напомни|напомнить|напоминани|remind'),
  note: W('запиши|записать|заметк|сохрани (?:мысль|идею|заметку|текст)|запиши идею|note down|take a note|write down|jot'),
  task: W('задач|список дел|в дела|to-?do|task'),
  planner: W('запланир|расписани|календар|планировщик|в план|встреч[ауе]|событи|schedule|agenda|calendar|meeting|event'),
  agenda: W('что у меня|какие у меня планы|что запланировано|что на сегодня|что на завтра|мои планы|мой день|what.?s on|what do i have|my day|my schedule'),
  memoryAdd: W('запомни|запомнить|имей в виду|remember that|remember'),
  memoryForget: W('забудь|забыть|forget'),
  search: W('найди|поищи|найти|покажи|какие у меня были|что я записывал|что я сохранял|где у меня|find|search|look up|show me'),
  create: W('добав|создай|создать|поставь|запиши|сделай задачу|новая задача|новую задачу|запланируй|add|create|new|set up|schedule'),
  update: W('перенеси|перенести|сдвинь|измени|поменяй|переименуй|отложи|move|reschedule|change|rename|postpone'),
  remove: W('удали|удалить|сотри|убери|очисти|отмени напоминание|delete|remove|clear|erase'),
  complete: W('выполнил|сделал|отметь|готово|закрой задачу|mark (?:as )?done|complete|finished'),
  bulk: W('все|всё|всех|выполненные|завершенные|старые|all|every|completed'),
  history: W('истори[юяи] (?:чата|переписки|диалогов)|историю|всю переписку|chat history'),
};
const TRIGGERS = /(?<![а-яa-z])(напомни(?:ть)?(?: мне)?|пожалуйста|wisp|создай|добавь|поставь|задачу|задача|напоминание|о том,? что|про то,? что|что|чтобы|remind me(?: to)?|please|add|a task|task|to)(?![а-яa-z])/gu;
const DATE_WORDS = /(?<![а-яa-z])(сегодня|завтра|послезавтра|утром|днем|вечером|ночью|через \S+(?: \S+)?|в \d{1,2}(?:[:.]\d{2})?(?: (?:утра|дня|вечера|ночи))?|к \d{1,2}(?:[:.]\d{2})?|\d{1,2}:\d{2}|в (?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)|на (?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)|в следующ\S+ \S+|tomorrow|today|tonight|at \d{1,2}(?::\d{2})?(?:\s?[ap]m)?|on \w+day|next \w+)(?![а-яa-z])/gu;
const FILLER = /(?<![а-яa-z])(мне|меня|me|i|в|на|к|и|а|о|об|про|the|at|on|in|for|for me|до|по)(?![а-яa-z])/gu;

/* То, что осталось от фразы без служебных слов и даты: «о чём» */
function subject(text) {
  return norm(text).replace(DATE_WORDS, ' ').replace(TRIGGERS, ' ').replace(FILLER, ' ').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}
const vague = (s) => !s || /^(?:подготовиться|сделать|что-то|кое-что|это|одно дело|дело|something|it|this|prepare|do)$/u.test(s) || s.length < 3;

function detect(text, { tz, now } = {}) {
  const s = norm(text);
  const out = { category: 'general', op: 'chat', confidence: 0, missing: [], dangerous: false, when: null };
  if (!s) return out;
  const short = s.split(' ').length <= 6;
  if (short && RX.confirmNo.test(s)) return { ...out, category: 'general', op: 'cancel', confidence: 0.6 };
  const object = /(?<![а-яa-z])(задач|замет|напомин|событи|встреч|истори|памят|task|note|remind|event|history)/u.test(s);
  if (short && !object && RX.confirmYes.test(s) && !RX.create.test(s.replace(RX.confirmYes, ''))) return { ...out, category: 'general', op: 'confirm', confidence: 0.6 };

  const isRemove = RX.remove.test(s);
  const isUpdate = RX.update.test(s);
  const isComplete = RX.complete.test(s) && RX.task.test(s);
  const pick = (category, op, confidence) => Object.assign(out, { category, op, confidence });

  if (RX.history.test(s) && isRemove) pick('general', 'delete', 0.8);
  else if (RX.memoryForget.test(s)) pick('memory', 'delete', 0.8);
  else if (RX.remind.test(s)) pick('reminders', isRemove ? 'delete' : isUpdate ? 'update' : /(?<![а-яa-z])(какие|список|покажи|list|show)/u.test(s) ? 'read' : 'create', 0.85);
  else if (RX.agenda.test(s)) pick('planner', 'read', 0.8);
  else if (RX.task.test(s)) pick('tasks', isRemove ? 'delete' : isComplete ? 'complete' : isUpdate ? 'update' : /(?<![а-яa-z])(какие|список|покажи|что осталось|list|show)/u.test(s) ? 'read' : 'create', 0.8);
  else if (RX.memoryAdd.test(s)) pick('memory', 'create', 0.75);
  else if (RX.search.test(s) || /(?<![а-яa-z])(какие у меня были|были ли у меня)/u.test(s)) pick('search', 'read', 0.7);
  else if (RX.note.test(s) || /^(?:идея|мысль)[:,]/u.test(s)) pick('notes', isRemove ? 'delete' : isUpdate ? 'update' : 'create', 0.75);
  else if (RX.planner.test(s) && (RX.create.test(s) || /(?<![а-яa-z])запланируй/u.test(s))) pick('planner', 'create', 0.7);
  else if (isRemove && /(?<![а-яa-z])(заметк|note)/u.test(s)) pick('notes', 'delete', 0.7);

  if (out.op === 'delete' || (out.op === 'update' && RX.bulk.test(s))) out.dangerous = true;
  if (out.category === 'general' && out.op === 'chat') return out;

  const when = resolve(s, tz, now);
  out.when = when.date || when.time || when.ambiguous ? { date: when.date, time: when.time, ambiguous: when.ambiguous ? when.ambiguous.question : null } : null;
  const subj = subject(s);
  if (out.op === 'create') {
    if (out.category === 'reminders') {
      if (vague(subj)) out.missing.push('title');
      if (!when.time && !when.ambiguous) out.missing.push('time');
      if (!when.date && !when.time && !when.ambiguous) out.missing.push('date');
      if (when.ambiguous) out.missing.push(when.ambiguous.field);
    } else if (out.category === 'tasks' || out.category === 'notes') {
      if (vague(subj)) out.missing.push(out.category === 'tasks' ? 'title' : 'content');
    } else if (out.category === 'planner') {
      if (vague(subj)) out.missing.push('title');
      if (!when.date && !when.ambiguous) out.missing.push('date');
      if (!when.time && !when.ambiguous) out.missing.push('start_time');
    }
  }
  if (out.op === 'update' && out.category === 'reminders' && when.ambiguous) out.missing.push(when.ambiguous.field);
  return out;
}

const CATEGORY_RU = { reminders: 'напоминания', notes: 'заметки', tasks: 'задачи', planner: 'планировщик', memory: 'память', search: 'поиск', general: 'разговор' };
const OP_RU = { create: 'создать', read: 'посмотреть', update: 'изменить', delete: 'удалить', complete: 'отметить выполненным', confirm: 'подтвердить', cancel: 'отменить', chat: 'поговорить' };
const MISSING_RU = { title: 'о чём именно (название)', content: 'текст', time: 'время', date: 'дату', start_time: 'время начала' };

/* Строка подсказки для системной инструкции */
function hint(intent) {
  if (!intent || (intent.category === 'general' && intent.op === 'chat')) return '';
  const parts = [`Подсказка сервера (эвристика, проверь сам): похоже, пользователь хочет ${OP_RU[intent.op] || intent.op} — ${CATEGORY_RU[intent.category]}.`];
  if (intent.when && (intent.when.date || intent.when.time)) parts.push(`Сервер понял дату/время как: ${[intent.when.date, intent.when.time].filter(Boolean).join(' ')}.`);
  if (intent.when && intent.when.ambiguous) parts.push(`Неоднозначно: ${intent.when.ambiguous} Спроси, прежде чем создавать.`);
  if (intent.missing.length) parts.push(`Не хватает: ${[...new Set(intent.missing)].map((m) => MISSING_RU[m] || m).join(', ')}. Не придумывай — коротко уточни одним вопросом.`);
  if (intent.dangerous) parts.push('Это удаление или массовое изменение: сервер попросит подтверждение карточкой, не говори, что уже сделал.');
  return parts.join(' ');
}

module.exports = { detect, hint, subject, RX, CATEGORY_RU };
