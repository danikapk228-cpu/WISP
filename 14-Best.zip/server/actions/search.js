/* WISP · Server · Actions · Search (Layer 8)
 * Поиск по данным ОДНОГО пользователя (документы приходят уже отфильтрованными по user_id из сессии).
 * Без эмбеддингов: те же основы слов и темы, что у памяти (server/memory/text.js) — «игры» находит «игру»,
 * «идеи для игр» находит заметку «сделать собственную игру».
 * docs: [{ kind, rec, title, body }] → лучшие совпадения по убыванию релевантности (не больше limit). */
'use strict';
const TX = require('../memory/text');

const match = (q, d) => q === d || (q.length === 2 && d.length <= 4 && d.startsWith(q)) || (d.length === 2 && q.length <= 4 && q.startsWith(d)) || (Math.min(q.length, d.length) >= 3 && (d.startsWith(q) || q.startsWith(d)) && Math.abs(q.length - d.length) <= 4);
/* слова запроса, которые сами по себе ничего не ищут («какие у меня были идеи» → «идеи») */
const SOFT = new Set(['ид', 'иде', 'как', 'котор', 'мн', 'мысл', 'запис', 'заметк', 'замет', 'задач', 'напомин', 'событ', 'план', 'был', 'есть', 'мо', 'мои', 'сохран', 'найд', 'поищ', 'покаж', 'нужн', 'idea', 'note', 'task', 'remind', 'find', 'search', 'show']);

function searchAll(docs, query, limit) {
  const q = TX.analyze(String(query || ''));
  const hard = q.stems.filter((s) => !SOFT.has(s));
  const soft = q.stems.filter((s) => SOFT.has(s));
  const needle = TX.normalize(String(query || '')).trim();
  if (!q.stems.length && !needle) return [];
  const scored = [];
  for (const d of docs) {
    const title = TX.analyze(d.title || '');
    const body = TX.analyze(d.body || '');
    const all = new Set([...title.stems, ...body.stems]);
    let score = 0, hits = 0;
    for (const s of hard) {
      if (title.stems.some((x) => match(s, x))) { score += 3; hits++; }
      else if (body.stems.some((x) => match(s, x))) { score += 2; hits++; }
    }
    for (const s of soft) if ([...all].some((x) => match(s, x))) score += 0.5;
    const hay = TX.normalize(`${d.title || ''} ${d.body || ''}`);
    if (needle.length >= 3 && hay.includes(needle)) score += 4;
    const topics = new Set([...title.topics, ...body.topics]);
    const shared = q.topics.filter((t) => topics.has(t)).length;
    score += shared * 1.2;
    // нужен хотя бы один «настоящий» признак: общее слово или общая тема (если в запросе есть содержательные слова)
    if (hard.length && !hits && !shared) continue;
    if (!hard.length && score < 0.5) continue;
    if (score <= 0) continue;
    const fresh = d.rec.updated_at || d.rec.created_at || 0;
    scored.push({ ...d, score, fresh });
  }
  scored.sort((a, b) => b.score - a.score || b.fresh - a.fresh);
  return scored.slice(0, limit || 10);
}

module.exports = { searchAll };
