/* WISP · Server · Actions · Repository (Layer 8)
 * SQL для ожидающих подтверждения действий и ключей повторных запросов. Каждый запрос содержит user_id из сессии:
 * чужое ожидающее действие для пользователя просто «не существует» (404), даже если известен его id. */
'use strict';
const crypto = require('node:crypto');

const COLS = 'id, user_id, conversation_id, message_id, tool, category, title, verb, count, items, payload, button_only, status, result, error, resolved_via, created_at, expires_at, resolved_at';
const parse = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };
const row = (r) => r && ({ ...r, items: parse(r.items, []), payload: parse(r.payload, {}), result: parse(r.result, null), button_only: !!r.button_only });

class ActionsRepo {
  constructor(store) {
    this.store = store;
    const q = (sql) => store.db.prepare(sql);
    this.q = {
      insert: q(`INSERT INTO pending_actions (id, user_id, conversation_id, message_id, tool, category, title, verb, count, items, payload, button_only, status, created_at, expires_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)`),
      get: q(`SELECT ${COLS} FROM pending_actions WHERE id = ? AND user_id = ?`),
      byPrefix: q(`SELECT ${COLS} FROM pending_actions WHERE user_id = ? AND conversation_id = ? AND message_id IS NOT NULL AND id LIKE ? ORDER BY created_at DESC LIMIT 2`),
      openInConv: q(`SELECT ${COLS} FROM pending_actions WHERE user_id = ? AND conversation_id = ? AND message_id IS NOT NULL AND status = 'pending' AND expires_at > ? ORDER BY created_at DESC LIMIT 5`),
      claim: q("UPDATE pending_actions SET status = 'executing' WHERE id = ? AND user_id = ? AND status = 'pending' AND expires_at > ?"),
      finish: q('UPDATE pending_actions SET status = ?, result = ?, error = ?, resolved_via = ?, resolved_at = ? WHERE id = ? AND user_id = ?'),
      cancel: q("UPDATE pending_actions SET status = 'cancelled', resolved_via = ?, resolved_at = ? WHERE id = ? AND user_id = ? AND status = 'pending'"),
      expire: q("UPDATE pending_actions SET status = 'expired', resolved_at = ? WHERE user_id = ? AND status = 'pending' AND expires_at <= ?"),
      // зависшие «executing» (процесс упал посреди выполнения) честно помечаем как сбой
      stale: q("UPDATE pending_actions SET status = 'failed', error = 'interrupted', resolved_at = ? WHERE status = 'executing' AND created_at < ?"),
      purge: q("DELETE FROM pending_actions WHERE status <> 'pending' AND COALESCE(resolved_at, created_at) < ?"),
      setMessage: q('UPDATE pending_actions SET message_id = ? WHERE id = ? AND user_id = ?'),

      keyGet: q('SELECT key, scope, state, status, response, created_at FROM request_keys WHERE user_id = ? AND key = ?'),
      keyStart: q("INSERT OR IGNORE INTO request_keys (user_id, key, scope, state, created_at) VALUES (?, ?, ?, 'started', ?)"),
      keyDone: q("UPDATE request_keys SET state = 'done', status = ?, response = ? WHERE user_id = ? AND key = ?"),
      keyDrop: q('DELETE FROM request_keys WHERE user_id = ? AND key = ?'),
      keyPurge: q('DELETE FROM request_keys WHERE created_at < ?'),
    };
  }

  /* ── Ожидающие подтверждения ── */
  create(userId, p) {
    const id = crypto.randomUUID();
    const t = Date.now();
    this.q.insert.run(id, userId, p.conversationId || null, p.messageId || null, p.tool, p.category, p.title, p.verb, p.count || 0,
      JSON.stringify(p.items || []), JSON.stringify(p.payload || {}), p.buttonOnly ? 1 : 0, t, t + p.ttlMs);
    return this.get(id, userId);
  }
  get(id, userId) { return row(this.q.get.get(id, userId)); }
  byRef(userId, conversationId, ref) {
    const hex = String(ref || '').trim().replace(/^p/i, '').toLowerCase();
    if (!/^[0-9a-f]{8}$/.test(hex) || !conversationId) return null;
    const rows = this.q.byPrefix.all(userId, conversationId, `${hex}%`);
    return rows.length === 1 ? row(rows[0]) : null;
  }
  openIn(userId, conversationId) {
    if (!conversationId) return [];
    this.expire(userId);
    return this.q.openInConv.all(userId, conversationId, Date.now()).map(row);
  }
  /* атомарно: только один запрос получит право выполнить */
  claim(id, userId) { return this.q.claim.run(id, userId, Date.now()).changes === 1; }
  finish(id, userId, { status, result, error, via }) { this.q.finish.run(status, result ? JSON.stringify(result) : null, error || null, via || null, Date.now(), id, userId); }
  cancel(id, userId, via) { return this.q.cancel.run(via || null, Date.now(), id, userId).changes === 1; }
  expire(userId) { this.q.expire.run(Date.now(), userId, Date.now()); }
  setMessage(id, userId, messageId) { this.q.setMessage.run(messageId, id, userId); }
  maintenance() {
    const t = Date.now();
    this.q.stale.run(t, t - 5 * 60 * 1000);
    this.q.purge.run(t - 30 * 86400000);
    this.q.keyPurge.run(t - 86400000);
  }

  /* ── Ключи повторных запросов ── */
  /* → { fresh: true } — ключ новый, можно выполнять; { fresh: false, entry } — такой запрос уже был */
  startKey(userId, key, scope) {
    const fresh = this.q.keyStart.run(userId, key, scope, Date.now()).changes === 1;
    if (fresh) return { fresh: true };
    const e = this.q.keyGet.get(userId, key);
    return { fresh: false, entry: e ? { ...e, response: parse(e.response, null) } : null };
  }
  finishKey(userId, key, status, response) { this.q.keyDone.run(status, JSON.stringify(response || {}), userId, key); }
  dropKey(userId, key) { this.q.keyDrop.run(userId, key); }
}

const refOf = (id) => `p${String(id).slice(0, 8)}`;

module.exports = { ActionsRepo, refOf };
