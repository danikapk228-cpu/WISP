/* WISP · Server · Actions · Engine (Layer 8)
 * Единая точка выполнения действий AI. Модель только просит; решает и выполняет сервер:
 *
 *   вызов модели → разрешённый инструмент? (белый список) → доступен на тарифе? → аргументы — объект?
 *   → повтор в этом же ответе? → не хватает данных / дата неоднозначна? (Clarify: вопрос, без выполнения)
 *   → дневной лимит действий → опасное? (удаление, очистка, массовое изменение → карточка подтверждения)
 *   → то же самое только что уже сделано? (повтор запроса) → выполнение через ToolsService / MemoryService
 *   (с повтором при временной ошибке базы) → запись в журнал → карточка в чат.
 *
 * Модель получает ok: true только после записи в базу; для опасного действия — executed: false и просьбу
 * дождаться подтверждения. Подтвердить можно кнопкой (POST /api/actions/:id/confirm) или словами «да» в следующем
 * сообщении (confirm_action): сервер сам проверяет, что «да» сказал пользователь, а не модель.
 * Голос и текст идут одним путём: распознанная речь — обычное сообщение чата. */
'use strict';
const crypto = require('node:crypto');
const { HttpError } = require('../lib/http');
const T = require('../tools/time');
const D = require('./dates');
const { ActionsRepo, refOf } = require('./repo');
const { CONFIRM_DEFINITIONS, KIND } = require('../tools/ai');
const { RX, hint } = require('./intent');
const { pubNote, pubTask, pubReminder, pubEvent } = require('../tools/service');

const CATEGORY = {
  create_reminder: 'reminders', list_reminders: 'reminders', update_reminder: 'reminders', delete_reminders: 'reminders',
  create_task: 'tasks', list_tasks: 'tasks', update_task: 'tasks', complete_task: 'tasks', bulk_update_tasks: 'tasks', delete_tasks: 'tasks',
  create_note: 'notes', search_notes: 'notes', update_note: 'notes', delete_notes: 'notes',
  create_event: 'planner', get_agenda: 'planner', update_event: 'planner', delete_events: 'planner',
  search_everything: 'search', clear_chat_history: 'general',
  remember: 'memory', suggest_memory: 'memory', forget_memory: 'memory',
  confirm_action: 'general', cancel_action: 'general',
};
const READ = new Set(['list_reminders', 'list_tasks', 'search_notes', 'get_agenda', 'search_everything']);
const CREATE = new Set(['create_reminder', 'create_task', 'create_note', 'create_event']);
const DANGER = new Set(['delete_reminders', 'delete_tasks', 'delete_notes', 'delete_events', 'clear_chat_history', 'forget_memory']);
const MEMORY = new Set(['remember', 'suggest_memory', 'forget_memory']);
const META = new Set(['confirm_action', 'cancel_action']);
const DEDUPE_MS = 2 * 60 * 1000;

const DEFAULT_LIMITS = {
  free: { writes_per_day: 150, bulk_max: 20, search_results: 8, agenda_days_max: 7, confirm_ttl_minutes: 15, disabled: [] },
  plus: { writes_per_day: 2000, bulk_max: 200, search_results: 25, agenda_days_max: 31, confirm_ttl_minutes: 30, disabled: [] },
};

const sleep = (ms) => { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (e) { /* без задержки */ } };
const stable = (v) => (Array.isArray(v) ? `[${v.map(stable).join(',')}]` : v && typeof v === 'object' ? `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${stable(v[k])}`).join(',')}}` : JSON.stringify(v === undefined ? null : v));
const fingerprint = (name, args) => crypto.createHash('sha256').update(`${name}\n${stable(args || {})}`).digest('hex').slice(0, 32);
const startOfUtcDay = () => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); return d.getTime(); };
const clip = (s, n) => (s && s.length > n ? s.slice(0, n - 1) + '…' : s || '');
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14) ? b : c; };

/* Явное согласие пользователя: «да», «да, удаляй», «подтверждаю». Отрицание рядом («да нет», «не надо») — не согласие. */
function affirmative(text) {
  const s = D.norm(text).replace(/[!.?,;:…]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!s || s.split(' ').length > 8) return false;
  if (/(?<![а-яa-z])(нет|не надо|не нужно|не удаляй|не стоит|отмен|стоп|подожди|no|not|don't|cancel|stop|wait)(?![а-яa-z])/u.test(s)) return false;
  return RX.confirmYes.test(s) || /(?<![а-яa-z])(подтверждаю|удаляй|очищай|применяй|давай|go ahead|confirm)(?![а-яa-z])/u.test(s);
}

/* «Создал», «записал», «удалил»… — утверждение о выполненном действии */
const CLAIM = /(?<![а-яa-z])(создал[аи]?|сохранил[аи]?|записал[аи]?|добавил[аи]?|поставил[аи]?|удалил[аи]?|перен[её]с(ла)?|отметил[аи]?|запланировал[аи]?|напомню|обновил[аи]?|изменил[аи]?|i(?:'ve| have)? (?:created|saved|added|deleted|scheduled|set))(?![а-яa-z])/u;
const NEGATED = /(?<![а-яa-z])(не (?:смог|получилось|удалось|создал|сохранил|записал|добавил|удалил|перен[её]с)|пока не|ещё не|не буду|couldn't|could not|didn't|did not|haven't)(?![а-яa-z])/u;

class ActionEngine {
  constructor({ store, tools, toolkit, memoryToolkit, memoryService, config, log }) {
    this.store = store;
    this.tools = tools;
    this.toolkit = toolkit;
    this.memoryToolkit = memoryToolkit;
    this.memory = memoryService;
    this.config = config;
    this.log = log;
    this.repo = new ActionsRepo(store);
    try { this.repo.maintenance(); } catch (e) { /* база только что создана */ }
    this.timer = setInterval(() => { try { this.repo.maintenance(); } catch (e) { /* база закрыта */ } }, 30 * 60 * 1000);
    this.timer.unref();
  }
  stop() { clearInterval(this.timer); }

  limits(planId) {
    const key = planId === 'plus' ? 'plus' : 'free';
    const p = (this.config.plans && this.config.plans[key]) || {};
    return { ...DEFAULT_LIMITS[key], ...(p.actions || {}) };
  }
  available(name, planId) {
    if (!CATEGORY[name]) return false;
    const L = this.limits(planId);
    return !(Array.isArray(L.disabled) && L.disabled.includes(name));
  }

  /* Что предложить модели в этом ответе: разрешённые тарифом действия + функции памяти + подтверждение, если есть чего ждать */
  definitions({ plan, memDefs, pending }) {
    const base = this.toolkit.definitions().filter((d) => this.available(d.name, plan));
    const mem = (memDefs || []).filter((d) => this.available(d.name, plan));
    const meta = pending && pending.length ? CONFIRM_DEFINITIONS : [];
    return [...base, ...mem, ...meta];
  }

  pendingFor(userId, conversationId) {
    try { return this.repo.openIn(userId, conversationId); } catch (e) { return []; }
  }

  /* Раздел системной инструкции Layer 8 */
  promptSection({ tz, now, enabled, plan, intent, pending, inputMode }) {
    const base = this.toolkit.promptSection({ tz, now, enabled });
    if (!enabled) return base;
    const L = this.limits(plan);
    const lines = [base,
      'Календарь пользователя (не считай дни недели сам, бери отсюда):',
      ...D.calendar(tz, now, 10).map((l) => `  · ${l}`),
      'Как выполнять действия (Layer 8):',
      '- Категории: напоминания, задачи, заметки, планировщик, память (remember), поиск по данным пользователя (search_everything). Обычный разговор — без функций.',
      '- Когда пользователь называет момент словами, передавай их в поле when как есть («завтра в 10 утра»): сервер сам переведёт в его часовой пояс.',
      '- Безопасные действия (создать заметку, задачу, напоминание, событие; посмотреть план; найти; изменить ОДНУ запись) выполняй сразу.',
      '- Удаление, очистка истории, изменение нескольких записей сразу — сервер НЕ выполнит без согласия: вызови функцию, и пользователь увидит карточку подтверждения. Скажи коротко «Подтверди в карточке». Не говори «удалил», пока действие не подтверждено.',
      '- Чтобы изменить или удалить запись, нужен её id: возьми из прошлых действий или найди через list_reminders / list_tasks / get_agenda / search_everything. Подходит несколько записей — спроси, какую именно.',
      '- Функция вернула needs_clarification — задай пользователю этот вопрос одной фразой и ничего не выполняй.',
      '- О найденном рассказывай только то, что вернул сервер. Ничего не нашлось — так и скажи. Не смешивай с выдуманными данными.',
      `- За один раз можно изменить не больше ${L.bulk_max} записей.`,
    ];
    if (pending && pending.length) {
      lines.push('Ждут подтверждения пользователя (созданы раньше, НЕ выполнены):');
      for (const p of pending) lines.push(`  · «${p.title}» — ref ${refOf(p.id)}${p.button_only ? ' (только кнопкой в карточке)' : ''}`);
      lines.push('- Если в последнем сообщении пользователь явно согласился («да», «удаляй», «подтверждаю») — вызови confirm_action с этим ref. Отказался («нет», «не надо») — cancel_action. Иначе не трогай.');
    }
    if (inputMode === 'voice') lines.push('- Пользователь говорит голосом и, возможно, не смотрит на экран: отвечай 1–2 короткими фразами, без списков, таблиц и Markdown; время и даты называй словами («завтра в десять утра»). Подтвердить удаление он может словом «да».');
    const h = hint(intent);
    if (h) lines.push(`- ${h}`);
    return lines.join('\n');
  }

  /* ── Выполнение одного вызова модели ──
   * ctx: { userId, plan, tz, now, conversationId, messageId, userMessage:{content, created_at}, mem:{refs, offered, round},
   *        seen: Map, busy: () => boolean }
   * → { ok, forModel, action (с id журнала и live), emit } */
  execute(call, ctx) {
    const name = call.name;
    const args = call.input && typeof call.input === 'object' && !Array.isArray(call.input) ? call.input : null;
    const fp = fingerprint(name, args);
    const finish = (r, { write, log } = {}) => this.record(ctx, name, r, { fp, write, logArgs: log, args });
    // повтор того же вызова в этом же ответе: результат первого, без второй карточки
    if (ctx.seen && ctx.seen.has(fp) && !READ.has(name)) {
      const prev = ctx.seen.get(fp);
      return { ...prev, emit: false, forModel: { ...prev.forModel, duplicate: true, note: 'Этот вызов уже выполнен в этом ответе — повторно не делаю.' } };
    }
    let r;
    if (!CATEGORY[name]) r = this.fail(name, 'unknown_tool', 'Такой функции нет.');
    else if (!this.available(name, ctx.plan)) r = this.fail(name, 'plan_required', 'Это действие недоступно на твоём тарифе.');
    else if (!args) r = this.fail(name, 'bad_input', 'Аргументы функции не разобраны: нужен JSON-объект.');
    else if (META.has(name)) r = this.meta(name, args, ctx);
    else if (!READ.has(name) && this.overDaily(ctx)) r = this.fail(name, 'limit_actions', `Дневной лимит действий WISP на твоём тарифе исчерпан (${this.limits(ctx.plan).writes_per_day}). Завтра он обновится.`);
    else if (DANGER.has(name) || (name === 'bulk_update_tasks' && Array.isArray(args.task_ids) && new Set(args.task_ids).size > 1)) r = this.propose(name, args, ctx);
    else if (MEMORY.has(name)) {
      const m = this.memoryToolkit.execute(name, args, { userId: ctx.userId, plan: ctx.plan, conversationId: ctx.conversationId, ...(ctx.mem || {}) });
      const out = finish(m, { write: m.ok, log: m.log });
      if (ctx.seen) ctx.seen.set(fp, out);
      return out;
    } else {
      const dup = CREATE.has(name) ? this.recentDuplicate(ctx, name, fp) : null;
      r = dup || this.withRetry(() => this.toolkit.execute(name, args, { userId: ctx.userId, plan: ctx.plan, tz: ctx.tz, now: ctx.now, limits: this.limits(ctx.plan) }));
    }
    const out = finish(r, { write: r.ok && !READ.has(name) && !r.deduplicated && r.action.op !== 'pending' ? true : false });
    if (ctx.seen && !r.clarify) ctx.seen.set(fp, out);
    return out;
  }

  fail(name, code, message) {
    return { ok: false, forModel: { ok: false, error: message }, action: { tool: name, kind: KIND[name] || (MEMORY.has(name) ? 'memory' : 'tool'), op: 'failed', error: message, code } };
  }

  withRetry(fn) {
    let r;
    for (let i = 0; i < 3; i++) {
      r = fn();
      if (r.ok || !r.transient) return r;
      sleep(40 * (i + 1) * (i + 1));
    }
    return r;
  }

  overDaily(ctx) {
    const L = this.limits(ctx.plan);
    return this.tools.repo.writesSince(ctx.userId, startOfUtcDay()) >= L.writes_per_day;
  }

  /* То же создание с теми же аргументами только что уже выполнено (повтор запроса, «ответить заново») и запись жива */
  recentDuplicate(ctx, name, fp) {
    const prev = this.tools.repo.recentCall(ctx.userId, fp, Date.now() - DEDUPE_MS);
    if (!prev || !prev.result || !prev.result.record_id) return null;
    const live = this.lookup(ctx.userId, [{ kind: prev.result.kind, id: prev.result.record_id }]).get(`${prev.result.kind}:${prev.result.record_id}`);
    if (!live) return null;
    return { ok: true, deduplicated: true, forModel: { ok: true, already_done: true, note: 'Точно такое же действие уже выполнено только что — второй раз не создаю. Скажи, что уже сделано.', record: { id: live.id, title: live.title } },
      action: { ...prev.result, deduplicated: true } };
  }

  /* Журнал + карточка для клиента */
  record(ctx, name, r, { fp, write, logArgs, args }) {
    const logged = logArgs || { args: MEMORY.has(name) ? {} : sanitizeArgs(name, args), result: r.action };
    let id = null;
    try {
      id = this.tools.repo.logCall(ctx.userId, ctx.messageId, { name, args: logged.args, status: r.ok ? 'ok' : 'error', result: logged.result, fingerprint: r.ok && !r.deduplicated ? fp : null, write });
    } catch (e) { this.log && this.log.error('tool log failed', { tool: name, error: e && e.message }); }
    if (r.pendingId && ctx.messageId) { try { this.repo.setMessage(r.pendingId, ctx.userId, ctx.messageId); } catch (e) { /* не критично */ } }
    const action = { ...r.action, id, status: r.ok ? 'ok' : 'error' };
    this.enrich(ctx.userId, [action]);
    return { ok: r.ok, forModel: r.forModel, action, emit: !r.clarify, clarify: !!r.clarify };
  }

  /* ── Опасное действие: подготовить и спросить пользователя ── */
  propose(name, args, ctx) {
    let plan;
    try {
      if (name === 'forget_memory') {
        if (!ctx.mem || !ctx.mem.offered || !ctx.mem.offered.has('forget_memory')) throw new HttpError(403, 'memory_off', 'Память недоступна в этом разговоре.');
        const id = ctx.mem.refs && ctx.mem.refs.get(String(args.ref || '').trim());
        if (!id) throw new HttpError(400, 'bad_ref', 'Нет воспоминания с таким ref в списке памяти.');
        plan = { title: 'Забыть это воспоминание?', verb: 'Забыть', count: 1, items: [{ kind: 'memory', id }], payload: { ids: [id] } };
      } else {
        plan = this.toolkit.prepare(name, args, { userId: ctx.userId, plan: ctx.plan, tz: ctx.tz, now: ctx.now, limits: this.limits(ctx.plan) });
      }
    } catch (e) { return this.toolkit.failure(name, e); }
    const ttl = this.limits(ctx.plan).confirm_ttl_minutes * 60000;
    const p = this.repo.create(ctx.userId, { conversationId: ctx.conversationId, messageId: ctx.messageId, tool: name, category: CATEGORY[name], title: plan.title, verb: plan.verb, count: plan.count, items: plan.items, payload: plan.payload, buttonOnly: !!plan.buttonOnly, ttlMs: ttl });
    const ref = refOf(p.id);
    return {
      ok: true, pendingId: p.id,
      forModel: { ok: true, executed: false, needs_confirmation: true, ref, summary: plan.title, note: plan.buttonOnly ? 'НЕ выполнено. Пользователь подтвердит кнопкой в карточке. Скажи об этом коротко.' : 'НЕ выполнено. Пользователь видит карточку с кнопками «Подтвердить / Отмена» и может ответить «да». Скажи коротко, что ждёшь подтверждения.' },
      action: { tool: name, kind: 'confirm', op: 'pending', pending_id: p.id, ref, category: CATEGORY[name], title: plan.title, verb: plan.verb, count: plan.count, button_only: !!plan.buttonOnly, note: plan.note || null, expires_at: p.expires_at },
    };
  }

  /* ── confirm_action / cancel_action из чата ── */
  meta(name, args, ctx) {
    const p = this.repo.byRef(ctx.userId, ctx.conversationId, args.ref);
    if (!p) return this.fail(name, 'not_found', 'Нет такого ожидающего подтверждения действия в этом диалоге.');
    const base = { kind: 'confirm', pending_id: p.id, ref: refOf(p.id), category: p.category, title: p.title, verb: p.verb, count: p.count };
    if (name === 'cancel_action') {
      if (!this.repo.cancel(p.id, ctx.userId, 'chat')) return this.fail(name, 'not_pending', this.stateText(this.repo.get(p.id, ctx.userId)));
      return { ok: true, forModel: { ok: true, cancelled: true, note: 'Отменено, ничего не изменилось.' }, action: { tool: name, ...base, op: 'cancelled' } };
    }
    if (p.status !== 'pending' || p.expires_at <= Date.now()) return this.fail(name, 'not_pending', this.stateText(p));
    if (p.button_only) return this.fail(name, 'button_only', 'Это действие подтверждается только кнопкой в карточке.');
    const um = ctx.userMessage || {};
    if (!um.created_at || um.created_at <= p.created_at) return this.fail(name, 'not_user', 'Подтверждение должно прийти от пользователя следующим сообщением. Спроси его.');
    if (!affirmative(um.content)) return this.fail(name, 'not_affirmative', 'Пользователь не сказал явного «да». Ничего не выполнено — спроси, подтверждает ли он.');
    const res = this.commit(p, { userId: ctx.userId, plan: ctx.plan, tz: ctx.tz, via: 'chat', busy: ctx.busy, conversationId: ctx.conversationId });
    if (res.status !== 'done') return this.fail(name, res.code || 'failed', res.error || this.stateText(res));
    return { ok: true, forModel: { ok: true, executed: true, result: res.result }, action: { tool: name, ...base, op: 'done', result: res.result } };
  }
  stateText(p) {
    if (!p) return 'Действие не найдено.';
    return { done: 'Это уже выполнено.', cancelled: 'Это действие отменено.', expired: 'Время подтверждения вышло. Попроси ещё раз.', failed: 'Это действие не удалось выполнить.', executing: 'Это действие уже выполняется.' }[p.status] || 'Действие не ждёт подтверждения.';
  }

  /* ── Подтверждение (кнопка или «да»): атомарно pending → executing → done | failed ── */
  commit(p, { userId, plan, tz, via, busy, conversationId }) {
    if (p.status === 'pending' && p.expires_at <= Date.now()) { this.repo.expire(userId); return { ...this.repo.get(p.id, userId), code: 'expired', error: 'Время подтверждения вышло. Попроси WISP ещё раз.' }; }
    if (!this.available(p.tool, plan)) return { ...p, status: 'failed', code: 'plan_required', error: 'Это действие недоступно на твоём тарифе.' };
    if (p.tool === 'clear_chat_history' && busy && busy()) return { ...p, status: 'pending', code: 'busy', error: 'WISP ещё отвечает. Дождись ответа или останови его.' };
    if (this.overDaily({ userId, plan })) {
      return { ...p, code: 'limit_actions', error: `Дневной лимит действий WISP на твоём тарифе исчерпан (${this.limits(plan).writes_per_day}). Завтра он обновится.` };
    }
    if (!this.repo.claim(p.id, userId)) {
      const cur = this.repo.get(p.id, userId);
      return { ...cur, code: cur && cur.status === 'done' ? 'already_done' : 'not_pending', replayed: !!(cur && cur.status === 'done'), error: cur && cur.status === 'done' ? null : this.stateText(cur) };
    }
    const ctx = { userId, plan, tz, source: 'ai' };
    let result, error = null;
    for (let i = 0; i < 3; i++) {
      try {
        if (p.tool === 'forget_memory') {
          let n = 0;
          for (const id of p.payload.ids || []) { try { this.memory.forget({ userId, plan }, id); n++; } catch (e) { if (!(e instanceof HttpError && e.status === 404)) throw e; } }
          result = { done: n, skipped: (p.payload.ids || []).length - n };
        } else if (p.tool === 'clear_chat_history') {
          result = { done: this.store.deleteAllConversations(userId), skipped: 0 };
        } else result = this.toolkit.commit(p.tool, p.payload, ctx);
        error = null;
        break;
      } catch (e) {
        error = e;
        if (!(e && /SQLITE_BUSY|database is locked/i.test(e.message || ''))) break;
        sleep(40 * (i + 1) * (i + 1));
      }
    }
    if (error) {
      const msg = error instanceof HttpError ? error.message : 'Сервер не смог выполнить действие.';
      if (!(error instanceof HttpError)) this.log && this.log.error('confirm failed', { tool: p.tool, error: error.message });
      this.repo.finish(p.id, userId, { status: 'failed', error: msg, via });
      return { ...this.repo.get(p.id, userId), code: 'failed', error: msg };
    }
    this.repo.finish(p.id, userId, { status: 'done', result, via });
    // в журнал: что именно выполнено после подтверждения (для лимита и аудита); clear_chat_history удалил и сам диалог
    try { this.tools.repo.logCall(userId, null, { name: `confirm:${p.tool}`, args: { via }, status: 'ok', result: { tool: p.tool, kind: 'confirm', op: 'done', pending_id: p.id, count: result.done }, write: true }); } catch (e) { /* журнал не критичен */ }
    this.log && this.log.info('action confirmed', { tool: p.tool, via, done: result.done });
    return this.repo.get(p.id, userId);
  }

  /* REST: подтверждение и отмена кнопкой. Ошибки — HttpError с понятным текстом. */
  confirm(userId, plan, id, { tz, busy }) {
    const p = this.repo.get(String(id || ''), userId);
    if (!p) throw new HttpError(404, 'not_found', 'Действие не найдено.');
    if (p.status === 'done') return { action: this.publicPending(userId, p), replayed: true };
    if (p.status !== 'pending') throw new HttpError(409, p.status === 'expired' ? 'expired' : 'not_pending', this.stateText(p), { action: this.publicPending(userId, p) });
    const res = this.commit(p, { userId, plan, tz, via: 'button', busy, conversationId: p.conversation_id });
    if (res.code === 'busy') throw new HttpError(409, 'busy', res.error);
    if (res.code === 'already_done') return { action: this.publicPending(userId, this.repo.get(p.id, userId)), replayed: true };
    if (res.status !== 'done') throw new HttpError(res.code === 'expired' ? 410 : res.code === 'plan_required' ? 403 : res.code === 'limit_actions' ? 429 : 409, res.code || 'failed', res.error || this.stateText(res), { action: this.publicPending(userId, this.repo.get(p.id, userId) || res) });
    return { action: this.publicPending(userId, res), replayed: false };
  }
  cancel(userId, id) {
    const p = this.repo.get(String(id || ''), userId);
    if (!p) throw new HttpError(404, 'not_found', 'Действие не найдено.');
    if (p.status === 'cancelled') return { action: this.publicPending(userId, p), replayed: true };
    if (!this.repo.cancel(p.id, userId, 'button')) throw new HttpError(409, 'not_pending', this.stateText(this.repo.get(p.id, userId)), { action: this.publicPending(userId, this.repo.get(p.id, userId)) });
    return { action: this.publicPending(userId, this.repo.get(p.id, userId)), replayed: false };
  }
  get(userId, id) {
    this.repo.expire(userId);
    const p = this.repo.get(String(id || ''), userId);
    if (!p) throw new HttpError(404, 'not_found', 'Действие не найдено.');
    return this.publicPending(userId, p);
  }
  publicPending(userId, p) {
    if (!p) return null;
    const live = this.lookup(userId, p.items);
    return {
      id: p.id, ref: refOf(p.id), tool: p.tool, category: p.category, title: p.title, verb: p.verb, count: p.count, status: p.status,
      button_only: p.button_only, result: p.result, error: p.error, created_at: p.created_at, expires_at: p.expires_at, resolved_at: p.resolved_at, resolved_via: p.resolved_via,
      items: p.items.map((it) => ({ kind: it.kind, record_id: it.id, live: live.get(`${it.kind}:${it.id}`) || null })),
    };
  }

  /* ── Карточки связаны с настоящими записями: текущее состояние берётся из базы при каждом показе ── */
  lookup(userId, refs) {
    const out = new Map();
    const R = this.tools.repo;
    const mem = [];
    for (const ref of refs || []) {
      const kind = ref.kind, id = ref.id || ref.record_id;
      if (!kind || typeof id !== 'string') continue;
      const key = `${kind}:${id}`;
      if (out.has(key)) continue;
      let v = null;
      try {
        if (kind === 'reminder') { const r = R.getReminder(id, userId); v = r && liveReminder(pubReminder(r)); }
        else if (kind === 'task') { const t = R.getTask(id, userId); v = t && liveTask(pubTask(t)); }
        else if (kind === 'note') { const n = R.getNote(id, userId); v = n && liveNote(pubNote(n)); }
        else if (kind === 'event') { const e = R.getEvent(id, userId); v = e && liveEvent(pubEvent(e)); }
        else if (kind === 'memory') { mem.push(id); continue; }
        else continue;
      } catch (e) { v = null; }
      out.set(key, v || null);
    }
    if (mem.length && this.memory) {
      let m = new Map();
      try { m = this.memory.lookup(userId, mem); } catch (e) { m = new Map(); }
      for (const id of mem) { const x = m.get(id); out.set(`memory:${id}`, x && x.status === 'active' ? { id: x.id, content: x.content, category: x.category } : null); }
    }
    return out;
  }
  /* Дополнить карточки: live записи, live элементов списка, текущее состояние ожидающего подтверждения */
  enrich(userId, actions) {
    const refs = [];
    const pend = [];
    for (const a of actions || []) {
      if (a.record_id && ['reminder', 'task', 'note', 'event'].includes(a.kind)) refs.push({ kind: a.kind, id: a.record_id });
      if (Array.isArray(a.items)) for (const it of a.items) if (it && it.record_id) refs.push({ kind: it.kind, id: it.record_id });
      if (a.kind === 'confirm' && a.pending_id) pend.push(a);
    }
    const live = this.lookup(userId, refs);
    for (const a of actions || []) {
      if (a.record_id && ['reminder', 'task', 'note', 'event'].includes(a.kind)) a.live = live.get(`${a.kind}:${a.record_id}`) || null;
      if (Array.isArray(a.items)) a.items = a.items.map((it) => (it && it.record_id ? { kind: it.kind, record_id: it.record_id, date: it.date || undefined, live: live.get(`${it.kind}:${it.record_id}`) || null } : it));
    }
    if (pend.length) {
      try { this.repo.expire(userId); } catch (e) { /* ок */ }
      for (const a of pend) {
        const p = this.repo.get(a.pending_id, userId);
        const pub = p ? this.publicPending(userId, p) : null;
        a.pending_status = pub ? pub.status : 'gone';
        a.pending = pub ? { status: pub.status, result: pub.result, error: pub.error, expires_at: pub.expires_at, resolved_via: pub.resolved_via, items: pub.items, button_only: pub.button_only } : null;
      }
    }
    return actions;
  }

  /* ── Честность: модель написала «создал», но ни одно изменение не выполнено ── */
  claimGuard(text, intent, actions) {
    if (!intent || intent.category === 'general' || !['create', 'update', 'delete', 'complete'].includes(intent.op)) return null;
    const did = (actions || []).some((a) => a.status === 'ok' && a.op !== 'read' && a.op !== 'clarify');
    if (did) return null;
    const asked = (actions || []).some((a) => a.op === 'clarify');
    const t = String(text || '');
    if (!CLAIM.test(D.norm(t)) || NEGATED.test(D.norm(t)) || /\?\s*$/.test(t.trim()) || asked) return null;
    return { tool: 'guard', kind: 'notice', op: 'unverified', error: 'Действие не выполнено: WISP ничего не сохранил. Повтори просьбу, и я сделаю это по-настоящему.' };
  }
}

const liveReminder = (r) => ({ id: r.id, title: r.title, date: r.date, time: r.time, remind_at: r.remind_at, done: r.done });
const liveTask = (t) => ({ id: t.id, title: t.title, due_date: t.due_date, priority: t.priority, done: t.done });
const liveNote = (n) => ({ id: n.id, title: n.title || clip(n.content.split('\n')[0], 60), excerpt: clip(n.content.replace(/\s+/g, ' '), 140), updated_at: n.updated_at });
const liveEvent = (e) => ({ id: e.id, title: e.title, date: e.date, start_time: e.start_time, end_time: e.end_time });

/* В журнал аргументы вызова пишутся без длинных текстов (заметки могут быть большими и личными) */
function sanitizeArgs(name, args) {
  if (!args || typeof args !== 'object') return {};
  const out = {};
  for (const [k, v] of Object.entries(args)) out[k] = typeof v === 'string' ? clip(v, 200) : Array.isArray(v) ? v.slice(0, 50) : v;
  return out;
}

module.exports = { ActionEngine, affirmative, fingerprint, CATEGORY, DEFAULT_LIMITS, plural };
