/* WISP · Server · Actions · Dates (Layer 8)
 * Относительные даты и время в часовом поясе пользователя, без зависимостей.
 * Модель может ошибиться в арифметике дней недели, поэтому слова пользователя («завтра в 10», «в пятницу вечером»,
 * «через неделю») сервер разбирает сам и сверяет с тем, что передала модель.
 *
 * resolve(text, tz, now) → {
 *   date: 'YYYY-MM-DD' | null,  time: 'HH:MM' | null,
 *   date_kind: 'relative' | 'absolute' | null,  time_kind: 'exact' | 'part_of_day' | 'relative' | null,
 *   ambiguous: null | { field: 'date' | 'time', options: [...], question },
 *   past: boolean   (момент уже прошёл)
 * }
 * calendar(tz, now, days) → строки для системной инструкции: «завтра — понедельник, 2026-11-09». */
'use strict';
const T = require('../tools/time');

const MONTHS = {
  январ: 1, феврал: 2, март: 3, апрел: 4, ма: 5, мая: 5, июн: 6, июл: 7, август: 8, сентябр: 9, октябр: 10, ноябр: 11, декабр: 12,
  янв: 1, фев: 2, мар: 3, апр: 4, авг: 8, сен: 9, сент: 9, окт: 10, ноя: 11, нояб: 11, дек: 12,
  january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12,
  jan: 1, feb: 2, apr: 4, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12,
};
const MONTH_RE = '(январ[яьею]?|феврал[яьею]?|марта?|апрел[яьею]?|ма[яей]|июн[яье]?|июл[яье]?|августа?|сентябр[яье]?|октябр[яье]?|ноябр[яье]?|декабр[яье]?|янв|фев|мар|апр|авг|сент?|окт|нояб?|дек|january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|apr|jun|jul|aug|sept?|oct|nov|dec)\\.?';
const WEEKDAYS = [
  ['воскресень', 0], ['понедельник', 1], ['вторник', 2], ['сред', 3], ['четверг', 4], ['пятниц', 5], ['суббот', 6],
  ['sunday', 0], ['monday', 1], ['tuesday', 2], ['wednesday', 3], ['thursday', 4], ['friday', 5], ['saturday', 6],
];
const WD_RE = '(воскресенье|понедельник|вторник|сред[уаы]|четверг|пятниц[уаы]|суббот[уаы]|sunday|monday|tuesday|wednesday|thursday|friday|saturday)';
const WD_GEN = ['воскресенье', 'понедельник', 'вторник', 'среду', 'четверг', 'пятницу', 'субботу'];
const NUM_WORDS = { один: 1, одну: 1, одна: 1, два: 2, две: 2, пару: 2, три: 3, четыре: 4, пять: 5, шесть: 6, семь: 7, восемь: 8, девять: 9, десять: 10, a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
const PARTS = { утром: '09:00', 'с утра': '09:00', днем: '13:00', 'в обед': '13:00', вечером: '19:00', ночью: '23:00', morning: '09:00', 'in the morning': '09:00', afternoon: '14:00', 'in the afternoon': '14:00', evening: '19:00', 'in the evening': '19:00', tonight: '20:00', 'at night': '23:00' };

const pad = (n) => String(n).padStart(2, '0');
const norm = (s) => String(s || '').toLocaleLowerCase('ru').replace(/ё/g, 'е').replace(/[«»"“”]/g, ' ').replace(/\s+/g, ' ').trim();
const weekdayOf = (date) => { const d = T.parseDate(date); return new Date(Date.UTC(d.y, d.m - 1, d.d)).getUTCDay(); };
const num = (s) => (/^\d+$/.test(s) ? Number(s) : NUM_WORDS[s] || null);
function wdIndex(word) {
  const w = norm(word);
  const hit = WEEKDAYS.find(([p]) => w.startsWith(p));
  return hit ? hit[1] : null;
}
function monthIndex(word) {
  const w = norm(word).replace(/\.$/, '');
  if (MONTHS[w]) return MONTHS[w];
  for (const [p, m] of Object.entries(MONTHS)) if (p.length >= 3 && w.startsWith(p)) return m;
  return w === 'мая' || w === 'май' || w === 'мае' ? 5 : null;
}
function validDate(y, m, d) { const s = `${y}-${pad(m)}-${pad(d)}`; return T.parseDate(s) ? s : null; }

/* ── Дата ── */
function findDate(s, today, nowParts) {
  let m;
  if ((m = /\b(\d{4})-(\d{2})-(\d{2})\b/.exec(s))) {
    const d = validDate(+m[1], +m[2], +m[3]);
    if (d) return { date: d, kind: 'absolute', span: m[0] };
  }
  if ((m = new RegExp(`(?:^|[^\\d:])(\\d{1,2})(?:-?(?:го|е|ое))?\\s+${MONTH_RE}(?:\\s+(\\d{4}))?`, 'u').exec(s))) {
    const day = +m[1], month = monthIndex(m[2]);
    if (month) {
      let y = m[3] ? +m[3] : nowParts.y;
      let d = validDate(y, month, day);
      if (d && !m[3] && T.daysBetween(today, d) < 0) d = validDate(y + 1, month, day);
      if (d) return { date: d, kind: 'absolute', span: m[0] };
    }
  }
  if ((m = /(?:^|[^\d:.])(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?(?![\d:])/.exec(s)) && !/(?:^|\s)(?:в|at|к)\s*$/.test(s.slice(0, m.index + 1))) {
    const day = +m[1], month = +m[2];
    let y = m[3] ? (m[3].length === 2 ? 2000 + +m[3] : +m[3]) : nowParts.y;
    if (month >= 1 && month <= 12) {
      let d = validDate(y, month, day);
      if (d && !m[3] && T.daysBetween(today, d) < 0) d = validDate(y + 1, month, day);
      if (d) return { date: d, kind: 'absolute', span: m[0] };
    }
  }
  if (/послезавтра|day after tomorrow/.test(s)) return { date: T.addDays(today, 2), kind: 'relative', span: 'послезавтра' };
  if (/(?<![а-яa-z])(?:завтра|tomorrow)/.test(s)) return { date: T.addDays(today, 1), kind: 'relative', span: 'завтра' };
  if (/(?<![а-яa-z])(?:сегодня|today|tonight)/.test(s)) return { date: today, kind: 'relative', span: 'сегодня' };
  if (/(?<![а-яa-z])(?:вчера|yesterday)/.test(s)) return { date: T.addDays(today, -1), kind: 'relative', span: 'вчера' };
  if ((m = /(?<![а-яa-z])(?:через|in)\s+(?:(\d+|[а-яa-z]+)\s+)?(дн[яейь]|день|сутки|недел[юиь]|неделек|месяц[аев]*|week|weeks|day|days|month|months)(?![а-яa-z])/u.exec(s))) {
    const n = m[1] ? num(m[1]) : 1;
    if (n) {
      const unit = m[2];
      const days = /недел|week/.test(unit) ? 7 * n : /месяц|month/.test(unit) ? 30 * n : n;
      if (/месяц|month/.test(unit)) {
        const p = T.parseDate(today);
        const t = new Date(Date.UTC(p.y, p.m - 1 + n, p.d));
        return { date: `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}`, kind: 'relative', span: m[0] };
      }
      return { date: T.addDays(today, days), kind: 'relative', span: m[0] };
    }
  }
  if (/на выходных|в выходные|on the weekend|this weekend|на этих выходных/.test(s)) {
    const wd = weekdayOf(today);
    const sat = T.addDays(today, (6 - wd + 7) % 7);
    if (wd === 0) return { date: today, kind: 'relative', span: 'выходные', ambiguous: { field: 'date', options: [today, T.addDays(today, 6)], question: 'В какой день: сегодня (воскресенье) или в следующую субботу?' } };
    return { date: sat, kind: 'relative', span: 'выходные', ambiguous: { field: 'date', options: [sat, T.addDays(sat, 1)], question: 'В какой день выходных: в субботу или в воскресенье?' } };
  }
  if ((m = new RegExp(`(?<![а-яa-z])(?:(?:в|во|на|on|next|this)\\s+)?(?:(следующ\\w*|эт[уоиа]\\w*|ближайш\\w*|next|this)\\s+)?${WD_RE}`, 'u').exec(s))) {
    const target = wdIndex(m[2]);
    if (target !== null) {
      const qual = m[1] || (/\bnext\s/.test(m[0]) ? 'next' : /\bthis\s/.test(m[0]) ? 'this' : '');
      const wd = weekdayOf(today);
      let delta = (target - wd + 7) % 7;
      if (/следующ|next/.test(qual)) {
        // «в следующую пятницу» = пятница следующей недели (неделя с понедельника)
        const toNextMonday = ((1 - wd + 7) % 7) || 7;
        delta = toNextMonday + ((target - 1 + 7) % 7);
        return { date: T.addDays(today, delta), kind: 'relative', span: m[0] };
      }
      if (delta === 0 && !/эт|this/.test(qual)) {
        return { date: today, kind: 'relative', span: m[0], sameWeekday: true,
          ambiguous: { field: 'date', options: [today, T.addDays(today, 7)], question: `Сегодня как раз ${WD_GEN[wd]}. Имеешь в виду сегодня или ${WD_GEN[wd] === 'воскресенье' ? 'следующее' : 'следующую'} ${WD_GEN[wd]}?` } };
      }
      return { date: T.addDays(today, delta), kind: 'relative', span: m[0] };
    }
  }
  return null;
}

/* ── Время ── */
function findTime(s) {
  let m;
  if ((m = /(?<![а-яa-z])(?:через|in)\s+(?:(\d+|[а-яa-z]+)\s+)?(?:(полчаса|half an hour)|(час[аов]*|hours?|ч)|(минут[уы]?|мин|minutes?|mins?))(?![а-яa-z])/u.exec(s))) {
    if (m[2]) return { minutes: 30, kind: 'relative', span: m[0] };
    const n = m[1] ? num(m[1]) : 1;
    if (n) return { minutes: m[3] ? n * 60 : n, kind: 'relative', span: m[0] };
  }
  if (/(?<![а-яa-z])(?:в полдень|at noon|noon)(?![а-яa-z])/.test(s)) return { time: '12:00', kind: 'exact', span: 'полдень' };
  if (/(?<![а-яa-z])(?:в полночь|at midnight|midnight)(?![а-яa-z])/.test(s)) return { time: '00:00', kind: 'exact', span: 'полночь' };
  if ((m = /(?:^|[^\d.])(\d{1,2}):(\d{2})(?!\d)(?:\s*(утра|дня|вечера|ночи|am|pm|a\.m\.|p\.m\.))?/.exec(s)) || (m = /(?:^|\s)(?:в|к|at)\s+(\d{1,2})\.(\d{2})(?![\d.])(?:\s*(утра|дня|вечера|ночи|am|pm))?/.exec(s))) {
    let h = +m[1]; const min = +m[2];
    if (h <= 23 && min <= 59) {
      h = applyQualifier(h, m[3]);
      if (h !== null) return { time: `${pad(h)}:${pad(min)}`, kind: 'exact', span: m[0] };
    }
  }
  if ((m = /(?:^|\s)(?:в|к|около|at|by)\s+(\d{1,2})(?:\s*(?:ч|час|часа|часов|h)(?![а-яa-z])\.?)?(?:\s*(утра|дня|вечера|ночи|am|pm|a\.m\.|p\.m\.))?(?=$|[\s,.!?;)])/u.exec(s))
    || (m = /(?:^|\s)(\d{1,2})\s*(am|pm|a\.m\.|p\.m\.|утра|вечера|дня|ночи)(?=$|[\s,.!?;)])/u.exec(s))) {
    let h = +m[1];
    const q = m[2];
    if (h <= 24) {
      if (h === 24) h = 0;
      if (!q && h >= 1 && h <= 7) {
        return { kind: 'exact', span: m[0], ambiguous: { field: 'time', options: [`${pad(h)}:00`, `${pad(h + 12)}:00`], question: `В ${h} утра или в ${h} вечера?` } };
      }
      const hh = applyQualifier(h, q);
      if (hh !== null) return { time: `${pad(hh)}:00`, kind: 'exact', span: m[0] };
    }
  }
  for (const [word, t] of Object.entries(PARTS).sort((a, b) => b[0].length - a[0].length)) {
    if (new RegExp(`(?:^|\\s)${word}(?=$|[\\s,.!?;])`, 'u').test(s)) return { time: t, kind: 'part_of_day', span: word };
  }
  return null;
}
function applyQualifier(h, q) {
  if (!q) return h;
  if (/утра|am|a\.m\./.test(q)) return h === 12 ? 0 : h <= 12 ? h : null;
  if (/дня/.test(q)) return h >= 1 && h <= 6 ? h + 12 : h === 12 ? 12 : h <= 23 ? h : null;
  if (/вечера|pm|p\.m\./.test(q)) return h < 12 ? h + 12 : h === 12 ? 12 : h;
  if (/ночи/.test(q)) return h === 12 ? 0 : h <= 4 ? h : h >= 9 && h <= 11 ? h + 12 : null;
  return h;
}

function resolve(text, tz, now) {
  const s = norm(text);
  const ms = now == null ? Date.now() : now;
  const zone = tz && T.isValidTimeZone(tz) ? tz : 'UTC';
  const p = T.zonedParts(ms, zone);
  const today = T.todayIn(zone, ms);
  const out = { date: null, time: null, date_kind: null, time_kind: null, ambiguous: null, past: false };
  if (!s) return out;
  const tm = findTime(s);
  if (tm && tm.minutes) {
    const at = ms + tm.minutes * 60000;
    out.date = T.localDateOf(at, zone); out.time = T.localTimeOf(at, zone);
    out.date_kind = 'relative'; out.time_kind = 'relative';
    return out;
  }
  const dt = findDate(s, today, p);
  if (dt) { out.date = dt.date; out.date_kind = dt.kind; }
  if (tm) { out.time = tm.time || null; out.time_kind = tm.kind; }
  // «в пятницу в 9», а сегодня пятница и 9 уже прошло — значит следующая пятница, вопроса нет
  if (dt && dt.sameWeekday && out.time && T.zonedToUtc(today, out.time, zone) < ms) { out.date = T.addDays(today, 7); dt.ambiguous = null; }
  if (dt && dt.sameWeekday && out.time && T.zonedToUtc(today, out.time, zone) >= ms) dt.ambiguous = dt.ambiguous; // всё ещё неясно: сегодня или через неделю
  if (tm && tm.ambiguous) {
    // «завтра в 7»: 7 утра или 7 вечера. Если дата сегодня и 7 утра уже прошло, остаётся 19:00 — тоже спросим, но короче
    const opts = tm.ambiguous.options;
    if (!dt || dt.date === today) {
      const left = opts.filter((o) => T.zonedToUtc(today, o, zone) > ms);
      if (left.length === 1 && !dt) { out.time = left[0]; out.time_kind = 'exact'; }
      else out.ambiguous = tm.ambiguous;
    } else out.ambiguous = tm.ambiguous;
  }
  if (!out.ambiguous && dt && dt.ambiguous) out.ambiguous = dt.ambiguous;
  // время без даты: сегодня, а если уже прошло — завтра
  if (!out.date && out.time && !out.ambiguous) {
    out.date = T.zonedToUtc(today, out.time, zone) > ms ? today : T.addDays(today, 1);
    out.date_kind = 'relative';
  }
  if (out.date && T.daysBetween(today, out.date) < 0) out.past = true;
  if (out.date && out.time && !out.ambiguous) {
    const at = T.zonedToUtc(out.date, out.time, zone);
    if (at != null && at < ms - 60000) out.past = true;
  }
  return out;
}

/* Календарь на ближайшие дни: модель не считает дни недели сама */
function calendar(tz, now, days) {
  const zone = tz && T.isValidTimeZone(tz) ? tz : 'UTC';
  const today = T.todayIn(zone, now);
  const names = ['сегодня', 'завтра', 'послезавтра'];
  const out = [];
  for (let i = 0; i < (days || 10); i++) {
    const d = T.addDays(today, i);
    out.push(`${names[i] || `через ${i} дн.`} — ${T.humanDate(d)} (${d})`);
  }
  return out;
}

module.exports = { resolve, calendar, norm };
