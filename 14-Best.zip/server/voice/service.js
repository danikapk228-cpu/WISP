/* WISP · Server · Voice service (Layer 7)
 * Настоящее распознавание и синтез речи через OpenAI-совместимый Audio API:
 *   STT  POST {base}/audio/transcriptions  (multipart: file + model [+ language, prompt]) → { text }
 *   TTS  POST {base}/audio/speech          (JSON: model, voice, input [, instructions], response_format) → аудио
 * Ключ провайдера — только здесь, на сервере (config.voice.apiKey). Клиент получает лишь «доступно / нет», голоса и лимиты.
 *
 * Приватность:
 *  · аудио пользователя живёт только в памяти процесса на время одного запроса к провайдеру и нигде не сохраняется;
 *  · в лог пишутся только размер, длительность и код ошибки — ни звука, ни текста;
 *  · в базе — только дневные счётчики (voice_usage) для лимитов тарифа.
 * Ошибки провайдера переводятся в коды WISP (те же, что у чата: provider_auth, provider_busy, timeout…). */
'use strict';
const { HttpError } = require('../lib/http');
const { AIError, fromHttp } = require('../ai/errors');
const { SlidingWindow, dayKey, nextReset } = require('../lib/limits');

const DEFAULT_LIMITS = { stt_daily: 60, stt_max_seconds: 60, tts_chars_daily: 30000, tts_max_chars: 1500, per_minute: 40 };
const MAX_AUDIO_BYTES = 8 * 1024 * 1024;                // ~ несколько минут opus/aac; у провайдера предел 25 МБ
const MIN_AUDIO_BYTES = 600;                            // меньше — это не речь, а пустой контейнер
const PERSONALITIES = ['friendly', 'calm', 'business', 'humor', 'adaptive'];
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;

/* Формат по первым байтам (не верим заголовку Content-Type). Провайдер определяет формат по расширению файла. */
function sniff(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return { ext: 'webm', mime: 'audio/webm' };
  if (buf.toString('latin1', 4, 8) === 'ftyp') return { ext: 'mp4', mime: 'audio/mp4' };
  if (buf.toString('latin1', 0, 4) === 'OggS') return { ext: 'ogg', mime: 'audio/ogg' };
  if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WAVE') return { ext: 'wav', mime: 'audio/wav' };
  if (buf.toString('latin1', 0, 3) === 'ID3' || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0)) return { ext: 'mp3', mime: 'audio/mpeg' };
  if (buf.toString('latin1', 0, 4) === 'fLaC') return { ext: 'flac', mime: 'audio/flac' };
  return null;
}

const toHttp = (e) => {
  if (e instanceof HttpError) return e;
  if (e instanceof AIError) return new HttpError(e.status, e.code, e.message, { retryable: e.retryable });
  return new HttpError(502, 'provider_error', 'Сервис речи ответил ошибкой.', { retryable: true });
};

class VoiceService {
  constructor({ config, store, log }) {
    this.cfg = config.voice || { stt: {}, tts: {}, personalityInstructions: {} };
    this.plans = config.plans;
    this.store = store;
    this.log = log;
    this.perMinute = new SlidingWindow(60 * 1000);
    this.sweeper = setInterval(() => this.perMinute.sweep(), 5 * 60 * 1000);
    this.sweeper.unref();
  }
  stop() { clearInterval(this.sweeper); }

  limits(planId) {
    const p = (this.plans[planId] || this.plans.free || {}).voice || {};
    return { ...DEFAULT_LIMITS, ...p };
  }
  get sttAvailable() { return !!this.cfg.stt.enabled; }
  get ttsAvailable() { return !!this.cfg.tts.enabled; }

  /* Что можно показать клиенту: без ключей и адресов */
  status(userId, planId) {
    const L = this.limits(planId);
    const u = this.store.voiceUsage(userId, dayKey());
    return {
      stt: { available: this.sttAvailable, engine: this.sttAvailable ? 'server' : null, max_seconds: L.stt_max_seconds, max_bytes: MAX_AUDIO_BYTES,
        used: u.stt_requests, limit: L.stt_daily, remaining: Math.max(0, L.stt_daily - u.stt_requests) },
      tts: { available: this.ttsAvailable, engine: this.ttsAvailable ? 'server' : null, voices: this.ttsAvailable ? this.cfg.tts.voices : [],
        default_voice: this.ttsAvailable ? this.cfg.tts.defaultVoice : null, max_chars: L.tts_max_chars, format: this.cfg.tts.format,
        styled: !!this.cfg.tts.instructions,
        used: u.tts_chars, limit: L.tts_chars_daily, remaining: Math.max(0, L.tts_chars_daily - u.tts_chars) },
      reset_at: nextReset(),
    };
  }

  rate(userId, planId) {
    const r = this.perMinute.hit(userId, this.limits(planId).per_minute);
    if (!r.ok) throw new HttpError(429, 'rate_limited', 'Слишком много голосовых запросов подряд. Подожди немного.', { retry_after: r.retryAfter });
  }

  async call(path, init, timeoutMs, signal) {
    const timeout = new AbortController();
    const timer = setTimeout(() => timeout.abort(), timeoutMs || this.cfg.timeoutMs || 30000);
    const combined = signal ? AbortSignal.any([signal, timeout.signal]) : timeout.signal;
    let res;
    try {
      res = await fetch(this.cfg.baseUrl + path, { ...init, headers: { Authorization: `Bearer ${this.cfg.apiKey}`, ...(init.headers || {}) }, signal: combined });
    } catch (e) {
      clearTimeout(timer);
      if (signal && signal.aborted) throw new HttpError(499, 'aborted', 'Запрос отменён.');
      if (timeout.signal.aborted) throw new AIError('timeout');
      throw new AIError('network', e && e.cause ? e.cause.code || e.cause.message : e && e.message);
    }
    if (!res.ok) {
      clearTimeout(timer);
      let text = '';
      try { text = (await res.text()).slice(0, 2000); } catch (e) { /* тело недоступно */ }
      throw fromHttp(res.status, text);
    }
    return { res, done: () => clearTimeout(timer) };
  }

  /* ── Распознавание речи ── */
  async transcribe({ userId, plan, audio, durationMs, name, signal }) {
    if (!this.sttAvailable) throw new HttpError(503, 'voice_unavailable', 'Распознавание речи на сервере не подключено.');
    const L = this.limits(plan);
    if (!audio || audio.length < MIN_AUDIO_BYTES) throw new HttpError(422, 'audio_empty', 'Запись пустая. Попробуй сказать ещё раз.');
    if (audio.length > MAX_AUDIO_BYTES) throw new HttpError(413, 'too_large', 'Запись слишком длинная.');
    const fmt = sniff(audio);
    if (!fmt) throw new HttpError(415, 'bad_audio', 'Неподдерживаемый формат записи.');
    const ms = Number.isFinite(durationMs) && durationMs > 0 ? durationMs : 0;
    if (ms > (L.stt_max_seconds + 3) * 1000) throw new HttpError(413, 'too_long', `Запись длиннее ${L.stt_max_seconds} секунд.`);
    const day = dayKey();
    const used = this.store.voiceUsage(userId, day);
    if (used.stt_requests >= L.stt_daily) throw new HttpError(429, 'voice_limit', 'Лимит распознавания речи на сегодня исчерпан.', { reset_at: nextReset(), kind: 'stt' });
    this.rate(userId, plan);
    this.store.addVoiceUsage(userId, day, { stt: 1, sttMs: ms });

    const form = new FormData();
    form.append('file', new Blob([audio], { type: fmt.mime }), `speech.${fmt.ext}`);
    form.append('model', this.cfg.stt.model);
    form.append('response_format', 'json');
    if (this.cfg.stt.language) form.append('language', this.cfg.stt.language);
    const prompt = [this.cfg.stt.prompt, name ? `Пользователя зовут ${String(name).replace(CONTROL, '').slice(0, 32)}.` : ''].filter(Boolean).join(' ');
    if (prompt) form.append('prompt', prompt);
    const t0 = Date.now();
    try {
      const { res, done } = await this.call('/audio/transcriptions', { method: 'POST', body: form }, this.cfg.timeoutMs, signal);
      let data = null;
      try { data = await res.json(); } finally { done(); }
      const text = String((data && data.text) || '').replace(CONTROL, '').replace(/\s+/g, ' ').trim();
      this.log.info('voice stt', { bytes: audio.length, ms: Math.round(ms), took: Date.now() - t0, empty: !text });
      return { text, duration_ms: Math.round(ms) };
    } catch (e) {
      // сбой не по вине пользователя: попытку не засчитываем
      if (!(e instanceof HttpError) || e.status >= 500 || e.status === 499) this.store.addVoiceUsage(userId, day, { stt: -1, sttMs: -ms });
      this.log.warn('voice stt failed', { code: e.code || 'error', detail: e.detail || '' });
      throw toHttp(e);
    }
  }

  /* ── Синтез речи. Возвращает поток аудио провайдера (ничего не сохраняется) ── */
  prepareText(raw, plan) {
    const L = this.limits(plan);
    const text = String(raw || '').replace(CONTROL, ' ').replace(/\s+/g, ' ').trim();
    if (!text) throw new HttpError(400, 'bad_text', 'Нечего озвучивать.');
    if (text.length > L.tts_max_chars) throw new HttpError(413, 'too_large', `Фрагмент длиннее ${L.tts_max_chars} символов.`);
    return text;
  }
  async speech({ userId, plan, text: raw, voice, personality, signal }) {
    if (!this.ttsAvailable) throw new HttpError(503, 'voice_unavailable', 'Синтез речи на сервере не подключён.');
    const L = this.limits(plan);
    const text = this.prepareText(raw, plan);
    const v = this.cfg.tts.voices.some((x) => x.id === voice) ? voice : this.cfg.tts.defaultVoice;
    const day = dayKey();
    const used = this.store.voiceUsage(userId, day);
    if (used.tts_chars + text.length > L.tts_chars_daily) throw new HttpError(429, 'voice_limit', 'Лимит озвучки на сегодня исчерпан. Ответы остаются текстом.', { reset_at: nextReset(), kind: 'tts' });
    this.rate(userId, plan);
    this.store.addVoiceUsage(userId, day, { ttsChars: text.length });
    const body = { model: this.cfg.tts.model, voice: v, input: text, response_format: this.cfg.tts.format };
    if (this.cfg.tts.instructions) {
      const p = PERSONALITIES.includes(personality) ? personality : 'adaptive';
      const instr = this.cfg.personalityInstructions[p];
      if (instr) body.instructions = String(instr).slice(0, 500);
    }
    try {
      const { res, done } = await this.call('/audio/speech', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, this.cfg.timeoutMs, signal);
      if (!res.body) { done(); throw new AIError('empty_reply'); }
      const type = String(res.headers.get('content-type') || '');
      const mime = /^audio\//i.test(type) ? type.split(';')[0] : (this.cfg.tts.format === 'wav' ? 'audio/wav' : this.cfg.tts.format === 'aac' ? 'audio/aac' : this.cfg.tts.format === 'opus' ? 'audio/ogg' : 'audio/mpeg');
      this.log.info('voice tts', { chars: text.length, voice: v });
      return { body: res.body, mime, voice: v, chars: text.length, done };
    } catch (e) {
      if (!(e instanceof HttpError) || e.status >= 500 || e.status === 499) this.store.addVoiceUsage(userId, day, { ttsChars: -text.length });
      this.log.warn('voice tts failed', { code: e.code || 'error', detail: e.detail || '' });
      throw toHttp(e);
    }
  }
}

module.exports = { VoiceService, sniff, MAX_AUDIO_BYTES, DEFAULT_LIMITS };
