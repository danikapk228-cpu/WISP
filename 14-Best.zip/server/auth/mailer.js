/* WISP · Server · Layer 9 · Mailer
 * Письма подтверждения почты и восстановления пароля. Без npm-зависимостей, четыре транспорта:
 *  · smtp    — любой SMTP-сервер (Postmark, Mailgun, SendGrid, Yandex 360, Gmail Workspace, свой Postfix):
 *              порт 465 = TLS сразу, 587/25 = STARTTLS. Пароль/логин уходят только по зашифрованному каналу
 *              (WISP_SMTP_REQUIRE_TLS=0 отключает это — только для локального тестового SMTP).
 *  · resend  — HTTP API Resend (https://resend.com), ключ WISP_RESEND_API_KEY;
 *  · outbox  — РАЗРАБОТКА: письмо пишется файлом в data/outbox/, ссылка — в лог сервера. Это не обход проверки:
 *              ссылка такая же одноразовая и проверяется сервером. В NODE_ENV=production outbox запрещён;
 *  · memory  — только для автотестов (письма в массиве mailer.sent).
 * Если транспорт не настроен или нет WISP_PUBLIC_URL, регистрация и восстановление честно отвечают
 * «отправка писем не настроена» (503), а не делают вид, что письмо ушло.
 * Ссылки в письмах строятся только из WISP_PUBLIC_URL, никогда из заголовка Host (защита от подмены ссылки). */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const tls = require('node:tls');
const crypto = require('node:crypto');

const ADDR = /^[^\s<>"@]{1,64}@[a-z0-9.-]{1,253}\.[a-z0-9-]{2,63}$/i;
const noCRLF = (s) => String(s || '').replace(/[\r\n]+/g, ' ').trim();

function parseFrom(raw) {
  const v = noCRLF(raw);
  const m = /^(.*?)\s*<([^<>]+)>$/.exec(v);
  const name = m ? m[1].replace(/^"|"$/g, '').trim() : '';
  const address = (m ? m[2] : v).trim();
  return ADDR.test(address) ? { name, address } : null;
}

const encodeWord = (s) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${Buffer.from(s, 'utf8').toString('base64')}?=`);
const wrap76 = (b64) => b64.replace(/.{1,76}/g, '$&\r\n');
function formatAddress({ name, address }) {
  if (!name) return `<${address}>`;
  const enc = encodeWord(name);
  return `${enc === name ? `"${name.replace(/["\\]/g, '')}"` : enc} <${address}>`;
}

/* RFC 5322 + MIME: multipart/alternative (текст + HTML), UTF-8, base64 */
function buildMessage({ from, to, subject, text, html, domain }) {
  const boundary = `wisp_${crypto.randomBytes(12).toString('hex')}`;
  const headers = [
    `From: ${formatAddress(from)}`,
    `To: <${to}>`,
    `Subject: ${encodeWord(noCRLF(subject))}`,
    `Date: ${new Date().toUTCString().replace('GMT', '+0000')}`,
    `Message-ID: <${crypto.randomUUID()}@${domain}>`,
    'MIME-Version: 1.0',
    'Auto-Submitted: auto-generated',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
  ];
  const part = (type, body) => [`--${boundary}`, `Content-Type: ${type}; charset=utf-8`, 'Content-Transfer-Encoding: base64', '', wrap76(Buffer.from(body, 'utf8').toString('base64'))].join('\r\n');
  return headers.join('\r\n') + '\r\n\r\n' + part('text/plain', text) + part('text/html', html) + `--${boundary}--\r\n`;
}

/* ── Минимальный SMTP-клиент (RFC 5321, STARTTLS RFC 3207, AUTH PLAIN/LOGIN RFC 4954) ── */
function smtpSend(cfg, { from, to, message }) {
  return new Promise((resolve, reject) => {
    let socket, buf = '', waiter = null, finished = false;
    const timer = setTimeout(() => fail(new Error('SMTP timeout')), cfg.timeoutMs || 20000);
    function fail(e) { if (finished) return; finished = true; clearTimeout(timer); try { socket && socket.destroy(); } catch (er) {} reject(e); }
    function done() { if (finished) return; finished = true; clearTimeout(timer); try { socket.end(); } catch (e) {} resolve(); }
    function onData(chunk) {
      buf += chunk.toString('utf8');
      for (;;) {
        // ответ закончен, когда пришла строка «КОД пробел …»
        const lines = buf.split('\r\n');
        const complete = lines.slice(0, -1);                     // последняя часть может быть недочитанной строкой
        const idx = complete.findIndex((l) => /^\d{3} /.test(l) || /^\d{3}$/.test(l));
        if (idx < 0) return;
        const reply = complete.slice(0, idx + 1);
        buf = lines.slice(idx + 1).join('\r\n');
        const code = parseInt(reply[reply.length - 1].slice(0, 3), 10);
        const w = waiter; waiter = null;
        if (w) w({ code, lines: reply.map((l) => l.slice(4)) });
      }
    }
    const read = () => new Promise((r) => { waiter = r; });
    const cmd = async (line, ok) => {
      socket.write(line + '\r\n');
      const res = await read();
      if (!ok.includes(Math.floor(res.code / 100) * 100) && !ok.includes(res.code)) throw new Error(`SMTP ${line.split(' ')[0]} → ${res.code}`);
      return res;
    };
    function attach(s) {
      socket = s;
      s.on('data', onData);
      s.on('error', fail);
      s.on('close', () => { if (!finished) fail(new Error('SMTP connection closed')); });
    }
    const tlsOpts = { servername: cfg.host, rejectUnauthorized: cfg.rejectUnauthorized !== false, minVersion: 'TLSv1.2' };
    attach(cfg.secure ? tls.connect({ host: cfg.host, port: cfg.port, ...tlsOpts }) : net.connect({ host: cfg.host, port: cfg.port }));

    (async () => {
      let res = await read();
      if (res.code !== 220) throw new Error(`SMTP greeting ${res.code}`);
      let encrypted = !!cfg.secure;
      res = await cmd(`EHLO ${cfg.ehlo}`, [250]);
      if (!encrypted && res.lines.some((l) => /^STARTTLS\b/i.test(l))) {
        await cmd('STARTTLS', [220]);
        socket.removeListener('data', onData);
        const plain = socket;
        await new Promise((ok, bad) => {
          const t = tls.connect({ socket: plain, ...tlsOpts }, ok);
          t.once('error', bad);
          attach(t);
        });
        encrypted = true;
        buf = '';
        res = await cmd(`EHLO ${cfg.ehlo}`, [250]);
      }
      if (!encrypted && cfg.requireTLS) throw new Error('SMTP server does not offer TLS (WISP_SMTP_REQUIRE_TLS=1)');
      if (cfg.user) {
        const authLine = res.lines.find((l) => /^AUTH\b/i.test(l)) || '';
        if (/\bPLAIN\b/i.test(authLine) || !/\bLOGIN\b/i.test(authLine)) {
          await cmd('AUTH PLAIN ' + Buffer.from(`\0${cfg.user}\0${cfg.pass}`, 'utf8').toString('base64'), [235]);
        } else {
          await cmd('AUTH LOGIN', [334]);
          await cmd(Buffer.from(cfg.user, 'utf8').toString('base64'), [334]);
          await cmd(Buffer.from(cfg.pass, 'utf8').toString('base64'), [235]);
        }
      }
      await cmd(`MAIL FROM:<${from}>`, [250]);
      await cmd(`RCPT TO:<${to}>`, [250, 251]);
      await cmd('DATA', [354]);
      const body = message.replace(/\r?\n/g, '\r\n').replace(/^\./gm, '..');
      socket.write(body.endsWith('\r\n') ? body : body + '\r\n');
      await cmd('.', [250]);
      try { socket.write('QUIT\r\n'); } catch (e) { /* не важно */ }
      done();
    })().catch(fail);
  });
}

class Mailer {
  constructor({ config, log }) {
    this.cfg = config.mail || {};
    this.log = log;
    this.dataDir = config.dataDir;
    this.sent = [];                                  // только транспорт memory (тесты)
    this.from = parseFrom(this.cfg.from || '');
    this.reason = null;
    const t = this.cfg.transport;
    if (!config.publicUrl) this.reason = 'WISP_PUBLIC_URL не задан';
    else if (!t) this.reason = 'WISP_MAIL_TRANSPORT не задан';
    else if (!this.from) this.reason = 'WISP_MAIL_FROM не задан или некорректен';
    else if (t === 'smtp' && !this.cfg.smtp.host) this.reason = 'WISP_SMTP_HOST не задан';
    else if (t === 'resend' && !this.cfg.resendKey) this.reason = 'WISP_RESEND_API_KEY не задан';
    else if (t === 'outbox' && config.production) this.reason = 'outbox нельзя использовать в production';
    else if (!['smtp', 'resend', 'outbox', 'memory'].includes(t)) this.reason = `неизвестный транспорт ${t}`;
    this.configured = !this.reason;
    this.transport = this.configured ? t : null;
  }

  async send({ to, subject, text, html, kind }) {
    if (!this.configured) throw Object.assign(new Error('mail not configured'), { code: 'mail_not_configured' });
    if (!ADDR.test(to)) throw new Error('bad recipient');
    const domain = this.from.address.split('@')[1];
    if (this.transport === 'memory') { this.sent.push({ to, subject, text, html, kind, at: Date.now() }); return; }
    if (this.transport === 'outbox') {
      const dir = path.join(this.dataDir, 'outbox');
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      const file = path.join(dir, `${new Date().toISOString().replace(/[:.]/g, '-')}-${kind || 'mail'}.eml`);
      fs.writeFileSync(file, buildMessage({ from: this.from, to, subject, text, html, domain }), { mode: 0o600 });
      /* Verification and password-reset URLs are bearer credentials. Keep them in the
       * owner-readable outbox file only; logs may be centralized or retained longer. */
      this.log.warn('outbox: письмо не отправлено, а сохранено в файл (режим разработки)', { kind, file: path.relative(this.dataDir, file) });
      return;
    }
    if (this.transport === 'resend') {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), this.cfg.timeoutMs || 15000);
      try {
        const res = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: { Authorization: `Bearer ${this.cfg.resendKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ from: formatAddressPlain(this.from), to: [to], subject, text, html }),
          signal: ctrl.signal,
        });
        if (!res.ok) throw new Error(`resend ${res.status}`);
      } finally { clearTimeout(timer); }
      return;
    }
    const s = this.cfg.smtp;
    await smtpSend({ ...s, ehlo: s.ehlo || domain, timeoutMs: this.cfg.timeoutMs }, { from: this.from.address, to, message: buildMessage({ from: this.from, to, subject, text, html, domain }) });
  }
}
const formatAddressPlain = ({ name, address }) => (name ? `${name.replace(/[<>"]/g, '')} <${address}>` : address);

module.exports = { Mailer, buildMessage, parseFrom, smtpSend };
