/* WISP · Server · Layer 9 · Email templates
 * Письма в стиле WISP: тёмный фон #050508, белый текст, лавандовая кнопка. Всегда есть текстовая версия.
 * В письмо попадают только имя пользователя (экранируется) и одноразовая ссылка. */
'use strict';

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function layout({ title, lead, button, link, note, foot }) {
  const btn = button && link
    ? `<tr><td style="padding:28px 0 8px"><a href="${esc(link)}" style="display:inline-block;background:#c3bcff;color:#0b0a14;text-decoration:none;font-weight:600;font-size:16px;line-height:20px;padding:16px 28px;border-radius:999px">${esc(button)}</a></td></tr>
       <tr><td style="padding:14px 0 0;font-size:13px;line-height:19px;color:rgba(232,229,255,.5)">Если кнопка не работает, открой ссылку:<br><a href="${esc(link)}" style="color:#c3bcff;word-break:break-all">${esc(link)}</a></td></tr>`
    : '';
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="color-scheme" content="dark"><title>${esc(title)}</title></head>
<body style="margin:0;padding:0;background:#050508">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#050508"><tr><td align="center" style="padding:40px 20px">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:480px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#f4f3ff">
<tr><td style="padding:0 0 28px;font-size:15px;letter-spacing:.24em;font-weight:700;color:#f4f3ff"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#c3bcff;box-shadow:0 0 12px #a59bff;margin-right:10px;vertical-align:middle"></span>WISP</td></tr>
<tr><td style="font-size:26px;line-height:32px;font-weight:650;letter-spacing:-.02em">${esc(title)}</td></tr>
<tr><td style="padding:14px 0 0;font-size:16px;line-height:24px;color:rgba(232,229,255,.78)">${lead}</td></tr>
${btn}
${note ? `<tr><td style="padding:24px 0 0;font-size:14px;line-height:21px;color:rgba(232,229,255,.56)">${note}</td></tr>` : ''}
<tr><td style="padding:36px 0 0;font-size:12px;line-height:18px;color:rgba(232,229,255,.36)">${foot || 'Это автоматическое письмо WISP. Отвечать на него не нужно.'}</td></tr>
</table></td></tr></table></body></html>`;
}

function verify({ name, link, hours }) {
  const hi = name ? `${name}, привет!` : 'Привет!';
  return {
    kind: 'verify',
    subject: 'Подтверди почту для WISP',
    text: `${hi}\n\nЧтобы закончить регистрацию в WISP, подтверди адрес почты по ссылке:\n${link}\n\nСсылка действует ${hours} ч и сработает один раз.\nЕсли ты не регистрировался в WISP, просто удали это письмо: без подтверждения аккаунт не заработает.\n`,
    html: layout({
      title: 'Подтверди почту',
      lead: `${esc(hi)} Остался один шаг: подтверди, что это твой адрес, и WISP сохранит чаты, память и задачи в твоём аккаунте.`,
      button: 'Подтвердить почту', link,
      note: `Ссылка действует ${hours} ч и сработает один раз. Если ты не регистрировался в WISP, просто удали это письмо: без подтверждения аккаунт не заработает.`,
    }),
  };
}

function reset({ link, minutes }) {
  return {
    kind: 'reset',
    subject: 'Восстановление пароля WISP',
    text: `Кто-то (надеемся, ты) попросил восстановить пароль от WISP.\n\nЗадать новый пароль:\n${link}\n\nСсылка действует ${minutes} минут и сработает один раз. После смены пароля WISP завершит все открытые сеансы.\nЕсли ты ничего не просил, просто удали письмо: пароль останется прежним.\n`,
    html: layout({
      title: 'Новый пароль',
      lead: 'Кто-то (надеемся, ты) попросил восстановить пароль от WISP. Нажми кнопку, чтобы задать новый.',
      button: 'Задать новый пароль', link,
      note: `Ссылка действует ${minutes} минут и сработает один раз. После смены пароля WISP завершит все открытые сеансы. Если ты ничего не просил, просто удали письмо: пароль останется прежним.`,
    }),
  };
}

/* Повторная регистрация на уже существующий адрес: ответ сайта одинаковый, а владелец адреса узнаёт об этом из письма */
function alreadyRegistered({ loginLink, resetLink }) {
  return {
    kind: 'exists',
    subject: 'Попытка регистрации в WISP',
    text: `Кто-то пытался зарегистрироваться в WISP с этим адресом, но аккаунт с ним уже есть.\n\nЕсли это был ты, просто войди: ${loginLink}\nЗабыл пароль? Восстанови его: ${resetLink}\n\nЕсли это был не ты, ничего делать не нужно: без пароля в аккаунт не войти.\n`,
    html: layout({
      title: 'У тебя уже есть аккаунт',
      lead: 'Кто-то пытался зарегистрироваться в WISP с этим адресом, но аккаунт с ним уже есть. Если это был ты, просто войди.',
      button: 'Войти в WISP', link: loginLink,
      note: `Забыл пароль? <a href="${esc(resetLink)}" style="color:#c3bcff">Восстанови его</a>. Если это был не ты, ничего делать не нужно: без пароля в аккаунт не войти.`,
    }),
  };
}

function passwordChanged({ resetLink }) {
  return {
    kind: 'changed',
    subject: 'Пароль WISP изменён',
    text: `Пароль от твоего аккаунта WISP только что изменили. Остальные сеансы завершены.\n\nЕсли это был не ты, сразу восстанови доступ: ${resetLink}\n`,
    html: layout({
      title: 'Пароль изменён',
      lead: 'Пароль от твоего аккаунта WISP только что изменили. Все остальные сеансы завершены.',
      button: 'Это был не я', link: resetLink,
      note: 'Если пароль менял ты, ничего делать не нужно.',
    }),
  };
}

module.exports = { verify, reset, alreadyRegistered, passwordChanged, esc };
