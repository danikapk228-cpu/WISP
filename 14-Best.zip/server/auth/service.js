/* WISP · Server · Layer 9 · Account service
 * Вся логика аккаунтов: регистрация, подтверждение почты, вход, восстановление и смена пароля, удаление.
 * Правила (email, пароль, имя) — общий файл src/auth/rules.js, но решение всегда принимает сервер.
 *
 * Приватность:
 *  · ответ «зарегистрироваться» одинаковый для нового и уже занятого адреса (владельцу занятого адреса уходит
 *    письмо «у тебя уже есть аккаунт»); «забыли пароль» и «отправить письмо ещё раз» не говорят, есть ли адрес;
 *  · вход: «неверная почта или пароль» без уточнения, время проверки одинаковое (dummyVerify);
 *    «почта не подтверждена» сообщается только тому, кто ввёл верный пароль.
 * Ссылки из писем одноразовые, в базе только SHA-256 токена, срок: подтверждение 24 ч, сброс пароля 30 мин.
 * Неподтверждённый аккаунт не может войти; через 7 дней без подтверждения он удаляется (адрес освобождается).
 * Защита от «захвата заранее» (кто-то регистрирует чужой адрес первым): пароль задаёт та регистрация,
 * по ссылке из письма которой подтвердили почту (токен хранит хеш её пароля). */
'use strict';
const crypto = require('node:crypto');
const { HttpError } = require('../lib/http');
const Rules = require('../../src/auth/rules');
const Password = require('./password');
const Emails = require('./emails');
const Profile = require('../account/profile');
const { Throttle, RULES, emailKey } = require('./throttle');
const { hash: sha, newToken } = require('../lib/auth');

const DAY = 24 * 60 * 60 * 1000;
const TOKEN_RE = /^[A-Za-z0-9_-]{40,64}$/;

const bad = (code, field, status) => new HttpError(status || 400, code, Rules.message(code) || 'Проверь данные.', field ? { field } : null);
function maskEmail(email) {
  const [local, domain] = String(email).split('@');
  if (!domain) return '';
  const head = local.length <= 2 ? local[0] : local.slice(0, 2);
  return `${head}${'•'.repeat(Math.max(2, Math.min(6, local.length - head.length)))}@${domain}`;
}

class AccountService {
  constructor({ store, config, mailer, log, memoryService }) {
    this.store = store;
    this.config = config;
    this.mailer = mailer;
    this.log = log;
    this.memoryService = memoryService || null;
    this.throttle = new Throttle(store);
    const a = config.accounts || {};
    this.verifyTtlMs = (a.verifyTtlHours || 24) * 60 * 60 * 1000;
    this.resetTtlMs = (a.resetTtlMinutes || 30) * 60 * 1000;
    this.unverifiedTtlMs = (a.unverifiedTtlDays || 7) * DAY;
    this.queue = new Set();                              // письма, которые отправляются в фоне (тестам — flush())
  }

  get mailReady() { return this.mailer.configured; }
  link(kind, token) { return `${this.config.publicUrl}/#/${kind}${token ? '/' + token : ''}`; }

  publicConfig() {
    return {
      accounts: true,
      registration: this.mailReady,
      password_reset: this.mailReady,
      guest_mode: !!(this.config.accounts && this.config.accounts.guestMode),
      password_min: Rules.PASSWORD_MIN,
      password_max: Rules.PASSWORD_MAX,
      verify_ttl_hours: Math.round(this.verifyTtlMs / 3600000),
      reset_ttl_minutes: Math.round(this.resetTtlMs / 60000),
    };
  }

  requireMail() {
    if (!this.mailReady) throw new HttpError(503, 'mail_not_configured', 'Сервер WISP пока не умеет отправлять письма, поэтому регистрация и восстановление пароля недоступны. Напиши в поддержку или попробуй позже.');
  }

  /* Лимит писем на адрес (общий для регистрации, повторной отправки и сброса): одинаков для существующих и нет */
  mailAllowed(email, ip) {
    const ek = emailKey(email);
    const gap = this.throttle.check('mail:gap:' + ek);
    if (!gap.ok) return { ok: false, retryAfter: gap.retryAfter };
    for (const [k, rule] of [['mail:em:' + ek, RULES.mailEmail], ['mail:ip:' + ip, RULES.mailIp]]) {
      const c = this.throttle.check(k);
      if (!c.ok) return { ok: false, retryAfter: c.retryAfter };
    }
    if (!this.throttle.hit('mail:gap:' + ek, RULES.mailGap)) return { ok: false, retryAfter: 60 };
    const a = this.throttle.hit('mail:em:' + ek, RULES.mailEmail);
    const b = this.throttle.hit('mail:ip:' + ip, RULES.mailIp);
    return a && b ? { ok: true } : { ok: false, retryAfter: 3600 };
  }

  async sendMail(to, tpl) {
    await this.mailer.send({ to, subject: tpl.subject, text: tpl.text, html: tpl.html, kind: tpl.kind });
  }
  /* Фоновая отправка: ответ не ждёт SMTP, поэтому по времени ответа нельзя понять, ушло ли письмо (есть ли адрес) */
  background(to, tpl) {
    const p = this.sendMail(to, tpl).catch((e) => this.log.error('mail failed', { kind: tpl.kind, error: e && e.message }));
    this.queue.add(p);
    p.finally(() => this.queue.delete(p));
  }
  async flush() { await Promise.all([...this.queue]); }

  issue(userId, purpose, ttlMs, meta) {
    const token = newToken();
    this.store.createToken(sha(token), userId, purpose, ttlMs, meta);
    return token;
  }

  profileName(userId) {
    const p = this.store.getProfile(userId);
    return p && p.data && p.data.user && p.data.user.name ? p.data.user.name : null;
  }
  /* Имя аккаунта живёт в профиле (Layer 6), второй копии нет */
  setProfileName(userId, name) {
    const cur = this.store.getProfile(userId);
    const base = cur ? cur.data : { user: {}, meta: {} };
    const next = Profile.sanitize({ ...base, user: { ...(base.user || {}), name }, meta: { ...(base.meta || {}), updated_at: new Date().toISOString() } });
    if (next) this.store.saveProfile(userId, next);
  }

  /* ── Регистрация ── */
  async register({ name, email: rawEmail, password, passwordConfirm, ip }) {
    if (!this.throttle.hit('reg:ip:' + ip, RULES.registerIp)) throw new HttpError(429, 'rate_limited', 'Слишком много регистраций с этого адреса. Попробуй через час.', { retry_after: 3600 });
    const nameErr = Rules.nameError(name);
    if (nameErr) throw bad(nameErr, 'name');
    const email = Rules.normalizeEmail(rawEmail);
    const emailErr = Rules.emailError(email);
    if (emailErr) throw bad(emailErr, 'email');
    const cleanName = Rules.normalizeName(name);
    const pc = Rules.passwordCheck(password, { email, name: cleanName });
    if (!pc.ok) throw bad(pc.error, 'password');
    if (passwordConfirm !== undefined && passwordConfirm !== password) throw bad('password_mismatch', 'password_confirm');
    this.requireMail();

    const passwordHash = await Password.hash(password);        // считаем всегда: одинаковое время для любых адресов
    const quota = this.mailAllowed(email, ip);
    let user = this.store.getUserByEmail(email);
    let tpl = null;
    if (!user) {
      user = this.store.transaction(() => {
        const u = this.store.createAccount({ email, passwordHash });
        this.setProfileName(u.id, cleanName);
        return u;
      });
      this.log.info('account registered', { user: user.id });
    } else if (!user.email_verified_at) {
      this.store.rehashPassword(user.id, passwordHash);         // «почта не подтверждена» сообщаем тому, кто знает последний пароль
    }
    if (!user.email_verified_at) {
      const token = this.issue(user.id, 'verify', this.verifyTtlMs, { hash: passwordHash, name: cleanName });
      tpl = Emails.verify({ name: cleanName, link: this.link('verify', token), hours: Math.round(this.verifyTtlMs / 3600000) });
    } else {
      tpl = Emails.alreadyRegistered({ loginLink: this.link('login'), resetLink: this.link('forgot') });
    }
    let sent = false;
    if (quota.ok) {
      try { await this.sendMail(email, tpl); sent = true; } catch (e) { this.log.error('mail failed', { kind: tpl.kind, error: e && e.message }); }
    }
    return { ok: true, email, email_sent: sent, resend_after: quota.ok ? 60 : quota.retryAfter };
  }

  /* ── Подтверждение почты по ссылке ── */
  readToken(raw, purpose, ip) {
    const ipKey = 'token:ip:' + ip;
    const lim = this.throttle.check(ipKey);
    if (!lim.ok) throw new HttpError(429, 'too_many_attempts', 'Слишком много попыток открыть ссылку. Подожди немного.', { retry_after: lim.retryAfter });
    const t = typeof raw === 'string' && TOKEN_RE.test(raw) ? this.store.getToken(sha(raw)) : null;
    if (!t || t.purpose !== purpose) {
      this.throttle.fail(ipKey, RULES.tokenIp);
      throw new HttpError(400, 'token_invalid', purpose === 'verify'
        ? 'Ссылка недействительна. Скопируй её из письма целиком или запроси новое письмо.'
        : 'Ссылка недействительна. Запроси восстановление пароля ещё раз.');
    }
    return t;
  }

  verify({ token, ip }) {
    const t = this.readToken(token, 'verify', ip);
    if (t.email_verified_at) { this.store.useToken(t.token_hash); return { ok: true, email: t.email, already: true }; }
    if (t.used_at) throw new HttpError(400, 'token_used', 'Эта ссылка уже использована. Запроси новое письмо.', { email: t.email });
    if (t.expires_at < Date.now()) throw new HttpError(410, 'token_expired', 'Срок действия ссылки истёк. Отправим новое письмо?', { email: t.email });
    this.store.transaction(() => {
      /* Consume this exact token atomically. A prior readToken() is not enough:
       * two concurrent requests could otherwise both apply its pending metadata. */
      if (!this.store.useToken(t.token_hash)) {
        throw new HttpError(400, 'token_used', 'Эта ссылка уже использована. Запроси новое письмо.', { email: t.email });
      }
      if (!this.store.markVerified(t.user_id)) {
        throw new HttpError(400, 'token_used', 'Эта ссылка уже использована. Запроси новое письмо.', { email: t.email });
      }
      if (t.meta && t.meta.hash) this.store.setPassword(t.user_id, t.meta.hash);
      if (t.meta && t.meta.name) this.setProfileName(t.user_id, t.meta.name);
      this.store.useAllTokens(t.user_id, 'verify');
    });
    this.log.info('email verified', { user: t.user_id });
    return { ok: true, email: t.email, already: false };
  }

  /* ── Письмо подтверждения ещё раз ── */
  resend({ email: rawEmail, ip }) {
    const email = Rules.normalizeEmail(rawEmail);
    const err = Rules.emailError(email);
    if (err) throw bad(err, 'email');
    this.requireMail();
    const quota = this.mailAllowed(email, ip);
    if (!quota.ok) throw new HttpError(429, 'rate_limited', 'Письмо только что ушло. Подожди немного и проверь «Спам».', { retry_after: quota.retryAfter });
    const user = this.store.getUserByEmail(email);
    if (user && !user.email_verified_at) {
      const name = this.profileName(user.id);
      const token = this.issue(user.id, 'verify', this.verifyTtlMs, { hash: user.password_hash, name });
      this.background(email, Emails.verify({ name, link: this.link('verify', token), hours: Math.round(this.verifyTtlMs / 3600000) }));
    }
    return { ok: true, resend_after: 60 };
  }

  /* ── Вход ── */
  async login({ email: rawEmail, password, ip }) {
    const email = Rules.normalizeEmail(rawEmail);
    const err = Rules.emailError(email);
    if (err) throw bad(err, 'email');
    if (typeof password !== 'string' || !password) throw bad('password_required', 'password');
    if (password.length > 1024) throw new HttpError(401, 'invalid_credentials', 'Неверная почта или пароль.');
    const ek = emailKey(email);
    const keys = [['login:ip:' + ip, RULES.loginIp], [`login:pair:${ek}:${ip}`, RULES.loginPair], ['login:em:' + ek, RULES.loginEmail]];
    for (const [k] of keys) {
      const c = this.throttle.check(k);
      if (!c.ok) throw new HttpError(429, 'too_many_attempts', `Слишком много попыток входа. Попробуй через ${Math.ceil(c.retryAfter / 60)} мин или восстанови пароль.`, { retry_after: c.retryAfter });
    }
    const user = this.store.getUserByEmail(email);
    const ok = user && user.password_hash ? await Password.verify(password, user.password_hash) : await Password.dummyVerify(password);
    if (!ok) {
      let left = null;
      for (const [k, rule] of keys) { const r = this.throttle.fail(k, rule); if (k.startsWith('login:pair:')) left = Math.max(0, rule.max - r.count); }
      throw new HttpError(401, 'invalid_credentials', 'Неверная почта или пароль. Проверь раскладку и Caps Lock или восстанови пароль.', { attempts_left: left });
    }
    this.throttle.reset(keys[1][0]);
    this.throttle.reset(keys[2][0]);
    if (!user.email_verified_at) throw new HttpError(403, 'email_not_verified', 'Почта ещё не подтверждена. Открой ссылку из письма или отправь его ещё раз.', { email });
    if (Password.needsRehash(user.password_hash)) this.store.rehashPassword(user.id, await Password.hash(password));
    return { userId: user.id, email };
  }

  /* ── Восстановление пароля ── */
  forgot({ email: rawEmail, ip }) {
    const email = Rules.normalizeEmail(rawEmail);
    const err = Rules.emailError(email);
    if (err) throw bad(err, 'email');
    this.requireMail();
    const quota = this.mailAllowed(email, ip);
    if (!quota.ok) throw new HttpError(429, 'rate_limited', 'Письмо уже отправлено. Подожди немного и проверь «Спам».', { retry_after: quota.retryAfter });
    const user = this.store.getUserByEmail(email);
    if (user) {
      this.store.useAllTokens(user.id, 'reset');                 // действует только последняя ссылка
      const token = this.issue(user.id, 'reset', this.resetTtlMs);
      this.background(email, Emails.reset({ link: this.link('reset', token), minutes: Math.round(this.resetTtlMs / 60000) }));
    }
    return { ok: true, resend_after: 60, ttl_minutes: Math.round(this.resetTtlMs / 60000) };
  }

  liveReset(token, ip) {
    const t = this.readToken(token, 'reset', ip);
    if (t.used_at) throw new HttpError(400, 'token_used', 'Эта ссылка уже использована или заменена новой. Запроси восстановление ещё раз.');
    if (t.expires_at < Date.now()) throw new HttpError(410, 'token_expired', 'Срок действия ссылки истёк. Запроси восстановление пароля ещё раз.');
    return t;
  }
  checkReset({ token, ip }) {
    const t = this.liveReset(token, ip);
    return { ok: true, email_hint: maskEmail(t.email), expires_at: t.expires_at };
  }

  async reset({ token, password, passwordConfirm, ip }) {
    const t = this.liveReset(token, ip);
    const pc = Rules.passwordCheck(password, { email: t.email, name: this.profileName(t.user_id) });
    if (!pc.ok) throw bad(pc.error, 'password');
    if (passwordConfirm !== undefined && passwordConfirm !== password) throw bad('password_mismatch', 'password_confirm');
    const passwordHash = await Password.hash(password);
    const fresh = this.store.getToken(t.token_hash);            // пока считался хеш, ссылку могли использовать
    if (!fresh || fresh.used_at) throw new HttpError(400, 'token_used', 'Эта ссылка уже использована. Запроси восстановление ещё раз.');
    this.store.transaction(() => {
      if (!this.store.useToken(t.token_hash)) throw new HttpError(400, 'token_used', 'Эта ссылка уже использована.');
      this.store.setPassword(t.user_id, passwordHash);
      this.store.markVerified(t.user_id);                       // ссылка пришла на эту почту: адрес подтверждён
      this.store.useAllTokens(t.user_id, 'reset');
      this.store.deleteSessionsOf(t.user_id);                   // все прежние сеансы завершены
    });
    this.log.info('password reset', { user: t.user_id });
    this.throttle.reset('login:em:' + emailKey(t.email));
    this.background(t.email, Emails.passwordChanged({ resetLink: this.link('forgot') }));
    return { ok: true, email: t.email };
  }

  /* ── Проверка текущего пароля (смена пароля, удаление аккаунта) ── */
  async checkCurrent(session, password) {
    const key = 'pw:user:' + session.userId;
    const c = this.throttle.check(key);
    if (!c.ok) throw new HttpError(429, 'too_many_attempts', `Слишком много попыток. Попробуй через ${Math.ceil(c.retryAfter / 60)} мин.`, { retry_after: c.retryAfter });
    const u = this.store.getUserAuth(session.userId);
    const ok = u && typeof password === 'string' && password.length <= 1024 && await Password.verify(password, u.password_hash);
    if (!ok) { this.throttle.fail(key, RULES.passwordUser); throw new HttpError(400, 'wrong_password', 'Текущий пароль введён неверно.', { field: 'current' }); }
    this.throttle.reset(key);
    return u;
  }

  async changePassword({ session, current, password, passwordConfirm }) {
    const u = await this.checkCurrent(session, current);
    const pc = Rules.passwordCheck(password, { email: u.email, name: this.profileName(u.id) });
    if (!pc.ok) throw bad(pc.error, 'password');
    if (passwordConfirm !== undefined && passwordConfirm !== password) throw bad('password_mismatch', 'password_confirm');
    if (password === current) throw new HttpError(400, 'password_same', 'Новый пароль совпадает с текущим. Придумай другой.', { field: 'password' });
    const passwordHash = await Password.hash(password);
    this.store.transaction(() => {
      this.store.setPassword(u.id, passwordHash);
      this.store.deleteSessionsOf(u.id, session.tokenHash);      // остальные устройства выходят
      this.store.reauthSession(session.tokenHash);
    });
    if (this.mailReady) this.background(u.email, Emails.passwordChanged({ resetLink: this.link('forgot') }));
    return { ok: true };
  }

  async deleteAccount({ session, password }) {
    const user = await this.checkCurrent(session, password);
    this.store.deleteUser(session.userId);
    this.store.deleteAccountThrottle(emailKey(user.email), user.id);
    if (this.memoryService) this.memoryService.clearUserCache(user.id);
    this.log.info('account deleted', { user: session.userId });
    return { ok: true };
  }

  purge() { return this.store.purgeAuth(this.unverifiedTtlMs); }
}

module.exports = { AccountService, maskEmail };
