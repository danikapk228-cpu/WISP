/* WISP · Server · Layer 9 · Throttle
 * Ограничение попыток входа и частоты писем. Счётчики лежат в SQLite (auth_throttle), поэтому перезапуск сервера
 * их не сбрасывает. Ключи содержат только SHA-256 от email, сам адрес в таблицу не попадает.
 *
 * rule = { max, windowMs, lockMs }:
 *  · fail(key)  — неудачная попытка; на max-й внутри окна ключ блокируется на lockMs;
 *  · hit(key)   — событие, которое просто считается (регистрация, письмо); при превышении — блок;
 *  · check(key) — { ok } или { ok:false, retryAfter } (секунды);
 *  · reset(key) — после успешного входа. */
'use strict';
const crypto = require('node:crypto');

const MIN = 60 * 1000;
const RULES = {
  loginIp: { max: 30, windowMs: 15 * MIN, lockMs: 15 * MIN },          // один адрес перебирает много аккаунтов
  loginPair: { max: 5, windowMs: 15 * MIN, lockMs: 15 * MIN },         // этот адрес + этот аккаунт
  loginEmail: { max: 20, windowMs: 60 * MIN, lockMs: 30 * MIN },       // распределённый перебор одного аккаунта
  registerIp: { max: 10, windowMs: 60 * MIN, lockMs: 60 * MIN },
  mailEmail: { max: 5, windowMs: 60 * MIN, lockMs: 60 * MIN },         // писем на один адрес в час
  mailGap: { max: 1, windowMs: 1 * MIN, lockMs: 1 * MIN },             // не чаще раза в минуту
  mailIp: { max: 20, windowMs: 60 * MIN, lockMs: 60 * MIN },
  tokenIp: { max: 30, windowMs: 15 * MIN, lockMs: 15 * MIN },          // перебор ссылок подтверждения / сброса
  passwordUser: { max: 5, windowMs: 15 * MIN, lockMs: 15 * MIN },      // текущий пароль при смене / удалении
};

const emailKey = (email) => crypto.createHash('sha256').update('wisp-email:' + email).digest('hex').slice(0, 32);

class Throttle {
  constructor(store) { this.store = store; }

  check(key) {
    const r = this.store.throttleGet(key);
    const t = Date.now();
    if (r && r.locked_until > t) return { ok: false, retryAfter: Math.max(1, Math.ceil((r.locked_until - t) / 1000)) };
    return { ok: true };
  }

  count(key, rule) {
    const t = Date.now();
    const r = this.store.throttleGet(key);
    let count = 1, start = t;
    if (r && t - r.window_start < rule.windowMs) { count = r.count + 1; start = r.window_start; }
    const locked = count >= rule.max ? t + rule.lockMs : 0;
    this.store.throttleSet(key, count, start, locked);
    return { count, locked: !!locked };
  }

  fail(key, rule) { return this.count(key, rule); }

  /* Посчитать событие и сказать, разрешено ли оно (true) — превышение лимита блокирует ключ */
  hit(key, rule) {
    if (!this.check(key).ok) return false;
    const t = Date.now();
    const r = this.store.throttleGet(key);
    const count = r && t - r.window_start < rule.windowMs ? r.count + 1 : 1;
    if (count > rule.max) { this.store.throttleSet(key, r.count, r.window_start, r.window_start + rule.windowMs); return false; }
    this.store.throttleSet(key, count, count === 1 ? t : r.window_start, 0);
    return true;
  }

  reset(key) { this.store.throttleDelete(key); }
}

module.exports = { Throttle, RULES, emailKey };
