/* WISP · Server · Layer 9 · Password hashing
 * scrypt из встроенного node:crypto (RFC 7914) — проверенная функция растяжения ключа, рекомендованная OWASP.
 * Без npm-зависимостей: проект работает на голом Node ≥ 22.13 (argon2 появился в node:crypto только в Node 24).
 *
 * Формат строки в базе:  scrypt$1$ln=15,r=8,p=3$<соль base64url>$<ключ base64url>
 *  · соль 16 байт из crypto.randomBytes, ключ 32 байта;
 *  · параметры по умолчанию — вариант OWASP «N=2^15, r=8, p=3» (≈32 МБ памяти на хеш);
 *    WISP_SCRYPT_LOG_N=14..17 меняет стоимость; старые хеши перехешируются при следующем входе (needsRehash);
 *  · сравнение через timingSafeEqual; пароль перед хешированием приводится к NFKC (одинаковые символы = одинаковый пароль).
 * Пароль в открытом виде нигде не хранится и не пишется в лог. */
'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(crypto.scrypt);
const KEY_LEN = 32;
const SALT_LEN = 16;
const R = 8;
const P = 3;

function logN() {
  const n = parseInt(process.env.WISP_SCRYPT_LOG_N, 10);
  return Number.isFinite(n) && n >= 14 && n <= 17 ? n : 15;
}

const b64 = (buf) => buf.toString('base64url');
const prep = (password) => Buffer.from(String(password).normalize('NFKC'), 'utf8');
const maxmem = (ln, r) => 256 * (1 << ln) * r;

async function derive(password, salt, ln, r, p) {
  return scrypt(prep(password), salt, KEY_LEN, { N: 1 << ln, r, p, maxmem: maxmem(ln, r) });
}

async function hash(password) {
  const ln = logN();
  const salt = crypto.randomBytes(SALT_LEN);
  const key = await derive(password, salt, ln, R, P);
  return `scrypt$1$ln=${ln},r=${R},p=${P}$${b64(salt)}$${b64(key)}`;
}

function parse(stored) {
  if (typeof stored !== 'string') return null;
  const m = /^scrypt\$1\$ln=(\d{2}),r=(\d{1,2}),p=(\d{1,2})\$([A-Za-z0-9_-]{16,64})\$([A-Za-z0-9_-]{32,128})$/.exec(stored);
  if (!m) return null;
  const ln = +m[1], r = +m[2], p = +m[3];
  if (ln < 10 || ln > 20 || r < 1 || r > 32 || p < 1 || p > 16) return null;
  return { ln, r, p, salt: Buffer.from(m[4], 'base64url'), key: Buffer.from(m[5], 'base64url') };
}

async function verify(password, stored) {
  const h = parse(stored);
  if (!h || typeof password !== 'string') return false;
  const key = await derive(password, h.salt, h.ln, h.r, h.p);
  return key.length === h.key.length && crypto.timingSafeEqual(key, h.key);
}

function needsRehash(stored) {
  const h = parse(stored);
  return !h || h.ln !== logN() || h.r !== R || h.p !== P;
}

/* Для входа с несуществующим адресом: тратим столько же времени, сколько на настоящую проверку,
 * чтобы по времени ответа нельзя было узнать, есть ли такой аккаунт. */
let dummy = null;
async function dummyVerify(password) {
  if (!dummy) dummy = await hash('wisp-dummy-' + crypto.randomBytes(8).toString('hex'));
  await verify(String(password || ''), dummy);
  return false;
}

module.exports = { hash, verify, needsRehash, dummyVerify, parse };
