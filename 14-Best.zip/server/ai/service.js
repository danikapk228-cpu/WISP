/* WISP · Server · AI service
 * Универсальная точка доступа к языковым моделям. Интерфейс не знает, какой провайдер за моделью:
 * провайдер выбирается по models.json, новый провайдер = новый адаптер в providers/ с функцией stream().
 * Адаптер получает нормализованный диалог и отдаёт события { delta | usage | tool_call | finish }. */
'use strict';
const { AIError } = require('./errors');

const ADAPTERS = {
  openai: require('./providers/openai'),
  anthropic: require('./providers/anthropic'),
};

class AIService {
  constructor(config) {
    this.config = config;
    this.providers = config.providers;
    this.models = config.models;
  }

  /* Модель «подключена», если у провайдера есть адаптер, адрес и ключ (или ключ не обязателен) */
  availability(model) {
    const p = this.providers[model.provider];
    if (!p || !ADAPTERS[p.type]) return { available: false, reason: 'Провайдер не настроен на сервере' };
    if (!p.baseUrl) return { available: false, reason: 'Не указан адрес провайдера' };
    if (!p.apiKey && !p.keyOptional) return { available: false, reason: 'Модель не подключена на сервере' };
    return { available: true };
  }

  find(id) { return this.models.find((m) => m.id === id) || null; }

  allowedForPlan(model, planId) { return model.tier === 'free' || planId === 'plus'; }

  /* Публичное описание без ключей, адресов и имён моделей провайдера */
  publicModel(model, planId) {
    const a = this.availability(model);
    return {
      id: model.id,
      label: model.label,
      description: model.description,
      tier: model.tier,
      vision: model.vision,
      available: a.available,
      allowed: this.allowedForPlan(model, planId),
      reason: a.available ? null : a.reason,
    };
  }

  listFor(planId) { return this.models.map((m) => this.publicModel(m, planId)); }

  /* Модель по умолчанию для тарифа: из конфига, иначе первая доступная разрешённая */
  defaultFor(planId) {
    const pref = this.find(this.config.defaultModel[planId]) || this.find(this.config.defaultModel.free);
    if (pref && this.availability(pref).available && this.allowedForPlan(pref, planId)) return pref;
    return this.models.find((m) => this.availability(m).available && this.allowedForPlan(m, planId)) || null;
  }

  anyAvailable() { return this.models.some((m) => this.availability(m).available); }

  /* Проверка выбора модели для запроса. Возвращает модель или бросает понятную ошибку. */
  resolve(requestedId, planId) {
    if (requestedId) {
      const m = this.find(requestedId);
      if (!m) { const e = new AIError('model_unavailable', 'unknown id'); e.status = 400; throw e; }
      if (!this.allowedForPlan(m, planId)) { const e = new Error('plan_required'); e.code = 'plan_required'; e.status = 403; throw e; }
      if (!this.availability(m).available) throw new AIError('model_unavailable', 'not configured');
      return m;
    }
    const d = this.defaultFor(planId);
    if (!d) throw new AIError('model_unavailable', 'no configured models');
    return d;
  }

  /* Модель умеет вызывать функции (Layer 4): флаг tools в models.json, по умолчанию да */
  supportsTools(model) { return model.tools !== false; }

  /* Потоковая генерация. messages: [{ role, parts:[{type:'text',text}|{type:'image',mime,base64}
   *   |{type:'tool_call',id,name,input}|{type:'tool_result',id,content,isError}] }], role: user|assistant|tool.
   * tools (необязательно): [{ name, description, parameters }] — адаптер вернёт события tool_call. */
  async *stream({ model, system, messages, maxTokens, signal, tools }) {
    const provider = this.providers[model.provider];
    const adapter = ADAPTERS[provider.type];
    const timeouts = { firstByteMs: this.config.upstreamTimeoutMs, idleMs: this.config.idleTimeoutMs };
    try {
      yield* adapter.stream({ provider, model, system, messages, maxTokens, signal, timeouts, tools: tools && this.supportsTools(model) ? tools : null });
    } catch (e) {
      if (e && e.code === 'idle_timeout') throw new AIError('timeout', 'idle');
      if (e && e.code === 'response_too_large') throw new AIError('response_too_large');
      if (e && e.name === 'AbortError') {
        if (signal && signal.aborted) { const err = new Error('aborted'); err.code = 'aborted'; throw err; }
        throw new AIError('timeout');
      }
      if (e instanceof AIError || (e && e.code === 'aborted')) throw e;
      if (e && e.name === 'TypeError') throw new AIError('network', e.message);
      throw new AIError('provider_error', e && e.message);
    }
  }
}

module.exports = { AIService, ADAPTERS };
