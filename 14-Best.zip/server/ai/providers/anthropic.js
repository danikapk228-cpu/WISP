/* WISP · Server · Provider: Anthropic Messages API
 * POST {base_url}/v1/messages, stream: true → SSE-события message_start / content_block_delta (text_delta) /
 * message_delta / message_stop / error. Системная инструкция передаётся отдельным полем system.
 * Layer 4: tool use. Инструменты уходят в tools[] (input_schema), вызов приходит блоком tool_use:
 * content_block_start (id, name) → input_json_delta (кусочки JSON) → content_block_stop.
 * Результаты возвращаются модели блоками tool_result в реплике user. */
'use strict';
const { parseSSE } = require('../sse');
const { AIError, fromHttp } = require('../errors');
const { openStream } = require('./http');
const MAX_TOOL_CALLS = 32;
const MAX_TOOL_ARGUMENT_CHARS = 32 * 1024;

const API_VERSION = '2023-06-01';

/* Messages API ожидает диалог, начинающийся с user; подряд идущие реплики одной роли склеиваем. */
function toMessages(messages) {
  const out = [];
  for (const m of messages) {
    const role = m.role === 'tool' ? 'user' : m.role;
    const content = [];
    for (const p of m.parts) {
      if (p.type === 'text' && p.text) content.push({ type: 'text', text: p.text });
      else if (p.type === 'image' && m.role === 'user') content.push({ type: 'image', source: { type: 'base64', media_type: p.mime, data: p.base64 } });
      else if (p.type === 'tool_call' && m.role === 'assistant') content.push({ type: 'tool_use', id: p.id, name: p.name, input: p.input || {} });
      else if (p.type === 'tool_result' && m.role === 'tool') content.push({ type: 'tool_result', tool_use_id: p.id, content: p.content, ...(p.isError ? { is_error: true } : {}) });
    }
    if (!content.length) continue;
    const last = out[out.length - 1];
    if (last && last.role === role) {
      // результаты инструментов должны идти первыми в реплике пользователя
      if (m.role === 'tool') last.content.unshift(...content); else last.content.push(...content);
    } else out.push({ role, content });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}

function toTools(tools) {
  return tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
}

function eventError(err) {
  const type = err && err.type;
  if (type === 'overloaded_error') return new AIError('provider_busy', type);
  if (type === 'rate_limit_error') return new AIError('provider_rate_limited', type);
  if (type === 'authentication_error' || type === 'permission_error') return new AIError('provider_auth', type);
  if (type === 'not_found_error') return new AIError('model_unavailable', type);
  return new AIError('provider_error', type || 'stream error');
}

function parseInput(raw) {
  if (!raw || !raw.trim()) return {};
  try { const v = JSON.parse(raw); return v && typeof v === 'object' && !Array.isArray(v) ? v : null; } catch (e) { return null; }
}

async function* stream({ provider, model, system, messages, maxTokens, signal, timeouts, tools }) {
  const body = {
    model: model.model,
    max_tokens: maxTokens,
    messages: toMessages(messages),
    stream: true,
  };
  if (system) body.system = system;
  if (model.temperature != null) body.temperature = model.temperature;
  if (tools && tools.length) body.tools = toTools(tools);
  const headers = {
    'Content-Type': 'application/json',
    Accept: 'text/event-stream',
    'anthropic-version': API_VERSION,
    ...provider.headers,
  };
  if (provider.apiKey) headers['x-api-key'] = provider.apiKey;

  const res = await openStream(`${provider.baseUrl}/v1/messages`, { headers, body, signal, timeoutMs: timeouts.firstByteMs });
  let stop = null;
  let produced = false;
  const blocks = new Map();                           // index → { id, name, json }
  const calls = [];
  const closeBlock = (index) => {
    const b = blocks.get(index);
    if (!b) return;
    blocks.delete(index);
    calls.push({ type: 'tool_call', id: b.id, name: b.name, input: b.json ? parseInput(b.json) : (b.input || {}) });
  };
  for await (const ev of parseSSE(res.body, { idleTimeoutMs: timeouts.idleMs, signal })) {
    let obj;
    try { obj = JSON.parse(ev.data); } catch (e) { continue; }
    const type = obj.type || ev.event;
    if (type === 'error') throw eventError(obj.error);
    if (type === 'message_start' && obj.message && obj.message.usage) yield { type: 'usage', input: obj.message.usage.input_tokens || 0, output: 0 };
    else if (type === 'content_block_start' && obj.content_block && obj.content_block.type === 'tool_use') {
      if (blocks.size >= MAX_TOOL_CALLS) throw new AIError('response_too_large');
      if (String(obj.content_block.name || '').length > 128) throw new AIError('response_too_large');
      blocks.set(obj.index, { id: obj.content_block.id, name: obj.content_block.name, json: '', input: obj.content_block.input });
    } else if (type === 'content_block_delta' && obj.delta) {
      if (obj.delta.type === 'text_delta' && obj.delta.text) { produced = true; yield { type: 'delta', text: obj.delta.text }; }
      else if (obj.delta.type === 'input_json_delta' && blocks.has(obj.index)) {
        const block = blocks.get(obj.index);
        const part = obj.delta.partial_json || '';
        if (block.json.length + part.length > MAX_TOOL_ARGUMENT_CHARS) throw new AIError('response_too_large');
        block.json += part;
      }
    } else if (type === 'content_block_stop') closeBlock(obj.index);
    else if (type === 'message_delta') {
      if (obj.delta && obj.delta.stop_reason) stop = obj.delta.stop_reason;
      if (obj.usage) yield { type: 'usage', input: 0, output: obj.usage.output_tokens || 0 };
    } else if (type === 'message_stop') break;
  }
  for (const k of [...blocks.keys()]) closeBlock(k);
  for (const c of calls) { produced = true; yield c; }
  if (stop === 'refusal' && !produced) throw new AIError('content_filtered');
  yield { type: 'finish', reason: calls.length ? 'tool_calls' : stop === 'max_tokens' ? 'length' : 'stop' };
}

module.exports = { stream, toMessages, toTools, fromHttp };
