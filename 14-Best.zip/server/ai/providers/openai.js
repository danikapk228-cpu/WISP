/* WISP · Server · Provider: OpenAI Chat Completions (и совместимые API)
 * POST {base_url}/chat/completions, stream: true → SSE с чанками choices[].delta.content, завершение "data: [DONE]".
 * Подходит для OpenAI, OpenRouter, а также локальных серверов с OpenAI-совместимым API (Ollama, LM Studio, vLLM).
 * Layer 4: function calling. Инструменты уходят в tools[], вызовы приходят кусками в delta.tool_calls[index]
 * и собираются здесь; наружу отдаётся одно событие { type:'tool_call', id, name, input } на вызов. */
'use strict';
const { parseSSE } = require('../sse');
const { AIError, fromHttp } = require('../errors');
const { openStream } = require('./http');
const MAX_TOOL_CALLS = 32;
const MAX_TOOL_ARGUMENT_CHARS = 32 * 1024;

function toMessages(system, messages) {
  const out = [];
  if (system) out.push({ role: 'system', content: system });
  for (const m of messages) {
    if (m.role === 'tool') {
      for (const p of m.parts) if (p.type === 'tool_result') out.push({ role: 'tool', tool_call_id: p.id, content: p.content });
      continue;
    }
    const images = m.parts.filter((p) => p.type === 'image');
    const calls = m.parts.filter((p) => p.type === 'tool_call');
    const text = m.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n\n');
    if (m.role === 'user' && images.length) {
      const content = [];
      if (text) content.push({ type: 'text', text });
      for (const im of images) content.push({ type: 'image_url', image_url: { url: `data:${im.mime};base64,${im.base64}` } });
      out.push({ role: 'user', content });
    } else if (m.role === 'assistant' && calls.length) {
      out.push({
        role: 'assistant', content: text || null,
        tool_calls: calls.map((c) => ({ id: c.id, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.input || {}) } })),
      });
    } else {
      out.push({ role: m.role, content: text });
    }
  }
  return out;
}

function toTools(tools) {
  return tools.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } }));
}

/* Аргументы приходят строкой JSON. Если модель прислала мусор, отдаём input = null: сервер ответит ей ошибкой. */
function parseArgs(raw) {
  if (!raw || !raw.trim()) return {};
  try { const v = JSON.parse(raw); return v && typeof v === 'object' && !Array.isArray(v) ? v : null; } catch (e) { return null; }
}

async function* stream({ provider, model, system, messages, maxTokens, signal, timeouts, tools }) {
  const body = {
    model: model.model,
    messages: toMessages(system, messages),
    stream: true,
  };
  body[provider.maxTokensParam || 'max_tokens'] = maxTokens;
  if (model.temperature != null) body.temperature = model.temperature;
  if (provider.streamUsage) body.stream_options = { include_usage: true };
  if (tools && tools.length) { body.tools = toTools(tools); body.tool_choice = 'auto'; }

  const headers = { 'Content-Type': 'application/json', Accept: 'text/event-stream', ...provider.headers };
  if (provider.apiKey) {
    headers[provider.apiKeyHeader || 'Authorization'] =
      `${provider.apiKeyPrefix === undefined ? 'Bearer ' : provider.apiKeyPrefix}${provider.apiKey}`;
  }

  const res = await openStream(`${provider.baseUrl}/chat/completions`, { headers, body, signal, timeoutMs: timeouts.firstByteMs });
  let finish = null;
  let produced = false;
  const calls = [];                                  // index → { id, name, args }
  for await (const ev of parseSSE(res.body, { idleTimeoutMs: timeouts.idleMs, signal })) {
    const data = ev.data.trim();
    if (!data) continue;
    if (data === '[DONE]') break;
    let obj;
    try { obj = JSON.parse(data); } catch (e) { continue; }       // неполный/служебный чанк: пропускаем
    if (obj.error) {
      const status = Number(obj.error.code) || Number(obj.error.status) || 500;
      throw fromHttp(status, JSON.stringify(obj.error));
    }
    if (obj.usage) yield { type: 'usage', input: obj.usage.prompt_tokens || 0, output: obj.usage.completion_tokens || 0 };
    const choice = obj.choices && obj.choices[0];
    if (!choice) continue;
    const delta = choice.delta || {};
    if (typeof delta.content === 'string' && delta.content) { produced = true; yield { type: 'delta', text: delta.content }; }
    if (delta.refusal && typeof delta.refusal === 'string') { produced = true; yield { type: 'delta', text: delta.refusal }; }
    if (Array.isArray(delta.tool_calls)) {
      for (const tc of delta.tool_calls) {
        const i = Number.isInteger(tc.index) ? tc.index : calls.length;
        if (i < 0 || i >= MAX_TOOL_CALLS) throw new AIError('response_too_large');
        const cur = calls[i] || (calls[i] = { id: '', name: '', args: '' });
        if (tc.id) cur.id = tc.id;
        if (tc.function && tc.function.name) {
          cur.name += tc.function.name;
          if (cur.name.length > 128) throw new AIError('response_too_large');
        }
        if (tc.function && typeof tc.function.arguments === 'string') {
          if (cur.args.length + tc.function.arguments.length > MAX_TOOL_ARGUMENT_CHARS) throw new AIError('response_too_large');
          cur.args += tc.function.arguments;
        }
      }
    }
    if (choice.finish_reason) finish = choice.finish_reason;
  }
  const done = calls.filter((c) => c && c.name);
  for (let i = 0; i < done.length; i++) {
    produced = true;
    yield { type: 'tool_call', id: done[i].id || `call_${i}`, name: done[i].name, input: parseArgs(done[i].args) };
  }
  if (finish === 'content_filter' && !produced) throw new AIError('content_filtered');
  yield { type: 'finish', reason: done.length ? 'tool_calls' : finish === 'length' ? 'length' : 'stop' };
}

module.exports = { stream, toMessages, toTools, parseArgs };
