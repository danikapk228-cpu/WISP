/* WISP · Server · Provider HTTP
 * Открывает потоковый запрос к провайдеру: таймаут до первого байта, отмена по сигналу клиента,
 * перевод HTTP-ошибок в коды WISP. Тело ошибки читается ограниченно и в лог попадает только после redact(). */
'use strict';
const { AIError, fromHttp } = require('../errors');

async function openStream(url, { headers, body, signal, timeoutMs }) {
  const timeout = new AbortController();
  const timer = setTimeout(() => timeout.abort(), timeoutMs || 45000);
  const combined = signal ? AbortSignal.any([signal, timeout.signal]) : timeout.signal;
  let res;
  try {
    res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body), signal: combined });
  } catch (e) {
    clearTimeout(timer);
    if (signal && signal.aborted) { const err = new Error('aborted'); err.code = 'aborted'; throw err; }
    if (timeout.signal.aborted) throw new AIError('timeout');
    throw new AIError('network', e && e.cause ? e.cause.code || e.cause.message : e && e.message);
  }
  clearTimeout(timer);
  if (!res.ok) {
    let text = '';
    try { text = (await res.text()).slice(0, 2000); } catch (e) { /* тело недоступно */ }
    throw fromHttp(res.status, text);
  }
  if (!res.body) throw new AIError('empty_reply');
  return res;
}

module.exports = { openStream };
