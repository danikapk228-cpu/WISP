/* WISP · Server · Conversation context
 * Какие сообщения диалога увидит модель.
 *  · берём историю с конца, пока помещаемся в бюджет токенов (минимум из окна модели и лимита тарифа);
 *  · последнее сообщение пользователя попадает всегда;
 *  · пустые и ошибочные ответы не передаются, прерванные передаются (пользователь их видел);
 *  · изображения отправляются только для последних IMAGE_TURNS реплик и только если модель их понимает,
 *    в остальных случаях вместо них короткая текстовая пометка.
 * Память (Layer 5): server/memory/service.js (recall) — в системную инструкцию попадают только
 * отобранные для сообщения факты. NullMemoryProvider оставлен как «память выключена» для тестов и встраивания. */
'use strict';

const IMAGE_TURNS = 2;
const IMAGE_TOKENS = 850;          // грубая оценка стоимости картинки в токенах
const MESSAGE_OVERHEAD = 6;

/* Оценка без токенизатора: для смешанного русского/английского текста ~3 символа на токен (с запасом) */
function estimateTokens(text) { return Math.ceil(String(text || '').length / 3); }

/* Минимальный MemoryProvider: памяти нет (тот же интерфейс, что у MemoryService.recall) */
class NullMemoryProvider {
  recall(/* { userId, plan, query } */) { return { enabled: false, suggest: false, items: [], total: 0 }; }
}

/* history: сообщения диалога по порядку (role, content, status, attachments[{mime, data}]) */
function buildContext({ history, systemPrompt, model, plan, maxOutputTokens }) {
  const windowBudget = model.contextTokens - maxOutputTokens - estimateTokens(systemPrompt) - 256;
  const budget = Math.max(512, Math.min(windowBudget, plan.history_tokens));
  const usable = history.filter((m) => m.role === 'user' || (m.role === 'assistant' && m.content && m.content.trim() && m.status !== 'error'));

  const picked = [];
  let used = 0;
  let userTurns = 0;
  let truncated = false;
  for (let i = usable.length - 1; i >= 0; i--) {
    const m = usable[i];
    const isUser = m.role === 'user';
    if (isUser) userTurns++;
    const withImages = isUser && model.vision && userTurns <= IMAGE_TURNS;
    const parts = [];
    const atts = m.attachments || [];
    let text = m.content || '';
    if (atts.length && !withImages) {
      const note = atts.length === 1 ? '[Пользователь прикрепил изображение]' : `[Пользователь прикрепил изображения: ${atts.length}]`;
      text = text ? `${text}\n\n${note}` : note;
    }
    if (text) parts.push({ type: 'text', text });
    if (withImages) for (const a of atts) parts.push({ type: 'image', mime: a.mime, base64: Buffer.from(a.data).toString('base64') });
    if (!parts.length) continue;
    const cost = estimateTokens(text) + MESSAGE_OVERHEAD + (withImages ? atts.length * IMAGE_TOKENS : 0);
    const isLatest = picked.length === 0;
    if (!isLatest && used + cost > budget) { truncated = true; break; }
    used += cost;
    picked.push({ role: m.role, parts });
  }
  picked.reverse();
  while (picked.length && picked[0].role !== 'user') picked.shift();     // начинаем всегда с реплики пользователя
  return { messages: picked, truncated, estimatedTokens: used, budget };
}

module.exports = { buildContext, estimateTokens, NullMemoryProvider, IMAGE_TURNS };
