/* WISP · Server · AI errors
 * Единые коды ошибок генерации. Клиент показывает по коду своё состояние; текст провайдера наружу не уходит. */
'use strict';

const CODES = {
  model_unavailable: { status: 503, retryable: false, message: 'Эта модель сейчас недоступна.' },
  provider_auth:     { status: 502, retryable: false, message: 'AI-сервис отклонил ключ доступа. Нужна настройка сервера.' },
  provider_rate_limited: { status: 503, retryable: true, message: 'AI-сервис перегружен запросами. Попробуй чуть позже.' },
  provider_busy:     { status: 503, retryable: true, message: 'AI-сервис сейчас перегружен. Попробуй чуть позже.' },
  provider_error:    { status: 502, retryable: true, message: 'AI-сервис ответил ошибкой.' },
  provider_bad_request: { status: 502, retryable: false, message: 'AI-сервис не принял запрос.' },
  content_filtered:  { status: 422, retryable: false, message: 'AI-сервис отказался отвечать на этот запрос.' },
  response_too_large: { status: 502, retryable: false, message: 'Ответ модели получился слишком большим. Попробуй попросить короче.' },
  timeout:           { status: 504, retryable: true, message: 'AI-сервис слишком долго не отвечал.' },
  network:           { status: 502, retryable: true, message: 'Сервер не смог связаться с AI-сервисом.' },
  empty_reply:       { status: 502, retryable: true, message: 'Модель вернула пустой ответ.' },
};

class AIError extends Error {
  constructor(code, detail) {
    const def = CODES[code] || CODES.provider_error;
    super(def.message);
    this.code = CODES[code] ? code : 'provider_error';
    this.status = def.status;
    this.retryable = def.retryable;
    this.detail = detail ? String(detail).slice(0, 300) : '';   // только для логов (без ключей, см. redact)
  }
}

/* HTTP-статус провайдера → код WISP */
function fromHttp(status, bodyText) {
  const t = (bodyText || '').toLowerCase();
  if (status === 401 || status === 403) return new AIError('provider_auth', `HTTP ${status}`);
  if (status === 404 || /model_not_found|does not exist|not_found_error|no such model|unknown model|invalid model/.test(t)) return new AIError('model_unavailable', `HTTP ${status}`);
  if (status === 429) return new AIError('provider_rate_limited', `HTTP ${status}`);
  if (status === 529 || status === 503) return new AIError('provider_busy', `HTTP ${status}`);
  if (status === 400 && /content.?(policy|filter)|safety/.test(t)) return new AIError('content_filtered', `HTTP ${status}`);
  if (status >= 400 && status < 500) return new AIError('provider_bad_request', `HTTP ${status}: ${redact(bodyText).slice(0, 200)}`);
  return new AIError('provider_error', `HTTP ${status}`);
}

/* Убираем из строки всё, что похоже на ключ, чтобы случайно не записать его в лог */
function redact(s) {
  return String(s || '')
    .replace(/(sk|pk|rk)-[A-Za-z0-9_\-]{8,}/g, '$1-***')
    .replace(/(api[_-]?key|authorization|x-api-key|bearer)(["'\s:=]+)[^\s"',}]+/gi, '$1$2***');
}

module.exports = { AIError, fromHttp, redact, CODES };
