/* WISP · Server · SSE parser
 * Разбор потока text/event-stream от провайдера (спецификация WHATWG): события разделены пустой строкой,
 * поля event:/data:, несколько data: склеиваются через \n, строки-комментарии (":") игнорируются. */
'use strict';

async function* parseSSE(body, options = {}) {
  const { idleTimeoutMs, signal } = options;
  const maxEventChars = Number.isInteger(options.maxEventChars) && options.maxEventChars > 0
    ? options.maxEventChars : 1024 * 1024;
  const decoder = new TextDecoder('utf-8');
  const reader = body.getReader();
  let buf = '';
  let eventChars = 0;
  let event = { event: 'message', data: [] };

  const readChunk = () => {
    if (!idleTimeoutMs) return reader.read();
    let timer;
    return Promise.race([
      reader.read(),
      new Promise((_, reject) => { timer = setTimeout(() => { const e = new Error('idle timeout'); e.code = 'idle_timeout'; reject(e); }, idleTimeoutMs); }),
    ]).finally(() => clearTimeout(timer));
  };

  try {
    for (;;) {
      if (signal && signal.aborted) return;
      const { value, done } = await readChunk();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      if (buf.length > maxEventChars) {
        const e = new Error('provider event too large');
        e.code = 'response_too_large';
        throw e;
      }
      let idx;
      while ((idx = buf.search(/\r\n|\r|\n/)) >= 0) {
        const line = buf.slice(0, idx);
        const nl = buf[idx] === '\r' && buf[idx + 1] === '\n' ? 2 : 1;
        // одиночный \r в самом конце буфера может оказаться началом \r\n: ждём следующий кусок
        if (buf[idx] === '\r' && idx + 1 === buf.length) break;
        buf = buf.slice(idx + nl);
        if (line === '') {
          if (event.data.length) yield { event: event.event, data: event.data.join('\n') };
          event = { event: 'message', data: [] };
          eventChars = 0;
          continue;
        }
        if (line.startsWith(':')) continue;
        const c = line.indexOf(':');
        const field = c < 0 ? line : line.slice(0, c);
        let val = c < 0 ? '' : line.slice(c + 1);
        if (val.startsWith(' ')) val = val.slice(1);
        if (field === 'event') event.event = val || 'message';
        else if (field === 'data') {
          eventChars += val.length;
          if (eventChars > maxEventChars) {
            const e = new Error('provider event too large');
            e.code = 'response_too_large';
            throw e;
          }
          event.data.push(val);
        }
      }
    }
    buf += decoder.decode();
    if (buf.trim()) {
      for (const line of buf.split(/\r?\n/)) {
        if (line.startsWith('data:')) event.data.push(line.slice(5).replace(/^ /, ''));
        else if (line.startsWith('event:')) event.event = line.slice(6).trim();
      }
    }
    if (event.data.length) yield { event: event.event, data: event.data.join('\n') };
  } finally {
    try { reader.releaseLock(); } catch (e) { /* поток уже закрыт */ }
  }
}

module.exports = { parseSSE };
