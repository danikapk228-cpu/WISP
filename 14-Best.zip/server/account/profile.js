/* WISP · Server · Profile & settings (Layer 6)
 * Серверная нормализация профиля: те же справочники и ограничения, что в src/core/profile.js.
 * Клиенту не доверяем: всё неизвестное отбрасывается, строки обрезаются, перечисления сверяются с белыми списками.
 * В базу НЕ попадают: тариф (источник правды — users.plan), разрешения браузера (они про конкретное устройство),
 * любые поля, которых нет в схеме (токены, ключи и т.п.). */
'use strict';

const SCHEMA_VERSION = 1;
const LIMITS = { name: 32, about: 1000, avatar: 90000 };
const INTERESTS = ['technology', 'games', 'programming', 'creativity', 'science', 'sport', 'music', 'learning', 'business', 'design', 'travel', 'other'];
const OCCUPATIONS = ['school', 'university', 'work', 'own_project', 'multiple', 'other', 'undisclosed'];
const PERSONALITIES = ['friendly', 'calm', 'business', 'humor', 'adaptive'];

/* Настройки: общая схема клиента и сервера (Layer 13) — src/core/preferences-schema.js.
 * Раньше здесь была копия таблицы из src/core/profile.js; копии расходились (сервер отбрасывал новые ключи,
 * синхронизация гоняла профиль по кругу). Теперь источник один. */
const PrefSchema = require('../../src/core/preferences-schema.js');
const PREFERENCES = PrefSchema.SCHEMA;

const CONTROL = /[\x00-\u0008\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;
const ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/;
const AVATAR = /^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/;

function name(v) {
  if (typeof v !== 'string') return null;
  const s = v.replace(CONTROL, '').replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, LIMITS.name).trim();
  return s || null;
}
const about = (v) => (typeof v === 'string' ? v.replace(CONTROL, '').replace(/\r\n?/g, '\n').slice(0, LIMITS.about) : '');
const oneOf = (v, list) => (typeof v === 'string' && list.includes(v) ? v : null);
const iso = (v) => (typeof v === 'string' && ISO.test(v) && !Number.isNaN(Date.parse(v)) ? v : null);
function avatar(v) {
  if (typeof v !== 'string' || v.length > LIMITS.avatar || !AVATAR.test(v)) return null;
  return v;
}

function preferences(raw) {
  return PrefSchema.sanitize(raw);
}

/* Профиль из запроса → то, что можно хранить. Возвращает null, если это не профиль вовсе. */
function sanitize(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const u = raw.user && typeof raw.user === 'object' ? raw.user : {};
  const m = raw.meta && typeof raw.meta === 'object' ? raw.meta : {};
  const now = new Date().toISOString();
  return {
    schema_version: SCHEMA_VERSION,
    user: {
      name: name(u.name),
      interests: Array.isArray(u.interests) ? INTERESTS.filter((i) => u.interests.includes(i)) : [],
      occupation: oneOf(u.occupation, OCCUPATIONS),
      about: about(u.about),
      assistant_personality: oneOf(u.assistant_personality, PERSONALITIES),
      onboarding_completed: u.onboarding_completed === true,
      avatar: avatar(u.avatar),
      preferences: preferences(u.preferences),
    },
    meta: {
      created_at: iso(m.created_at) || now,
      updated_at: iso(m.updated_at) || now,
      completed_at: iso(m.completed_at),
    },
  };
}

module.exports = { sanitize, preferences, PREFERENCES, LIMITS, SCHEMA_VERSION };
