/* WISP · Server · Subscription API (Layer 10)
 * userId и тариф — только из сессии. Тариф, сроки и права из запроса нигде не читаются.
 * Изменяющие запросы проходят общую проверку Origin + X-WISP-Client (server/app.js).
 *
 *  GET   /api/subscription                 тариф, срок, лимиты и их использование, сравнение Free/Plus, история активаций
 *  POST  /api/subscription/redeem {code}    активировать код доступа WISP (всё проверяет сервер, см. subscription/service.js)
 *
 * Администрирования по HTTP нет намеренно: кампании и коды создаются только командой на сервере (npm run admin). */
'use strict';
const { sendJSON, readJSON, HttpError } = require('../lib/http');
const Features = require('../subscription/features');

function register(router, { auth, subscription, quota, ai, voice, billing }) {
  function payload(s) {
    const st = subscription.state(s.userId);
    const t = Date.now();
    const rows = Features.compare({ quota, ai, voice });
    const policy = subscription.redeemPolicy(s);
    return {
      server_time: t,
      kind: s.kind || 'guest',
      plan: st.plan,
      subscription: {
        plan: st.plan,
        status: st.status,                                   // free | active | lifetime
        lifetime: st.lifetime,
        source: st.source,                                   // access_code | admin | payment | legacy
        started_at: st.started_at,
        expires_at: st.expires_at,
        days_left: st.expires_at ? Math.max(0, Math.ceil((st.expires_at - t) / 86400000)) : null,
      },
      meters: quota.meters(s),
      warn_ratio: quota.warnRatio,
      plans: {
        free: { id: 'free', title: quota.planLimits('free').title, highlights: Features.highlights(rows, 'free') },
        plus: { id: 'plus', title: quota.planLimits('plus').title, highlights: Features.highlights(rows, 'plus') },
      },
      compare: rows,
      upcoming: Features.UPCOMING,
      codes: { available: subscription.codesAvailable, can_redeem: policy.can, reason: policy.reason },
      billing: billing.publicInfo(),
      history: subscription.history(s.userId),
    };
  }

  router.add('GET', '/api/subscription', async (c) => {
    const s = auth.require(c.req);
    sendJSON(c.res, 200, payload(s));
  });

  router.add('POST', '/api/subscription/redeem', async (c) => {
    const s = auth.require(c.req);
    const body = await readJSON(c.req, 2 * 1024);
    if (typeof body.code !== 'string') throw new HttpError(400, 'code_format', 'Введи код доступа.');
    const r = subscription.redeem({ session: s, code: body.code, ip: c.ip });
    const fresh = auth.require(c.req);                       // тариф заново из базы: уже с новым периодом
    sendJSON(c.res, 200, { redeemed: r, ...payload(fresh) });
  });

  return { payload };
}

module.exports = { register };
