/* WISP · Server · Chat API
 * Все endpoint'ы требуют сессию; данные выбираются только по user_id из сессии.
 *
 *  POST   /api/session                                   сессия устройства (создаётся при первом обращении)
 *  GET    /api/session                                   тариф, лимиты, модели
 *  GET    /api/conversations                             список диалогов (по последней активности)
 *  GET    /api/conversations/:id                         диалог с сообщениями
 *  PATCH  /api/conversations/:id        {title?, model?} переименование / выбор модели
 *  DELETE /api/conversations/:id                         удаление диалога
 *  DELETE /api/conversations          {confirm:"clear_all"} Layer 6: очистить всю историю чатов (память и инструменты остаются)
 *  POST   /api/conversations/:id/messages                новое сообщение → поток ответа (:id = new создаёт диалог)
 *  POST   /api/conversations/:id/regenerate              повторная генерация последнего ответа → поток
 *  POST   /api/conversations/:id/messages/:mid/edit      правка последнего сообщения пользователя → поток
 *  DELETE /api/conversations/:id/messages/:mid           удаление сообщения (для реплики пользователя: вместе с ответом)
 *  GET    /api/attachments/:id                           изображение из своего диалога
 *
 * Поток (text/event-stream): start → (delta | tool)* → done | error.
 * Layer 4: модель может вызвать функции WISP (напоминание, задача, заметка, событие, планы на день).
 * Сервер выполняет их сам (ToolsService, userId из сессии), сохраняет и шлёт событие tool с результатом;
 * модель получает { ok: true } только после успешной записи в базу.
 * Layer 5: перед ответом сервер берёт из долговременной памяти только относящиеся к сообщению факты
 * (memory.recall) и кладёт их в системную инструкцию. Функции памяти (remember / suggest_memory /
 * forget_memory) выполняет MemoryService. Ошибка памяти не ломает чат: ответ идёт без неё.
 * Какие воспоминания видел ответ, сохраняется (messages.memory_used) и показывается в чате.
 * Layer 8: все вызовы функций проходят через ActionEngine (server/actions/engine.js): белый список, тариф,
 * уточнение недостающих данных, подтверждение опасных действий, защита от повторов, повтор при временной ошибке.
 * Карточки действий в истории дополняются текущим состоянием записей (live). Повторная отправка того же сообщения
 * (client_id) не создаёт второй ответ и второе действие: сервер отвечает 409 duplicate_request. Голос (input: voice)
 * идёт тем же путём, что и текст: распознанная речь — обычное сообщение. */
'use strict';
const { HttpError, sendJSON, readJSON } = require('../lib/http');
const { parseAttachment } = require('../lib/images');
const { AIError } = require('../ai/errors');
const { buildContext } = require('../ai/context');
const { sanitizeProfile } = require('../ai/prompt');
const { isValidTimeZone } = require('../tools/time');
const { MAX_CALLS_PER_ROUND, actionsNote } = require('../tools/ai');
const { NullMemoryProvider } = require('../ai/context');
const Intent = require('../actions/intent');

const KEY_RE = /^[A-Za-z0-9_-]{8,80}$/;
const PROVIDER_RETRY_MS = 700;

const MAX_TOOL_ROUNDS = 3;            // после третьего круга модель обязана ответить текстом

const KB = 1024;
const MB = 1024 * KB;
const SAVE_EVERY_MS = 1500;
const PING_EVERY_MS = 15000;
const TITLE_MAX = 80;
const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
const cleanText = (s) => String(s).replace(CONTROL, '').replace(/\r\n?/g, '\n');

/* Название по первому сообщению: первая строка без разметки, до 48 символов по границе слова */
function makeTitle(text, hasImages) {
  const line = String(text || '').split('\n').map((l) => l.trim()).find(Boolean) || '';
  const plain = line.replace(/[`*_~#>|[\]]+/g, '').replace(/\s+/g, ' ').trim();
  if (!plain) return hasImages ? 'Изображение' : 'Новый диалог';
  if (plain.length <= 48) return plain.charAt(0).toLocaleUpperCase('ru') + plain.slice(1);
  let cut = plain.slice(0, 48);
  const sp = cut.lastIndexOf(' ');
  if (sp > 24) cut = cut.slice(0, sp);
  cut = cut.replace(/[\s,.;:!?—–-]+$/, '');
  return cut.charAt(0).toLocaleUpperCase('ru') + cut.slice(1) + '…';
}

const publicAction = (row) => ({ ...(row.result || {}), id: row.id, status: row.status });

function publicMessage(m) {
  return {
    id: m.id,
    role: m.role,
    content: m.content,
    status: m.status,
    error_code: m.error_code || null,
    model: m.model || null,
    created_at: m.created_at,
    attachments: (m.attachments || []).map((a) => ({ id: a.id, mime: a.mime, width: a.width, height: a.height, url: `/api/attachments/${a.id}` })),
    actions: m.actions || [],
    memory_used: m.memory_used_items || [],
  };
}
function publicConversation(c) {
  return { id: c.id, title: c.title, title_source: c.title_source, model: c.model, created_at: c.created_at, updated_at: c.updated_at };
}

function register(router, deps) {
  const { store, auth, limits, ai, prompts, log, config, tools, toolkit, memoryService, memoryToolkit, engine, subscription, quota } = deps;
  const memory = deps.memory || new NullMemoryProvider();
  const generating = new Map();                    // conversationId → userId: в этом диалоге сейчас идёт ответ

  /* ── Сессия ── */
  function sessionPayload(s) {
    const plan = limits.plan(s.plan);
    const def = ai.defaultFor(s.plan);
    /* Layer 9: kind — guest (данные устройства) или account; account — то, что показывает страница профиля */
    const prof = s.kind === 'account' ? store.getProfile(s.userId) : null;
    return {
      user: { id: s.userId, plan: s.plan, created_at: s.createdAt },
      kind: s.kind || 'guest',
      account: s.kind === 'account' ? {
        email: s.email, email_verified: !!s.emailVerifiedAt, email_verified_at: s.emailVerifiedAt, created_at: s.createdAt,
        name: prof && prof.data && prof.data.user ? prof.data.user.name || null : null,
      } : null,
      plan: {
        id: s.plan, title: plan.title, daily_requests: plan.daily_requests,
        history_tokens: plan.history_tokens, max_input_chars: plan.max_input_chars, max_images_per_message: plan.max_images_per_message,
      },
      usage: limits.usage(s.userId, s.plan),
      models: ai.listFor(s.plan),
      default_model: def ? def.id : null,
      ai_connected: ai.anyAvailable(),
      tools: tools ? tools.limits(s.plan) : null,
      actions: engine ? publicActionLimits(engine.limits(s.plan)) : null,
      memory: memoryService ? { ...memoryLimits(s.plan), settings: memoryService.settings({ userId: s.userId }) } : null,
      timezone: s.timezone || null,
      /* Layer 10: срок Plus — чтобы клиент обновил тариф ровно в момент окончания (решение всё равно за сервером) */
      subscription: subscription ? ((st) => ({ status: st.status, lifetime: st.lifetime, expires_at: st.expires_at }))(subscription.state(s.userId)) : null,
      plans: Object.fromEntries(['free', 'plus'].filter((k) => config.plans[k]).map((k) => [k, { title: config.plans[k].title, daily_requests: config.plans[k].daily_requests, tools: tools ? tools.limits(k) : null, memory: memoryService ? memoryLimits(k) : null }])),
    };
  }

  function publicActionLimits(L) { return { writes_per_day: L.writes_per_day, bulk_max: L.bulk_max, search_results: L.search_results, agenda_days_max: L.agenda_days_max, confirm_ttl_minutes: L.confirm_ttl_minutes }; }
  function memoryLimits(plan) { const L = memoryService.limits(plan); return { items_max: L.items_max, pinned_max: L.pinned_max, item_max_chars: L.item_max_chars, context_items: L.context_items, query_turns: L.query_turns }; }

  /* Пояс пользователя: из запроса (если корректен) запоминается на сервере, иначе последний известный */
  function rememberTimezone(s, raw) {
    if (typeof raw === 'string' && isValidTimeZone(raw)) {
      if (raw !== s.timezone) { store.setTimezone(s.userId, raw); s.timezone = raw; }
      return raw;
    }
    return s.timezone && isValidTimeZone(s.timezone) ? s.timezone : 'UTC';
  }

  router.add('POST', '/api/session', async (c) => {
    let body = {};
    try { body = await readJSON(c.req, 4 * KB); } catch (e) { body = {}; }
    let s = auth.current(c.req);
    if (!s) {
      /* Layer 9: «Продолжить без аккаунта». Сначала — гость этого браузера, отложенный на время входа в аккаунт */
      const parked = auth.parkedGuest(c.req);
      if (parked) s = auth.resumeGuest(c.req, c.res, parked);
      else {
        if (config.accounts && config.accounts.guestMode === false) throw new HttpError(403, 'guest_disabled', 'На этом сервере WISP работает только с аккаунтом. Войди или создай аккаунт.');
        limits.checkSessionCreate(c.ip); s = auth.create(c.req, c.res); log.info('session created');
      }
    }
    rememberTimezone(s, body.timezone);
    sendJSON(c.res, 200, sessionPayload(s));
  });
  router.add('GET', '/api/session', async (c) => sendJSON(c.res, 200, sessionPayload(auth.require(c.req))));

  /* ── Диалоги ── */
  function ownConversation(id, userId) {
    if (!ID_RE.test(id)) throw new HttpError(404, 'not_found', 'Диалог не найден.');
    const conv = store.getConversation(id, userId);
    if (!conv) throw new HttpError(404, 'not_found', 'Диалог не найден.');
    return conv;
  }
  function ensureIdle(convId) {
    if (generating.has(convId)) throw new HttpError(409, 'busy', 'WISP ещё отвечает в этом диалоге.');
  }

  router.add('GET', '/api/conversations', async (c) => {
    const s = auth.require(c.req);
    const rawOffset = Number(c.url.searchParams.get('offset') || 0);
    const offset = Number.isSafeInteger(rawOffset) && rawOffset >= 0 ? rawOffset : 0;
    const pageSize = 100;
    const page = store.listConversations(s.userId, pageSize + 1, offset);
    const hasMore = page.length > pageSize;
    const conversations = page.slice(0, pageSize).map(publicConversation);
    sendJSON(c.res, 200, { conversations, has_more: hasMore, next_offset: offset + conversations.length });
  });

  router.add('GET', '/api/conversations/:id', async (c) => {
    const s = auth.require(c.req);
    const conv = ownConversation(c.params.id, s.userId);
    const acts = actionsByMessage(conv.id, s.userId);
    const raw = store.messagesWithAttachments(conv.id);
    const used = memoryUsedItems(raw, s.userId);
    const messages = raw.map((m) => publicMessage({ ...m, actions: acts.get(m.id), memory_used_items: used.get(m.id) }));
    sendJSON(c.res, 200, { conversation: publicConversation(conv), messages, generating: generating.has(conv.id) });
  });

  router.add('PATCH', '/api/conversations/:id', async (c) => {
    const s = auth.require(c.req);
    const conv = ownConversation(c.params.id, s.userId);
    ensureIdle(conv.id);
    const body = await readJSON(c.req, 16 * KB);
    if (body.title !== undefined) {
      const title = typeof body.title === 'string' ? cleanText(body.title).replace(/\s+/g, ' ').trim().slice(0, TITLE_MAX) : '';
      if (!title) throw new HttpError(400, 'bad_title', 'Название не может быть пустым.');
      store.renameConversation(conv.id, s.userId, title, 'user');
    }
    if (body.model !== undefined) {
      const m = ai.find(String(body.model));
      if (!m) throw new HttpError(400, 'bad_model', 'Такой модели нет.');
      if (!ai.allowedForPlan(m, s.plan)) throw new HttpError(403, 'plan_required', 'Эта модель доступна в Plus.');
      store.setConversationModel(conv.id, s.userId, m.id);
    }
    sendJSON(c.res, 200, { conversation: publicConversation(store.getConversation(conv.id, s.userId)) });
  });

  /* Layer 6: вся история чатов. Пока идёт ответ, не трогаем (иначе поток пишет в удалённый диалог). */
  router.add('DELETE', '/api/conversations', async (c) => {
    const s = auth.require(c.req);
    const body = await readJSON(c.req, 4 * KB);
    if (body.confirm !== 'clear_all') throw new HttpError(400, 'confirm_required', 'Нужно подтверждение.');
    if (limits.active.has(s.userId) || [...generating.values()].includes(s.userId)) throw new HttpError(409, 'busy', 'WISP ещё отвечает. Дождись ответа или останови его.');
    if (limits.checkSettingsWrite) limits.checkSettingsWrite(s.userId, 20);
    const deleted = store.deleteAllConversations(s.userId);
    sendJSON(c.res, 200, { ok: true, deleted });
  });

  router.add('DELETE', '/api/conversations/:id', async (c) => {
    const s = auth.require(c.req);
    const conv = ownConversation(c.params.id, s.userId);
    ensureIdle(conv.id);
    store.deleteConversation(conv.id, s.userId);
    sendJSON(c.res, 200, { ok: true });
  });

  router.add('DELETE', '/api/conversations/:id/messages/:mid', async (c) => {
    const s = auth.require(c.req);
    const conv = ownConversation(c.params.id, s.userId);
    ensureIdle(conv.id);
    const msg = ID_RE.test(c.params.mid) ? store.getMessage(c.params.mid, conv.id, s.userId) : null;
    if (!msg) throw new HttpError(404, 'not_found', 'Сообщение не найдено.');
    const deleted = store.transaction(() => {
      const ids = [msg.id];
      if (msg.role === 'user') {
        const all = store.messagesWithAttachments(conv.id);
        const i = all.findIndex((m) => m.id === msg.id);
        const next = all[i + 1];
        if (next && next.role === 'assistant') { store.deleteMessage(next.id, conv.id); ids.push(next.id); }
      }
      store.deleteMessage(msg.id, conv.id);
      return ids;
    });
    sendJSON(c.res, 200, { deleted, remaining: store.messageCount(conv.id) });
  });

  router.add('GET', '/api/attachments/:id', async (c) => {
    const s = auth.require(c.req);
    const a = ID_RE.test(c.params.id) ? store.getAttachment(c.params.id, s.userId) : null;
    if (!a) throw new HttpError(404, 'not_found', 'Файл не найден.');
    c.res.writeHead(200, {
      'Content-Type': a.mime, 'Content-Length': a.bytes, 'Cache-Control': 'private, max-age=86400, immutable',
      'Content-Disposition': 'inline', 'X-Content-Type-Options': 'nosniff',
    });
    c.res.end(Buffer.from(a.data));
  });

  /* Действия AI по сообщениям диалога (Layer 4). Layer 5: для действий памяти текст и статус берутся
   * из таблицы memories прямо сейчас — удалённое воспоминание в истории показывается как удалённое. */
  function actionsByMessage(convId, userId) {
    const map = new Map();
    if (!tools) return map;
    const rows = tools.repo.callsForConversation(convId, userId);
    const memIds = rows.map((r) => r.result && r.result.kind === 'memory' && r.result.memory_id).filter(Boolean);
    let live = new Map();
    if (memIds.length && memoryService) { try { live = memoryService.lookup(userId, memIds); } catch (e) { live = new Map(); } }
    for (const row of rows) {
      if (!map.has(row.message_id)) map.set(row.message_id, []);
      const a = publicAction(row);
      if (a.kind === 'memory' && a.memory_id) {
        const m = live.get(a.memory_id);
        Object.assign(a, m ? { content: m.content, category: m.category, memory_status: m.status, sensitive: m.sensitive } : { content: null, memory_status: a.op === 'forgotten' ? 'forgotten' : 'gone' });
      }
      map.get(row.message_id).push(a);
    }
    // Layer 8: карточки связаны с настоящими записями — текущее состояние из базы (удалено, перенесено, выполнено)
    if (engine) { try { engine.enrich(userId, [...map.values()].flat()); } catch (e) { log.warn('enrich failed', { error: e && e.message }); } }
    return map;
  }
  /* Какие воспоминания видел каждый ответ — только те, что ещё существуют */
  function memoryUsedItems(msgs, userId) {
    const out = new Map();
    if (!memoryService) return out;
    const per = new Map();
    for (const m of msgs) {
      if (!m.memory_used) continue;
      try { const ids = JSON.parse(m.memory_used); if (Array.isArray(ids) && ids.length) per.set(m.id, ids); } catch (e) { /* пропускаем */ }
    }
    if (!per.size) return out;
    let live;
    try { live = memoryService.lookup(userId, [...per.values()].flat()); } catch (e) { return out; }
    for (const [mid, ids] of per) {
      const items = ids.map((id) => live.get(id)).filter((x) => x && x.status === 'active').map((x) => ({ id: x.id, category: x.category, content: x.content }));
      if (items.length) out.set(mid, items);
    }
    return out;
  }
  /* Текст для поиска релевантных воспоминаний: последнее сообщение (вес 1), до N-1 предыдущих (вес 0.5) */
  function memoryQuery(history) {
    const users = history.filter((m) => m.role === 'user' && m.content).slice(-3).reverse();
    return users.map((m, i) => ({ text: String(m.content).slice(0, 4000), weight: i === 0 ? 1 : 0.5 }));
  }
  async function recallMemory(session, conv, history) {
    try {
      const r = await memory.recall({ userId: session.userId, plan: session.plan, conversationId: conv.id, query: memoryQuery(history) });
      if (Array.isArray(r)) return { enabled: r.length > 0, suggest: false, total: r.length, items: r.map((c, i) => ({ ref: `m${i + 1}`, id: null, category: 'other', content: String(c), updated_at: Date.now() })) };
      return r && typeof r === 'object' ? { enabled: !!r.enabled, suggest: !!r.suggest, total: r.total || 0, items: Array.isArray(r.items) ? r.items : [] } : { enabled: false, suggest: false, total: 0, items: [] };
    } catch (e) {
      log.warn('memory recall failed', { error: e && e.message });
      return { failed: true, enabled: false, suggest: false, total: 0, items: [] };
    }
  }

  /* ── Валидация входа ── */
  function readContent(body, plan, { allowEmpty } = {}) {
    const raw = typeof body.content === 'string' ? cleanText(body.content) : '';
    const content = raw.replace(/^\s+|\s+$/g, '');
    if (content.length > plan.max_input_chars) throw new HttpError(413, 'too_long', `Сообщение слишком длинное (максимум ${plan.max_input_chars} символов).`, { limit: plan.max_input_chars });
    if (!content && !allowEmpty) throw new HttpError(400, 'empty', 'Пустое сообщение.');
    return content;
  }
  function readAttachments(body, plan, model) {
    const list = Array.isArray(body.attachments) ? body.attachments : [];
    if (!list.length) return [];
    if (list.length > plan.max_images_per_message) throw new HttpError(413, 'too_many_images', `Можно прикрепить не больше ${plan.max_images_per_message} изображений.`, { limit: plan.max_images_per_message });
    if (!model.vision) throw new HttpError(422, 'model_no_vision', 'Эта модель не понимает изображения.');
    return list.map(parseAttachment);
  }
  function resolveModel(requested, conv, planId) {
    try {
      const id = requested || (conv && conv.model) || null;
      // сохранённая в диалоге модель могла стать недоступной: тогда — модель тарифа по умолчанию
      if (!requested && id) {
        const m = ai.find(id);
        if (m && ai.allowedForPlan(m, planId) && ai.availability(m).available) return m;
        return ai.resolve(null, planId);
      }
      return ai.resolve(id, planId);
    } catch (e) {
      if (e.code === 'plan_required') throw new HttpError(403, 'plan_required', 'Эта модель доступна в Plus.');
      if (e instanceof AIError) throw new HttpError(e.status === 400 ? 400 : 503, 'model_unavailable', 'Эта модель сейчас недоступна.');
      throw e;
    }
  }

  /* ── Генерация с потоковой передачей ──
   * Круг: модель → (текст | вызовы функций). Если были вызовы: сервер выполняет их, шлёт событие tool,
   * отдаёт результаты модели и запускает следующий круг. Текст всех кругов складывается в один ответ. */
  async function generate(c, { session, conv, userMessage, model, profile, lease, tz, priorActions, inputMode }) {
    const plan = limits.plan(session.plan);
    const maxTokens = Math.max(64, Math.min(model.maxOutputTokens, plan.max_output_tokens));
    const maxReplyChars = maxTokens * 8 * (MAX_TOOL_ROUNDS + 1);
    const toolsOn = !!(toolkit && ai.supportsTools(model));
    let system, ctx, assistant, mem, memDefs = [], fallback = null, intent = null, pending = [], lastUser = null;
    try {
      const acts = actionsByMessage(conv.id, session.userId);
      // модель видит, какие действия она уже выполнила в прошлых ответах (иначе возможны дубликаты)
      const history = store.historyForModel(conv.id).map((m) => {
        const a = m.role === 'assistant' && acts.get(m.id);
        return a ? { ...m, content: [actionsNote(a), m.content].filter(Boolean).join('\n\n') } : m;
      });
      // ── Layer 8: намерение последнего сообщения (подсказка модели и проверка честности) и ожидающие подтверждения ──
      lastUser = [...store.messagesWithAttachments(conv.id)].reverse().find((m) => m.role === 'user') || null;
      intent = lastUser ? Intent.detect(lastUser.content, { tz }) : null;
      pending = toolsOn && engine ? engine.pendingFor(session.userId, conv.id) : [];
      // ── Layer 5: долговременная память (только относящееся к сообщению; ошибка памяти не ломает ответ) ──
      mem = await recallMemory(session, conv, history);
      const memOn = !!(memoryToolkit && mem.enabled && !mem.failed);
      if (memOn && toolsOn) memDefs = memoryToolkit.definitions(mem);
      if (memOn && !toolsOn) {
        try { fallback = lastUser ? memoryToolkit.fallback(lastUser.content, { userId: session.userId, plan: session.plan, conversationId: conv.id }) : null; } catch (e) { fallback = null; }
      }
      const memoryText = memoryToolkit ? memoryToolkit.promptSection(mem, { tools: toolsOn && memOn, saved: fallback && fallback.line }) : '';
      let toolText = engine
        ? engine.promptSection({ tz, now: Date.now(), enabled: toolsOn, plan: session.plan, intent, pending, inputMode })
        : toolkit ? toolkit.promptSection({ tz, enabled: toolsOn }) : '';
      if (toolsOn && priorActions && priorActions.length) {
        toolText += `\n- Для последнего сообщения пользователя уже выполнено (повторно не делай, если он не просит снова): ${actionsNote(priorActions).replace(/^\[|\]$/g, '')}.`;
      }
      system = prompts.build({ profile, memory: memoryText, now: new Date(), modelLabel: model.label, timezone: tz, tools: toolText });
      ctx = buildContext({ history, systemPrompt: system, model, plan, maxOutputTokens: maxTokens });
      assistant = store.startAssistantMessage(conv.id, session.userId, model.id);
      const usedIds = mem.items.map((i) => i.id).filter(Boolean);
      if (usedIds.length) store.setMemoryUsed(assistant.id, usedIds);
    } catch (e) {
      lease.end({ refund: true });
      throw e;
    }
    generating.set(conv.id, session.userId);

    const memoryUsed = mem.items.filter((i) => i.id).map((i) => ({ id: i.id, category: i.category, content: i.content }));
    const memRefs = new Map(mem.items.filter((i) => i.id).map((i) => [i.ref, i.id]));
    const memOffered = new Set(memDefs.map((d) => d.name));
    const memRound = { suggested: false };
    const offeredTools = toolsOn ? (engine ? engine.definitions({ plan: session.plan, memDefs, pending }) : [...toolkit.definitions(), ...memDefs]) : null;
    const res = c.res;
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-store, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    if (res.socket) res.socket.setNoDelay(true);
    const send = (event, data) => { if (!res.writableEnded && !res.destroyed) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); };
    res.write(': wisp\n\n');

    const ctrl = new AbortController();
    let finished = false;
    res.on('close', () => { if (!finished) ctrl.abort(); });
    const ping = setInterval(() => { if (!res.writableEnded) res.write(': ping\n\n'); }, PING_EVERY_MS);

    send('start', {
      conversation: publicConversation(store.getConversation(conv.id, session.userId) || conv),
      user_message: userMessage ? publicMessage(userMessage) : null,
      assistant_message: publicMessage(assistant),
      model: ai.publicModel(model, session.plan),
      context: { truncated: ctx.truncated, messages: ctx.messages.length },
      tools: toolsOn,
      memory: { enabled: !!mem.enabled, failed: !!mem.failed, used: memoryUsed },
      intent: intent && toolsOn ? { category: intent.category, op: intent.op } : null,
    });

    let text = '';
    let lastSave = Date.now();
    let tokensIn = 0, tokensOut = 0;
    let finishReason = 'stop';
    const actions = [];
    const t0 = Date.now();
    /* запасной путь «запомни…» без функций: сервер уже сохранил — показываем карточку сразу */
    if (fallback) {
      const id = tools.repo.logCall(session.userId, assistant.id, { name: 'remember', args: fallback.log.args, status: fallback.ok ? 'ok' : 'error', result: fallback.log.result });
      const action = { ...fallback.action, id, status: fallback.ok ? 'ok' : 'error' };
      actions.push(action);
      send('tool', { action });
    }
    const emit = (t) => {
      if (text.length + t.length > maxReplyChars) throw new AIError('response_too_large');
      text += t;
      send('delta', { text: t });
      if (Date.now() - lastSave > SAVE_EVERY_MS) { store.saveProgress(assistant.id, text); lastSave = Date.now(); }
    };
    /* контекст выполнения действий: пользователь и тариф только из сессии */
    const execCtx = {
      userId: session.userId, plan: session.plan, tz, now: Date.now(), conversationId: conv.id, messageId: assistant.id,
      userMessage: lastUser ? { content: lastUser.content, created_at: lastUser.created_at } : null,
      mem: { refs: memRefs, offered: memOffered, round: memRound }, seen: new Map(),
      busy: () => true,                                  // мы внутри ответа: очистку истории — только кнопкой
    };
    try {
      let convo = ctx.messages;
      for (let round = 0; ; round++) {
        const offer = toolsOn && round < MAX_TOOL_ROUNDS;
        let calls = [];
        let roundText = '';
        /* Временный сбой провайдера до первого токена и без вызовов функций: одна тихая повторная попытка */
        for (let attempt = 0; ; attempt++) {
          calls = []; roundText = '';
          try {
            for await (const ev of ai.stream({ model, system, messages: convo, maxTokens, signal: ctrl.signal, tools: offer ? offeredTools : null })) {
              if (ev.type === 'delta') {
                if (!roundText && text && !/\s$/.test(text)) emit('\n\n');          // новый круг — новый абзац
                roundText += ev.text;
                emit(ev.text);
              } else if (ev.type === 'usage') {
                tokensIn += ev.input || 0; tokensOut += ev.output || 0;
              } else if (ev.type === 'tool_call') {
                if (offer) calls.push(ev);
              } else if (ev.type === 'finish') finishReason = ev.reason;
            }
            break;
          } catch (e) {
            const retry = attempt === 0 && !roundText && !calls.length && e instanceof AIError && e.retryable && !ctrl.signal.aborted;
            if (!retry) throw e;
            log.warn('provider retry', { model: model.id, code: e.code });
            await new Promise((r) => setTimeout(r, PROVIDER_RETRY_MS));
            if (ctrl.signal.aborted) { const err = new Error('aborted'); err.code = 'aborted'; throw err; }
          }
        }
        if (!calls.length) break;
        if (ctrl.signal.aborted) { const err = new Error('aborted'); err.code = 'aborted'; throw err; }

        // ── выполнение: сервер проверяет аргументы, пишет в базу, и только тогда отвечает модели ──
        const asked = [];
        const results = [];
        calls.forEach((call, i) => {
          let r;
          if (i >= MAX_CALLS_PER_ROUND) {
            const isMem = !!(memoryToolkit && memoryToolkit.has(call.name));
            const action = { tool: call.name, kind: isMem ? 'memory' : 'tool', op: 'failed', error: 'Слишком много действий за один раз.' };
            const id = tools.repo.logCall(session.userId, assistant.id, { name: call.name, args: {}, status: 'error', result: action });
            r = { ok: false, forModel: { ok: false, error: 'Слишком много действий за один раз.' }, action: { ...action, id, status: 'error' }, emit: true };
          } else {
            r = engine.execute(call, execCtx);
          }
          if (r.emit !== false) { actions.push(r.action); send('tool', { action: r.action }); }
          else if (r.clarify) actions.push(r.action);                    // уточнение: карточки нет, но ответ знает, что спросил
          asked.push({ type: 'tool_call', id: call.id, name: call.name, input: call.input || {} });
          results.push({ type: 'tool_result', id: call.id, name: call.name, content: JSON.stringify(r.forModel), isError: !r.ok });
          log.info('tool', { tool: call.name, ok: r.ok, op: r.action && r.action.op });
        });
        const said = roundText ? [{ type: 'text', text: roundText }] : [];
        convo = convo.concat([{ role: 'assistant', parts: [...said, ...asked] }, { role: 'tool', parts: results }]);
      }
      const visible = actions.filter((a) => a.op !== 'clarify');
      if (!text.trim() && actions.some((a) => a.op === 'clarify')) emit(actions.find((a) => a.op === 'clarify').question);
      if (!text.trim() && visible.length) emit(fallbackText(visible));       // модель промолчала, но действие выполнено
      if (!text.trim()) throw new AIError('empty_reply');
      // ── Layer 8: честность — модель сказала «создал», но ничего не выполнено ──
      if (toolsOn && engine) {
        const g = engine.claimGuard(text, intent, actions);
        if (g) {
          const id = tools.repo.logCall(session.userId, assistant.id, { name: 'guard', args: {}, status: 'error', result: g });
          const action = { ...g, id, status: 'error' };
          actions.push(action);
          send('tool', { action });
          log.warn('unverified claim', { model: model.id, intent: intent && intent.category });
        }
      }
      finished = true;
      store.finishAssistantMessage(assistant.id, { content: text, status: 'complete', tokensIn, tokensOut });
      store.touchConversation(conv.id, session.userId);
      lease.end();
      send('done', {
        message: publicMessage({ ...assistant, content: text, status: 'complete', actions: actions.filter((a) => a.op !== 'clarify'), memory_used_items: memoryUsed }),
        finish_reason: finishReason === 'tool_calls' ? 'stop' : finishReason,
        usage: limits.usage(session.userId, session.plan),
        conversation: publicConversation(store.getConversation(conv.id, session.userId) || conv),
      });
      log.info('reply', { model: model.id, ms: Date.now() - t0, out: tokensOut || undefined, tools: actions.length || undefined });
    } catch (e) {
      const aborted = ctrl.signal.aborted || (e && e.code === 'aborted');
      finished = true;
      const shown = actions.filter((a) => a.op !== 'clarify');
      if (aborted) {
        // клиент ушёл (остановил ответ, закрыл вкладку, пропала сеть): сохраняем то, что успели получить
        store.finishAssistantMessage(assistant.id, { content: text, status: 'interrupted', errorCode: 'interrupted', tokensIn, tokensOut });
        lease.end();
        log.info('reply interrupted', { model: model.id, chars: text.length });
      } else {
        const err = e instanceof AIError ? e : new AIError('provider_error', e && e.message);
        const status = text ? 'interrupted' : err.code === 'empty_reply' ? 'empty' : 'error';
        store.finishAssistantMessage(assistant.id, { content: text, status, errorCode: err.code, tokensIn, tokensOut });
        lease.end({ refund: !text && !shown.length });
        log.warn('reply failed', { model: model.id, code: err.code, detail: err.detail });
        send('error', {
          code: err.code, message: err.message, retryable: err.retryable,
          message_saved: publicMessage({ ...assistant, content: text, status, error_code: err.code, actions: shown, memory_used_items: memoryUsed }),
          usage: limits.usage(session.userId, session.plan),
        });
      }
    } finally {
      clearInterval(ping);
      generating.delete(conv.id);
      if (!res.writableEnded) res.end();
    }
  }

  function fallbackText(actions) {
    const okN = actions.filter((a) => a.status === 'ok' && a.op !== 'read').length;
    const bad = actions.find((a) => a.status !== 'ok');
    if (bad && !okN) return `Не получилось: ${bad.error || 'ошибка'}`;
    const mem = actions.filter((a) => a.kind === 'memory' && a.status === 'ok');
    if (okN && mem.length === okN) {
      if (mem.some((a) => a.op === 'suggested' || a.op === 'needs_consent')) return 'Если хочешь, чтобы я это запомнил, подтверди в карточке.';
      if (mem.some((a) => a.op === 'forgotten')) return 'Забыл.';
      return 'Запомнил.';
    }
    return okN ? 'Готово.' : 'Посмотрел.';
  }

  /* Действия ответов, которые будут удалены перед повторной генерацией: модель о них узнает */
  function actionsAfter(convId, userId, seq) {
    const msgs = store.messagesWithAttachments(convId).filter((m) => m.seq > seq && m.role === 'assistant');
    const acts = actionsByMessage(convId, userId);
    return msgs.flatMap((m) => acts.get(m.id) || []).filter((a) => a.status === 'ok' && a.op !== 'read');
  }

  /* Общая подготовка: сессия → тело → модель → лимит. Ошибки до начала потока уходят обычным JSON. */
  async function prepare(c, limit) {
    const session = auth.require(c.req);
    const body = await readJSON(c.req, limit);
    return { session, body, plan: limits.plan(session.plan), profile: sanitizeProfile(body.profile), tz: rememberTimezone(session, body.timezone) };
  }

  router.add('POST', '/api/conversations/:id/messages', async (c) => {
    const { session, body, plan, profile, tz } = await prepare(c, 17 * MB);
    // Layer 8: защита от повторной отправки (обрыв связи, двойное нажатие): тот же client_id = тот же запрос
    const key = typeof body.client_id === 'string' && KEY_RE.test(body.client_id) ? body.client_id : null;
    if (key && engine) {
      const k = engine.repo.startKey(session.userId, key, 'chat');
      if (!k.fresh) throw new HttpError(409, 'duplicate_request', 'Это сообщение уже отправлено.', { conversation_id: k.entry && k.entry.response ? k.entry.response.conversation_id : null });
    }
    const inputMode = body.input === 'voice' ? 'voice' : 'text';
    const isNew = c.params.id === 'new';
    const conv = isNew ? null : ownConversation(c.params.id, session.userId);
    if (conv) ensureIdle(conv.id);
    const model = resolveModel(body.model ? String(body.model) : null, conv, session.plan);
    const atts = readAttachments(body, plan, model);
    if (quota && atts.length) quota.checkImages(session, atts.length);    // Layer 10: plans.json → vision.images_daily
    const content = readContent(body, plan, { allowEmpty: atts.length > 0 });
    const lease = limits.begin(session.userId, session.plan, c.ip);
    let started = false;
    try {
      const target = conv || store.createConversation(session.userId, { title: makeTitle(content, atts.length > 0), model: model.id });
      if (conv && conv.model !== model.id) store.setConversationModel(conv.id, session.userId, model.id);
      if (conv && conv.title_source === 'auto' && store.messageCount(conv.id) === 0) store.renameConversation(conv.id, session.userId, makeTitle(content, atts.length > 0), 'auto');
      const userMessage = store.addUserMessage(target.id, session.userId, { content, attachments: atts });
      if (key && engine) engine.repo.finishKey(session.userId, key, 200, { conversation_id: target.id, message_id: userMessage.id });
      started = true;
      await generate(c, { session, conv: target, userMessage, model, profile, lease, tz, inputMode });
    } finally {
      if (!started) { lease.end({ refund: true }); if (key && engine) engine.repo.dropKey(session.userId, key); }
    }
  });

  router.add('POST', '/api/conversations/:id/regenerate', async (c) => {
    const { session, body, profile, tz } = await prepare(c, 64 * KB);
    const conv = ownConversation(c.params.id, session.userId);
    ensureIdle(conv.id);
    const msgs = store.messagesWithAttachments(conv.id);
    const lastUser = [...msgs].reverse().find((m) => m.role === 'user');
    if (!lastUser) throw new HttpError(400, 'nothing_to_regenerate', 'Здесь пока нечего повторять.');
    const model = resolveModel(body.model ? String(body.model) : null, conv, session.plan);
    if (lastUser.attachments.length && !model.vision) throw new HttpError(422, 'model_no_vision', 'Эта модель не понимает изображения.');
    const lease = limits.begin(session.userId, session.plan, c.ip);
    let started = false;
    try {
      const priorActions = actionsAfter(conv.id, session.userId, lastUser.seq);
      store.deleteMessagesAfter(conv.id, lastUser.seq);
      if (conv.model !== model.id) store.setConversationModel(conv.id, session.userId, model.id);
      started = true;
      await generate(c, { session, conv, userMessage: null, model, profile, lease, tz, priorActions });
    } finally {
      if (!started) lease.end({ refund: true });
    }
  });

  router.add('POST', '/api/conversations/:id/messages/:mid/edit', async (c) => {
    const { session, body, plan, profile, tz } = await prepare(c, 128 * KB);
    const conv = ownConversation(c.params.id, session.userId);
    ensureIdle(conv.id);
    const msgs = store.messagesWithAttachments(conv.id);
    const lastUser = [...msgs].reverse().find((m) => m.role === 'user');
    if (!lastUser || lastUser.id !== c.params.mid) throw new HttpError(409, 'not_last_message', 'Изменить можно только последнее своё сообщение.');
    const content = readContent(body, plan, { allowEmpty: lastUser.attachments.length > 0 });
    const model = resolveModel(body.model ? String(body.model) : null, conv, session.plan);
    if (lastUser.attachments.length && !model.vision) throw new HttpError(422, 'model_no_vision', 'Эта модель не понимает изображения.');
    const lease = limits.begin(session.userId, session.plan, c.ip);
    let started = false;
    try {
      const priorActions = actionsAfter(conv.id, session.userId, lastUser.seq);
      const updated = store.transaction(() => {
        store.editUserMessage(lastUser.id, content);
        store.deleteMessagesAfter(conv.id, lastUser.seq);
        const firstUser = msgs.find((m) => m.role === 'user');
        if (conv.title_source === 'auto' && firstUser && firstUser.id === lastUser.id) {
          store.renameConversation(conv.id, session.userId, makeTitle(content, lastUser.attachments.length > 0), 'auto');
        }
        if (conv.model !== model.id) store.setConversationModel(conv.id, session.userId, model.id);
        return { ...lastUser, content };
      });
      started = true;
      await generate(c, { session, conv, userMessage: updated, model, profile, lease, tz, priorActions });
    } finally {
      if (!started) lease.end({ refund: true });
    }
  });

  return { generating, config, sessionPayload };
}

module.exports = { register, makeTitle, publicMessage };
