/* WISP · Server · Actions API (Layer 8)
 * Все endpoint'ы требуют сессию; userId и тариф — только из неё. Изменения проходят проверку Origin + X-WISP-Client.
 *  GET  /api/actions/:id            ожидающее подтверждения действие (текущее состояние, цели с live-данными)
 *  POST /api/actions/:id/confirm    подтвердить (кнопка в карточке). Повторное нажатие/запрос не выполняет второй раз.
 *  POST /api/actions/:id/cancel     отменить
 *  POST /api/actions/records {refs:[{kind,id}]}  текущее состояние записей для карточек (только свои записи) */
'use strict';
const { sendJSON, readJSON, HttpError } = require('../lib/http');

function register(router, { auth, engine, generating, limits }) {
  const busy = (userId) => () => limits.active.has(userId) || [...generating.values()].includes(userId);
  router.add('GET', '/api/actions/:id', async (c) => {
    const s = auth.require(c.req);
    sendJSON(c.res, 200, { action: engine.get(s.userId, c.params.id) });
  });
  router.add('POST', '/api/actions/:id/confirm', async (c) => {
    const s = auth.require(c.req);
    await readJSON(c.req, 4096).catch(() => ({}));
    sendJSON(c.res, 200, engine.confirm(s.userId, s.plan, c.params.id, { tz: s.timezone || 'UTC', busy: busy(s.userId) }));
  });
  router.add('POST', '/api/actions/:id/cancel', async (c) => {
    const s = auth.require(c.req);
    sendJSON(c.res, 200, engine.cancel(s.userId, c.params.id));
  });
  router.add('POST', '/api/actions/records', async (c) => {
    const s = auth.require(c.req);
    const body = await readJSON(c.req, 32768);
    const refs = Array.isArray(body.refs) ? body.refs.slice(0, 100) : null;
    if (!refs) throw new HttpError(400, 'bad_input', 'Нужен список refs.');
    const live = engine.lookup(s.userId, refs.filter((r) => r && typeof r.kind === 'string' && typeof r.id === 'string'));
    sendJSON(c.res, 200, { records: Object.fromEntries(live) });
  });
}
module.exports = { register };
