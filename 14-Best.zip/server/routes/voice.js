/* WISP · Server · Voice API (Layer 7)
 * Все endpoint'ы требуют сессию; userId и тариф — только из сессии. Изменяющие запросы проходят общую проверку
 * Origin + X-WISP-Client (server/app.js). Ключ провайдера речи наружу не уходит.
 *
 *  GET  /api/voice                       что доступно: распознавание и синтез на сервере, голоса, лимиты на сегодня
 *  POST /api/voice/transcribe            тело — сама запись (audio/webm | audio/mp4 | audio/ogg | audio/wav | audio/mpeg),
 *                                        заголовок X-WISP-Audio-Ms — длительность записи → { text, duration_ms }
 *                                        Запись не сохраняется: после ответа провайдера буфер отпускается.
 *  POST /api/voice/speech {text, voice?, personality?}
 *                                        → аудио (audio/mpeg) потоком от провайдера; текст и звук не сохраняются.
 * Распознанный текст сервер в чат НЕ отправляет: клиент показывает его пользователю, а дальше это обычное
 * сообщение чата (POST /api/conversations/:id/messages) — с профилем, характером, памятью и инструментами. */
'use strict';
const { Readable } = require('node:stream');
const { HttpError, sendJSON, readJSON, readBody } = require('../lib/http');
const { MAX_AUDIO_BYTES } = require('../voice/service');

const KB = 1024;

function register(router, { auth, voice, store }) {
  router.add('GET', '/api/voice', async (c) => {
    const s = auth.require(c.req);
    sendJSON(c.res, 200, voice.status(s.userId, s.plan));
  });

  router.add('POST', '/api/voice/transcribe', async (c) => {
    const s = auth.require(c.req);
    const type = String(c.req.headers['content-type'] || '');
    if (!/^(audio\/|application\/octet-stream)/i.test(type)) throw new HttpError(415, 'bad_content_type', 'Ожидается аудиозапись.');
    if (!voice.sttAvailable) { c.req.resume(); throw new HttpError(503, 'voice_unavailable', 'Распознавание речи на сервере не подключено.'); }
    const audio = await readBody(c.req, MAX_AUDIO_BYTES);
    const ms = Number(c.req.headers['x-wisp-audio-ms']);
    const ctrl = new AbortController();
    const onClose = () => { if (!c.res.writableEnded) ctrl.abort(); };
    c.res.on('close', onClose);
    // имя помогает правильно написать его в распознанном тексте (тот же профиль, что видит чат)
    let name = null;
    try { const p = store.getProfile(s.userId); name = p && p.data && p.data.user ? p.data.user.name : null; } catch (e) { name = null; }
    try {
      const r = await voice.transcribe({ userId: s.userId, plan: s.plan, audio, durationMs: Number.isFinite(ms) ? ms : 0, name, signal: ctrl.signal });
      sendJSON(c.res, 200, { text: r.text, duration_ms: r.duration_ms, usage: voice.status(s.userId, s.plan).stt });
    } finally {
      c.res.off('close', onClose);
      audio.fill(0);                                        // запись не задерживается в памяти процесса
    }
  });

  router.add('POST', '/api/voice/speech', async (c) => {
    const s = auth.require(c.req);
    const body = await readJSON(c.req, 32 * KB);
    const ctrl = new AbortController();
    const onClose = () => { if (!c.res.writableEnded) ctrl.abort(); };
    c.res.on('close', onClose);
    let r;
    try {
      r = await voice.speech({ userId: s.userId, plan: s.plan, text: body.text, voice: typeof body.voice === 'string' ? body.voice : null, personality: typeof body.personality === 'string' ? body.personality : null, signal: ctrl.signal });
    } catch (e) { c.res.off('close', onClose); throw e; }
    c.res.writeHead(200, { 'Content-Type': r.mime, 'Cache-Control': 'no-store', 'X-WISP-Voice': r.voice, 'X-WISP-Chars': String(r.chars) });
    const stream = Readable.fromWeb(r.body);
    stream.on('error', () => { try { c.res.destroy(); } catch (e) { /* уже закрыт */ } });
    stream.on('end', () => r.done());
    c.res.on('close', () => { r.done(); if (!stream.destroyed) stream.destroy(); c.res.off('close', onClose); });
    stream.pipe(c.res);
  });
}

module.exports = { register };
