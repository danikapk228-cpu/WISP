/* WISP · Server · Memory API (Layer 5)
 * Все endpoint'ы требуют сессию; userId и тариф — только из неё (user_id, plan и права из запроса игнорируются).
 * Изменяющие запросы проходят общую проверку Origin + X-WISP-Client (server/app.js).
 *
 *  GET    /api/memories?q=&category=            список (активные + ожидающие подтверждения) и счётчики
 *  POST   /api/memories       {content, category?, importance?, pinned?, confirm_sensitive?}   добавить вручную
 *  GET    /api/memories/export                  все воспоминания JSON-файлом
 *  DELETE /api/memories       {confirm:"clear_all"}  очистить всю долговременную память
 *  GET    /api/memories/:id
 *  PATCH  /api/memories/:id   {content?, category?, importance?, pinned?, confirm_sensitive?}
 *  DELETE /api/memories/:id
 *  POST   /api/memories/:id/confirm   {confirm_sensitive?}   «Да, запомни» (предложение WISP)
 *  POST   /api/memories/:id/dismiss                          «Не надо»
 *  GET    /api/memory/settings · PATCH /api/memory/settings {enabled?, suggest?} */
'use strict';
const { sendJSON, readJSON } = require('../lib/http');

const KB = 1024;

function register(router, { auth, memory }) {
  const ctx = (c) => { const s = auth.require(c.req); return { userId: s.userId, plan: s.plan }; };
  const body = (c) => readJSON(c.req, 16 * KB);
  const json = (c, obj, status) => sendJSON(c.res, status || 200, obj);

  router.add('GET', '/api/memory/settings', async (c) => { const x = ctx(c); json(c, { settings: memory.settings(x), overview: memory.overview(x) }); });
  router.add('PATCH', '/api/memory/settings', async (c) => { const x = ctx(c); const s = memory.updateSettings(x, await body(c)); json(c, { settings: s, overview: memory.overview(x) }); });

  router.add('GET', '/api/memories', async (c) => {
    const x = ctx(c);
    json(c, memory.list(x, { q: c.url.searchParams.get('q') || '', category: c.url.searchParams.get('category') || '' }));
  });
  router.add('POST', '/api/memories', async (c) => { const x = ctx(c); const r = memory.create(x, await body(c)); json(c, { ...r, overview: memory.overview(x) }, r.op === 'created' ? 201 : 200); });
  router.add('DELETE', '/api/memories', async (c) => { const x = ctx(c); const r = memory.clear(x, await body(c)); json(c, { ...r, overview: memory.overview(x) }); });
  router.add('GET', '/api/memories/export', async (c) => {
    const x = ctx(c);
    const data = JSON.stringify(memory.export(x), null, 2);
    c.res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
      'Content-Disposition': `attachment; filename="wisp-memory-${new Date().toISOString().slice(0, 10)}.json"`,
      'Content-Length': Buffer.byteLength(data),
    });
    c.res.end(data);
  });
  router.add('GET', '/api/memories/:id', async (c) => { const x = ctx(c); json(c, { memory: memory.get(x, c.params.id) }); });
  router.add('PATCH', '/api/memories/:id', async (c) => { const x = ctx(c); json(c, { memory: memory.update(x, c.params.id, await body(c)), overview: memory.overview(x) }); });
  router.add('DELETE', '/api/memories/:id', async (c) => { const x = ctx(c); json(c, { ...memory.remove(x, c.params.id), overview: memory.overview(x) }); });
  router.add('POST', '/api/memories/:id/confirm', async (c) => { const x = ctx(c); json(c, { ...memory.confirm(x, c.params.id, await body(c)), overview: memory.overview(x) }); });
  router.add('POST', '/api/memories/:id/dismiss', async (c) => { const x = ctx(c); json(c, { ...memory.dismiss(x, c.params.id), overview: memory.overview(x) }); });
}

module.exports = { register };
