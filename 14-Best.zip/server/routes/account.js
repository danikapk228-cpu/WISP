/* WISP · Server · Account & Settings API (Layer 6)
 * userId и тариф берутся только из сессии. Тариф, переданный клиентом, игнорируется везде.
 * Изменяющие запросы проходят общую проверку Origin + X-WISP-Client (server/app.js).
 *
 *  GET    /api/app                                  «О приложении»: имя, версия, ссылки (без сессии, без секретов)
 *  GET    /api/account                              тариф, дата регистрации, что и сколько хранится на сервере
 *  GET    /api/profile                              профиль и настройки пользователя (или null, если ещё не сохранялись)
 *  PUT    /api/profile        {profile}             сохранить профиль и настройки (нормализация на сервере)
 *  PATCH  /api/account/profile {name?, avatar?}      Layer 9: имя и фото со страницы аккаунта (подтверждает сервер)
 *  POST   /api/account/logout {confirm:"delete_device_data"}
 *                                                   гость (без аккаунта): стереть данные этого устройства с сервера.
 *                                                   В аккаунте этот запрос только завершает сессию — данные аккаунта
 *                                                   не удаляются (выход: POST /api/auth/logout, удаление: /api/account/delete).
 * Очистка истории чатов (DELETE /api/conversations) — в routes/chat.js рядом с остальными диалогами. */
'use strict';
const { HttpError, sendJSON, readJSON } = require('../lib/http');
const Profile = require('../account/profile');
const Rules = require('../../src/auth/rules');

const KB = 1024;

function register(router, { store, auth, limits, config, ai, log, tools, memory }) {
  router.add('GET', '/api/app', async (c) => sendJSON(c.res, 200, { app: config.app, ai_connected: ai.anyAvailable() }));

  router.add('GET', '/api/account', async (c) => {
    const s = auth.require(c.req);
    const plan = limits.plan(s.plan);
    const saved = store.getProfile(s.userId);
    sendJSON(c.res, 200, {
      user: { id: s.userId, plan: s.plan, created_at: s.createdAt },
      plan: { id: s.plan, title: plan.title },
      data: store.stats(s.userId),
      profile_saved_at: saved ? saved.updated_at : null,
      accounts: true,                               // Layer 9: вход по почте и паролю
      kind: s.kind,
      account: s.kind === 'account' ? { email: s.email, email_verified: !!s.emailVerifiedAt, created_at: s.createdAt } : null,
    });
  });

  router.add('GET', '/api/account/export', async (c) => {
    const s = auth.require(c.req);
    const profileRow = store.getProfile(s.userId);
    // SQLite LIMIT -1 means unbounded; exports must not silently truncate large accounts.
    const conversations = store.listConversations(s.userId, -1)
      .filter((x) => x.message_count > 0)
      .map((conversation) => ({
        id: conversation.id,
        title: conversation.title,
        model: conversation.model || null,
        created_at: conversation.created_at,
        updated_at: conversation.updated_at,
        messages: store.messagesWithAttachments(conversation.id).map((message) => ({
          id: message.id,
          role: message.role,
          content: message.content,
          status: message.status,
          error_code: message.error_code || null,
          model: message.model || null,
          created_at: message.created_at,
          updated_at: message.updated_at,
          attachments: (message.attachments || []).map((attachment) => {
            const full = store.getAttachment(attachment.id, s.userId);
            return {
              id: attachment.id,
              mime: attachment.mime,
              width: attachment.width,
              height: attachment.height,
              bytes: attachment.bytes,
              data_base64: full && full.data ? Buffer.from(full.data).toString('base64') : null,
            };
          }),
        })),
      }));
    const ctx = { userId: s.userId, plan: s.plan, tz: s.timezone || 'UTC', source: 'user' };
    const payload = {
      exported_at: new Date().toISOString(),
      account: { kind: s.kind, email: s.kind === 'account' ? s.email : null, created_at: s.createdAt },
      profile: profileRow ? Profile.sanitize(profileRow.data) : null,
      conversations,
      memory: memory ? memory.export(ctx) : null,
      tools: tools ? tools.exportAll(ctx) : { notes: [], tasks: [], reminders: [], events: [] },
    };
    const data = JSON.stringify(payload, null, 2);
    c.res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Disposition': `attachment; filename="wisp-export-${new Date().toISOString().slice(0, 10)}.json"`,
      'Content-Length': Buffer.byteLength(data),
    });
    c.res.end(data);
  });

  router.add('POST', '/api/account/reset', async (c) => {
    const s = auth.require(c.req);
    const body = await readJSON(c.req, 4 * KB);
    if (body.confirm !== 'reset') throw new HttpError(400, 'confirm_required', 'Нужно подтверждение.');
    if (limits.active.has(s.userId)) throw new HttpError(409, 'busy', 'WISP ещё отвечает. Дождись ответа и попробуй снова.');
    const section = body.section;
    let deleted = 0;
    if (section === 'conversations') {
      deleted = store.deleteAllConversations(s.userId);
    } else if (section === 'memories') {
      if (!memory) throw new HttpError(503, 'not_available', 'Память сейчас недоступна.');
      deleted = memory.clear({ userId: s.userId, plan: s.plan }, { confirm: 'clear_all' }).deleted;
    } else {
      const tables = {
        notes: 'notes',
        tasks: 'tasks',
        reminders: 'reminders',
        events: 'events',
      };
      const table = Object.prototype.hasOwnProperty.call(tables, section) ? tables[section] : null;
      if (!table) throw new HttpError(400, 'bad_section', 'Неизвестный раздел данных.');
      if (limits.checkSettingsWrite) limits.checkSettingsWrite(s.userId, 20);
      deleted = store.db.prepare(`DELETE FROM ${table} WHERE user_id = ?`).run(s.userId).changes;
    }
    sendJSON(c.res, 200, { ok: true, section, deleted });
  });

  function publicProfile(row, s) {
    if (!row) return { profile: null, updated_at: null, plan: s.plan, created_at: s.createdAt };
    const p = Profile.sanitize(row.data);           // перечитываем через нормализацию: старые записи тоже безопасны
    return { profile: p, updated_at: row.updated_at, plan: s.plan, created_at: s.createdAt };
  }

  router.add('GET', '/api/profile', async (c) => {
    const s = auth.require(c.req);
    sendJSON(c.res, 200, publicProfile(store.getProfile(s.userId), s));
  });

  router.add('PUT', '/api/profile', async (c) => {
    const s = auth.require(c.req);
    limits.checkSettingsWrite(s.userId);
    const body = await readJSON(c.req, 128 * KB);
    const p = Profile.sanitize(body.profile);
    if (!p) throw new HttpError(400, 'bad_profile', 'Некорректный профиль.');
    store.saveProfile(s.userId, p);
    sendJSON(c.res, 200, publicProfile(store.getProfile(s.userId), s));
  });

  /* Layer 9: имя и аватар со страницы аккаунта. Остальной профиль (анкета, настройки) не трогается. */
  router.add('PATCH', '/api/account/profile', async (c) => {
    const s = auth.require(c.req);
    limits.checkSettingsWrite(s.userId);
    const body = await readJSON(c.req, 128 * KB);
    const cur = store.getProfile(s.userId);
    const base = cur ? Profile.sanitize(cur.data) : Profile.sanitize({});
    const user = { ...base.user };
    if (body.name !== undefined) {
      const err = Rules.nameError(body.name);
      if (err) throw new HttpError(400, err, Rules.message(err), { field: 'name' });
      user.name = Rules.normalizeName(body.name);
    }
    if (body.avatar !== undefined) {
      if (body.avatar === null) user.avatar = null;
      else {
        const a = Profile.sanitize({ user: { avatar: body.avatar } }).user.avatar;
        if (!a) throw new HttpError(400, 'bad_avatar', 'Это фото не подошло: нужен JPEG, PNG или WebP до 90 КБ. Попробуй другое.', { field: 'avatar' });
        user.avatar = a;
      }
    }
    const next = Profile.sanitize({ ...base, user, meta: { ...base.meta, updated_at: new Date().toISOString() } });
    store.saveProfile(s.userId, next);
    sendJSON(c.res, 200, publicProfile(store.getProfile(s.userId), s));
  });

  router.add('POST', '/api/account/logout', async (c) => {
    const s = auth.require(c.req);
    if (s.kind === 'account') {                     // аккаунт: только выход, данные остаются в аккаунте
      auth.signOut(c.req, c.res, s);
      return sendJSON(c.res, 200, { ok: true, deleted: false });
    }
    const body = await readJSON(c.req, 4 * KB);
    if (body.confirm !== 'delete_device_data') throw new HttpError(400, 'confirm_required', 'Нужно подтверждение.');
    if (limits.active.has(s.userId)) throw new HttpError(409, 'busy', 'WISP ещё отвечает. Дождись ответа или останови его.');
    limits.checkSettingsWrite(s.userId, 10);
    store.deleteUser(s.userId);
    auth.clearCookie(c.req, c.res);
    log.info('user signed out and deleted');
    sendJSON(c.res, 200, { ok: true });
  });
}

module.exports = { register };
