/* WISP · Server · Tools API (Layer 4)
 * Все endpoint'ы требуют сессию; userId и тариф берутся из неё (тарифу из запроса не верим).
 * Изменяющие запросы дополнительно проходят общую проверку Origin + X-WISP-Client (server/app.js).
 *
 *  GET    /api/tools/summary?tz=              счётчики для сетки инструментов + лимиты тарифа
 *  GET    /api/notes?q=                        заметки (поиск по заголовку и тексту)
 *  POST   /api/notes            {title, content}
 *  GET    /api/notes/:id
 *  PATCH  /api/notes/:id        {title?, content?}          автосохранение
 *  DELETE /api/notes/:id
 *  GET    /api/tasks?filter=all|active|completed
 *  POST   /api/tasks            {title, description?, due_date?, priority?}
 *  GET    /api/tasks/:id · /api/reminders/:id · /api/events/:id
 *  PATCH  /api/tasks/:id        {…, done?}
 *  DELETE /api/tasks/:id
 *  GET    /api/reminders?status=active|done|all
 *  POST   /api/reminders        {title, description?, date, time, timezone}
 *  PATCH  /api/reminders/:id    {title?, description?, date?, time?, timezone?, done?}
 *  POST   /api/reminders/:id/notified                      уведомление показано (чтобы не дублировать)
 *  DELETE /api/reminders/:id
 *  GET    /api/events?date=YYYY-MM-DD
 *  POST   /api/events           {title, date, start_time, end_time?, note?}
 *  PATCH  /api/events/:id
 *  DELETE /api/events/:id
 *  GET    /api/agenda?date=&tz=                            день целиком: события, задачи со сроком, напоминания */
'use strict';
const { sendJSON, readJSON } = require('../lib/http');
const { isValidTimeZone } = require('../tools/time');

const KB = 1024;
const BODY = 96 * KB;              // заметка до 50 000 символов кириллицей в UTF-8 укладывается

function register(router, { auth, tools, store }) {
  /* Контекст запроса: только из сессии. Пояс: из запроса (если корректен) или сохранённый у пользователя. */
  function ctx(c) {
    const s = auth.require(c.req);
    const q = c.url.searchParams.get('tz');
    const tz = q && isValidTimeZone(q) ? q : s.timezone || 'UTC';
    return { userId: s.userId, plan: s.plan, tz, source: 'user', session: s };
  }
  const body = (c) => readJSON(c.req, BODY);
  const json = (c, obj, status) => sendJSON(c.res, status || 200, obj);

  router.add('GET', '/api/tools/summary', async (c) => { const x = ctx(c); json(c, { summary: tools.summary(x) }); });

  /* ── Заметки ── */
  router.add('GET', '/api/notes', async (c) => { const x = ctx(c); json(c, { notes: tools.listNotes(x, { q: c.url.searchParams.get('q') || '' }) }); });
  router.add('POST', '/api/notes', async (c) => { const x = ctx(c); json(c, { note: tools.createNote(x, await body(c)) }, 201); });
  router.add('GET', '/api/notes/:id', async (c) => { const x = ctx(c); json(c, { note: tools.getNote(x, c.params.id) }); });
  router.add('PATCH', '/api/notes/:id', async (c) => { const x = ctx(c); json(c, { note: tools.updateNote(x, c.params.id, await body(c)) }); });
  router.add('DELETE', '/api/notes/:id', async (c) => { const x = ctx(c); json(c, tools.deleteNote(x, c.params.id)); });

  /* ── Задачи ── */
  router.add('GET', '/api/tasks', async (c) => { const x = ctx(c); json(c, { tasks: tools.listTasks(x, { filter: c.url.searchParams.get('filter') }) }); });
  router.add('POST', '/api/tasks', async (c) => { const x = ctx(c); json(c, { task: tools.createTask(x, await body(c)) }, 201); });
  router.add('GET', '/api/tasks/:id', async (c) => { const x = ctx(c); json(c, { task: tools.getTask(x, c.params.id) }); });
  router.add('PATCH', '/api/tasks/:id', async (c) => { const x = ctx(c); json(c, { task: tools.updateTask(x, c.params.id, await body(c)) }); });
  router.add('DELETE', '/api/tasks/:id', async (c) => { const x = ctx(c); json(c, tools.deleteTask(x, c.params.id)); });

  /* ── Напоминания ── */
  router.add('GET', '/api/reminders', async (c) => { const x = ctx(c); json(c, { reminders: tools.listReminders(x, { status: c.url.searchParams.get('status') }), server_time: Date.now() }); });
  router.add('POST', '/api/reminders', async (c) => {
    const x = ctx(c);
    const b = await body(c);
    if (b.timezone && isValidTimeZone(b.timezone) && b.timezone !== x.session.timezone) store.setTimezone(x.userId, b.timezone);
    json(c, { reminder: tools.createReminder(x, b) }, 201);
  });
  router.add('GET', '/api/reminders/:id', async (c) => { const x = ctx(c); json(c, { reminder: tools.getReminder(x, c.params.id) }); });
  router.add('PATCH', '/api/reminders/:id', async (c) => { const x = ctx(c); json(c, { reminder: tools.updateReminder(x, c.params.id, await body(c)) }); });
  router.add('POST', '/api/reminders/:id/notified', async (c) => { const x = ctx(c); json(c, tools.markNotified(x, c.params.id)); });
  router.add('DELETE', '/api/reminders/:id', async (c) => { const x = ctx(c); json(c, tools.deleteReminder(x, c.params.id)); });

  /* ── Планировщик ── */
  router.add('GET', '/api/events', async (c) => { const x = ctx(c); json(c, tools.listEvents(x, { date: c.url.searchParams.get('date') || undefined })); });
  router.add('POST', '/api/events', async (c) => { const x = ctx(c); json(c, { event: tools.createEvent(x, await body(c)) }, 201); });
  router.add('GET', '/api/events/:id', async (c) => { const x = ctx(c); json(c, { event: tools.getEvent(x, c.params.id) }); });
  router.add('PATCH', '/api/events/:id', async (c) => { const x = ctx(c); json(c, { event: tools.updateEvent(x, c.params.id, await body(c)) }); });
  router.add('DELETE', '/api/events/:id', async (c) => { const x = ctx(c); json(c, tools.deleteEvent(x, c.params.id)); });
  router.add('GET', '/api/agenda', async (c) => { const x = ctx(c); json(c, { agenda: tools.agenda(x, { date: c.url.searchParams.get('date') || undefined }) }); });
}

module.exports = { register };
