/* WISP · Server · Auth API (Layer 9)
 * Все изменяющие запросы проходят общую проверку Origin + X-WISP-Client (server/app.js).
 * user_id берётся только из сессии (cookie HttpOnly); id из тела запроса нигде не читается.
 *
 *  GET    /api/auth/config                                что доступно на этом сервере (регистрация, гостевой режим)
 *  POST   /api/auth/register      {name,email,password,password_confirm}   аккаунт + письмо подтверждения (без входа)
 *  POST   /api/auth/verify        {token}                 подтвердить почту по ссылке из письма
 *  POST   /api/auth/verify/resend {email}                 письмо подтверждения ещё раз (ответ не раскрывает, есть ли адрес)
 *  POST   /api/auth/login         {email,password}        вход → сессия аккаунта (+ guest: есть ли данные гостя этого браузера)
 *  POST   /api/auth/logout                                выход: сессия удаляется на сервере, cookie стирается
 *  POST   /api/auth/logout-all                            выйти на всех устройствах (включая это)
 *  GET    /api/auth/sessions                              активные сеансы аккаунта
 *  POST   /api/auth/password/forgot {email}               письмо со ссылкой (ответ одинаковый для любых адресов)
 *  POST   /api/auth/password/check  {token}               жива ли ссылка восстановления
 *  POST   /api/auth/password/reset  {token,password,password_confirm}  новый пароль, все сеансы завершены
 *  POST   /api/auth/password/change {current,password,password_confirm} смена пароля в аккаунте
 *  GET    /api/auth/guest                                 данные гостя этого браузера, которые можно перенести в аккаунт
 *  POST   /api/auth/guest/merge   {confirm:"merge"}        перенести их в аккаунт (только по явному согласию)
 *  POST   /api/account/delete     {password}              удалить аккаунт и все его данные */
'use strict';
const { HttpError, sendJSON, readJSON } = require('../lib/http');

const KB = 1024;

function register(router, { store, auth, accounts, limits, log, sessionPayload }) {
  const body = (c) => readJSON(c.req, 8 * KB);

  router.add('GET', '/api/auth/config', async (c) => sendJSON(c.res, 200, accounts.publicConfig()));

  router.add('POST', '/api/auth/register', async (c) => {
    const b = await body(c);
    const r = await accounts.register({ name: b.name, email: b.email, password: b.password, passwordConfirm: b.password_confirm, ip: c.ip });
    sendJSON(c.res, 200, r);
  });

  router.add('POST', '/api/auth/verify', async (c) => {
    const b = await body(c);
    sendJSON(c.res, 200, accounts.verify({ token: b.token, ip: c.ip }));
  });

  router.add('POST', '/api/auth/verify/resend', async (c) => {
    const b = await body(c);
    sendJSON(c.res, 200, accounts.resend({ email: b.email, ip: c.ip }));
  });

  router.add('POST', '/api/auth/login', async (c) => {
    const b = await body(c);
    const r = await accounts.login({ email: b.email, password: b.password, ip: c.ip });
    const { session, parkedGuest } = auth.signIn(c.req, c.res, r.userId);
    log.info('signed in', { user: r.userId });
    sendJSON(c.res, 200, { ...sessionPayload(session), guest: parkedGuest ? guestSummary(parkedGuest.userId) : null });
  });

  router.add('POST', '/api/auth/logout', async (c) => {
    const s = auth.current(c.req);
    if (s && s.kind === 'account') {
      auth.signOut(c.req, c.res, s);
      log.info('signed out', { user: s.userId });
    } else {
      auth.clearCookie(c.req, c.res);                     // гостя «выход» не удаляет: данные устройства остаются
    }
    sendJSON(c.res, 200, { ok: true });
  });

  router.add('POST', '/api/auth/logout-all', async (c) => {
    const s = auth.requireAccount(c.req);
    const n = store.deleteSessionsOf(s.userId);
    auth.clearCookie(c.req, c.res);
    log.info('signed out everywhere', { user: s.userId, sessions: n });
    sendJSON(c.res, 200, { ok: true, sessions: n });
  });

  router.add('GET', '/api/auth/sessions', async (c) => {
    const s = auth.requireAccount(c.req);
    const list = store.listSessions(s.userId)
      .filter((x) => x.expires_at > Date.now())
      .map((x) => ({ current: x.token_hash === s.tokenHash, device: x.device || null, created_at: x.created_at, last_seen_at: x.last_seen_at }));
    sendJSON(c.res, 200, { sessions: list });
  });

  router.add('POST', '/api/auth/password/forgot', async (c) => {
    const b = await body(c);
    sendJSON(c.res, 200, accounts.forgot({ email: b.email, ip: c.ip }));
  });

  router.add('POST', '/api/auth/password/check', async (c) => {
    const b = await body(c);
    sendJSON(c.res, 200, accounts.checkReset({ token: b.token, ip: c.ip }));
  });

  router.add('POST', '/api/auth/password/reset', async (c) => {
    const b = await body(c);
    const r = await accounts.reset({ token: b.token, password: b.password, passwordConfirm: b.password_confirm, ip: c.ip });
    // если в этом браузере была сессия этого же аккаунта — она уже удалена на сервере, стираем и cookie
    const cur = auth.current(c.req);
    if (!cur) auth.clearCookie(c.req, c.res);
    sendJSON(c.res, 200, r);
  });

  router.add('POST', '/api/auth/password/change', async (c) => {
    const s = auth.requireAccount(c.req);
    const b = await body(c);
    sendJSON(c.res, 200, await accounts.changePassword({ session: s, current: b.current, password: b.password, passwordConfirm: b.password_confirm }));
  });

  /* ── Данные гостя этого браузера → аккаунт ── */
  function guestSummary(guestId) {
    const st = store.stats(guestId);
    const p = store.getProfile(guestId);
    return {
      conversations: st.conversations, notes: st.notes, tasks: st.tasks, reminders: st.reminders, events: st.events, memories: st.memories,
      profile: !!p, profile_name: p && p.data && p.data.user ? p.data.user.name || null : null,
    };
  }

  router.add('GET', '/api/auth/guest', async (c) => {
    const s = auth.requireAccount(c.req);
    const g = auth.parkedGuest(c.req);
    if (!g || g.userId === s.userId || !store.hasData(g.userId)) return sendJSON(c.res, 200, { guest: null, account_has_profile: !!store.getProfile(s.userId) });
    sendJSON(c.res, 200, { guest: guestSummary(g.userId), account_has_profile: !!store.getProfile(s.userId) });
  });

  router.add('POST', '/api/auth/guest/merge', async (c) => {
    const s = auth.requireAccount(c.req);
    const b = await body(c);
    if (b.confirm !== 'merge') throw new HttpError(400, 'confirm_required', 'Нужно подтверждение переноса.');
    const g = auth.parkedGuest(c.req);
    if (!g || g.userId === s.userId) throw new HttpError(404, 'no_guest_data', 'На этом устройстве нет данных без аккаунта.');
    if (limits.active.has(g.userId) || limits.active.has(s.userId)) throw new HttpError(409, 'busy', 'WISP ещё отвечает. Дождись ответа и попробуй снова.');
    const r = store.mergeUsers(g.userId, s.userId);
    auth.clearGuestCookie(c.req, c.res);
    log.info('guest data merged into account', { user: s.userId });
    sendJSON(c.res, 200, { ok: true, moved: r.moved, profile_moved: r.profile });
  });

  router.add('POST', '/api/account/delete', async (c) => {
    const s = auth.requireAccount(c.req);
    const b = await body(c);
    if (limits.active.has(s.userId)) throw new HttpError(409, 'busy', 'WISP ещё отвечает. Дождись ответа или останови его.');
    await accounts.deleteAccount({ session: s, password: b.password });
    auth.clearCookie(c.req, c.res);
    sendJSON(c.res, 200, { ok: true });
  });
}

module.exports = { register };
