# WISP Layer 14.1 · Settings overlay fix

## Fixed
- The settings overlay now marks the Home screen as being in settings mode. The Home header, panels, and navigation no longer show through or overlap the settings screen.
- The mascot is repositioned into the current settings screen's header slot while settings are open, instead of covering the controls.
- On wide screens, the optional side navigation stays hidden while Settings is open, including when the underlying tab is Chat.
- Added a browser regression assertion for the overlay state and hidden Home content.

## Verification
- Full Node server, tools, memory, voice, actions, auth, subscription, and theme-engine suites: PASS.
- Changed JavaScript syntax checks: PASS.
- Single-file build: PASS.
- Browser E2E and real-device checks: NOT RUN. The Playwright Chromium executable is missing in this environment.

## Included
This archive includes the Layer 14 settings UI, the Layer 14.1 overlay fix, updated E2E coverage, and the rebuilt `dist/wisp.html`.
