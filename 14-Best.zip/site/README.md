# WISP · Layer 12 · Публичный сайт

Отдельный статический сайт-презентация WISP. Это **не приложение**: он не обращается к API, не ставит cookie,
не загружает внешние шрифты и скрипты, в нём нет секретов. Приложение WISP (`index.html`, `src/`, `server/`) сайт не меняет,
а сервер WISP папку `site/` не раздаёт (он отдаёт только `/` и `/src/`).

## Структура
```
site/
  index.html              главная: Hero, About, Features, Free & Plus, Preview, Transparency, Footer
  privacy.html            политика конфиденциальности (черновик по фактическому устройству WISP)
  assets/css/site.css     стили (значения совпадают с src/design-system/tokens.css)
  assets/js/boot.js       включает анимации появления только при работающем JS
  assets/js/config.js     ссылки: приложение, Telegram, GitHub, почта, политика (пусто = ссылка скрыта)
  assets/js/site.js       поведение: ссылки, появление, история возможностей, характер, галерея
  assets/img/             маскот, иконки, картинка для соцсетей, скриншоты (WebP 360/720)
  _headers                CSP и заголовки для Netlify / Cloudflare Pages
  .nojekyll, robots.txt   для GitHub Pages и поисковиков
```

## Запуск локально
```
npm run site          # http://127.0.0.1:8080/site/
```
`tools/site_serve.js` отдаёт только `site/` и статический фронтенд приложения (как сервер WISP), чтобы работала кнопка «Открыть WISP».
`server/`, `.env` и `data/` он не отдаёт. API там нет: для полного WISP с AI запусти `npm start`.
```
```
Или просто открыть `site/index.html` двойным кликом.

## Настройка ссылок
`site/assets/js/config.js`:
- `appUrl`: адрес приложения. По умолчанию `../` (приложение из этого же репозитория). Если сайт размещается отдельно, впиши полный `https://` адрес.
- `telegramUrl`, `githubUrl`: только `https://`. Пусто = пункта нет на сайте.
- `supportEmail`: пусто = «Контакты» скрыты.
- `privacyUrl`: по умолчанию `privacy.html`.

## Данные на сайте
- Таблица Free / Plus генерируется из `server/config/plans.json`: `npm run site:assets` (меняет только блок между `<!-- plans:start -->` и `<!-- plans:end -->`).
- Маскот собирается из слоёв Layer 0 (`src/layer0-entrance/entrance.js`) тем же скриптом (нужен Pillow).
- Скриншоты: `npm run site:shots` снимает настоящий интерфейс (настоящий сервер и фронтенд, демонстрационный двойник AI вместо провайдера, временная база), затем `npm run site:assets` делает WebP. Нужен Playwright, как для `npm run test:e2e`.

## Размещение на бесплатном хостинге
Сайт работает из любой папки, все пути относительные.
**Публикуй только папку `site/`.** Не выкладывай на статический хостинг весь репозиторий: туда попадут закрытый `server/`, конфиги и, если они есть, `.env` и `data/`.
- **GitHub Pages:** публиковать содержимое `site/` (например, через GitHub Actions «Deploy static content» с `path: site`).
- **Cloudflare Pages / Netlify:** каталог сборки `site`, команды сборки нет. `_headers` подхватится автоматически.
- **Vercel:** Output directory `site`, framework «Other».
Если публикуется только `site/`, обязательно укажи `appUrl` полным адресом приложения.
