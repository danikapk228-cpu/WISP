/* WISP · Site · включает анимации появления только при работающем JS (без JS всё видно сразу). */
document.documentElement.classList.add('js');
