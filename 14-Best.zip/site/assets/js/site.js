/* WISP · Layer 12 · Public website
 * Без зависимостей. Ссылки из config.js, появление секций, подсветка текста About, история возможностей
 * с липким телефоном, переключатель характера, галерея, параллакс героя. Уважает prefers-reduced-motion. */
(function () {
  'use strict';
  const C = window.WISP_SITE || {};
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');

  /* ── ссылки: только настоящие адреса, пустые скрываются ── */
  const https = (u) => { try { const x = new URL(u); return x.protocol === 'https:' ? x.href : ''; } catch (e) { return ''; } };
  const email = (e) => (/^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/i.test(e || '') ? e : '');
  const app = (C.appUrl || '').trim();
  $$('[data-app-link]').forEach((a) => { if (app) a.href = app; else a.hidden = true; });
  const links = { telegram: https(C.telegramUrl), github: https(C.githubUrl), email: email(C.supportEmail) ? `mailto:${C.supportEmail}` : '', privacy: (C.privacyUrl || '').trim() };
  $$('[data-link]').forEach((a) => {
    const href = links[a.dataset.link];
    if (!href) { a.hidden = true; return; }
    a.href = href; a.hidden = false;
    if (/^https:/.test(href)) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
  });
  if (links.email) $$('[data-contact]').forEach((el) => { el.hidden = false; });
  const year = $('[data-year]'); if (year) year.textContent = String(new Date().getFullYear());

  /* ── шапка становится стеклянной после начала прокрутки ── */
  const nav = $('[data-nav]');
  const onNav = () => nav && nav.classList.toggle('is-solid', window.scrollY > 8);

  /* ── появление ── */
  const appear = $$('.rise, .reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    appear.forEach((el) => io.observe(el));
  } else appear.forEach((el) => el.classList.add('is-in'));
  requestAnimationFrame(() => $$('.hero .rise').forEach((el) => el.classList.add('is-in')));

  /* ── About: слова загораются по мере прокрутки ── */
  const words = $('[data-words]');
  let ws = [];
  if (words) {
    const parts = words.textContent.trim().split(/\s+/);
    words.textContent = '';
    parts.forEach((w, i) => { const s = document.createElement('span'); s.className = 'w'; s.textContent = w; words.appendChild(s); if (i < parts.length - 1) words.appendChild(document.createTextNode(' ')); });
    ws = $$('.w', words);
  }
  const onWords = () => {
    if (!ws.length) return;
    if (reduced.matches) { ws.forEach((w) => w.classList.add('is-lit')); return; }
    const r = words.getBoundingClientRect(), vh = window.innerHeight;
    const p = Math.min(1, Math.max(0, (vh * 0.86 - r.top) / (r.height + vh * 0.36)));
    const n = Math.round(p * ws.length);
    ws.forEach((w, i) => w.classList.toggle('is-lit', i < n));
  };

  /* ── параллакс телефона в герое ── */
  const par = $('[data-parallax]');
  const onPar = () => {
    if (!par || reduced.matches) return;
    const y = Math.min(window.scrollY, window.innerHeight);
    par.style.transform = `translate3d(0, ${(y * -0.06).toFixed(1)}px, 0)`;
  };

  let ticking = false;
  const onScroll = () => { if (ticking) return; ticking = true; requestAnimationFrame(() => { ticking = false; onNav(); onWords(); onPar(); }); };
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });
  onScroll();

  /* ── Features: активная глава меняет экран в липком телефоне ── */
  const chapters = $$('.chapter');
  const stage = $('[data-stage]');
  if (chapters.length && 'IntersectionObserver' in window) {
    const shots = stage ? $$('img', stage) : [];
    const setActive = (ch) => {
      chapters.forEach((c) => c.classList.toggle('is-active', c === ch));
      shots.forEach((im) => {
        const on = im.dataset.for === ch.dataset.screen;
        if (on && im.loading === 'lazy') im.loading = 'eager';
        im.classList.toggle('is-on', on);
      });
    };
    const co = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) setActive(e.target); }), { rootMargin: '-45% 0px -45% 0px' });
    chapters.forEach((c) => co.observe(c));
    setActive(chapters[0]);
    /* экраны липкого телефона подгружаем заранее, когда секция рядом */
    if (stage) {
      const pre = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { shots.forEach((im) => { im.loading = 'eager'; }); pre.disconnect(); } }, { rootMargin: '600px 0px' });
      pre.observe(stage);
    }
  }

  /* ── Personalization: настоящие приветствия из знакомства (src/core/profile.js) ── */
  const TONES = {
    friendly: 'Привет, Алекс! Рад тебя видеть. Чем займёмся сегодня?',
    calm: 'Здравствуй, Алекс. Давай спокойно разберёмся, что сегодня важно.',
    business: 'Алекс, на связи. Какая задача?',
    humor: 'О, Алекс! Я уже начал скучать. Спасаем мир или хотя бы этот день?',
    adaptive: 'Привет, Алекс. Подстроюсь под твой ритм: могу коротко, могу подробно.',
  };
  const tone = $('[data-tone]');
  if (tone) {
    const line = $('[data-tone-line]', tone);
    const btns = $$('[data-tone-id]', tone);
    let timer = 0;
    const pick = (b, focus) => {
      btns.forEach((x) => { const on = x === b; x.setAttribute('aria-checked', on ? 'true' : 'false'); x.tabIndex = on ? 0 : -1; });
      if (focus) b.focus();
      clearTimeout(timer);
      if (reduced.matches) { line.textContent = `«${TONES[b.dataset.toneId]}»`; return; }
      line.classList.add('is-swap');
      timer = setTimeout(() => { line.textContent = `«${TONES[b.dataset.toneId]}»`; line.classList.remove('is-swap'); }, 220);
    };
    btns.forEach((b, i) => {
      b.tabIndex = b.getAttribute('aria-checked') === 'true' ? 0 : -1;
      b.addEventListener('click', () => pick(b));
      b.addEventListener('keydown', (e) => {
        const d = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
        if (!d) return;
        e.preventDefault();
        pick(btns[(i + d + btns.length) % btns.length], true);
      });
    });
  }

  /* ── Preview: кнопки галереи ── */
  const gal = $('[data-gallery]');
  if (gal) {
    const prev = $('[data-gal="prev"]'), next = $('[data-gal="next"]');
    const step = () => { const it = $('.gallery__item', gal); return it ? it.getBoundingClientRect().width + parseFloat(getComputedStyle(gal).columnGap || 24) : 300; };
    const sync = () => {
      const max = gal.scrollWidth - gal.clientWidth - 2;
      if (prev) prev.disabled = gal.scrollLeft <= 2;
      if (next) next.disabled = gal.scrollLeft >= max;
    };
    const go = (d) => gal.scrollBy({ left: d * step(), behavior: reduced.matches ? 'auto' : 'smooth' });
    if (prev) prev.addEventListener('click', () => go(-1));
    if (next) next.addEventListener('click', () => go(1));
    gal.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') { e.preventDefault(); go(1); } if (e.key === 'ArrowLeft') { e.preventDefault(); go(-1); } });
    gal.addEventListener('scroll', () => requestAnimationFrame(sync), { passive: true });
    window.addEventListener('resize', sync, { passive: true });
    sync();
  }

  /* ── маскот в финале подпрыгивает, как в приложении ── */
  const hop = $('[data-hop]');
  if (hop) {
    hop.addEventListener('click', () => {
      if (reduced.matches) return;
      hop.classList.remove('is-hop'); void hop.offsetWidth; hop.classList.add('is-hop');
    });
    hop.addEventListener('animationend', (e) => { if (e.animationName === 'hop') hop.classList.remove('is-hop'); });
  }
})();
