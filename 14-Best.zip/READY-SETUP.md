# 14-Best: configured provider archive

## Ready now
- Groq is the Free default model.
- Gemini, OpenRouter, and Hugging Face providers are configured in the packaged `.env`.
- Only the first Groq key is wired: WISP currently supports one key per provider. Additional Groq keys are not copied into the archive.
- Cloudflare remains blank until its Account ID/base URL is known.
- Supabase remains blank until the Edge Function URL is deployed/known. The project contains the deployable proxy template and guide.

## Verification
- Full test suite: PASS. # tests 175; # pass 175; # fail 0; # duration_ms 38263.151988
- Single-file build regenerated; provider activation checked from local config.
- No live API calls were made; credentials were not tested against provider services.
- Browser E2E not run in this environment (no Chromium executable).

## Credential note
The ZIP contains `.env` with live API secrets. Anyone who can access this attachment can read them. Since they were also posted in the task thread, rotate the keys after testing and replace them with fresh ones in a private server environment.
