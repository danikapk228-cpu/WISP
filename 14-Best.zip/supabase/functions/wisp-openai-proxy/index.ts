const json = (status: number, body: Record<string, unknown>) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

export default {
  async fetch(request: Request) {
  if (request.method !== "POST") {
    return json(405, { error: { message: "POST required", type: "invalid_request_error" } });
  }

  const proxyToken = Deno.env.get("WISP_SUPABASE_PROXY_TOKEN") || "";
  const auth = request.headers.get("authorization") || "";
  if (!proxyToken || auth !== `Bearer ${proxyToken}`) {
    return json(401, { error: { message: "Unauthorized", type: "authentication_error" } });
  }

  const upstreamBase = Deno.env.get("WISP_AI_UPSTREAM_BASE_URL") || "";
  const upstreamModel = Deno.env.get("WISP_AI_UPSTREAM_MODEL") || "";
  const upstreamKey = Deno.env.get("WISP_AI_UPSTREAM_API_KEY") || "";
  if (!upstreamBase || !upstreamModel || !upstreamKey) {
    return json(503, { error: { message: "AI proxy is not configured", type: "server_error" } });
  }

  let endpoint: URL;
  try {
    endpoint = new URL(upstreamBase.replace(/\/+$/, "") + "/chat/completions");
    if (!["http:", "https:"].includes(endpoint.protocol)) throw new Error("invalid protocol");
  } catch {
    return json(500, { error: { message: "Invalid upstream URL", type: "server_error" } });
  }

  let payload: Record<string, unknown>;
  try {
    payload = await request.json();
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new Error("bad json");
  } catch {
    return json(400, { error: { message: "Expected a JSON object", type: "invalid_request_error" } });
  }

  // WISP keeps the proxy's public model alias in its server config; only the upstream model is sent onward.
  payload.model = upstreamModel;
  let upstream: Response;
  try {
    upstream = await fetch(endpoint, {
      method: "POST",
      headers: {
        authorization: `Bearer ${upstreamKey}`,
        "content-type": "application/json",
        accept: request.headers.get("accept") || "text/event-stream",
      },
      body: JSON.stringify(payload),
    });
  } catch {
    return json(502, { error: { message: "AI upstream is unreachable", type: "server_error" } });
  }

  const headers = new Headers({
    "cache-control": "no-store, no-transform",
    "x-content-type-options": "nosniff",
  });
  const contentType = upstream.headers.get("content-type");
  if (contentType) headers.set("content-type", contentType);
  return new Response(upstream.body, { status: upstream.status, headers });
  },
};
