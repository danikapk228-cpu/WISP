/* WISP · Tests · E2E в браузере (node --test tests/e2e.test.js)
 * Настоящий фронтенд + настоящий сервер + локальный двойник провайдера. Нужен Playwright (не входит в проект):
 *   npm i -D playwright && npx playwright install chromium     (или PLAYWRIGHT_MODULE=путь, CHROME_PATH=путь к Chromium)
 * Без Playwright тест пропускается. Скриншоты — в папку WISP_E2E_SHOTS (если задана).
 * Сценарий Layer 5 на iPhone-экране: пустая память → «запомни» в чате → факт в Memory → новый чат его учитывает
 * → предложение WISP с кнопками → правка, закрепление, поиск, категории → выключение памяти → личное с согласием
 * → очистка. Плюс проверка, что вкладки Layers 2–4 открываются и работают. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { startStack } = require('./helpers');

let pw = null;
try { pw = require(process.env.PLAYWRIGHT_MODULE || 'playwright'); } catch (e) { try { pw = require('playwright-core'); } catch (er) { pw = null; } }
const SHOTS = process.env.WISP_E2E_SHOTS || '';
const PROFILE = { schema_version: 1, user: { name: 'Гера', interests: ['games', 'programming'], occupation: 'own_project', about: '', assistant_personality: 'friendly', permissions: {}, onboarding_completed: true, plan: 'free' }, meta: { created_at: new Date().toISOString(), updated_at: new Date().toISOString(), completed_at: new Date().toISOString() } };
const TEST_AVATAR = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAFUlEQVR4nGP8z8DwnwEJMDGgAcICAIPRAgYCkO9YAAAAAElFTkSuQmCC';
const call = (name, args) => `[[call:${name} ${JSON.stringify(args)}]]`;

test('E2E · Layers 0–5 в браузере (iPhone)', { skip: !pw && 'Playwright не установлен' }, async (t) => {
  const S = await startStack({ voice: 'sk-wisp-e2e-voice-test-key' });
  S.provider.voice.transcript = 'Создай задачу голосом [[call:create_task {"title":"Задача голосом"}]]';
  const browser = await pw.chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
  t.after(async () => { await browser.close(); await S.close(); });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ru-RU', timezoneId: 'Europe/Moscow', reducedMotion: 'reduce' });
  await ctx.addInitScript((p) => { if (!localStorage.getItem('wisp:profile:v1')) localStorage.setItem('wisp:profile:v1', JSON.stringify(p)); }, PROFILE);
  await ctx.addInitScript(() => {
    const stream = { getTracks: () => [{ stop() {} }] };
    Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: { getUserMedia: async () => stream } });
    Object.defineProperty(window, 'AudioContext', { configurable: true, value: undefined });
    Object.defineProperty(window, 'webkitAudioContext', { configurable: true, value: undefined });
    class FakeRecorder {
      static isTypeSupported() { return true; }
      constructor(_stream, opts) { this.mimeType = opts && opts.mimeType || 'audio/webm'; this.state = 'inactive'; }
      start() { this.state = 'recording'; }
      stop() {
        this.state = 'inactive';
        setTimeout(() => {
          const bytes = new Uint8Array(1200);
          bytes.set([0x1a, 0x45, 0xdf, 0xa3]);
          if (this.ondataavailable) this.ondataavailable({ data: new Blob([bytes], { type: 'audio/webm' }) });
          if (this.onstop) this.onstop();
        }, 0);
      }
    }
    window.MediaRecorder = FakeRecorder;
  });
  const page = await ctx.newPage();
  const errors = [];
  const chatBodies = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon/.test(m.text())) errors.push(m.text()); });
  page.on('request', (req) => {
    if (req.method() === 'POST' && /\/api\/conversations\/[^/]+\/messages$/.test(new URL(req.url()).pathname)) {
      try { chatBodies.push(JSON.parse(req.postData() || '{}')); } catch (e) { /* тест проверит только валидное тело */ }
    }
  });
  let n = 0;
  const shot = async (name) => { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: path.join(SHOTS, `${String(++n).padStart(2, '0')}-${name}.png`) }); } };
  const tap = async (sel) => { await page.locator(sel).first().click(); };
  const tab = async (id) => {
    let active = await page.locator('.home').getAttribute('data-tab');
    if (active === 'chat' && id !== 'chat') {
      await page.locator('#home-panel-chat .chat-bar__btn[aria-label="Назад"]').click();
      await page.waitForSelector('#home-panel-home.is-active', { timeout: 5000 });
      active = 'home';
    }
    if (active !== id) await tap(`#home-tab-${id}`);
    await page.waitForTimeout(450);
  };
  const sendChat = async (textv) => {
    const box = page.locator('#home-panel-chat textarea');
    const before = await page.locator('#home-panel-chat .cm--wisp').count();
    await box.fill(textv);
    await page.locator('#home-panel-chat .home-send').click();
    await page.waitForFunction((n) => document.querySelectorAll('#home-panel-chat .cm--wisp').length > n && !document.querySelector('#home-panel-chat.is-generating'), before, { timeout: 15000 });
    await page.waitForTimeout(250);
  };

  await page.goto(S.base + '/');
  if (await page.locator('[data-auth-root]').count()) {
    await page.locator('[data-auth-action="guest"]').click();
  }
  await page.waitForSelector('.home.is-in', { timeout: 15000 });
  await page.waitForTimeout(600);
  await shot('home');

  await t.test('Memory: пустое состояние с объяснением', async () => {
    await tab('memory');
    await page.waitForSelector('.mm-empty');
    assert.match(await page.locator('.mm-empty').innerText(), /запомни/i);
    assert.equal(await page.locator('.mm-count__n').innerText(), '0');
    await shot('memory-empty');
  });

  await t.test('чат: «запомни» → карточка «Запомнил» (подтверждение сервера)', async () => {
    await tab('chat');
    await sendChat('Запомни, что я разрабатываю игру на JavaScript ' + call('remember', { content: 'Разрабатывает игру на JavaScript', category: 'work' }));
    await page.waitForSelector('.cm-act--mem');
    assert.match(await page.locator('.cm-act--mem').last().innerText(), /Запомнил[\s\S]*JavaScript/);
    await shot('chat-remembered');
  });

  await t.test('новый чат учитывает память: кнопка «Память · 1»', async () => {
    await tap('button[aria-label="Новый диалог"]');
    await sendChat('Как мне реализовать инвентарь?');
    await page.waitForSelector('.cm__mem:not([hidden])');
    assert.match(await page.locator('.cm__mem:not([hidden])').last().innerText(), /Память · 1/);
    await shot('chat-memory-used');
    await tap('.cm__mem:not([hidden])');
    await page.waitForSelector('.ds-sheet.is-open .mm-used');
    assert.match(await page.locator('.ds-sheet.is-open').innerText(), /Разрабатывает игру на JavaScript/);
    await shot('chat-memory-used-sheet');
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Понятно' }).click();
    await page.waitForTimeout(500);
  });

  await t.test('предложение WISP: «Запомнить?» → «Запомнил»', async () => {
    await sendChat('Мне нравится минималистичный дизайн ' + call('suggest_memory', { content: 'Нравится минималистичный дизайн', category: 'preferences' }));
    await page.waitForSelector('.cm-act.is-pending');
    await shot('chat-suggestion');
    await page.locator('.cm-act.is-pending').getByRole('button', { name: 'Запомнить' }).click();
    await page.waitForFunction(() => !document.querySelector('.cm-act.is-pending'));
    assert.match(await page.locator('.cm-act--mem').last().innerText(), /Запомнил[\s\S]*минималист/);
  });

  await t.test('Memory: карточки, счётчик, правка, закрепление, поиск, категории', async () => {
    await tab('memory');
    await page.waitForSelector('.mm-card');
    assert.equal(await page.locator('.mm-count__n').innerText(), '2');
    assert.equal(await page.locator('.mm-card').count(), 2);
    await shot('memory-list');
    // правка
    await page.locator('.mm-card__main', { hasText: 'JavaScript' }).click();
    await page.waitForSelector('.ds-sheet.is-open .mm-ed');
    await shot('memory-edit');
    await page.locator('.ds-sheet.is-open textarea').fill('Разрабатывает игру на TypeScript');
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Сохранить' }).click();
    await page.waitForSelector('.mm-card:has-text("TypeScript")');
    // закрепление
    await page.locator('.mm-card', { hasText: 'TypeScript' }).locator('.mm-card__pin').click();
    await page.waitForSelector('.mm-card.is-pinned:has-text("TypeScript")');
    assert.match(await page.locator('.mm-list').innerText(), /Закреплено/);
    // поиск с учётом формы слова
    await page.locator('.mm-search input').fill('игры');
    await page.waitForTimeout(700);
    assert.equal(await page.locator('.mm-card').count(), 1);
    await page.locator('.mm-search input').fill('');
    await page.waitForTimeout(700);
    // фильтр категории
    await page.locator('.mm-chip', { hasText: 'Preferences' }).click();
    await page.waitForTimeout(700);
    assert.equal(await page.locator('.mm-card').count(), 1);
    assert.match(await page.locator('.mm-card').innerText(), /минималист/);
    await page.locator('.mm-chip', { hasText: 'All' }).click();
    await page.waitForTimeout(600);
    await shot('memory-pinned');
  });

  await t.test('правка видна в новом чате', async () => {
    await tab('chat');
    await tap('button[aria-label="Новый диалог"]');
    const before = S.provider.requests.length;
    await sendChat('Как сделать инвентарь в игре?');
    const req = S.provider.requests[before];
    const sys = req.body.messages[0].content;
    assert.match(sys, /TypeScript/); assert.doesNotMatch(sys, /JavaScript/);
  });

  await t.test('выключение памяти: записи на месте, в чате не используется', async () => {
    await tab('memory');
    await page.locator('.mm-power .mm-switch').click();
    await page.waitForSelector('.mm-off:not([hidden])');
    await shot('memory-off');
    await tab('chat');
    await tap('button[aria-label="Новый диалог"]');
    const before = S.provider.requests.length;
    await sendChat('Как сделать инвентарь в игре?');
    assert.doesNotMatch(S.provider.requests[before].body.messages[0].content, /TypeScript/);
    await tab('memory');
    assert.equal(await page.locator('.mm-card').count(), 2, 'записи остались');
    await page.locator('.mm-power .mm-switch').click();
    await page.waitForSelector('.mm-off', { state: 'hidden' });
  });

  await t.test('ручное добавление личного: отдельное согласие; пароль не сохраняется', async () => {
    await tap('.tl-add');
    await page.waitForSelector('.ds-sheet.is-open .mm-ed');
    await page.locator('.ds-sheet.is-open textarea').fill('У меня аллергия на орехи');
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Запомнить' }).click();
    await page.waitForSelector('.ds-sheet.is-open .mm-consent:not([hidden])');
    await shot('memory-consent');
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Да, сохранить' }).click();
    await page.waitForSelector('.mm-card:has-text("аллергия")');
    assert.match(await page.locator('.mm-card', { hasText: 'аллергия' }).innerText(), /личное/);
    await tap('.tl-add');
    await page.waitForSelector('.ds-sheet.is-open .mm-ed');
    await page.locator('.ds-sheet.is-open textarea').fill('Пароль от почты hunter2');
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Запомнить' }).click();
    await page.waitForSelector('.ds-sheet.is-open .mm-ed__err:not([hidden])');
    assert.match(await page.locator('.ds-sheet.is-open .mm-ed__err').innerText(), /не запоминает/);
    await page.keyboard.press('Escape');
    await page.waitForTimeout(500);
  });

  await t.test('клавиатура iPhone: поле редактора видно над клавиатурой', async () => {
    await tap('.tl-add');
    await page.waitForSelector('.ds-sheet.is-open textarea');
    await page.setViewportSize({ width: 390, height: 500 });          // как будто открылась клавиатура
    await page.waitForTimeout(500);
    const box = await page.locator('.ds-sheet.is-open textarea').boundingBox();
    assert.ok(box && box.y >= 0 && box.y + 40 < 500, 'поле в видимой области');
    await shot('memory-keyboard');
    await page.setViewportSize({ width: 390, height: 844 });
    await page.keyboard.press('Escape');
    await page.waitForTimeout(500);
  });

  await t.test('очистка всей памяти: два касания', async () => {
    await page.locator('.mm-set--danger').scrollIntoViewIfNeeded();
    await tap('.mm-set--danger');
    await page.waitForSelector('.ds-sheet.is-open');
    const del = page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Очистить всю память' });
    await del.click();
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: /ещё раз/ }).click();
    await page.waitForSelector('.mm-empty');
    assert.equal(await page.locator('.mm-count__n').innerText(), '0');
  });

  await t.test('Layer 8: карточка записи, правка и удаление с явным подтверждением', async () => {
    await tab('chat');
    await sendChat('Создай задачу ' + call('create_task', { title: 'Карточка из чата' }));
    const card = page.locator('.cm-act--record').filter({ hasText: 'Карточка из чата' }).last();
    await card.getByRole('button', { name: 'Изменить' }).click();
    await page.waitForSelector('.ds-sheet.is-open .tl-form');
    const sheet = page.locator('.ds-sheet.is-open');
    await sheet.locator('input[aria-label="Название"]').fill('Карточка после правки');
    await sheet.getByRole('button', { name: 'Сохранить' }).click();
    await page.waitForFunction(() => [...document.querySelectorAll('.cm-act--record')].some((x) => x.innerText.includes('Карточка после правки')));

    const edited = page.locator('.cm-act--record').filter({ hasText: 'Карточка после правки' }).last();
    await edited.getByRole('button', { name: 'Удалить' }).click();
    await page.waitForSelector('.ds-sheet.is-open');
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Удалить' }).click();
    await page.waitForFunction(() => [...document.querySelectorAll('.cm-act--record')].some((x) => x.innerText.includes('Запись удалена')));
    await shot('chat-action-edited-deleted');
  });

  await t.test('Layer 8: расписание, поиск и карточка подтверждения', async () => {
    const today = await page.evaluate(() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    });
    await sendChat('Запланируй событие ' + call('create_event', { title: 'Встреча из чата', date: today, start_time: '23:55' }));
    await sendChat('Покажи план на сегодня ' + call('get_agenda', { date: today, days: 1 }));
    assert.match(await page.locator('.cm-act--list').last().innerText(), /Встреча из чата/);
    await sendChat('Найди встречу ' + call('search_everything', { query: 'Встреча из чата', types: ['events'] }));
    assert.match(await page.locator('.cm-act--list').last().innerText(), /Встреча из чата/);

    await sendChat('Создай задачу для подтверждения ' + call('create_task', { title: 'Удаляемая задача' }));
    const task = await page.evaluate(async () => {
      const r = await fetch('/api/tasks?filter=all');
      const data = await r.json();
      return data.tasks.find((x) => x.title === 'Удаляемая задача');
    });
    assert.ok(task && task.id);
    await sendChat('Удалить задачу ' + call('delete_tasks', { task_ids: [task.id] }));
    const confirm = page.locator('.cm-act--confirm').last();
    await confirm.getByRole('button', { name: 'Подтвердить' }).click();
    await page.waitForFunction(() => [...document.querySelectorAll('.cm-act--confirm')].some((x) => x.innerText.includes('Выполнено')));
    await shot('chat-action-confirmed');
  });

  await t.test('Layer 7 + 8: запись с микрофона уходит в чат как voice input', async () => {
    const before = await page.locator('#home-panel-chat .cm--wisp').count();
    const mic = page.locator('#home-panel-chat .home-mic');
    await mic.click();
    await page.waitForFunction(() => document.querySelector('#home-panel-chat .home-mic')?.getAttribute('aria-label') === 'Остановить запись');
    await mic.click();
    await page.waitForFunction((n) => document.querySelectorAll('#home-panel-chat .cm--wisp').length > n && !document.querySelector('#home-panel-chat.is-generating'), before, { timeout: 15000 });
    assert.ok(await page.locator('.cm-act--record').filter({ hasText: 'Задача голосом' }).count());
    const body = chatBodies.at(-1);
    assert.ok(body && body.client_id && body.input === 'voice');
    const providerRequest = S.provider.requests.filter((x) => x.kind === 'openai').at(-1);
    assert.match(providerRequest.body.messages[0].content, /Пользователь говорит голосом/);
  });

  await t.test('Layers 2–4 на месте: Home, Tools, Chat открываются', async () => {
    await tab('tools');
    await page.waitForSelector('.tl-tile');
    assert.equal(await page.locator('.tl-tile').count(), 4);
    await tab('home');
    await page.waitForSelector('#home-panel-home.is-active');
    await tab('chat');
    await page.waitForSelector('#home-panel-chat textarea');
  });

  await t.test('Layer 13: настройки на телефоне, темы, поиск, плотность и экспорт', async () => {
    await tab('home');
    await page.evaluate((avatar) => window.WispApp.store.update({ avatar }), TEST_AVATAR);
    await page.waitForSelector('.home-avatar-btn .home-avatar img');
    await page.waitForFunction(() => {
      const key = localStorage.getItem('wisp:active-profile:v1') || 'wisp:profile:v1';
      try { return JSON.parse(localStorage.getItem(key) || '{}').user?.avatar?.startsWith('data:image/'); } catch { return false; }
    });
    await page.locator('.home-avatar-btn').click();
    await page.locator('.ds-sheet.is-open').getByRole('button', { name: 'Настройки' }).click();
    await page.waitForSelector('.settings.is-open .st-screen[data-screen="main"].is-current');
    await page.waitForFunction(() => {
      const home = document.querySelector('.home');
      return home?.dataset.settings === 'open' &&
        Number.parseFloat(getComputedStyle(document.querySelector('.home-header')).opacity) < 0.05 &&
        Number.parseFloat(getComputedStyle(document.querySelector('.home-panels')).opacity) < 0.05;
    });

    const search = page.locator('.settings.is-open input[aria-label="Поиск по настройкам"]');
    await search.fill('эффекты');
    await page.waitForSelector('.settings.is-open [data-row="effects"]:not([hidden])');
    assert.equal(await page.locator('.settings.is-open [data-row="chat"][hidden]').count(), 1);
    await search.fill('');

    const settingsScroll = page.locator('.settings.is-open .st-scroll').first();
    const scrollMetrics = await settingsScroll.evaluate((el) => ({
      height: el.clientHeight, content: el.scrollHeight, overflow: getComputedStyle(el).overflowY,
      touchAction: getComputedStyle(el).touchAction,
    }));
    assert.ok(scrollMetrics.content > scrollMetrics.height, 'settings content scrolls in its own viewport');
    assert.equal(scrollMetrics.overflow, 'auto');
    assert.equal(scrollMetrics.touchAction, 'pan-y');
    await page.mouse.wheel(0, 520);
    await page.waitForFunction(() => document.querySelector('.settings.is-open .st-scroll')?.scrollTop > 0);
    await settingsScroll.evaluate((el) => { el.scrollTop = 0; });
    const appearanceButton = page.locator('.settings.is-open [data-row="appearance"]');
    const appearanceBox = await appearanceButton.boundingBox();
    assert.ok(appearanceBox, 'appearance setting is visible for a touch tap');
    assert.equal(await appearanceButton.evaluate((el) => getComputedStyle(el).pointerEvents), 'auto');
    assert.equal(await appearanceButton.evaluate((el) => {
      const box = el.getBoundingClientRect();
      const hit = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
      return !!hit && (el === hit || el.contains(hit));
    }), true, 'settings row receives pointer hit-testing instead of the inactive Home panel');
    await page.touchscreen.tap(appearanceBox.x + appearanceBox.width / 2, appearanceBox.y + appearanceBox.height / 2);
    await page.waitForSelector('.st-screen[data-screen="appearance"].is-current');
    await page.locator('.st-screen[data-screen="appearance"] .st-theme[data-id="black"]').click();
    assert.equal(await page.locator('html').getAttribute('data-theme-preset'), 'black');
    await page.locator('.st-screen[data-screen="appearance"] .st-theme[data-id="midnight"]').click();
    assert.equal(await page.locator('html').getAttribute('data-theme-preset'), 'midnight');
    await page.locator('.st-screen[data-screen="appearance"] button').getByText('Создать свою тему').click();
    await page.locator('.st-editor input[aria-label="Название своей темы"]').fill('Тестовая');
    await page.locator('.st-editor input[aria-label="Фон"]').evaluate((el) => { el.value = '#111827'; el.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.locator('.st-editor').getByRole('button', { name: 'Сохранить тему' }).click();
    assert.equal(await page.locator('html').getAttribute('data-theme-preset'), 'custom');
    await page.waitForFunction(() => {
      const key = localStorage.getItem('wisp:active-profile:v1') || 'wisp:profile:v1';
      try {
        const prefs = JSON.parse(localStorage.getItem(key) || '{}').user?.preferences;
        return prefs?.theme === 'custom' && prefs?.themes?.some((theme) => theme.name === 'Тестовая');
      } catch { return false; }
    });
    assert.ok(await page.locator('.st-screen[data-screen="appearance"] .st-themes--custom .st-theme').count());
    await page.locator('.st-screen[data-screen="appearance"] .tl-bar__btn').click();
    await page.waitForSelector('.st-screen[data-screen="main"].is-current');

    for (const id of ['effects', 'sound', 'chat', 'region']) {
      await page.locator(`.settings.is-open [data-row="${id}"]`).click();
      await page.waitForSelector(`.st-screen[data-screen="${id}"].is-current`);
      await page.waitForTimeout(850);
      assert.ok(await page.locator(`.st-screen[data-screen="${id}"]`).count());
      if (id === 'chat') {
        const overlaps = await page.locator('.st-screen[data-screen="chat"] .st-row').evaluateAll((rows) => rows.some((row) => {
          const label = row.querySelector('.st-row__label')?.getBoundingClientRect();
          const select = row.querySelector('.st-select')?.getBoundingClientRect();
          return label && select && label.right > select.left + 1 && label.left < select.right - 1;
        }));
        assert.equal(overlaps, false, 'Chat setting labels do not overlap their select controls');
        const mascot = await page.locator('.wisp-stage .wisp-actor').boundingBox();
        const slot = await page.locator('.st-screen[data-screen="chat"] .tl-bar__slot').boundingBox();
        assert.ok(mascot && slot);
        assert.ok(Math.abs((mascot.x + mascot.width / 2) - (slot.x + slot.width / 2)) < 8, 'mascot stays anchored in the visible toolbar slot after the screen transition');
      }
      await page.locator(`.st-screen[data-screen="${id}"] .tl-bar__btn`).click();
      await page.waitForSelector('.st-screen[data-screen="main"].is-current');
    }

    await page.locator('.settings.is-open [data-row="interface"]').click();
    await page.waitForSelector('.st-screen[data-screen="interface"].is-current');
    await page.locator('.st-screen[data-screen="interface"] .tl-seg[aria-label="Плотность интерфейса"] [data-id="compact"]').click();
    assert.equal(await page.locator('html').getAttribute('data-density'), 'compact');
    await page.locator('.st-screen[data-screen="interface"] .tl-seg[aria-label="Положение панели"] [data-id="side"]').click();
    assert.equal(await page.locator('html').getAttribute('data-nav'), 'side');
    await page.locator('.st-screen[data-screen="interface"] .tl-bar__btn').click();
    await page.waitForSelector('.st-screen[data-screen="main"].is-current');

    await page.locator('.settings.is-open [data-row="data"]').click();
    await page.waitForSelector('.st-screen[data-screen="data"].is-current');
    const downloadPromise = page.waitForEvent('download');
    await page.locator('.st-screen[data-screen="data"]').getByRole('button', { name: 'Скачать архив данных' }).click();
    const download = await downloadPromise;
    assert.match(download.suggestedFilename(), /^wisp-export-.*\\.json$/);
    await shot('settings-data-mobile');
    await page.locator('.st-screen[data-screen="data"] .tl-bar__btn').click();
    await page.waitForSelector('.st-screen[data-screen="main"].is-current');
    await page.locator('.st-screen[data-screen="main"] .tl-bar__btn').click();
    await page.waitForTimeout(450);
    assert.equal(await page.locator('.home-avatar-btn .home-avatar img').count(), 1, 'small Home avatar displays the saved profile photo');
  });

  await t.test('десктоп', async () => {
    await page.setViewportSize({ width: 1280, height: 820 });
    await tab('memory');
    await page.waitForTimeout(500);
    assert.equal(await page.locator('html').getAttribute('data-nav'), 'side');
    assert.equal(await page.locator('.home-nav').evaluate((el) => getComputedStyle(el).position), 'absolute');
    await shot('desktop-memory');
  });

  assert.deepEqual(errors, [], 'без ошибок в консоли');
});
