'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadAssistant(fetchImpl) {
  const App = { core: { Profile: {} } };
  const window = { WispApp: App };
  const context = {
    window,
    location: { href: 'https://wisp.test/', origin: 'https://wisp.test' },
    navigator: { onLine: true },
    URL,
    fetch: fetchImpl,
    Response,
    ReadableStream,
    TextDecoder,
    AbortController,
    setTimeout,
    clearTimeout,
  };
  const source = fs.readFileSync(path.join(__dirname, '../src/core/assistant.js'), 'utf8');
  vm.runInNewContext(source, context, { filename: 'assistant.js' });
  return App.core.Assistant.AssistantClient;
}

test('accepted event stream without start is ambiguous, not safe to retry', async () => {
  const Client = loadAssistant(async () => new Response(
    new ReadableStream({ start(controller) { controller.close(); } }),
    { status: 200, headers: { 'Content-Type': 'text/event-stream; charset=utf-8' } },
  ));
  const client = new Client({ endpoint: '/api' });
  const result = await client.stream('/conversations/new/messages', { content: 'hello' });
  assert.equal(result.phase, 'interrupted');
  assert.equal(result.accepted, true);
  assert.equal(result.started, false);
  assert.equal(result.error.code, 'request_ambiguous');
});

test('network failure before an HTTP response remains unsent', async () => {
  const Client = loadAssistant(async () => { throw new Error('connection refused'); });
  const client = new Client({ endpoint: '/api' });
  const result = await client.stream('/conversations/new/messages', { content: 'hello' });
  assert.equal(result.phase, 'unsent');
  assert.equal(result.error.code, 'network');
});
