'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const PrefSchema = require('../src/core/preferences-schema.js');

function loadEngine() {
  const attrs = new Map();
  const vars = new Map();
  const makeMeta = () => ({ values: {}, setAttribute(k, v) { this.values[k] = v; } });
  const metas = {
    'meta[name="theme-color"]': makeMeta(),
    'meta[name="color-scheme"]': makeMeta(),
  };
  const document = {
    documentElement: {
      style: {
        setProperty: (k, v) => vars.set(k, v),
        removeProperty: (k) => vars.delete(k),
      },
      setAttribute: (k, v) => attrs.set(k, v),
      getAttribute: (k) => attrs.get(k) || null,
    },
    querySelector: (selector) => metas[selector] || null,
  };
  const window = { document };
  const context = { window, document, globalThis: window };
  const source = fs.readFileSync(path.join(__dirname, '../src/settings/theme-engine.js'), 'utf8');
  vm.runInNewContext(source, context, { filename: 'theme-engine.js' });
  return { engine: window.WispThemeEngine, attrs, vars, metas };
}

test('default dark leaves the original design tokens alone', () => {
  const { engine, attrs, vars } = loadEngine();
  const p = PrefSchema.defaults();
  const state = engine.apply(p, 'dark');
  assert.equal(state.active, false);
  assert.equal(attrs.get('data-theme'), 'dark');
  assert.equal(attrs.get('data-theme-preset'), 'dark');
  assert.equal(vars.size, 0);
});

test('built-in black and system light resolve to their own palettes', () => {
  const { engine } = loadEngine();
  const p = PrefSchema.defaults();
  assert.equal(engine.resolvePalette({ ...p, theme: 'black' }, 'dark').bg, '#000000');
  const system = engine.resolvePalette({ ...p, theme: 'system' }, 'light');
  assert.equal(system.preset, 'light');
  assert.equal(system.mode, 'light');
});

test('custom palettes retain four color roles and use the background for contrast mode', () => {
  const oldShape = PrefSchema.sanitizeTheme({
    id: 'soft1', name: 'Soft', bg: '#f6f4ff', accent: '#6252e0', tint: '#bdb6ff', glow: '#6c5ceb',
  });
  assert.deepEqual(oldShape && {
    bg: oldShape.bg, primary: oldShape.primary, secondary: oldShape.secondary,
    accent: oldShape.accent, glow: oldShape.glow,
  }, {
    bg: '#f6f4ff', primary: '#6252e0', secondary: '#bdb6ff',
    accent: '#6252e0', glow: '#6c5ceb',
  });
  const { engine } = loadEngine();
  const p = PrefSchema.sanitize({
    ...PrefSchema.defaults(),
    theme: 'custom',
    theme_custom: 'soft1',
    themes: [oldShape],
  });
  const state = engine.resolvePalette(p, 'dark');
  assert.equal(state.preset, 'custom');
  assert.equal(state.mode, 'light');
  assert.equal(state.primary, '#6252e0');
});

test('appearance controls reach runtime variables, including glow strength', () => {
  const { engine, vars, attrs } = loadEngine();
  const p = PrefSchema.defaults();
  engine.apply({ ...p, theme: 'midnight', glass: 70, radius: 125, fx_glow: 50 }, 'dark');
  assert.equal(attrs.get('data-theme-preset'), 'midnight');
  assert.equal(vars.get('--wisp-bg'), '#080b1c');
  assert.equal(vars.get('--wisp-rk'), '1.25');
  assert.equal(vars.get('--wisp-theme-glow-a040'), '0.200');
  assert.equal(vars.get('--wisp-glass'), 'rgba(240, 238, 255, 0.035)');
  engine.apply({ ...p, theme: 'light' }, 'dark');
  assert.equal(vars.get('--wisp-glass'), 'rgba(255, 255, 255, 0.640)');
  engine.apply(p, 'dark');
  assert.equal(vars.size, 0);
});

test('stage 3: custom mode follows text contrast, colors are pulled to readable contrast', () => {
  const { engine } = loadEngine();
  const mk = (bg, primary) => PrefSchema.sanitize({ ...PrefSchema.defaults(), theme: 'custom', theme_custom: 'grey1', themes: [{ id: 'grey1', bg, primary, accent: primary }] });
  for (const bg of ['#9a9a9a', '#b0b0b0']) {
    const st = engine.resolvePalette(mk(bg, '#5a4bd4'), 'dark');
    assert.equal(st.mode, 'light', bg);
    assert.ok(st.contrast.text >= 4.5, bg);
  }
  const y = engine.resolvePalette(mk('#ffffff', '#ffff00'), 'dark');
  assert.ok(y.contrast.primary >= 4.5);
  assert.ok(y.contrast.accent >= 3);
  assert.equal(y.adjusted.primary, true);
});

test('stage 3: radius, blur and speed work on the default dark theme too', () => {
  const { engine, vars, attrs } = loadEngine();
  const p = PrefSchema.defaults();
  engine.apply({ ...p, radius: 60, fx_blur: 0, fx_speed: 'slow' }, 'dark');
  assert.equal(attrs.get('data-theme-preset'), 'dark');
  assert.equal(vars.get('--wisp-rk'), '0.6');
  assert.equal(vars.get('--wisp-bk'), '0');
  assert.equal(vars.get('--wisp-tk'), '1.5');
  engine.apply({ ...p, glass: 80 }, 'dark');
  assert.equal(attrs.get('data-theme-preset'), 'custom');
  engine.apply(p, 'dark');
  assert.equal(vars.size, 0);
});

test('section reset groups keep interface density out of appearance', () => {
  const defaults = PrefSchema.defaults();
  const custom = { ...defaults, density: 'comfortable' };
  const afterAppearanceReset = { ...custom, ...PrefSchema.groupDefaults('appearance') };
  const afterInterfaceReset = { ...custom, ...PrefSchema.groupDefaults('interface') };
  assert.equal(afterAppearanceReset.density, 'comfortable');
  assert.equal(afterInterfaceReset.density, defaults.density);
});
