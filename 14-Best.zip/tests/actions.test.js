/* WISP · Tests · Layer 8 AI Actions (node --test): уточнения, подтверждение удаления, повторы, поиск, изоляция */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startStack, client } = require('./helpers');
const T = require('../server/tools/time');
const D = require('../server/actions/dates');
const TZ = 'Europe/Moscow';
const call = (n, a) => `[[call:${n} ${JSON.stringify(a)}]]`;
async function session(S) { const c = client(S.base); const r = await c.json('POST', '/api/session', { timezone: TZ }); return { c, id: r.data.user.id }; }
async function say(who, content, conv) { const r = await who.c.stream(`/api/conversations/${conv || 'new'}/messages`, { timezone: TZ, content }); return { ...r, conv: r.events[0] && r.events[0].data.conversation && r.events[0].data.conversation.id, actions: r.events.filter((e) => e.event === 'tool').map((e) => e.data.action), text: r.events.filter((e) => e.event === 'delta').map((e) => e.data.text).join('') }; }

test('Layer 8 · даты', () => {
  const now = Date.UTC(2026, 10, 8, 16, 10);
  assert.deepEqual([D.resolve('завтра в 10 утра', TZ, now).date, D.resolve('завтра в 10 утра', TZ, now).time], ['2026-11-09', '10:00']);
  assert.equal(D.resolve('послезавтра', TZ, now).date, '2026-11-10');
  assert.equal(D.resolve('через неделю', TZ, now).date, '2026-11-15');
  assert.equal(D.resolve('в пятницу', TZ, now).date, '2026-11-13');
  assert.ok(D.resolve('в воскресенье', TZ, now).ambiguous, 'сегодня воскресенье — спросить');
  assert.ok(D.resolve('завтра в 7', TZ, now).ambiguous, '7 утра или вечера');
});

test('Layer 8 · действия AI', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const A = await session(S), B = await session(S);
  const tomorrow = T.addDays(T.todayIn(TZ), 1);

  await t.test('«напомни завтра в 10 купить продукты» — сервер сам разбирает when', async () => {
    const r = await say(A, call('create_reminder', { title: 'Купить продукты', when: 'завтра в 10' }));
    assert.equal(r.actions[0].status, 'ok'); assert.equal(r.actions[0].date, tomorrow); assert.equal(r.actions[0].time, '10:00');
    assert.ok(r.actions[0].live && r.actions[0].live.title === 'Купить продукты', 'карточка связана с записью');
  });
  await t.test('не хватает данных → вопрос, ничего не создано', async () => {
    const r = await say(A, call('create_reminder', { when: 'завтра' }));
    assert.equal(r.actions.length, 0); assert.match(r.text, /needs_clarification/);
    const r2 = await say(A, call('create_task', { title: 'Подготовиться' }));
    assert.match(r2.text, /К чему подготовиться/);
    assert.equal((await A.c.json('GET', '/api/reminders')).data.reminders.length, 1);
  });
  let taskId, pending, conv;
  await t.test('удаление: карточка подтверждения, «да» модели без пользователя не срабатывает, кнопка — один раз', async () => {
    taskId = (await say(A, call('create_task', { title: 'Старое дело' }))).actions[0].record_id;
    const r = await say(A, call('delete_tasks', { task_ids: [taskId] }));
    conv = r.conv; pending = r.actions[0];
    assert.equal(pending.kind, 'confirm'); assert.equal(pending.op, 'pending');
    assert.ok((await A.c.json('GET', `/api/tasks/${taskId}`)).status === 200, 'ещё не удалено');
    assert.equal((await B.c.json('POST', `/api/actions/${pending.pending_id}/confirm`, {})).status, 404, 'чужой не подтвердит');
    const no = await say(A, 'Хм, подожди ' + call('confirm_action', { ref: pending.ref }), conv);
    assert.equal(no.actions[0].status, 'error', 'без явного «да» не выполняется');
    const c1 = await A.c.json('POST', `/api/actions/${pending.pending_id}/confirm`, {});
    const c2 = await A.c.json('POST', `/api/actions/${pending.pending_id}/confirm`, {});
    assert.equal(c1.status, 200); assert.equal(c1.data.action.status, 'done'); assert.equal(c2.data.replayed, true);
    assert.equal((await A.c.json('GET', `/api/tasks/${taskId}`)).status, 404);
  });
  await t.test('подтверждение голосом/текстом «да» в следующем сообщении', async () => {
    const id = (await say(A, call('create_note', { content: 'черновик' }))).actions[0].record_id;
    const r = await say(A, call('delete_notes', { note_ids: [id] }));
    const ok = await say(A, 'да ' + call('confirm_action', { ref: r.actions[0].ref }), r.conv);
    assert.equal(ok.actions[0].status, 'ok'); assert.equal(ok.actions[0].op, 'done');
  });
  await t.test('повтор того же создания не дублирует запись', async () => {
    await say(A, call('create_task', { title: 'Один раз' }));
    const r = await say(A, call('create_task', { title: 'Один раз' }));
    assert.equal(r.actions[0].deduplicated, true);
    assert.equal((await A.c.json('GET', '/api/tasks')).data.tasks.filter((x) => x.title === 'Один раз').length, 1);
  });
  await t.test('повторная отправка сообщения с тем же client_id — 409', async () => {
    const body = { timezone: TZ, content: 'привет', client_id: 'k_' + Date.now() };
    await A.c.stream('/api/conversations/new/messages', body);
    const r = await A.c.stream('/api/conversations/new/messages', body);
    assert.equal(r.status, 409);
  });
  await t.test('live-записи доступны только владельцу и обновляются после правки', async () => {
    const made = await say(A, call('create_task', { title: 'Live карточка' }));
    const id = made.actions[0].record_id;
    const before = await A.c.json('POST', '/api/actions/records', { refs: [{ kind: 'task', id }] });
    assert.equal(before.status, 200);
    assert.equal(before.data.records[`task:${id}`].title, 'Live карточка');
    await A.c.json('PATCH', `/api/tasks/${id}`, { title: 'Обновлённая карточка' });
    const after = await A.c.json('POST', '/api/actions/records', { refs: [{ kind: 'task', id }] });
    assert.equal(after.data.records[`task:${id}`].title, 'Обновлённая карточка');
    const other = await B.c.json('POST', '/api/actions/records', { refs: [{ kind: 'task', id }] });
    assert.equal(other.data.records[`task:${id}`], null);
  });
  await t.test('отмена pending-действия идемпотентна и ничего не удаляет', async () => {
    const note = (await say(A, call('create_note', { content: 'Оставить после отмены' }))).actions[0];
    const proposed = await say(A, call('delete_notes', { note_ids: [note.record_id] }));
    const pendingId = proposed.actions[0].pending_id;
    const first = await A.c.json('POST', `/api/actions/${pendingId}/cancel`, {});
    const replay = await A.c.json('POST', `/api/actions/${pendingId}/cancel`, {});
    assert.equal(first.data.action.status, 'cancelled');
    assert.equal(replay.data.replayed, true);
    assert.equal((await A.c.json('GET', `/api/notes/${note.record_id}`)).status, 200);
  });
  await t.test('голосовой режим передаётся в контекст действий', async () => {
    const r = await A.c.stream('/api/conversations/new/messages', {
      timezone: TZ, content: 'Привет', input: 'voice', client_id: 'voice_' + Date.now(),
    });
    assert.equal(r.status, 200);
    const req = S.provider.requests.filter((x) => x.kind === 'openai').at(-1);
    assert.match(req.body.messages[0].content, /Пользователь говорит голосом/);
  });
  await t.test('поиск: «идеи для игр» находит заметку; чужие данные не видны', async () => {
    await say(A, call('create_note', { content: 'Сделать собственную игру' }));
    const r = await say(A, call('search_everything', { query: 'идеи для игр' }));
    assert.ok(r.actions[0].count >= 1);
    const rb = await say(B, call('search_everything', { query: 'игр' }));
    assert.equal(rb.actions[0].count, 0, 'изоляция пользователей');
  });
  await t.test('очистка истории удаляет привязанные вызовы инструментов и неподтверждённые действия', async () => {
    const made = await say(A, call('create_note', { content: 'Останется после очистки истории' }));
    const noteId = made.actions[0].record_id;
    const callId = made.actions[0].id;
    const pending = await say(A, call('delete_notes', { note_ids: [noteId] }), made.conv);
    const pendingId = pending.actions[0].pending_id;
    const store = S.app.store;
    const writesBefore = store.db.prepare("SELECT COUNT(*) AS n FROM tool_calls WHERE user_id = ? AND status = 'ok' AND write = 1").get(A.id).n;
    const linkedCalls = store.db.prepare(`SELECT COUNT(*) AS n FROM tool_calls
      WHERE user_id = ? AND message_id IN (
        SELECT m.id FROM messages m JOIN conversations c ON c.id = m.conversation_id WHERE c.user_id = ?
      )`).get(A.id, A.id).n;
    assert.ok(linkedCalls > 0);
    assert.ok(store.db.prepare("SELECT 1 FROM pending_actions WHERE id = ? AND status = 'pending'").get(pendingId));

    const reset = await A.c.json('POST', '/api/account/reset', { section: 'conversations', confirm: 'reset' });
    assert.equal(reset.status, 200);
    assert.equal((await A.c.json('POST', `/api/actions/${pendingId}/confirm`, {})).status, 404);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM tool_calls WHERE user_id = ? AND message_id IS NOT NULL').get(A.id).n, 0);
    assert.equal(store.db.prepare("SELECT COUNT(*) AS n FROM tool_calls WHERE user_id = ? AND status = 'ok' AND write = 1").get(A.id).n, writesBefore);
    const redacted = store.db.prepare('SELECT message_id, args, result FROM tool_calls WHERE id = ?').get(callId);
    assert.equal(redacted.message_id, null);
    assert.equal(redacted.args, '{}');
    assert.doesNotMatch(redacted.result, /Останется после очистки истории/);
    assert.equal(store.db.prepare('SELECT 1 FROM pending_actions WHERE id = ?').get(pendingId), undefined);
    assert.equal((await A.c.json('GET', `/api/notes/${noteId}`)).status, 200, 'запись инструмента не удаляется');
    assert.equal((await A.c.json('GET', '/api/conversations')).data.conversations.length, 0);
  });
  await t.test('неизвестный раздел сброса всегда даёт bad_section', async () => {
    for (const section of ['__proto__', 'constructor', 'toString', 'unknown']) {
      const result = await A.c.json('POST', '/api/account/reset', { section, confirm: 'reset' });
      assert.equal(result.status, 400, section);
      assert.equal(result.data.error.code, 'bad_section', section);
    }
  });
});

test('pending action confirmation respects the daily write quota', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  S.config.plans.free.actions = { writes_per_day: 1, confirm_ttl_minutes: 30 };
  const A = await session(S);
  const note = await A.c.json('POST', '/api/notes', { title: 'Квота', content: 'Оставить до подтверждения' });
  const pending = await say(A, call('delete_notes', { note_ids: [note.data.note.id] }));
  assert.equal(pending.actions[0].op, 'pending');
  const created = await say(A, call('create_task', { title: 'Единственная разрешённая запись' }));
  assert.equal(created.actions[0].status, 'ok');
  const confirm = await A.c.json('POST', `/api/actions/${pending.actions[0].pending_id}/confirm`, {});
  assert.equal(confirm.status, 429);
  assert.equal(confirm.data.error.code, 'limit_actions');
  assert.equal((await A.c.json('GET', `/api/notes/${note.data.note.id}`)).status, 200);
});

test('chat-history clear confirmation reports the exact count above 1,000', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const A = await session(S);
  const store = S.app.store;
  const insertConversation = store.db.prepare(`INSERT INTO conversations
    (id, user_id, title, title_source, model, created_at, updated_at)
    VALUES (?, ?, ?, 'user', NULL, ?, ?)`);
  const insertMessage = store.db.prepare(`INSERT INTO messages
    (id, conversation_id, seq, role, content, status, error_code, model, created_at, updated_at)
    VALUES (?, ?, 1, 'user', '', 'complete', NULL, NULL, ?, ?)`);
  const now = Date.now();
  store.transaction(() => {
    for (let i = 0; i < 1000; i++) {
      const id = `count-conv-${i}`, at = now + i;
      insertConversation.run(id, A.id, 'Диалог', at, at);
      insertMessage.run(`count-msg-${i}`, id, at, at);
    }
  });
  const result = await say(A, call('clear_chat_history', {}));
  assert.equal(result.actions[0].count, 1001);
});
