/* WISP · Tests · Server (node --test)
 * Проверяет настоящий серверный код: сессии, изоляцию пользователей, потоковую генерацию,
 * историю, правку/повтор/удаление, лимиты Free/Plus, ошибки провайдера, отсутствие ключей в ответах. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { startStack, client, text } = require('./helpers');

const PROFILE = { name: 'Гера', interests: ['music', 'design', 'evil'], occupation: 'work', about: 'Делаю синтезаторы', personality: 'humor', permissions: { secret: 1 } };

test('WISP server', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const a = client(S.base);
  const b = client(S.base);

  await t.test('без сессии защищённые endpoint\'ы закрыты', async () => {
    const r = await a.json('GET', '/api/conversations');
    assert.equal(r.status, 401);
    const r2 = await a.json('GET', '/api/session');
    assert.equal(r2.status, 401);
  });

  await t.test('изменяющие запросы без заголовка клиента или с чужого Origin отклоняются', async () => {
    const r = await fetch(S.base + '/api/session', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    assert.equal(r.status, 403);
    const r2 = await a.json('POST', '/api/session', {}, { headers: { Origin: 'https://evil.example' } });
    assert.equal(r2.status, 403);
  });

  await t.test('сессия создаётся, cookie HttpOnly, ключей в ответе нет', async () => {
    const r = await a.json('POST', '/api/session', {});
    assert.equal(r.status, 200);
    const set = r.res.headers.get('set-cookie');
    assert.match(set, /wisp_sid=/);
    assert.match(set, /HttpOnly/);
    assert.match(set, /SameSite=Lax/);
    assert.equal(r.data.user.plan, 'free');
    assert.equal(r.data.default_model, 'fast');
    const raw = JSON.stringify(r.data);
    assert.ok(!raw.includes('sk-test'), 'ключ не должен попадать в ответ');
    assert.ok(!raw.includes('127.0.0.1'), 'адрес провайдера не должен попадать в ответ');
    assert.ok(!raw.includes('test-fast'), 'имя модели провайдера не должно попадать в ответ');
    const ghost = r.data.models.find((m) => m.id === 'ghost');
    assert.equal(ghost.available, false);
    const smart = r.data.models.find((m) => m.id === 'smart');
    assert.equal(smart.allowed, false);
    await b.json('POST', '/api/session', {});
    assert.notEqual(a.cookie, b.cookie);
  });

  let convId;
  await t.test('сообщение → настоящий поток: start, несколько delta, done', async () => {
    const r = await a.stream('/api/conversations/new/messages', { content: '  Привет, WISP!  ', profile: PROFILE });
    assert.equal(r.status, 200);
    const names = r.events.map((e) => e.event);
    assert.equal(names[0], 'start');
    assert.equal(names[names.length - 1], 'done');
    assert.ok(names.filter((n) => n === 'delta').length >= 4, 'ответ должен прийти несколькими частями');
    assert.equal(text(r.events), 'Привет! Это **потоковый** ответ WISP.\n\n```js\nconst a = 1;\n```');
    const start = r.events[0].data;
    assert.equal(start.user_message.content, 'Привет, WISP!');
    assert.equal(start.conversation.title, 'Привет, WISP!');
    convId = start.conversation.id;
    const done = r.events[r.events.length - 1].data;
    assert.equal(done.message.status, 'complete');
    assert.equal(done.usage.used, 1);
    // что ушло провайдеру
    const sent = S.provider.requests[S.provider.requests.length - 1];
    assert.equal(sent.kind, 'openai');
    assert.equal(sent.body.stream, true);
    assert.equal(sent.body.model, 'test-fast');
    assert.equal(sent.body.max_completion_tokens, 400, 'лимит вывода по тарифу Free');
    assert.match(sent.headers.authorization, /^Bearer sk-test/);
    const sys = sent.body.messages[0];
    assert.equal(sys.role, 'system');
    assert.match(sys.content, /Имя: Гера/);
    assert.match(sys.content, /с чувством юмора/);
    assert.match(sys.content, /музыка, дизайн/);
    assert.ok(!sys.content.includes('evil'), 'неизвестные интересы отбрасываются');
    assert.ok(!sys.content.includes('secret'), 'служебные поля профиля в модель не уходят');
    assert.match(sys.content, /не человек/);
  });

  await t.test('поток действительно идёт частями во времени (не одним куском)', async () => {
    const r = await a.stream(`/api/conversations/${convId}/messages`, { content: 'Ещё раз [[slow]]', profile: PROFILE });
    const deltas = r.events.filter((e) => e.event === 'delta');
    assert.ok(deltas.length >= 4);
    const spread = deltas[deltas.length - 1].at - deltas[0].at;
    assert.ok(spread > 600, `части пришли с интервалами (${spread} мс)`);
  });

  await t.test('история передаётся модели и сохраняется', async () => {
    const sent = S.provider.requests[S.provider.requests.length - 1].body.messages;
    assert.deepEqual(sent.slice(1).map((m) => m.role), ['user', 'assistant', 'user']);
    const r = await a.json('GET', `/api/conversations/${convId}`);
    assert.equal(r.status, 200);
    assert.equal(r.data.messages.length, 4);
    assert.deepEqual(r.data.messages.map((m) => m.role), ['user', 'assistant', 'user', 'assistant']);
    assert.ok(r.data.messages.every((m) => m.status === 'complete'));
  });

  await t.test('чужой диалог недоступен (404), нельзя писать, удалять и смотреть вложения', async () => {
    assert.equal((await b.json('GET', `/api/conversations/${convId}`)).status, 404);
    assert.equal((await b.json('DELETE', `/api/conversations/${convId}`)).status, 404);
    assert.equal((await b.json('PATCH', `/api/conversations/${convId}`, { title: 'взлом' })).status, 404);
    const s = await b.stream(`/api/conversations/${convId}/messages`, { content: 'hi' });
    assert.equal(s.status, 404);
    const list = await b.json('GET', '/api/conversations');
    assert.equal(list.data.conversations.length, 0);
  });

  await t.test('повтор генерации заменяет последний ответ', async () => {
    const r = await a.stream(`/api/conversations/${convId}/regenerate`, { profile: PROFILE });
    assert.equal(r.events[r.events.length - 1].event, 'done');
    const conv = await a.json('GET', `/api/conversations/${convId}`);
    assert.equal(conv.data.messages.length, 4);
  });

  await t.test('правка последнего сообщения пересоздаёт ответ; не последнее — нельзя', async () => {
    const conv = await a.json('GET', `/api/conversations/${convId}`);
    const users = conv.data.messages.filter((m) => m.role === 'user');
    const first = users[0], last = users[users.length - 1];
    const bad = await a.stream(`/api/conversations/${convId}/messages/${first.id}/edit`, { content: 'x' });
    assert.equal(bad.status, 409);
    const ok = await a.stream(`/api/conversations/${convId}/messages/${last.id}/edit`, { content: 'Исправленный вопрос', profile: PROFILE });
    assert.equal(ok.events[0].data.user_message.content, 'Исправленный вопрос');
    assert.equal(ok.events[ok.events.length - 1].event, 'done');
    const after = await a.json('GET', `/api/conversations/${convId}`);
    assert.equal(after.data.messages.length, 4);
    assert.equal(after.data.messages[2].content, 'Исправленный вопрос');
  });

  await t.test('удаление сообщения пользователя удаляет и ответ на него', async () => {
    const conv = await a.json('GET', `/api/conversations/${convId}`);
    const lastUser = conv.data.messages[2];
    const r = await a.json('DELETE', `/api/conversations/${convId}/messages/${lastUser.id}`);
    assert.equal(r.status, 200);
    assert.equal(r.data.deleted.length, 2);
    assert.equal(r.data.remaining, 2);
  });

  await t.test('переименование, сортировка по активности, удаление диалога', async () => {
    const r2 = await a.stream('/api/conversations/new/messages', { content: 'Второй диалог про очень длинное название, которое точно не поместится в заголовок целиком', profile: PROFILE });
    const id2 = r2.events[0].data.conversation.id;
    assert.match(r2.events[0].data.conversation.title, /…$/);
    let list = await a.json('GET', '/api/conversations');
    assert.deepEqual(list.data.conversations.map((c) => c.id), [id2, convId]);
    await a.stream(`/api/conversations/${convId}/messages`, { content: 'Поднимаю первый наверх' });
    list = await a.json('GET', '/api/conversations');
    assert.equal(list.data.conversations[0].id, convId);
    const rn = await a.json('PATCH', `/api/conversations/${convId}`, { title: '  Мой   диалог  ' });
    assert.equal(rn.data.conversation.title, 'Мой диалог');
    assert.equal((await a.json('PATCH', `/api/conversations/${convId}`, { title: '   ' })).status, 400);
    assert.equal((await a.json('DELETE', `/api/conversations/${id2}`)).status, 200);
    assert.equal((await a.json('GET', `/api/conversations/${id2}`)).status, 404);
  });

  await t.test('Plus-модель недоступна на Free: нельзя выбрать и нельзя отправить', async () => {
    assert.equal((await a.json('PATCH', `/api/conversations/${convId}`, { model: 'smart' })).status, 403);
    const r = await a.stream(`/api/conversations/${convId}/messages`, { content: 'hi', model: 'smart' });
    assert.equal(r.status, 403);
    assert.equal(r.error.error.code, 'plan_required');
    // клиент может прислать что угодно про тариф: сервер это игнорирует
    const r2 = await a.stream(`/api/conversations/${convId}/messages`, { content: 'hi', model: 'smart', plan: 'plus', profile: { ...PROFILE, plan: 'plus' } });
    assert.equal(r2.status, 403);
  });

  await t.test('после выдачи Plus на сервере модель становится доступной (Anthropic, поток)', async () => {
    const me = await a.json('GET', '/api/session');
    S.app.store.setPlan(me.data.user.id, 'plus');
    const s2 = await a.json('GET', '/api/session');
    assert.equal(s2.data.user.plan, 'plus');
    assert.equal(s2.data.models.find((m) => m.id === 'smart').allowed, true);
    const r = await a.stream(`/api/conversations/${convId}/messages`, { content: 'Теперь Plus', model: 'smart', profile: PROFILE });
    assert.equal(r.events[r.events.length - 1].event, 'done');
    assert.equal(text(r.events).startsWith('Привет! Это'), true);
    const sent = S.provider.requests[S.provider.requests.length - 1];
    assert.equal(sent.kind, 'anthropic');
    assert.equal(sent.body.max_tokens, 800, 'лимит вывода по тарифу Plus');
    assert.match(sent.body.system, /Гера/);
    assert.equal(sent.body.messages[0].role, 'user');
    assert.equal(sent.headers['anthropic-version'], '2023-06-01');
    S.app.store.setPlan(me.data.user.id, 'free');
  });

  await t.test('модель без ключа → model_unavailable', async () => {
    const r = await a.stream(`/api/conversations/${convId}/messages`, { content: 'hi', model: 'ghost' });
    assert.equal(r.status, 503);
    assert.equal(r.error.error.code, 'model_unavailable');
  });

  await t.test('ошибки провайдера: понятный код, сообщение пользователя сохранено, лимит возвращён', async () => {
    const before = (await a.json('GET', '/api/session')).data.usage.used;
    const cases = [['[[http500]]', 'provider_error'], ['[[http404]]', 'model_unavailable'], ['[[http401]]', 'provider_auth'], ['[[http429]]', 'provider_rate_limited'], ['[[empty]]', 'empty_reply']];
    for (const [marker, code] of cases) {
      const r = await a.stream(`/api/conversations/${convId}/messages`, { content: `Проверка ${marker}` });
      const last = r.events[r.events.length - 1];
      assert.equal(last.event, 'error', marker);
      assert.equal(last.data.code, code, marker);
      assert.ok(!JSON.stringify(last.data).includes('sk-'), 'ключ не утекает в ошибку');
      assert.equal(r.events[0].data.user_message.content, `Проверка ${marker}`);
    }
    const after = (await a.json('GET', '/api/session')).data.usage.used;
    assert.equal(after, before, 'неудачные запросы без ответа не списываются с лимита');
    const conv = await a.json('GET', `/api/conversations/${convId}`);
    const lastMsgs = conv.data.messages.slice(-2);
    assert.equal(lastMsgs[0].role, 'user');
    assert.ok(['error', 'empty'].includes(lastMsgs[1].status));
  });

  await t.test('ошибка посреди потока: частичный ответ сохраняется как прерванный', async () => {
    const r = await a.stream(`/api/conversations/${convId}/messages`, { content: 'Середина [[midError]]' });
    const last = r.events[r.events.length - 1];
    assert.equal(last.event, 'error');
    assert.equal(last.data.code, 'provider_busy');
    assert.equal(last.data.message_saved.status, 'interrupted');
    assert.equal(last.data.message_saved.content, 'Привет! Это ');
  });

  await t.test('обрыв соединения провайдера → ошибка, а не зависание', async () => {
    const r = await a.stream(`/api/conversations/${convId}/messages`, { content: 'Обрыв [[drop]]' });
    const last = r.events[r.events.length - 1];
    assert.equal(last.event, 'error');
    assert.equal(last.data.retryable, true);
  });

  await t.test('клиент остановил ответ: сервер отменяет запрос и сохраняет частичный текст', async () => {
    const ctrl = new AbortController();
    let deltas = 0;
    await a.stream(`/api/conversations/${convId}/messages`, { content: 'Длинный [[slow]]' }, {
      signal: ctrl.signal, expectAbort: true,
      onEvent: (e) => { if (e.event === 'delta' && ++deltas === 2) ctrl.abort(); },
    }).catch(() => null);
    await new Promise((r) => setTimeout(r, 400));
    const conv = await a.json('GET', `/api/conversations/${convId}`);
    const last = conv.data.messages[conv.data.messages.length - 1];
    assert.equal(last.role, 'assistant');
    assert.equal(last.status, 'interrupted');
    assert.ok(last.content.length > 0 && last.content.length < 30, `частичный ответ: «${last.content}»`);
    assert.equal(conv.data.generating, false);
  });

  await t.test('изображения: сигнатура проверяется, модель без зрения отказывает, вложение доступно только владельцу', async () => {
    const png = 'data:image/png;base64,' + Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8ffff3f0005fe02fea7d6a5d20000000049454e44ae426082', 'hex').toString('base64');
    const fakeImg = 'data:image/png;base64,' + Buffer.from('<script>alert(1)</script>').toString('base64');
    const bad = await a.stream('/api/conversations/new/messages', { content: '', attachments: [{ data: fakeImg }] });
    assert.equal(bad.status, 415);
    const blind = await a.stream('/api/conversations/new/messages', { content: 'что тут?', model: 'blind', attachments: [{ data: png }] });
    assert.equal(blind.status, 422);
    assert.equal(blind.error.error.code, 'model_no_vision');
    const many = await a.stream('/api/conversations/new/messages', { content: 'x', attachments: [{ data: png }, { data: png }, { data: png }] });
    assert.equal(many.status, 413);
    const ok = await a.stream('/api/conversations/new/messages', { content: '', attachments: [{ data: png, width: 1, height: 1 }] });
    const start = ok.events[0].data;
    assert.equal(start.conversation.title, 'Изображение');
    const att = start.user_message.attachments[0];
    assert.equal(att.mime, 'image/png');
    const sent = S.provider.requests[S.provider.requests.length - 1].body.messages;
    const lastUser = sent[sent.length - 1];
    assert.equal(lastUser.content[0].type, 'image_url');
    assert.match(lastUser.content[0].image_url.url, /^data:image\/png;base64,/);
    const own = await a.req('GET', att.url);
    assert.equal(own.status, 200);
    assert.equal(own.headers.get('content-type'), 'image/png');
    const other = await b.req('GET', att.url);
    assert.equal(other.status, 404);
  });

  await t.test('слишком длинное и пустое сообщение отклоняются', async () => {
    const long = await a.stream('/api/conversations/new/messages', { content: 'я'.repeat(2001) });
    assert.equal(long.status, 413);
    assert.equal(long.error.error.code, 'too_long');
    const empty = await a.stream('/api/conversations/new/messages', { content: '   ' });
    assert.equal(empty.status, 400);
  });

  await t.test('длинный диалог: контекст ограничен бюджетом тарифа, последнее сообщение всегда в нём', async () => {
    const r = await a.stream('/api/conversations/new/messages', { content: 'Старт длинного' });
    const id = r.events[0].data.conversation.id;
    for (let i = 0; i < 12; i++) await a.stream(`/api/conversations/${id}/messages`, { content: `Сообщение ${i} ` + 'слово '.repeat(150) });
    const last = await a.stream(`/api/conversations/${id}/messages`, { content: 'Финальный вопрос' });
    assert.equal(last.events[0].data.context.truncated, true);
    const sent = S.provider.requests[S.provider.requests.length - 1].body.messages;
    assert.ok(sent.length < 27, `в модель ушло ${sent.length} сообщений из 27`);
    assert.equal(sent[1].role, 'user', 'после system контекст начинается с пользователя');
    assert.equal(sent[sent.length - 1].content, 'Финальный вопрос');
  });

  await t.test('статика: index.html с CSP, server/ и .env не раздаются', async () => {
    const r = await fetch(S.base + '/');
    assert.equal(r.status, 200);
    assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
    for (const p of ['/server/config.js', '/.env', '/src/../server/config.js', '/src/%2e%2e/server/config.js', '/data/wisp.db', '/package.json']) {
      const x = await fetch(S.base + p);
      assert.equal(x.status, 404, p);
    }
    const js = await fetch(S.base + '/src/core/assistant.js');
    assert.equal(js.status, 200);
    const body = await js.text();
    assert.ok(!/sk-[A-Za-z0-9]/.test(body));
  });

  await t.test('во фронтенде нет ключей и адресов провайдеров', async () => {
    const root = path.join(__dirname, '..', 'src');
    const files = [];
    const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else files.push(p); } };
    walk(root);
    files.push(path.join(__dirname, '..', 'index.html'));
    for (const f of files) {
      const s = fs.readFileSync(f, 'utf8');
      assert.ok(!/sk-[A-Za-z0-9_-]{10,}/.test(s), f);
      assert.ok(!/api\.openai\.com|api\.anthropic\.com|openrouter\.ai/.test(s), f);
      assert.ok(!/OPENAI_API_KEY|ANTHROPIC_API_KEY/.test(s), f);
    }
  });
});

test('Лимиты Free: дневной лимит и частота проверяются сервером', async (t) => {
  const S = await startStack({
    plans: {
      free: { title: 'Free', daily_requests: 3, per_minute: 100, history_tokens: 3000, max_output_tokens: 400, max_input_chars: 2000, max_images_per_message: 1 },
      plus: { title: 'Plus', daily_requests: 100, per_minute: 5, history_tokens: 6000, max_output_tokens: 800, max_input_chars: 4000, max_images_per_message: 4 },
    },
  });
  t.after(() => S.close());
  const a = client(S.base);
  const s = await a.json('POST', '/api/session', {});
  assert.equal(s.data.usage.limit, 3);
  let id = 'new';
  for (let i = 0; i < 3; i++) {
    const r = await a.stream(`/api/conversations/${id}/messages`, { content: `m${i}` });
    assert.equal(r.events[r.events.length - 1].event, 'done');
    id = r.events[0].data.conversation.id;
  }
  const over = await a.stream(`/api/conversations/${id}/messages`, { content: 'ещё' });
  assert.equal(over.status, 429);
  assert.equal(over.error.error.code, 'limit_daily');
  assert.ok(over.error.error.reset_at > Date.now());
  const regen = await a.stream(`/api/conversations/${id}/regenerate`, {});
  assert.equal(regen.status, 429, 'повтор тоже считается запросом');
  const conv = await a.json('GET', `/api/conversations/${id}`);
  assert.equal(conv.data.messages.length, 6, 'отклонённое по лимиту сообщение не сохраняется');

  // Plus: выше дневной лимит, но и у него есть частотный предел
  S.app.store.setPlan(s.data.user.id, 'plus');
  const p1 = await a.stream(`/api/conversations/${id}/messages`, { content: 'plus 1' });
  assert.equal(p1.events[p1.events.length - 1].event, 'done');
  const p2 = await a.stream(`/api/conversations/${id}/messages`, { content: 'plus 2' });
  assert.equal(p2.events[p2.events.length - 1].event, 'done');
  const p3 = await a.stream(`/api/conversations/${id}/messages`, { content: 'plus 3' });
  assert.equal(p3.status, 429);
  assert.equal(p3.error.error.code, 'rate_limited');
});

test('Одна генерация за раз и защита от массового создания сессий', async (t) => {
  const S = await startStack({ env: { WISP_SESSIONS_PER_IP_HOUR: '3' } });
  t.after(() => S.close());
  const a = client(S.base);
  await a.json('POST', '/api/session', {});
  const first = a.stream('/api/conversations/new/messages', { content: 'долго [[slow]]' });
  await new Promise((r) => setTimeout(r, 150));
  const second = await a.stream('/api/conversations/new/messages', { content: 'параллельно' });
  assert.equal(second.status, 409);
  assert.equal(second.error.error.code, 'busy');
  await first;
  for (let i = 0; i < 2; i++) assert.equal((await client(S.base).json('POST', '/api/session', {})).status, 200);
  const blocked = await client(S.base).json('POST', '/api/session', {});
  assert.equal(blocked.status, 429);
});

test('Перезапуск сервера: история на месте, незавершённые ответы помечены прерванными', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const a = client(S.base);
  await a.json('POST', '/api/session', {});
  const r = await a.stream('/api/conversations/new/messages', { content: 'Запомни этот диалог' });
  const id = r.events[0].data.conversation.id;
  // имитируем «упавший» сервер: ответ остался в статусе streaming
  S.app.store.db.prepare("UPDATE messages SET status = 'streaming' WHERE role = 'assistant'").run();
  const db = require('../server/lib/db');
  const reopened = db.open(path.join(S.dir, 'wisp.db'));
  const msgs = reopened.messagesWithAttachments(id);
  assert.equal(msgs.length, 2);
  assert.equal(msgs[1].status, 'interrupted');
  reopened.close();
});
