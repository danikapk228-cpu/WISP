/* WISP · Tests · Layer 4 Tools (node --test)
 * Настоящий серверный код: заметки, задачи, напоминания, планировщик; изоляция пользователей; лимиты Free/Plus;
 * часовые пояса; сохранение после перезапуска; AI tool calls через протоколы OpenAI и Anthropic. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const vm = require('node:vm');
const { startStack, client, text } = require('./helpers');
const { createApp } = require('../server/app');
const T = require('../server/tools/time');

const PLANS = {
  free: { title: 'Free', daily_requests: 100, per_minute: 100, history_tokens: 3000, max_output_tokens: 400, max_input_chars: 4000, max_images_per_message: 2,
    tools: { notes_max: 5, note_max_chars: 500, tasks_max: 6, reminders_active_max: 3, events_per_day_max: 3, planner_days_ahead: 14, writes_per_minute: 1000 } },
  plus: { title: 'Plus', daily_requests: 1000, per_minute: 100, history_tokens: 12000, max_output_tokens: 800, max_input_chars: 8000, max_images_per_message: 4,
    tools: { notes_max: 50, note_max_chars: 5000, tasks_max: 50, reminders_active_max: 20, events_per_day_max: 10, planner_days_ahead: 365, writes_per_minute: 1000 } },
};
const TZ = 'Europe/Moscow';
const tomorrow = () => T.addDays(T.todayIn(TZ), 1);
const lastProvider = (S) => S.provider.requests[S.provider.requests.length - 1];

async function session(S, tz) {
  const c = client(S.base);
  const r = await c.json('POST', '/api/session', { timezone: tz || TZ });
  assert.equal(r.status, 200);
  return { c, id: r.data.user.id, data: r.data };
}

test('Layer 4 · инструменты', async (t) => {
  const S = await startStack({ plans: PLANS });
  t.after(() => S.close());
  const A = await session(S);
  const B = await session(S, 'America/New_York');

  await t.test('без сессии и без заголовка клиента доступа нет', async () => {
    const anon = client(S.base);
    for (const url of ['/api/notes', '/api/tasks', '/api/reminders', '/api/events', '/api/agenda', '/api/tools/summary']) {
      assert.equal((await anon.json('GET', url)).status, 401, url);
    }
    const r = await fetch(S.base + '/api/notes', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: A.c.cookie }, body: '{"content":"x"}' });
    assert.equal(r.status, 403, 'без X-WISP-Client изменения запрещены (CSRF)');
  });

  await t.test('сессия знает пояс и лимиты тарифа', async () => {
    assert.equal(A.data.timezone, TZ);
    assert.equal(A.data.tools.reminders_active_max, 3);
    assert.equal(A.data.plans.plus.tools.reminders_active_max, 20);
  });

  let noteId;
  await t.test('заметки: создание, автосохранение, поиск, удаление', async () => {
    const empty = await A.c.json('POST', '/api/notes', { title: '  ', content: '' });
    assert.equal(empty.status, 400);
    const r = await A.c.json('POST', '/api/notes', { title: 'Идеи', content: 'Мне понравилась ИДЕЯ с огоньком\nвторая строка' });
    assert.equal(r.status, 201);
    noteId = r.data.note.id;
    const created = r.data.note.updated_at;
    await new Promise((res) => setTimeout(res, 5));
    const u = await A.c.json('PATCH', `/api/notes/${noteId}`, { content: 'Мне понравилась ИДЕЯ с огоньком\nправка' });
    assert.equal(u.status, 200);
    assert.equal(u.data.note.title, 'Идеи');
    assert.ok(u.data.note.updated_at > created, 'дата изменения обновляется');
    await A.c.json('POST', '/api/notes', { content: 'Купить молоко' });
    const s1 = await A.c.json('GET', '/api/notes?q=' + encodeURIComponent('идея'));
    assert.deepEqual(s1.data.notes.map((n) => n.id), [noteId], 'поиск без учёта регистра, по-русски');
    const s2 = await A.c.json('GET', '/api/notes?q=' + encodeURIComponent('100%_'));
    assert.equal(s2.data.notes.length, 0, '% и _ ищутся буквально');
    const all = await A.c.json('GET', '/api/notes');
    const times = all.data.notes.map((n) => n.updated_at);
    assert.deepEqual(times, [...times].sort((a, b) => b - a), 'сначала последние изменённые');
    const long = await A.c.json('PATCH', `/api/notes/${noteId}`, { content: 'я'.repeat(501) });
    assert.equal(long.status, 400, 'лимит длины заметки на Free');
    const tmp = await A.c.json('POST', '/api/notes', { content: 'удалить меня' });
    assert.equal((await A.c.json('DELETE', `/api/notes/${tmp.data.note.id}`)).status, 200);
    assert.equal((await A.c.json('GET', `/api/notes/${tmp.data.note.id}`)).status, 404);
  });

  let taskId;
  await t.test('задачи: приоритет, срок, выполнение, фильтры, удаление', async () => {
    assert.equal((await A.c.json('POST', '/api/tasks', { title: '' })).status, 400);
    assert.equal((await A.c.json('POST', '/api/tasks', { title: 'x', priority: 'urgent' })).status, 400);
    assert.equal((await A.c.json('POST', '/api/tasks', { title: 'x', due_date: '2026-02-30' })).status, 400);
    const r = await A.c.json('POST', '/api/tasks', { title: 'Закончить проект', description: 'Layer 4', due_date: T.todayIn(TZ), priority: 'high' });
    assert.equal(r.status, 201);
    taskId = r.data.task.id;
    assert.equal(r.data.task.done, false);
    await A.c.json('POST', '/api/tasks', { title: 'Низкий', priority: 'low' });
    const d = await A.c.json('PATCH', `/api/tasks/${taskId}`, { done: true });
    assert.equal(d.data.task.done, true);
    assert.ok(d.data.task.completed_at > 0);
    assert.equal((await A.c.json('PATCH', `/api/tasks/${taskId}`, { done: 'yes' })).status, 400);
    const active = await A.c.json('GET', '/api/tasks?filter=active');
    const completed = await A.c.json('GET', '/api/tasks?filter=completed');
    assert.ok(!active.data.tasks.some((x) => x.id === taskId));
    assert.ok(completed.data.tasks.some((x) => x.id === taskId));
    const undo = await A.c.json('PATCH', `/api/tasks/${taskId}`, { done: false });
    assert.equal(undo.data.task.completed_at, null);
    const tmp = await A.c.json('POST', '/api/tasks', { title: 'временная' });
    assert.equal((await A.c.json('DELETE', `/api/tasks/${tmp.data.task.id}`)).status, 200);
    assert.ok(!(await A.c.json('GET', '/api/tasks')).data.tasks.some((x) => x.id === tmp.data.task.id));
  });

  let remId;
  await t.test('напоминания: время в поясе пользователя → UTC, прошлое запрещено, правка, выполнено', async () => {
    const date = tomorrow();
    const r = await A.c.json('POST', '/api/reminders', { title: 'Позвонить маме', date, time: '10:00', timezone: TZ });
    assert.equal(r.status, 201);
    remId = r.data.reminder.id;
    assert.equal(r.data.reminder.remind_at, T.zonedToUtc(date, '10:00', TZ));
    assert.equal(new Date(r.data.reminder.remind_at).getUTCHours(), 7, '10:00 в Москве = 07:00 UTC');
    assert.equal(r.data.reminder.date, date);
    assert.equal(r.data.reminder.time, '10:00');
    const past = await A.c.json('POST', '/api/reminders', { title: 'x', date: T.todayIn(TZ), time: '00:00', timezone: TZ });
    assert.ok(past.status === 422 || T.localTimeOf(Date.now(), TZ) === '00:00', 'прошедшее время не принимается');
    assert.equal((await A.c.json('POST', '/api/reminders', { title: 'x', date, time: '25:61', timezone: TZ })).status, 400);
    assert.equal((await A.c.json('POST', '/api/reminders', { title: 'x', date, time: '10:00', timezone: 'Mars/Olympus' })).status, 400);
    // тот же момент «10:00» в Нью-Йорке у другого пользователя — другой UTC
    const ny = await B.c.json('POST', '/api/reminders', { title: 'NY', date, time: '10:00', timezone: 'America/New_York' });
    assert.equal(ny.data.reminder.remind_at, T.zonedToUtc(date, '10:00', 'America/New_York'));
    assert.notEqual(ny.data.reminder.remind_at, r.data.reminder.remind_at);

    const n1 = await A.c.json('POST', `/api/reminders/${remId}/notified`, {});
    assert.equal(n1.data.first, true);
    const n2 = await A.c.json('POST', `/api/reminders/${remId}/notified`, {});
    assert.equal(n2.data.first, false, 'уведомление не дублируется');
    const moved = await A.c.json('PATCH', `/api/reminders/${remId}`, { time: '11:30' });
    assert.equal(moved.data.reminder.time, '11:30');
    assert.equal(moved.data.reminder.notified_at, null, 'новое время = новое уведомление');
    const done = await A.c.json('PATCH', `/api/reminders/${remId}`, { done: true });
    assert.equal(done.data.reminder.done, true);
    const active = await A.c.json('GET', '/api/reminders?status=active');
    assert.ok(!active.data.reminders.some((x) => x.id === remId));
    await A.c.json('PATCH', `/api/reminders/${remId}`, { done: false });

    const pastAt = Date.now() - 120_000;
    const pastId = require('node:crypto').randomUUID();
    const pastDate = T.localDateOf(pastAt, TZ);
    const pastTime = T.localTimeOf(pastAt, TZ);
    S.app.store.db.prepare(`INSERT INTO reminders
      (id, user_id, title, description, remind_at, local_date, local_time, tz, done, done_at, notified_at, source, created_at, updated_at)
      VALUES (?, ?, ?, '', ?, ?, ?, ?, 1, ?, ?, 'user', ?, ?)`)
      .run(pastId, A.id, 'Прошедшее напоминание', pastAt, pastDate, pastTime, TZ, pastAt, pastAt, pastAt, pastAt);
    const restore = await A.c.json('PATCH', `/api/reminders/${pastId}`, { done: false });
    assert.equal(restore.status, 422);
    assert.equal(restore.data.error.code, 'in_past');
    assert.equal((await A.c.json('GET', `/api/reminders/${pastId}`)).data.reminder.done, true);
  });

  await t.test('изоляция: чужие записи для пользователя не существуют', async () => {
    const ev = await A.c.json('POST', '/api/events', { title: 'Встреча', date: T.todayIn(TZ), start_time: '15:00' });
    const targets = [`/api/notes/${noteId}`, `/api/tasks/${taskId}`, `/api/reminders/${remId}`, `/api/events/${ev.data.event.id}`];
    for (const url of targets) {
      assert.equal((await B.c.json('GET', url)).status, 404, 'GET ' + url);
      assert.equal((await B.c.json('PATCH', url, { title: 'взлом', done: true })).status, 404, 'PATCH ' + url);
      assert.equal((await B.c.json('DELETE', url)).status, 404, 'DELETE ' + url);
    }
    assert.equal((await B.c.json('POST', `/api/reminders/${remId}/notified`, {})).status, 404);
    const lists = await Promise.all(['/api/notes', '/api/tasks', '/api/reminders'].map((u) => B.c.json('GET', u)));
    const raw = JSON.stringify(lists.map((x) => x.data));
    assert.ok(!raw.includes(noteId) && !raw.includes(taskId) && !raw.includes(remId));
    assert.equal((await A.c.json('GET', `/api/notes/${noteId}`)).data.note.title, 'Идеи', 'у владельца всё на месте');
    assert.equal((await B.c.json('GET', '/api/notes/../../etc/passwd')).status, 404);
  });

  await t.test('планировщик: события дня, проверка времени, горизонт Free, сводка дня', async () => {
    const day = T.todayIn(TZ);
    assert.equal((await A.c.json('POST', '/api/events', { title: 'x', date: day, start_time: '12:00', end_time: '11:00' })).status, 400);
    const e = await A.c.json('POST', '/api/events', { title: 'Тренировка', date: day, start_time: '09:00', end_time: '10:00' });
    assert.equal(e.status, 201);
    const list = await A.c.json('GET', `/api/events?date=${day}`);
    assert.deepEqual(list.data.events.map((x) => x.start_time), ['09:00', '15:00'], 'по времени');
    const edit = await A.c.json('PATCH', `/api/events/${e.data.event.id}`, { start_time: '08:30' });
    assert.equal(edit.data.event.start_time, '08:30');
    const far = await A.c.json('POST', '/api/events', { title: 'Далеко', date: T.addDays(day, 30), start_time: '10:00' });
    assert.equal(far.status, 403);
    assert.equal(far.data.error.code, 'limit_tools');
    const ag = await A.c.json('GET', `/api/agenda?date=${day}&tz=${encodeURIComponent(TZ)}`);
    assert.equal(ag.data.agenda.events.length, 2);
    assert.ok(ag.data.agenda.tasks.some((x) => x.id === taskId), 'задачи со сроком на этот день');
    const sum = await A.c.json('GET', '/api/tools/summary');
    assert.equal(sum.data.summary.events_today, 2);
    assert.ok(sum.data.summary.notes >= 2);
  });

  await t.test('лимиты Free проверяет сервер; тариф из запроса игнорируется; Plus только из базы', async () => {
    const date = tomorrow();
    const results = [];
    for (let i = 0; i < 4; i++) results.push((await A.c.json('POST', '/api/reminders', { title: `R${i}`, date, time: '12:0' + i, timezone: TZ, plan: 'plus' }, { headers: { 'X-WISP-Plan': 'plus' } })).status);
    // одно активное уже есть (remId) → ещё 2, потом лимит
    assert.deepEqual(results, [201, 201, 403, 403]);
    S.app.store.setPlan(A.id, 'plus');
    const ok = await A.c.json('POST', '/api/reminders', { title: 'Plus', date, time: '13:00', timezone: TZ });
    assert.equal(ok.status, 201, 'после выдачи Plus на сервере лимит выше');
    S.app.store.setPlan(A.id, 'free');
  });

  /* ═══ AI tool calls ═══ */
  await t.test('AI (OpenAI): «напомни завтра в 10:00» → настоящая запись в базе → подтверждение после записи', async () => {
    const date = tomorrow();
    const B2 = await session(S);
    const args = JSON.stringify({ title: 'Позвонить маме', date, time: '10:00' });
    const r = await B2.c.stream('/api/conversations/new/messages', { content: `Напомни мне завтра в 10:00 позвонить маме [[call:create_reminder ${args}]]`, timezone: TZ });
    const names = r.events.map((e) => e.event);
    assert.equal(names[0], 'start');
    assert.equal(r.events[0].data.tools, true);
    const tool = r.events.find((e) => e.event === 'tool');
    assert.ok(tool, 'событие tool пришло');
    assert.equal(tool.data.action.status, 'ok');
    assert.equal(tool.data.action.kind, 'reminder');
    assert.equal(tool.data.action.time, '10:00');
    assert.ok(names.indexOf('tool') < names.indexOf('delta'), 'подтверждение текстом только после выполнения');
    const reply = text(r.events);
    assert.match(reply, /"ok":true/);
    const done = r.events[r.events.length - 1];
    assert.equal(done.event, 'done');
    assert.equal(done.data.message.actions.length, 1);
    const rems = await B2.c.json('GET', '/api/reminders?status=active');
    assert.equal(rems.data.reminders.length, 1);
    assert.equal(rems.data.reminders[0].remind_at, T.zonedToUtc(date, '10:00', TZ));
    assert.equal(rems.data.reminders[0].source, 'ai');
    // что ушло провайдеру: определения функций, пояс и «сейчас» в системной инструкции, результат функции
    const req = lastProvider(S);
    assert.ok(Array.isArray(req.body.tools) && req.body.tools.some((x) => x.function.name === 'create_reminder'));
    assert.match(req.body.messages[0].content, /Сейчас у пользователя: .*Europe\/Moscow/);
    const toolMsg = req.body.messages.find((m) => m.role === 'tool');
    assert.equal(JSON.parse(toolMsg.content).ok, true);
    const asst = req.body.messages.find((m) => m.role === 'assistant' && m.tool_calls);
    assert.equal(JSON.parse(asst.tool_calls[0].function.arguments).time, '10:00');
    // история диалога хранит карточку действия
    const conv = await B2.c.json('GET', `/api/conversations/${r.events[0].data.conversation.id}`);
    const am = conv.data.messages.find((m) => m.role === 'assistant');
    assert.equal(am.actions[0].kind, 'reminder');
    assert.equal(am.actions[0].title, 'Позвонить маме');
  });

  await t.test('AI (Anthropic): задача и заметка за один ответ', async () => {
    const C = await session(S);
    const r = await C.c.stream('/api/conversations/new/messages', {
      model: 'blind', timezone: TZ,
      content: 'Создай задачу и запиши идею [[call:create_task {"title":"Закончить проект","priority":"high"}]] [[call:create_note {"content":"Мне понравилась эта идея"}]]',
    });
    const tools = r.events.filter((e) => e.event === 'tool').map((e) => e.data.action);
    assert.deepEqual(tools.map((a) => [a.kind, a.status]), [['task', 'ok'], ['note', 'ok']]);
    const req = lastProvider(S);
    assert.equal(req.kind, 'anthropic');
    assert.ok(req.body.tools.some((x) => x.name === 'create_task' && x.input_schema));
    const results = req.body.messages[req.body.messages.length - 1].content.filter((p) => p.type === 'tool_result');
    assert.equal(results.length, 2);
    assert.equal((await C.c.json('GET', '/api/tasks')).data.tasks[0].priority, 'high');
    assert.equal((await C.c.json('GET', '/api/notes')).data.notes[0].content, 'Мне понравилась эта идея');
  });

  await t.test('AI: неверные аргументы → ошибка модели, в базе ничего, ответ честный', async () => {
    const C = await session(S);
    const r = await C.c.stream('/api/conversations/new/messages', { timezone: TZ, content: 'Напомни [[call:create_reminder {"title":"x","date":"завтра","time":"25:99"}]]' });
    const tool = r.events.find((e) => e.event === 'tool').data.action;
    assert.equal(tool.status, 'error');
    assert.match(text(r.events), /"ok":false/);
    assert.equal((await C.c.json('GET', '/api/reminders')).data.reminders.length, 0);
    const r2 = await C.c.stream('/api/conversations/new/messages', { timezone: TZ, content: '[[call:delete_everything {}]]' });
    assert.equal(r2.events.find((e) => e.event === 'tool').data.action.status, 'error', 'неизвестная функция не выполняется');
  });

  await t.test('AI: чужую задачу через чат не изменить; user_id из аргументов не принимается', async () => {
    const r = await B.c.stream('/api/conversations/new/messages', { timezone: TZ, content: `[[call:complete_task {"task_id":"${taskId}","user_id":"${A.id}"}]]` });
    assert.equal(r.events.find((e) => e.event === 'tool').data.action.status, 'error');
    const mine = (await A.c.json('GET', '/api/tasks')).data.tasks.find((x) => x.id === taskId);
    assert.equal(mine.done, false, 'задача владельца не тронута');
  });

  await t.test('AI: лимит тарифа действует и для чата', async () => {
    const r = await A.c.stream('/api/conversations/new/messages', { timezone: TZ, content: `[[call:create_reminder {"title":"ещё","date":"${tomorrow()}","time":"18:00"}]]` });
    const tool = r.events.find((e) => e.event === 'tool').data.action;
    assert.equal(tool.status, 'error');
    assert.match(tool.error, /активных напоминаний/);
  });

  await t.test('AI: «что у меня сегодня?» читает настоящие данные', async () => {
    const r = await A.c.stream('/api/conversations/new/messages', { timezone: TZ, content: `Что у меня запланировано сегодня? [[call:get_agenda {"date":"${T.todayIn(TZ)}"}]]` });
    const res = JSON.parse(text(r.events).replace(/^Результат: /, ''));
    assert.equal(res.ok, true);
    assert.deepEqual(res.events.map((e) => e.title), ['Тренировка', 'Встреча']);
    assert.ok(res.tasks_due.some((x) => x.title === 'Закончить проект'));
  });

  await t.test('AI: повтор ответа знает о выполненных действиях; удаление диалога не удаляет созданное', async () => {
    const C = await session(S);
    const r = await C.c.stream('/api/conversations/new/messages', { timezone: TZ, content: '[[call:create_task {"title":"Один раз"}]]' });
    const convId = r.events[0].data.conversation.id;
    await C.c.stream(`/api/conversations/${convId}/regenerate`, { timezone: TZ });
    assert.match(lastProvider(S).body.messages[0].content, /уже выполнено.*«Один раз»/s);
    assert.equal((await C.c.json('DELETE', `/api/conversations/${convId}`)).status, 200);
    assert.ok((await C.c.json('GET', '/api/tasks')).data.tasks.some((x) => x.title === 'Один раз'));
  });

  await t.test('AI: модель промолчала после действия → короткий текст, а не ошибка', async () => {
    const C = await session(S);
    const r = await C.c.stream('/api/conversations/new/messages', { timezone: TZ, content: '[[silent]] [[call:create_note {"content":"тихо"}]]' });
    const done = r.events[r.events.length - 1];
    assert.equal(done.event, 'done');
    assert.equal(done.data.message.content, 'Готово.');
  });
});

test('Layer 4 · модель без функций честно без инструментов', async (t) => {
  const S = await startStack({
    plans: PLANS,
    models: {
      providers: { openai: { type: 'openai', base_url_env: 'T_OPENAI_URL', api_key_env: 'T_OPENAI_KEY' } },
      default_model: { free: 'plain', plus: 'plain' },
      models: [{ id: 'plain', label: 'Plain', provider: 'openai', model: 'p', tier: 'free', vision: false, tools: false, context_tokens: 8000, max_output_tokens: 300 }],
    },
  });
  t.after(() => S.close());
  const A = await session(S);
  const r = await A.c.stream('/api/conversations/new/messages', { timezone: TZ, content: 'Напомни завтра [[call:create_reminder {"title":"x","date":"2030-01-01","time":"10:00"}]]' });
  assert.equal(r.events[0].data.tools, false);
  assert.ok(!r.events.some((e) => e.event === 'tool'));
  const req = S.provider.requests[S.provider.requests.length - 1];
  assert.equal(req.body.tools, undefined, 'функции не отправляются');
  assert.match(req.body.messages[0].content, /нет доступа к инструментам WISP/);
  assert.equal((await A.c.json('GET', '/api/reminders')).data.reminders.length, 0);
});

test('Layer 4 · данные на месте после перезапуска сервера', async (t) => {
  const S = await startStack({ plans: PLANS });
  let app2 = null;
  t.after(async () => { if (app2) await app2.close(); await S.provider.close(); require('node:fs').rmSync(S.dir, { recursive: true, force: true }); });
  const A = await session(S);
  await A.c.json('POST', '/api/notes', { title: 'Переживу рестарт', content: 'да' });
  await A.c.json('POST', '/api/tasks', { title: 'Тоже' });
  await A.c.json('POST', '/api/reminders', { title: 'И я', date: tomorrow(), time: '09:15', timezone: TZ });
  await S.app.close();
  app2 = createApp(S.config, { dbFile: path.join(S.dir, 'wisp.db') });
  await new Promise((r) => app2.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app2.server.address().port}`;
  const c = client(base);
  c.cookie = A.c.cookie;
  assert.equal((await c.json('GET', '/api/notes')).data.notes[0].title, 'Переживу рестарт');
  assert.equal((await c.json('GET', '/api/tasks')).data.tasks[0].title, 'Тоже');
  const rem = (await c.json('GET', '/api/reminders')).data.reminders[0];
  assert.equal(rem.time, '09:15');
  assert.equal(rem.timezone, TZ);
});

test('Layer 4 · время и часовые пояса', () => {
  assert.equal(new Date(T.zonedToUtc('2026-11-09', '10:00', 'Europe/Moscow')).toISOString(), '2026-11-09T07:00:00.000Z');
  assert.equal(new Date(T.zonedToUtc('2026-07-01', '12:00', 'America/New_York')).toISOString(), '2026-07-01T16:00:00.000Z', 'летнее время');
  assert.equal(new Date(T.zonedToUtc('2026-01-01', '12:00', 'America/New_York')).toISOString(), '2026-01-01T17:00:00.000Z', 'зимнее время');
  assert.equal(new Date(T.zonedToUtc('2026-03-08', '02:30', 'America/New_York')).toISOString(), '2026-03-08T07:30:00.000Z', 'несуществующее время сдвигается вперёд');
  assert.equal(new Date(T.zonedToUtc('2026-01-01', '00:15', 'Asia/Kolkata')).toISOString(), '2025-12-31T18:45:00.000Z', 'пояс с получасом, смена даты');
  const at = Date.parse('2026-11-08T12:57:00Z');
  assert.equal(T.todayIn('Pacific/Kiritimati', at), '2026-11-09');
  assert.equal(T.todayIn('Pacific/Pago_Pago', at), '2026-11-08');
  assert.equal(T.parseDate('2026-02-29'), null);
  assert.ok(T.parseDate('2028-02-29'));
  assert.equal(T.parseTime('9:05'), '09:05');
  assert.equal(T.parseTime('24:00'), null);
  assert.equal(T.isValidTimeZone('Europe/Moscow'), true);
  assert.equal(T.isValidTimeZone('../../etc'), false);
});

test('reminder edits preserve an explicit stored timezone', async () => {
  const App = { core: { Assistant: { timezone: () => 'America/Los_Angeles' } } };
  const window = { WispApp: App };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/core/tools-api.js'), 'utf8'), { window });
  const requests = [];
  const api = App.core.ToolsAPI({
    connected: true,
    ready: true,
    request: async (method, url, body) => {
      requests.push({ method, url, body });
      return { ok: true };
    },
  });
  await api.reminders.update('reminder-id', { date: '2026-11-09', time: '20:30', timezone: 'Europe/Moscow' });
  assert.equal(requests[0].body.timezone, 'Europe/Moscow');
  await api.reminders.update('reminder-id', { date: '2026-11-09', time: '20:40' });
  assert.equal(requests[1].body.timezone, 'America/Los_Angeles');
});
