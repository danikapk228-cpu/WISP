/* WISP · Tests · Layer 5 Memory (node --test)
 * Настоящий серверный код и настоящий потоковый чат (через локальный двойник провайдера):
 * явное «запомни», предложения с подтверждением, использование в новом чате, правка, удаление,
 * выключение памяти, изоляция пользователей, чувствительные данные, лимиты Free/Plus, поиск,
 * сбой памяти не ломает чат, модели без функций, протокол Anthropic, миграция базы v2 → v3. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { startStack, client, text } = require('./helpers');
const { createApp } = require('../server/app');
const db = require('../server/lib/db');
const T = require('../server/memory/text');
const Sensitive = require('../server/memory/sensitive');
const { explicitRequest, guessCategory } = require('../server/memory/extract');

const MEM_FREE = { items_max: 6, pinned_max: 1, item_max_chars: 120, pending_max: 3, pending_ttl_days: 7, context_items: 4, context_core: 2, context_chars: 800, query_turns: 1, writes_per_minute: 1000 };
const MEM_PLUS = { items_max: 100, pinned_max: 20, item_max_chars: 400, pending_max: 10, pending_ttl_days: 14, context_items: 10, context_core: 4, context_chars: 3000, query_turns: 3, writes_per_minute: 1000 };
const PLANS = {
  free: { title: 'Free', daily_requests: 500, per_minute: 500, history_tokens: 3000, max_output_tokens: 400, max_input_chars: 4000, max_images_per_message: 2, tools: { writes_per_minute: 1000 }, memory: MEM_FREE },
  plus: { title: 'Plus', daily_requests: 1000, per_minute: 500, history_tokens: 12000, max_output_tokens: 800, max_input_chars: 8000, max_images_per_message: 4, tools: { writes_per_minute: 1000 }, memory: MEM_PLUS },
};
const TZ = 'Europe/Moscow';

async function session(S) {
  const c = client(S.base);
  const r = await c.json('POST', '/api/session', { timezone: TZ });
  assert.equal(r.status, 200);
  return { c, id: r.data.user.id, data: r.data };
}
/* Отправить сообщение и вернуть события + запросы к провайдеру этой генерации */
async function say(S, who, content, conv) {
  const before = S.provider.requests.length;
  const r = await who.c.stream(`/api/conversations/${conv || 'new'}/messages`, { timezone: TZ, content });
  const reqs = S.provider.requests.slice(before);
  return { ...r, reqs, first: reqs[0], done: r.events.find((e) => e.event === 'done'), start: r.events.find((e) => e.event === 'start'), actions: r.events.filter((e) => e.event === 'tool').map((e) => e.data.action) };
}
const sys = (req) => (req.kind === 'openai' ? req.body.messages[0].content : typeof req.body.system === 'string' ? req.body.system : JSON.stringify(req.body.system));
const toolNames = (req) => (req.body.tools || []).map((t) => (t.function ? t.function.name : t.name));
const list = async (who, qs) => (await who.c.json('GET', `/api/memories${qs || ''}`)).data;
const call = (name, args) => `[[call:${name} ${JSON.stringify(args)}]]`;

test('Layer 5 · долговременная память', async (t) => {
  const S = await startStack({ plans: PLANS });
  t.after(() => S.close());
  const A = await session(S);
  const B = await session(S);

  await t.test('без сессии закрыто, без заголовка клиента изменения запрещены', async () => {
    const anon = client(S.base);
    for (const url of ['/api/memories', '/api/memory/settings', '/api/memories/export']) assert.equal((await anon.json('GET', url)).status, 401, url);
    const r = await fetch(S.base + '/api/memories', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: A.c.cookie }, body: '{"content":"x"}' });
    assert.equal(r.status, 403, 'CSRF');
  });

  await t.test('пустая память и настройки по умолчанию', async () => {
    const d = await list(A);
    assert.equal(d.total, 0);
    assert.deepEqual(d.memories, []);
    assert.deepEqual(d.settings, { enabled: true, suggest: true });
    assert.equal(d.limits.items_max, MEM_FREE.items_max);
    assert.equal(A.data.memory.items_max, MEM_FREE.items_max, 'лимиты памяти в сессии');
    assert.equal(A.data.plans.plus.memory.items_max, MEM_PLUS.items_max);
    assert.equal(d.categories.length, 6);
  });

  let gameId;
  await t.test('«запомни» в чате: сервер сохраняет, модель узнаёт об этом только после записи', async () => {
    const r = await say(S, A, 'Запомни, что я разрабатываю игру на JavaScript ' + call('remember', { content: 'Разрабатывает игру на JavaScript', category: 'work', importance: 2 }));
    assert.ok(r.done, 'ответ завершён');
    assert.equal(r.actions.length, 1);
    const a = r.actions[0];
    assert.equal(a.kind, 'memory'); assert.equal(a.op, 'saved'); assert.equal(a.status, 'ok');
    assert.equal(a.content, 'Разрабатывает игру на JavaScript');
    assert.match(text(r.events), /"saved":true/, 'модель получила подтверждение сохранения');
    const d = await list(A);
    assert.equal(d.total, 1);
    const m = d.memories[0];
    gameId = m.id;
    assert.equal(m.category, 'work'); assert.equal(m.source, 'explicit'); assert.equal(m.status, 'active'); assert.equal(m.pinned, false);
    assert.ok(m.created_at && m.updated_at);
    // журнал действий не хранит текст факта
    const row = S.app.store.db.prepare("SELECT args, result FROM tool_calls WHERE name = 'remember'").get();
    assert.ok(!row.args.includes('JavaScript') && !row.result.includes('JavaScript'), 'текст факта не дублируется в журнале');
  });

  await t.test('новый чат: используется то, что относится к вопросу, нерелевантное не попадает', async () => {
    const add = await A.c.json('POST', '/api/memories', { content: 'Любит гулять с собакой по утрам', category: 'other' });
    assert.equal(add.status, 201);
    const r = await say(S, A, 'Как мне реализовать инвентарь?');
    const s = sys(r.first);
    assert.match(s, /Разрабатывает игру на JavaScript/, 'проект в контексте');
    assert.doesNotMatch(s, /гулять с собакой/, 'нерелевантное не передаётся');
    assert.match(s, /показано 1 из 2/);
    assert.deepEqual(r.start.data.memory.used.map((x) => x.id), [gameId]);
    assert.deepEqual(r.done.data.message.memory_used.map((x) => x.id), [gameId]);
    const names = toolNames(r.first);
    for (const n of ['remember', 'suggest_memory', 'forget_memory', 'create_task']) assert.ok(names.includes(n), n);
    // в истории диалога подсказка «WISP учёл память» сохраняется
    const conv = await A.c.json('GET', `/api/conversations/${r.start.data.conversation.id}`);
    assert.deepEqual(conv.data.messages[1].memory_used.map((x) => x.content), ['Разрабатывает игру на JavaScript']);
    // «привет» — ничего лишнего
    const r2 = await say(S, A, 'Привет!');
    assert.doesNotMatch(sys(r2.first), /JavaScript|собакой/);
    assert.match(sys(r2.first), /ничего не относится/);
  });

  await t.test('правка: WISP использует обновлённую версию', async () => {
    const u = await A.c.json('PATCH', `/api/memories/${gameId}`, { content: 'Разрабатывает игру на TypeScript' });
    assert.equal(u.status, 200);
    assert.ok(u.data.memory.updated_at >= u.data.memory.created_at);
    const r = await say(S, A, 'Как сделать инвентарь в игре?');
    assert.match(sys(r.first), /TypeScript/);
    assert.doesNotMatch(sys(r.first), /JavaScript/);
  });

  await t.test('похожее воспоминание обновляется, а не дублируется', async () => {
    const before = (await list(A)).total;
    const r = await A.c.json('POST', '/api/memories', { content: 'Я разрабатываю игру на TypeScript и Phaser', category: 'work' });
    assert.equal(r.status, 200);
    assert.equal(r.data.op, 'updated');
    assert.equal(r.data.memory.id, gameId);
    assert.equal((await list(A)).total, before);
  });

  await t.test('изоляция: другой пользователь не видит и не меняет чужую память', async () => {
    const d = await list(B);
    assert.equal(d.total, 0);
    assert.equal((await B.c.json('GET', `/api/memories/${gameId}`)).status, 404);
    assert.equal((await B.c.json('PATCH', `/api/memories/${gameId}`, { content: 'взлом' })).status, 404);
    assert.equal((await B.c.json('DELETE', `/api/memories/${gameId}`)).status, 404);
    assert.equal((await B.c.json('POST', `/api/memories/${gameId}/confirm`, {})).status, 404);
    // user_id в теле игнорируется
    const r = await B.c.json('POST', '/api/memories', { content: 'Пишет музыку в Ableton', category: 'work', user_id: A.id, plan: 'plus' });
    assert.equal(r.status, 201);
    assert.ok(!(await list(A)).memories.some((m) => m.content.includes('Ableton')));
    const chat = await say(S, B, 'Как мне реализовать инвентарь в игре?');
    assert.doesNotMatch(sys(chat.first), /TypeScript|JavaScript/, 'чужая память не попадает в чат');
    assert.equal((await B.c.json('DELETE', '/api/memories', { confirm: 'clear_all' })).status, 200);
    assert.ok((await list(A)).total >= 2, 'очистка у B не задела A');
    assert.equal((await A.c.json('GET', `/api/memories/${gameId}`)).status, 200);
  });

  await t.test('предложение WISP: ждёт подтверждения и до него не используется', async () => {
    const r = await say(S, A, 'Мне вообще нравится минималистичный дизайн ' + call('suggest_memory', { content: 'Нравится минималистичный дизайн', category: 'preferences' }));
    const a = r.actions[0];
    assert.equal(a.op, 'suggested'); assert.equal(a.memory_status, 'pending');
    assert.match(text(r.events), /"suggested":true/);
    assert.doesNotMatch(text(r.events), /"saved":true/);
    const d = await list(A);
    assert.equal(d.pending.length, 1);
    assert.ok(!d.memories.some((m) => m.content.includes('минималист')), 'в активной памяти его нет');
    const r1 = await say(S, A, 'Подбери палитру для интерфейса');
    assert.doesNotMatch(sys(r1.first), /минималист/, 'неподтверждённое не используется');
    const ok = await A.c.json('POST', `/api/memories/${a.memory_id}/confirm`, {});
    assert.equal(ok.status, 200); assert.equal(ok.data.op, 'saved'); assert.equal(ok.data.memory.source, 'suggested');
    const r2 = await say(S, A, 'Подбери палитру для интерфейса');
    assert.match(sys(r2.first), /минималистичный дизайн/);
    // карточка в истории показывает текущий статус
    const conv = await A.c.json('GET', `/api/conversations/${r.start.data.conversation.id}`);
    assert.equal(conv.data.messages[1].actions[0].memory_status, 'active');
  });

  await t.test('«не надо»: предложение удаляется и не повторяется; одно предложение за ответ', async () => {
    const r = await say(S, A, 'Я сова ' + call('suggest_memory', { content: 'Сова, работает по ночам', category: 'personal' }));
    const id = r.actions[0].memory_id;
    assert.equal((await A.c.json('POST', `/api/memories/${id}/dismiss`)).status, 200);
    assert.equal((await A.c.json('GET', `/api/memories/${id}`)).status, 404);
    const again = await say(S, A, 'Я сова ' + call('suggest_memory', { content: 'Сова, работает по ночам', category: 'personal' }));
    assert.equal(again.actions[0].op, 'failed');
    assert.match(again.actions[0].error, /отказался/);
    const two = await say(S, A, 'x ' + call('suggest_memory', { content: 'Любит зелёный чай', category: 'preferences' }) + call('suggest_memory', { content: 'Играет на гитаре', category: 'personal' }));
    assert.equal(two.actions[0].op, 'suggested');
    assert.equal(two.actions[1].op, 'failed');
    assert.equal((await A.c.json('POST', `/api/memories/${two.actions[0].memory_id}/dismiss`)).status, 200);
  });

  await t.test('просроченное предложение памяти нельзя подтвердить по старой карточке', async () => {
    const proposed = await say(S, A, 'Запомни это ' + call('suggest_memory', { content: 'Старое предложение, ожидающее согласия', category: 'preferences' }));
    const id = proposed.actions[0].memory_id;
    assert.ok(id);
    S.app.store.db.prepare('UPDATE memories SET updated_at = ? WHERE id = ? AND user_id = ?')
      .run(Date.now() - 8 * 86400000, id, A.id);
    const confirm = await A.c.json('POST', `/api/memories/${id}/confirm`, {});
    assert.equal(confirm.status, 404);
    assert.equal((await A.c.json('GET', `/api/memories/${id}`)).status, 404);
    assert.ok(!(await list(A)).memories.some((m) => m.id === id));
  });

  await t.test('подтверждение не позволяет обойти лимит закреплённых воспоминаний', async () => {
    const active = await B.c.json('POST', '/api/memories', {
      content: 'Закреплённый факт для проверки лимита', category: 'preferences', pinned: true,
    });
    assert.equal(active.status, 201);
    const proposed = await say(S, B, 'Предложение ' + call('suggest_memory', {
      content: 'Второй факт, тоже хочу закрепить', category: 'preferences',
    }));
    const id = proposed.actions[0].memory_id;
    assert.ok(id);
    assert.equal((await B.c.json('PATCH', `/api/memories/${id}`, { pinned: true })).status, 200);
    const blocked = await B.c.json('POST', `/api/memories/${id}/confirm`, {});
    assert.equal(blocked.status, 403);
    assert.equal(blocked.data.error.kind, 'pinned');
    assert.equal((await B.c.json('GET', `/api/memories/${id}`)).data.memory.status, 'pending');
    await B.c.json('PATCH', `/api/memories/${active.data.memory.id}`, { pinned: false });
    const confirmed = await B.c.json('POST', `/api/memories/${id}/confirm`, {});
    assert.equal(confirmed.status, 200);
    assert.equal(confirmed.data.memory.pinned, true);
  });

  await t.test('личные сведения — только с отдельным согласием, пароли — никогда', async () => {
    const r = await say(S, A, 'Запомни, что у меня диабет ' + call('remember', { content: 'Есть диабет', category: 'personal' }));
    const a = r.actions[0];
    assert.equal(a.op, 'needs_consent'); assert.equal(a.memory_status, 'pending'); assert.equal(a.sensitive, true);
    assert.match(text(r.events), /needs_confirmation/);
    const r1 = await say(S, A, 'Что мне приготовить на ужин при диабете?');
    assert.doesNotMatch(sys(r1.first), /Есть диабет/, 'без согласия не используется');
    assert.equal((await A.c.json('POST', `/api/memories/${a.memory_id}/confirm`, {})).status, 409, 'нужно отдельное подтверждение');
    const ok = await A.c.json('POST', `/api/memories/${a.memory_id}/confirm`, { confirm_sensitive: true });
    assert.equal(ok.status, 200); assert.equal(ok.data.memory.sensitive, true);
    const sug = await say(S, A, 'x ' + call('suggest_memory', { content: 'Принимает антидепрессанты', category: 'personal' }));
    assert.equal(sug.actions[0].op, 'failed', 'чувствительное WISP сам не предлагает');
    const manual = await A.c.json('POST', '/api/memories', { content: 'Принимаю лекарства от давления', category: 'personal' });
    assert.equal(manual.status, 409); assert.equal(manual.data.error.code, 'memory_sensitive');
    assert.equal((await A.c.json('POST', '/api/memories', { content: 'Принимаю лекарства от давления', category: 'personal', confirm_sensitive: true })).status, 201);
    const secret = await A.c.json('POST', '/api/memories', { content: 'Мой пароль от почты hunter2', category: 'other', confirm_sensitive: true });
    assert.equal(secret.status, 422); assert.equal(secret.data.error.code, 'memory_secret');
    const card = await say(S, A, 'Запомни номер карты ' + call('remember', { content: 'Карта 4111 1111 1111 1111', category: 'other' }));
    assert.equal(card.actions[0].op, 'failed');
    assert.ok(!(await list(A)).memories.some((m) => /4111|hunter2/.test(m.content)));
    // уберём, чтобы не мешали лимитам
    for (const m of (await list(A)).memories.filter((x) => x.sensitive)) await A.c.json('DELETE', `/api/memories/${m.id}`);
  });

  await t.test('проверка ввода', async () => {
    assert.equal((await A.c.json('POST', '/api/memories', { content: '   ' })).status, 400);
    assert.equal((await A.c.json('POST', '/api/memories', { content: 42 })).status, 400);
    assert.equal((await A.c.json('POST', '/api/memories', { content: 'ок', category: 'evil' })).status, 400);
    assert.equal((await A.c.json('POST', '/api/memories', { content: 'я'.repeat(MEM_FREE.item_max_chars + 1) })).status, 400);
    assert.equal((await A.c.json('POST', '/api/memories', { content: 'Факт', importance: 7 })).status, 400);
    assert.equal((await A.c.json('PATCH', `/api/memories/${gameId}`, { pinned: 'yes' })).status, 400);
    assert.equal((await A.c.json('GET', '/api/memories/not-an-id')).status, 404);
    assert.equal((await A.c.json('GET', '/api/memories?category=evil')).status, 400);
    assert.equal((await A.c.json('PATCH', '/api/memory/settings', { enabled: 'no' })).status, 400);
    const r = await A.c.json('POST', '/api/memories', { content: 'Сестру зовут Аня', status: 'pending', source: 'explicit', id: '00000000-0000-4000-8000-000000000000' });
    assert.equal(r.status, 201);
    assert.equal(r.data.memory.status, 'active'); assert.equal(r.data.memory.source, 'user'); assert.notEqual(r.data.memory.id, '00000000-0000-4000-8000-000000000000');
    assert.equal(r.data.memory.category, 'people', 'категория угадана по тексту');
  });

  await t.test('поиск и фильтр по категориям', async () => {
    const s1 = await list(A, '?q=' + encodeURIComponent('игры'));
    assert.deepEqual(s1.memories.map((m) => m.id), [gameId], 'с учётом формы слова');
    const s2 = await list(A, '?q=' + encodeURIComponent('PHASER'));
    assert.equal(s2.memories.length, 1, 'без учёта регистра');
    const s3 = await list(A, '?category=people');
    assert.ok(s3.memories.length >= 1 && s3.memories.every((m) => m.category === 'people'));
    assert.equal(s3.total, (await list(A)).total, 'счётчики — по всей памяти');
    assert.equal((await list(A, '?q=' + encodeURIComponent('%_'))).memories.length, 0);
  });

  await t.test('закрепление и лимиты Free проверяет сервер', async () => {
    const p = await A.c.json('PATCH', `/api/memories/${gameId}`, { pinned: true });
    assert.equal(p.status, 200); assert.equal(p.data.memory.pinned, true);
    const other = (await list(A)).memories.find((m) => !m.pinned);
    const p2 = await A.c.json('PATCH', `/api/memories/${other.id}`, { pinned: true });
    assert.equal(p2.status, 403); assert.equal(p2.data.error.code, 'limit_memory'); assert.equal(p2.data.error.kind, 'pinned');
    const first = (await list(A)).memories[0];
    assert.equal(first.id, gameId, 'закреплённые первыми');
    let n = (await list(A)).total;
    const extra = ['Пьёт кофе без сахара', 'Бегает по субботам', 'Учит японский язык', 'Живёт в Казани', 'Любит фантастику Лема', 'Читает про космос'];
    let last;
    for (const c of extra) { last = await A.c.json('POST', '/api/memories', { content: c }); if (last.status === 201) n++; else break; }
    assert.equal(n, MEM_FREE.items_max);
    assert.equal(last.status, 403); assert.equal(last.data.error.code, 'limit_memory'); assert.equal(last.data.error.kind, 'items');
  });

  await t.test('закреплённое и правила общения попадают в контекст всегда, но в пределах лимита', async () => {
    const r = await say(S, A, 'Привет, как дела?');
    const s = sys(r.first);
    assert.match(s, /TypeScript.*закреплено/, 'закреплённое — основной контекст');
    const items = r.start.data.memory.used;
    assert.ok(items.length <= MEM_FREE.context_items + MEM_FREE.context_core);
    assert.ok(items.length < (await list(A)).total, 'не вся память целиком');
  });

  await t.test('противоречие: модель обновляет устаревший факт (replaces), забывает по просьбе', async () => {
    const r0 = await say(S, A, 'Как сделать инвентарь в игре?');
    const ref = (sys(r0.first).match(/\[(m[0-9a-f]+)\][^\n]*TypeScript/) || [])[1];
    assert.ok(ref, 'у факта есть ref');
    const r = await say(S, A, 'Запомни: теперь я пишу игру на Godot ' + call('remember', { content: 'Разрабатывает игру на Godot', category: 'work', replaces: ref }));
    assert.equal(r.actions[0].op, 'updated');
    const m = (await A.c.json('GET', `/api/memories/${gameId}`)).data.memory;
    assert.equal(m.content, 'Разрабатывает игру на Godot');
    assert.equal(m.pinned, true, 'закрепление сохраняется');
    const bad = await say(S, A, 'x ' + call('remember', { content: 'Что-то', category: 'other', replaces: 'm99' }));
    assert.equal(bad.actions[0].op, 'failed', 'чужие/несуществующие ref не принимаются');
    const r1 = await say(S, A, 'Где лучше бегать по субботам?');
    const ref2 = (sys(r1.first).match(/\[(m[0-9a-f]+)\][^\n]*Бегает/) || [])[1];
    assert.ok(ref2);
    const f = await say(S, A, 'Забудь про бег ' + call('forget_memory', { ref: ref2 }));
    // Layer 8: удаление из памяти — опасное действие, сначала карточка подтверждения
    assert.equal(f.actions[0].kind, 'confirm'); assert.equal(f.actions[0].op, 'pending');
    assert.ok((await list(A)).memories.some((x) => x.content.includes('Бегает')), 'до подтверждения ничего не удалено');
    assert.equal((await A.c.json('POST', `/api/actions/${f.actions[0].pending_id}/confirm`, {})).status, 200);
    assert.ok(!(await list(A)).memories.some((x) => x.content.includes('Бегает')));
  });

  await t.test('удаление: удалённое больше не используется', async () => {
    const d = await A.c.json('DELETE', `/api/memories/${gameId}`);
    assert.equal(d.status, 200);
    const r = await say(S, A, 'Как мне реализовать инвентарь в игре?');
    assert.doesNotMatch(sys(r.first), /Godot|TypeScript|JavaScript/);
    // в старом диалоге карточка «запомнил» показывает, что факт удалён, и текста больше нет
    const convs = (await A.c.json('GET', '/api/conversations')).data.conversations;
    const firstConv = convs[convs.length - 1];
    const conv = await A.c.json('GET', `/api/conversations/${firstConv.id}`);
    const act = conv.data.messages[1].actions[0];
    assert.equal(act.memory_status, 'gone'); assert.equal(act.content, null);
  });

  await t.test('выключенная память не используется и не пополняется, записи остаются', async () => {
    const total = (await list(A)).total;
    const off = await A.c.json('PATCH', '/api/memory/settings', { enabled: false });
    assert.equal(off.status, 200); assert.equal(off.data.settings.enabled, false);
    const r = await say(S, A, 'Где лучше пить кофе? Запомни, что я люблю латте ' + call('remember', { content: 'Любит латте', category: 'preferences' }));
    const s = sys(r.first);
    assert.match(s, /память выключена/i);
    assert.doesNotMatch(s, /кофе без сахара/);
    assert.ok(!toolNames(r.first).includes('remember'), 'функции памяти не предлагаются');
    assert.equal(r.actions[0].op, 'failed', 'даже если модель попробует');
    assert.deepEqual(r.start.data.memory.used, []);
    assert.equal((await list(A)).total, total, 'ничего не добавилось и не удалилось');
    await A.c.json('PATCH', '/api/memory/settings', { enabled: true });
    const r2 = await say(S, A, 'Где лучше пить кофе?');
    assert.match(sys(r2.first), /кофе без сахара/, 'после включения снова используется');
  });

  await t.test('выключенные предложения: suggest_memory не предлагается', async () => {
    await A.c.json('PATCH', '/api/memory/settings', { suggest: false });
    const r = await say(S, A, 'Привет');
    assert.ok(toolNames(r.first).includes('remember'));
    assert.ok(!toolNames(r.first).includes('suggest_memory'));
    await A.c.json('PATCH', '/api/memory/settings', { suggest: true });
  });

  await t.test('экспорт и очистка всей памяти с подтверждением', async () => {
    const proposed = await say(S, A, 'Предложи запомнить ' + call('suggest_memory', { content: 'Ожидает подтверждения и должен попасть в экспорт', category: 'preferences' }));
    const pendingId = proposed.actions[0].memory_id;
    assert.ok(pendingId);
    const ex = await A.c.req('GET', '/api/memories/export');
    assert.equal(ex.status, 200);
    assert.match(ex.headers.get('content-disposition'), /attachment; filename="wisp-memory-/);
    const data = await ex.json();
    assert.ok(data.memories.length > 0 && data.memories.every((m) => !('user_id' in m)));
    assert.ok(data.memories.some((m) => m.id === pendingId && m.status === 'pending'));
    const fullExport = await A.c.json('GET', '/api/account/export');
    assert.ok(fullExport.data.memory.memories.some((m) => m.id === pendingId && m.status === 'pending'));
    assert.equal((await A.c.json('DELETE', '/api/memories', {})).status, 400, 'без подтверждения не очищается');
    const c = await A.c.json('DELETE', '/api/memories', { confirm: 'clear_all' });
    assert.equal(c.status, 200); assert.ok(c.data.deleted > 0);
    assert.equal((await list(A)).total, 0);
    const r = await say(S, A, 'Где лучше пить кофе?');
    assert.match(sys(r.first), /Память пока пуста/);
  });
});

test('Layer 5 · модель без функций: «запомни…» сохраняет сам сервер', async (t) => {
  const S = await startStack({
    plans: PLANS,
    models: {
      providers: { openai: { type: 'openai', base_url_env: 'T_OPENAI_URL', api_key_env: 'T_OPENAI_KEY' } },
      default_model: { free: 'plain', plus: 'plain' },
      models: [{ id: 'plain', label: 'Plain', provider: 'openai', model: 'p', tier: 'free', vision: false, tools: false, context_tokens: 8000, max_output_tokens: 300 }],
    },
  });
  t.after(() => S.close());
  const A = await session(S);
  const r = await say(S, A, 'Запомни, что мой проект называется WISP. И расскажи анекдот');
  assert.equal(r.start.data.tools, false);
  assert.equal(r.actions.length, 1);
  assert.equal(r.actions[0].op, 'saved');
  assert.equal(r.actions[0].content, 'Мой проект называется WISP');
  assert.match(sys(r.first), /Сервер уже сохранил в память по просьбе пользователя: «Мой проект называется WISP»/);
  assert.equal(r.first.body.tools, undefined);
  const d = (await A.c.json('GET', '/api/memories')).data;
  assert.equal(d.memories[0].category, 'work');
  const r2 = await say(S, A, 'Как лучше назвать новую версию проекта?');
  assert.match(sys(r2.first), /Мой проект называется WISP/);
  const plain = await say(S, A, 'Как дела?');
  assert.equal(plain.actions.length, 0, 'без просьбы ничего не сохраняется');
  const sens = await say(S, A, 'Запомни, что у меня аллергия на орехи');
  assert.equal(sens.actions[0].op, 'needs_consent');
  assert.match(sys(sens.first), /не говори «запомнил»/);
  const sec = await say(S, A, 'Запомни мой пароль: qwerty123');
  assert.equal(sec.actions[0].op, 'failed');
  assert.match(sys(sec.first), /сервер НЕ сохранил/);
});

test('Layer 5 · сбой памяти не ломает чат', async (t) => {
  const S = await startStack({ plans: PLANS });
  await S.app.close();
  const app = createApp(S.config, { dbFile: path.join(S.dir, 'wisp.db'), memory: { recall() { throw new Error('disk on fire'); } } });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  t.after(async () => { await app.close(); await S.provider.close(); require('node:fs').rmSync(S.dir, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const S2 = { ...S, base, app };
  const A = await session(S2);
  const r = await say(S2, A, 'Привет! Как реализовать инвентарь?');
  assert.ok(r.done, 'ответ пришёл');
  assert.equal(r.done.data.message.status, 'complete');
  assert.match(text(r.events), /Привет/);
  assert.equal(r.start.data.memory.failed, true);
  assert.match(sys(r.first), /память сейчас недоступна/i);
  assert.ok(!toolNames(r.first).includes('remember'));
  assert.ok(toolNames(r.first).includes('create_task'), 'инструменты Layer 4 работают');
  // экран Memory при этом работает (сломан только recall)
  assert.equal((await A.c.json('GET', '/api/memories')).status, 200);
});

test('Layer 5 · протокол Anthropic, Plus и учёт нескольких сообщений', async (t) => {
  const S = await startStack({ plans: PLANS });
  t.after(() => S.close());
  const A = await session(S);
  S.app.store.setPlan(A.id, 'plus');
  const s = await A.c.json('GET', '/api/session');
  assert.equal(s.data.memory.items_max, MEM_PLUS.items_max);
  const r = await A.c.stream('/api/conversations/new/messages', { timezone: TZ, model: 'smart', content: 'Запомни: сестру зовут Аня ' + call('remember', { content: 'Сестру зовут Аня', category: 'people' }) });
  const act = r.events.find((e) => e.event === 'tool').data.action;
  assert.equal(act.op, 'saved');
  const req = S.provider.requests.find((x) => x.kind === 'anthropic');
  assert.ok(req.body.tools.some((x) => x.name === 'remember' && x.input_schema));
  await A.c.json('POST', '/api/memories', { content: 'Разрабатывает игру на JavaScript', category: 'work' });
  // Plus учитывает и предыдущее сообщение: «а инвентарь?» само по себе об игре не говорит
  const conv = r.events[0].data.conversation.id;
  await say(S, A, 'Я про свою игру', conv);
  const r2 = await say(S, A, 'А как сделать сохранения?', conv);
  assert.match(sys(r2.first), /игру на JavaScript/);
});

test('Layer 5 · миграция базы v2 → v3 и данные после перезапуска', async (t) => {
  const os = require('node:os');
  const fs = require('node:fs');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wisp-mig-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const file = path.join(dir, 'wisp.db');
  // база «как в Layer 4»: без таблиц памяти и новых колонок
  let st = db.open(file);
  const u = st.createUser();
  const c = st.createConversation(u.id, { title: 'Старый диалог' });
  st.addUserMessage(c.id, u.id, { content: 'привет' });
  st.close();
  const raw = new DatabaseSync(file);
  raw.exec('DROP TABLE memories; DROP TABLE memory_dismissed; ALTER TABLE users DROP COLUMN memory_enabled; ALTER TABLE users DROP COLUMN memory_suggest; ALTER TABLE messages DROP COLUMN memory_used;');
  raw.prepare("UPDATE meta SET value = '2' WHERE key = 'schema_version'").run();
  raw.close();
  st = db.open(file);
  const ucols = st.db.prepare('PRAGMA table_info(users)').all().map((x) => x.name);
  assert.ok(ucols.includes('memory_enabled') && ucols.includes('memory_suggest'));
  assert.ok(st.db.prepare('PRAGMA table_info(messages)').all().some((x) => x.name === 'memory_used'));
  assert.equal(st.db.prepare("SELECT value FROM meta WHERE key = 'schema_version'").get().value, String(db.SCHEMA_VERSION), 'миграция доходит до текущей версии (Layer 6: 4)');
  assert.equal(st.listConversations(u.id)[0].title, 'Старый диалог', 'старые данные на месте');
  const { MemoryService } = require('../server/memory/service');
  const ms = new MemoryService({ store: st, config: { plans: PLANS } });
  ms.create({ userId: u.id, plan: 'free' }, { content: 'Переживу рестарт' });
  st.close();
  st = db.open(file);
  const ms2 = new MemoryService({ store: st, config: { plans: PLANS } });
  assert.equal(ms2.list({ userId: u.id, plan: 'free' }).memories[0].content, 'Переживу рестарт');
  assert.equal(ms2.settings({ userId: u.id }).enabled, true, 'старым пользователям память включена по умолчанию');
  st.close();
});

test('Layer 5 · анализ текста: формы слов, темы, похожесть, чувствительное, «запомни»', () => {
  assert.equal(T.stem('игру'), T.stem('игры'));
  assert.equal(T.stem('разрабатываю'), T.stem('разрабатывает'));
  const q = T.analyze('Как мне реализовать инвентарь?');
  const m = T.analyze('Разрабатывает игру на JavaScript');
  assert.ok(q.topics.includes('games') && m.topics.includes('games'), 'общая тема без общих слов');
  assert.ok(T.similarity(m, T.analyze('Я разрабатываю игру на JavaScript')) >= 0.6);
  assert.ok(T.similarity(T.analyze('Любит кофе'), T.analyze('Любит чай')) < 0.6);
  assert.equal(Sensitive.check('Разрабатывает игру на JavaScript').level, null);
  assert.equal(Sensitive.check('Мне нравится минималистичный дизайн').level, null);
  assert.equal(Sensitive.check('У меня ВИЧ').level, 'sensitive');
  assert.equal(Sensitive.check('Мой телефон +7 999 123-45-67').level, 'sensitive');
  assert.equal(Sensitive.check('Карта 4111 1111 1111 1111').level, 'secret');
  assert.equal(Sensitive.check('ключ sk-abcdefghijklmnopqrstuv').level, 'secret');
  assert.equal(Sensitive.check('Люблю раков').level, null);
  assert.deepEqual(explicitRequest('Привет! Запомни, что мою собаку зовут Рекс. И расскажи анекдот'), { content: 'Мою собаку зовут Рекс', category: 'people' });
  assert.equal(explicitRequest('Как мне реализовать инвентарь?'), null);
  assert.equal(explicitRequest('Запомни это'), null);
  assert.equal(guessCategory('Хочу выучить японский к 2027'), 'goals');
  assert.equal(guessCategory('Предпочитаю короткие ответы'), 'preferences');
});
