/* WISP · Tests · Layer 10 · Subscription & Access (сервер, без интернета)
 * Free и Plus с сервера, активация кодов (верный, неверный, просроченный, отключённый, повторный, лимит активаций,
 * привязка к пользователю, серия), сложение сроков, Founder, атомарность при гонке, перебор и блокировка,
 * истечение Plus → Free с сохранением всех данных, подмена тарифа клиентом, изоляция аккаунтов, хранение только HMAC,
 * журнал, админ-команды, миграция старого Plus, лимит изображений, предупреждение о лимите, контракт будущей оплаты. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { startStack, client } = require('./helpers');
const Codes = require('../server/subscription/codes');
const db = require('../server/lib/db');

const SECRET = 'test-access-code-secret-0123456789abcdef';
const PASS = 'Лунный-кот-2026';
const DAY = 86400000;
const PNG = 'data:image/png;base64,' + Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8ffff3f0005fe02fea7d6a5d20000000049454e44ae426082', 'hex').toString('base64');

const PLANS = {
  free: { title: 'Free', daily_requests: 5, per_minute: 100, history_tokens: 3000, max_output_tokens: 400, max_input_chars: 2000, max_images_per_message: 2,
    memory: { items_max: 3, pinned_max: 1, writes_per_minute: 100 }, tools: { notes_max: 2, tasks_max: 2, writes_per_minute: 200 }, vision: { images_daily: 1 } },
  plus: { title: 'Plus', daily_requests: 50, per_minute: 100, history_tokens: 12000, max_output_tokens: 800, max_input_chars: 8000, max_images_per_message: 4,
    memory: { items_max: 10, pinned_max: 5, writes_per_minute: 100 }, tools: { notes_max: 10, tasks_max: 10, writes_per_minute: 200 }, vision: { images_daily: 5 } },
};

const clearThrottle = (S) => S.app.store.db.exec('DELETE FROM auth_throttle');
const tokenFrom = (mail) => { const m = mail.text.match(/https:\/\/wisp\.test\/#\/verify\/([A-Za-z0-9_-]+)/); return m ? m[1] : null; };

async function signUp(S, email) {
  clearThrottle(S);
  const c = client(S.base);
  assert.equal((await c.json('POST', '/api/auth/register', { name: 'Тест', email, password: PASS, password_confirm: PASS })).status, 200);
  const mail = [...S.app.mailer.sent].reverse().find((m) => m.to === email && m.kind === 'verify');
  assert.equal((await c.json('POST', '/api/auth/verify', { token: tokenFrom(mail) })).status, 200);
  const l = await c.json('POST', '/api/auth/login', { email, password: PASS });
  assert.equal(l.status, 200, JSON.stringify(l.data));
  c.id = l.data.user.id;
  return c;
}
const campaign = (S, o) => S.app.subscription.createCampaign({ name: 'Тест', kind: 'plus_30', count: 1, ...o });
const redeem = (c, code) => c.json('POST', '/api/subscription/redeem', { code });
const plan = async (c) => (await c.json('GET', '/api/session')).data.user.plan;

test('Layer 10 · тарифы и коды доступа', async (t) => {
  const S = await startStack({ plans: PLANS, env: { WISP_ACCESS_CODE_SECRET: SECRET } });
  t.after(() => S.close());
  const { store, subscription } = S.app;

  await t.test('Free: страница подписки с сервера, лимиты и сравнение', async () => {
    const g = client(S.base);
    await g.json('POST', '/api/session', {});
    const r = await g.json('GET', '/api/subscription');
    assert.equal(r.status, 200);
    assert.equal(r.data.plan, 'free');
    assert.equal(r.data.subscription.status, 'free');
    assert.equal(r.data.subscription.expires_at, null);
    const ids = r.data.meters.map((m) => m.id);
    for (const id of ['ai', 'voice_stt', 'voice_tts', 'actions', 'memory', 'images']) assert.ok(ids.includes(id), id);
    const ai = r.data.meters.find((m) => m.id === 'ai');
    assert.deepEqual([ai.used, ai.limit, ai.remaining, ai.period], [0, 5, 5, 'day']);
    assert.ok(ai.reset_at > Date.now());
    assert.equal(r.data.meters.find((m) => m.id === 'voice_stt').available, false, 'голос не подключён — так и сказано');
    const chat = r.data.compare.find((x) => x.id === 'chat');
    assert.match(chat.free.text, /5 сообщений/);
    assert.match(chat.plus.text, /50 сообщений/);
    const models = r.data.compare.find((x) => x.id === 'models');
    assert.match(models.plus.text, /Smart/, 'подключённая plus-модель видна');
    assert.ok(r.data.upcoming.some((u) => u.id === 'documents'), 'анализ документов — в «ещё не готово», а не в преимуществах');
    assert.ok(!r.data.compare.some((x) => x.id === 'documents'));
    assert.equal(r.data.billing.available, false);
    assert.equal(r.data.codes.can_redeem, false);
    assert.equal(r.data.codes.reason, 'account_required');
    assert.equal((await client(S.base).json('GET', '/api/subscription')).status, 401, 'без сессии — нельзя');
  });

  await t.test('гость не может активировать код (по умолчанию)', async () => {
    const g = client(S.base);
    await g.json('POST', '/api/session', {});
    const { codes } = campaign(S, {});
    const r = await redeem(g, codes[0].code);
    assert.equal(r.status, 403);
    assert.equal(r.data.error.code, 'account_required');
    assert.equal(subscription.repo.code(codes[0].id).uses, 0, 'код не потрачен');
  });

  const A = await signUp(S, 'anna@example.com');
  const B = await signUp(S, 'boris@example.com');

  await t.test('действующий код → Plus на 30 дней, подтверждение сервера', async () => {
    const { codes } = campaign(S, { kind: 'plus_30', label: 'PLUS' });
    assert.match(codes[0].code, /^WISP-PLUS-[A-HJKMNP-Z2-9]{4}-[A-HJKMNP-Z2-9]{4}-[A-HJKMNP-Z2-9]{4}$/);
    assert.equal(await plan(A), 'free');
    // ввод в нижнем регистре, с пробелами и длинным тире — тот же код
    const typed = codes[0].code.toLowerCase().replace(/-/g, ' — ');
    const r = await redeem(A, typed);
    assert.equal(r.status, 200, JSON.stringify(r.data));
    assert.equal(r.data.redeemed.kind, 'plus_30');
    assert.equal(r.data.plan, 'plus');
    assert.ok(Math.abs(r.data.subscription.expires_at - (Date.now() + 30 * DAY)) < 60000);
    assert.equal(r.data.subscription.days_left, 30);
    assert.equal(await plan(A), 'plus');
    const s = await A.json('GET', '/api/session');
    assert.equal(s.data.models.find((m) => m.id === 'smart').allowed, true, 'Plus-модель открыта сервером');
    assert.equal(s.data.subscription.status, 'active');
    const sub = await A.json('GET', '/api/subscription');
    assert.equal(sub.data.history.length, 1);
    assert.equal(sub.data.history[0].kind, 'plus_30');
    assert.equal(sub.data.meters.find((m) => m.id === 'ai').limit, 50, 'лимиты Plus');
  });

  await t.test('неправильный код и неверный формат', async () => {
    clearThrottle(S);
    const r1 = await redeem(B, 'WISP-PLUS-AAAA-BBBB-CCCC');
    assert.equal(r1.status, 400);
    assert.equal(r1.data.error.code, 'code_invalid');
    assert.equal(typeof r1.data.error.attempts_left, 'number');
    const r2 = await redeem(B, 'hello');
    assert.equal(r2.data.error.code, 'code_format');
    const r3 = await redeem(B, 'WISP-PLUS-AAAA');                 // одна группа: такой формат не принимается
    assert.equal(r3.data.error.code, 'code_format');
    assert.equal((await B.json('POST', '/api/subscription/redeem', {})).status, 400);
    assert.equal(await plan(B), 'free');
  });

  await t.test('просроченный код', async () => {
    clearThrottle(S);
    const { campaign: c, codes } = campaign(S, { redeemUntil: Date.now() + 60000 });
    store.db.prepare('UPDATE access_campaigns SET redeem_until = ? WHERE id = ?').run(Date.now() - 1000, c.id);
    const r = await redeem(B, codes[0].code);
    assert.equal(r.status, 410);
    assert.equal(r.data.error.code, 'code_expired');
    assert.equal(subscription.repo.code(codes[0].id).uses, 0);
    // срок у отдельного кода
    const more = subscription.addCodes(c.id, { count: 1 });
    store.db.prepare('UPDATE access_campaigns SET redeem_until = NULL WHERE id = ?').run(c.id);
    store.db.prepare('UPDATE access_codes SET expires_at = ? WHERE id = ?').run(Date.now() - 1, more.codes[0].id);
    assert.equal((await redeem(B, more.codes[0].code)).data.error.code, 'code_expired');
  });

  await t.test('повторное использование: тот же код, та же серия, чужой одноразовый', async () => {
    clearThrottle(S);
    const { codes } = campaign(S, { kind: 'plus_7', usesPerCode: 5 });
    const ok = await redeem(B, codes[0].code);
    assert.equal(ok.status, 200);
    const exp = ok.data.subscription.expires_at;
    const again = await redeem(B, codes[0].code);
    assert.equal(again.status, 409);
    assert.equal(again.data.error.code, 'code_already_redeemed');
    assert.equal((await B.json('GET', '/api/subscription')).data.subscription.expires_at, exp, 'срок не продлился');
    assert.equal(subscription.repo.code(codes[0].id).uses, 1);
    // второй код той же кампании этому же человеку не положен
    const add = subscription.addCodes(subscription.repo.code(codes[0].id).campaign_id, { count: 1 });
    assert.equal((await redeem(B, add.codes[0].code)).data.error.code, 'code_campaign_used');
    // одноразовый код, уже активированный A, для B
    const single = campaign(S, { kind: 'plus_7' });
    assert.equal((await redeem(A, single.codes[0].code)).status, 200);
    const r = await redeem(B, single.codes[0].code);
    assert.equal(r.data.error.code, 'code_exhausted');
  });

  await t.test('ограничение количества активаций (код на 2 человека)', async () => {
    clearThrottle(S);
    const C = await signUp(S, 'clara@example.com');
    const { codes } = campaign(S, { kind: 'plus_7', usesPerCode: 2 });
    const D = await signUp(S, 'dima@example.com');
    assert.equal((await redeem(C, codes[0].code)).status, 200);
    assert.equal((await redeem(D, codes[0].code)).status, 200);
    const E = await signUp(S, 'egor@example.com');
    const r = await redeem(E, codes[0].code);
    assert.equal(r.status, 409);
    assert.equal(r.data.error.code, 'code_exhausted');
    assert.equal(subscription.repo.code(codes[0].id).uses, 2);
    assert.equal(await plan(E), 'free');
  });

  await t.test('атомарность: 8 одновременных активаций одноразового кода → ровно одна', async () => {
    const users = [];
    for (let i = 0; i < 8; i++) users.push(await signUp(S, `race${i}@example.com`));
    clearThrottle(S);
    const { codes } = campaign(S, { kind: 'plus_30' });
    const res = await Promise.all(users.map((u) => redeem(u, codes[0].code)));
    assert.equal(res.filter((r) => r.status === 200).length, 1);
    assert.equal(res.filter((r) => r.data.error && r.data.error.code === 'code_exhausted').length, 7);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM access_redemptions WHERE code_id = ?').get(codes[0].id).n, 1);
    assert.equal(store.db.prepare("SELECT COUNT(*) AS n FROM entitlements WHERE source = 'access_code' AND source_ref IN (SELECT id FROM access_redemptions WHERE code_id = ?)").get(codes[0].id).n, 1);
    // один человек жмёт «Активировать» 5 раз подряд
    const solo = await signUp(S, 'double@example.com');
    const many = campaign(S, { kind: 'plus_30', usesPerCode: 10 });
    const rr = await Promise.all([1, 2, 3, 4, 5].map(() => redeem(solo, many.codes[0].code)));
    assert.equal(rr.filter((r) => r.status === 200).length, 1);
    assert.equal(subscription.repo.code(many.codes[0].id).uses, 1);
  });

  await t.test('отключение кампании и кода, привязка к пользователю', async () => {
    clearThrottle(S);
    const { campaign: c, codes } = campaign(S, { kind: 'plus_7' });
    subscription.setCampaignEnabled(c.id, false, { reason: 'тест' });
    const F = await signUp(S, 'fedor@example.com');
    assert.equal((await redeem(F, codes[0].code)).data.error.code, 'code_disabled');
    subscription.setCampaignEnabled(c.id, true);
    subscription.setCodeEnabled(codes[0].id, false);
    assert.equal((await redeem(F, codes[0].code)).data.error.code, 'code_disabled');
    subscription.setCodeEnabled(codes[0].id, true);
    clearThrottle(S);
    assert.equal((await redeem(F, codes[0].code)).status, 200);
    // код только для A: для остальных его «нет»
    const bound = campaign(S, { kind: 'plus_7', bindUserId: B.id });
    const G = await signUp(S, 'gleb@example.com');
    assert.equal((await redeem(G, bound.codes[0].code)).data.error.code, 'code_invalid');
    clearThrottle(S);
    assert.equal((await redeem(B, bound.codes[0].code)).status, 200);
  });

  await t.test('сроки складываются; Founder — бессрочно; поверх Founder код не тратится', async () => {
    clearThrottle(S);
    const H = await signUp(S, 'hanna@example.com');
    const a7 = campaign(S, { kind: 'plus_7' }), a30 = campaign(S, { kind: 'plus_30' });
    await redeem(H, a7.codes[0].code);
    const r = await redeem(H, a30.codes[0].code);
    assert.ok(Math.abs(r.data.subscription.expires_at - (Date.now() + 37 * DAY)) < 60000, '7 + 30 дней');
    const f = campaign(S, { kind: 'founder', label: 'FOUNDER', groups: 2 });
    assert.match(f.codes[0].code, /^WISP-FOUNDER-\w{4}-\w{4}$/);
    const fr = await redeem(H, f.codes[0].code);
    assert.equal(fr.data.subscription.status, 'lifetime');
    assert.equal(fr.data.subscription.expires_at, null);
    const a90 = campaign(S, { kind: 'plus_90' });
    const x = await redeem(H, a90.codes[0].code);
    assert.equal(x.data.error.code, 'already_lifetime');
    assert.equal(subscription.repo.code(a90.codes[0].id).uses, 0, 'код не потрачен');
  });

  await t.test('истечение Plus: сразу Free, все данные на месте, лишнее не удаляется', async () => {
    clearThrottle(S);
    const U = await signUp(S, 'ulya@example.com');
    const { codes } = campaign(S, { kind: 'plus_7' });
    assert.equal((await redeem(U, codes[0].code)).status, 200);
    // на Plus — больше, чем позволяет Free
    for (let i = 0; i < 5; i++) assert.equal((await U.json('POST', '/api/notes', { title: `Заметка ${i}`, content: 'текст' })).status, 201);
    const facts = ['Играет на виолончели по вечерам', 'Работает дизайнером интерфейсов', 'Живёт в Казани с котом Барсиком', 'Учит японский язык третий год', 'Предпочитает зелёный чай без сахара'];
    for (const f of facts) assert.equal((await U.json('POST', '/api/memories', { content: f, category: 'other' })).status, 201, f);
    assert.equal((await U.json('POST', '/api/tasks', { title: 'Задача' })).status, 201);
    const chat = await U.stream('/api/conversations/new/messages', { content: 'Привет на Plus', model: 'smart' });
    assert.equal(chat.events[chat.events.length - 1].event, 'done');
    const before = store.stats(U.id);
    // срок закончился (часы «перематываем» в базе)
    store.db.prepare("UPDATE entitlements SET starts_at = ?, expires_at = ? WHERE user_id = ?").run(Date.now() - 8 * DAY, Date.now() - 1000, U.id);
    assert.equal(await plan(U), 'free', 'сервер вернул Free сразу, без фоновой задачи');
    const sub = await U.json('GET', '/api/subscription');
    assert.equal(sub.data.plan, 'free');
    const mem = sub.data.meters.find((m) => m.id === 'memory');
    assert.deepEqual([mem.used, mem.limit, mem.exhausted], [5, 3, true]);
    // Plus-модель снова закрыта
    const conv = chat.events[0].data.conversation.id;
    const r = await U.stream(`/api/conversations/${conv}/messages`, { content: 'ещё', model: 'smart' });
    assert.equal(r.status, 403);
    // данные целы и видны полностью
    assert.deepEqual(store.stats(U.id), before);
    assert.equal((await U.json('GET', '/api/notes')).data.notes.length, 5);
    assert.equal((await U.json('GET', '/api/memories')).status, 200);
    assert.equal((await U.json('GET', `/api/conversations/${conv}`)).status, 200);
    // новое сверх лимита Free — нельзя, старое — можно читать и менять
    assert.equal((await U.json('POST', '/api/notes', { title: 'шестая', content: 'x' })).status, 403);
    // журнал и кеш
    const sw = subscription.sweep();
    assert.ok(sw.users.includes(U.id));
    assert.equal(store.getUser(U.id).plan, 'free');
    assert.ok(subscription.repo.auditList({ action: 'subscription.expired', who: 'user:' + U.id }).length >= 1);
    assert.equal(subscription.sweep().users.includes(U.id), false, 'повторно не логируется');
  });

  await t.test('подмена тарифа на клиенте ничего не даёт', async () => {
    const G = client(S.base);
    await G.json('POST', '/api/session', {});
    const me = await G.json('GET', '/api/session');
    // профиль с plan: plus, поля в теле запросов, «свой» user_id
    await G.json('PUT', '/api/profile', { profile: { schema_version: 1, user: { name: 'Хакер', plan: 'plus', onboarding_completed: true }, meta: {} } });
    assert.equal((await G.json('GET', '/api/profile')).data.plan, 'free');
    const r = await G.stream('/api/conversations/new/messages', { content: 'hi', model: 'smart', plan: 'plus', user: { plan: 'plus' } });
    assert.equal(r.status, 403);
    assert.equal((await G.json('GET', '/api/subscription', undefined, { headers: { 'X-WISP-Plan': 'plus' } })).data.plan, 'free');
    // cookie с выдуманным значением — не сессия
    const fake = client(S.base); fake.cookie = 'wisp_sid=' + 'A'.repeat(43);
    assert.equal((await fake.json('GET', '/api/subscription')).status, 401);
    // активация «для другого пользователя» применяется только к тому, кто в сессии
    const { codes } = campaign(S, { kind: 'plus_7' });
    clearThrottle(S);
    const victim = await signUp(S, 'victim@example.com');
    const before = await plan(victim);
    await victim.json('POST', '/api/subscription/redeem', { code: codes[0].code, user_id: me.data.user.id });
    assert.equal(await plan(G), 'free');
    assert.equal(before, 'free');
    assert.equal(await plan(victim), 'plus');
    // CSRF: без заголовка клиента и с чужого Origin — отказ
    const raw = await fetch(S.base + '/api/subscription/redeem', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: victim.cookie }, body: JSON.stringify({ code: codes[0].code }) });
    assert.equal(raw.status, 403);
    const evil = await victim.json('POST', '/api/subscription/redeem', { code: 'WISP-AAAA-BBBB' }, { headers: { Origin: 'https://evil.example' } });
    assert.equal(evil.status, 403);
  });

  await t.test('изоляция аккаунтов: тариф, история и журнал не пересекаются', async () => {
    const sa = await A.json('GET', '/api/subscription');
    const sb = await B.json('GET', '/api/subscription');
    assert.notDeepEqual(sa.data.history.map((h) => h.id), sb.data.history.map((h) => h.id));
    assert.ok(sa.data.history.every((h) => !sb.data.history.some((x) => x.id === h.id)));
    const fresh = await signUp(S, 'fresh@example.com');
    const sf = await fresh.json('GET', '/api/subscription');
    assert.equal(sf.data.plan, 'free');
    assert.equal(sf.data.history.length, 0);
  });

  await t.test('перебор: блокировка после 5 неверных кодов, даже верный не проходит', async () => {
    clearThrottle(S);
    const Z = await signUp(S, 'zed@example.com');
    clearThrottle(S);
    for (let i = 0; i < 5; i++) {
      const r = await redeem(Z, `WISP-${Codes.generate({ groups: 3 }).slice(5)}`);
      assert.equal(r.data.error.code, 'code_invalid', 'попытка ' + i);
    }
    const { codes } = campaign(S, { kind: 'plus_7' });
    const r = await redeem(Z, codes[0].code);
    assert.equal(r.status, 429);
    assert.equal(r.data.error.code, 'code_locked');
    assert.ok(Number(r.res.headers.get('retry-after')) > 0);
    assert.equal(subscription.repo.code(codes[0].id).uses, 0);
    // блок переживает перезапуск: счётчики в SQLite
    assert.ok(store.db.prepare("SELECT COUNT(*) AS n FROM auth_throttle WHERE key LIKE 'code:%' AND locked_until > ?").get(Date.now()).n >= 1);
    // частота: 10 попыток в минуту на пользователя, даже без ошибок
    clearThrottle(S);
    let limited = 0;
    for (let i = 0; i < 12; i++) { const x = await redeem(Z, 'hello'); if (x.data.error.code === 'rate_limited' || x.data.error.code === 'code_locked') limited++; }
    assert.ok(limited >= 1);
    // в журнале — отказы с причинами
    const denied = subscription.repo.auditList({ action: 'access_code.redeem', who: 'user:' + Z.id, limit: 50 }).filter((x) => x.result === 'denied');
    assert.ok(denied.some((x) => x.reason === 'code_invalid'));
    assert.ok(denied.some((x) => x.reason === 'locked'));
  });

  await t.test('в базе нет открытых кодов: только HMAC с секретом сервера', async () => {
    const { codes } = campaign(S, { kind: 'plus_7', count: 3 });
    const dump = [];
    for (const { name } of store.db.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all()) {
      for (const row of store.db.prepare(`SELECT * FROM "${name}"`).all()) dump.push(JSON.stringify(row));
    }
    const all = dump.join('\n');
    for (const c of codes) {
      assert.ok(!all.includes(c.code), 'открытого кода нет');
      assert.ok(!all.includes(c.code.split('-').slice(-3).join('-')), 'и его тела тоже');
      const row = store.db.prepare('SELECT code_hash FROM access_codes WHERE id = ?').get(c.id);
      assert.equal(row.code_hash, Codes.hash(SECRET, c.code));
      assert.notEqual(row.code_hash, require('node:crypto').createHash('sha256').update(c.code).digest('hex'));
    }
    assert.ok(!fs.readdirSync(S.dir).includes('access-code.secret'), 'секрет из переменной окружения не пишется на диск');
  });

  await t.test('генератор: CSPRNG-алфавит без похожих символов, канонизация', () => {
    const seen = new Set();
    for (let i = 0; i < 2000; i++) {
      const c = Codes.generate({ label: 'EARLY', groups: 3 });
      assert.match(c, /^WISP-EARLY(-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{4}){3}$/);
      seen.add(c);
    }
    assert.equal(seen.size, 2000);
    assert.equal(Codes.canonical(' wisp_early 7kqm–h3td—x9ra '), 'WISP-EARLY-7KQM-H3TD-X9RA');
    assert.equal(Codes.canonical('WISP-0OIL-AAAA'), null, '0, O, I, L не бывает в коде');
    assert.equal(Codes.canonical('WISPABCDEFGH'), null);
    assert.equal(Codes.canonical('X'.repeat(500)), null);
  });

  await t.test('лимит изображений и предупреждение о приближении к лимиту', async () => {
    const G = client(S.base);
    await G.json('POST', '/api/session', {});
    const one = await G.stream('/api/conversations/new/messages', { content: 'что тут', attachments: [{ data: PNG }] });
    assert.equal(one.events[one.events.length - 1].event, 'done');
    const two = await G.stream('/api/conversations/new/messages', { content: 'а тут', attachments: [{ data: PNG }] });
    assert.equal(two.status, 429);
    assert.equal(two.error.error.code, 'limit_images');
    for (let i = 0; i < 2; i++) await G.stream('/api/conversations/new/messages', { content: 'ещё ' + i });
    const sub = await G.json('GET', '/api/subscription');
    const ai = sub.data.meters.find((m) => m.id === 'ai');
    assert.equal(ai.used, 3);
    assert.equal(ai.warn, false);
    await G.stream('/api/conversations/new/messages', { content: 'и ещё' });
    const ai2 = (await G.json('GET', '/api/subscription')).data.meters.find((m) => m.id === 'ai');
    assert.deepEqual([ai2.used, ai2.remaining, ai2.warn], [4, 1, true], '80%: предупреждение');
    const img = (await G.json('GET', '/api/subscription')).data.meters.find((m) => m.id === 'images');
    assert.deepEqual([img.used, img.limit, img.exhausted], [1, 1, true]);
  });

  await t.test('админ: выдача и отзыв Plus, совместимость setPlan, журнал', async () => {
    const W = await signUp(S, 'wanda@example.com');
    subscription.grant(W.id, { days: 7, actor: 'admin:test' });
    assert.equal(await plan(W), 'plus');
    subscription.grant(W.id, { days: 3, actor: 'admin:test' });
    const st = subscription.state(W.id);
    assert.ok(Math.abs(st.expires_at - (Date.now() + 10 * DAY)) < 60000);
    subscription.revoke(W.id, { actor: 'admin:test', reason: 'тест' });
    assert.equal(await plan(W), 'free');
    store.setPlan(W.id, 'plus');
    assert.equal(subscription.state(W.id).status, 'lifetime');
    store.setPlan(W.id, 'free');
    assert.equal(await plan(W), 'free');
    const acts = subscription.repo.auditList({ who: 'user:' + W.id, limit: 20 }).map((x) => x.action);
    assert.ok(acts.includes('subscription.grant') && acts.includes('subscription.revoke'));
  });

  await t.test('будущая оплата: период по ссылке провайдера идемпотентен, возврат отзывает', async () => {
    const P = await signUp(S, 'payer@example.com');
    const t0 = Date.now();
    const id1 = subscription.applyExternalPeriod({ userId: P.id, source: 'payment', sourceRef: 'fake:in_1', startsAt: t0, expiresAt: t0 + 30 * DAY });
    const id2 = subscription.applyExternalPeriod({ userId: P.id, source: 'payment', sourceRef: 'fake:in_1', startsAt: t0, expiresAt: t0 + 31 * DAY });
    assert.equal(id1, id2, 'повтор вебхука — та же запись');
    assert.equal(store.db.prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id = ?").get(P.id).n, 1);
    assert.equal(await plan(P), 'plus');
    subscription.revokeExternalPeriod({ source: 'payment', sourceRef: 'fake:in_1', reason: 'refund' });
    assert.equal(await plan(P), 'free');
    assert.throws(() => subscription.applyExternalPeriod({ userId: A.id, source: 'payment', sourceRef: 'fake:in_1', startsAt: t0, expiresAt: t0 + DAY }), /another user/);
  });

  await t.test('удаление аккаунта: периоды удаляются, история кодов обезличивается', async () => {
    const X = await signUp(S, 'xenia@example.com');
    const { codes } = campaign(S, { kind: 'plus_7' });
    clearThrottle(S);
    assert.equal((await redeem(X, codes[0].code)).status, 200);
    assert.equal((await X.json('POST', '/api/account/delete', { password: PASS })).status, 200);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM entitlements WHERE user_id = ?').get(X.id).n, 0);
    const red = store.db.prepare('SELECT user_id FROM access_redemptions WHERE code_id = ?').get(codes[0].id);
    assert.equal(red.user_id, null);
    assert.equal(subscription.repo.code(codes[0].id).uses, 1, 'активация остаётся израсходованной');
  });

  await t.test('CLI администратора: создать кампанию, коды работают на сервере', async () => {
    const env = { ...process.env, WISP_DATA_DIR: S.dir, WISP_ACCESS_CODE_SECRET: SECRET, WISP_MODELS_FILE: path.join(S.dir, 'models.json'), WISP_PLANS_FILE: path.join(S.dir, 'plans.json'), WISP_LOG_LEVEL: 'error' };
    const run = (...a) => execFileSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'server', 'admin.js'), ...a], { env, encoding: 'utf8' });
    const out = run('campaign', 'create', '--name', 'CLI', '--type', 'plus_90', '--count', '2', '--label', 'EARLY', '--expires', '2099-01-01');
    const codes = out.match(/WISP-EARLY-[A-Z0-9-]+/g);
    assert.equal(codes.length, 2);
    clearThrottle(S);
    const K = await signUp(S, 'kirill@example.com');
    const r = await redeem(K, codes[0]);
    assert.equal(r.status, 200);
    assert.equal(r.data.redeemed.added_days, 90);
    assert.match(run('campaign', 'list'), /CLI/);
    assert.match(run('redemptions', '--user', 'kirill@example.com'), /plus_90/);
    assert.match(run('code', 'find', codes[0]), /1\/1/);
    assert.match(run('sub', 'kirill@example.com'), /Plus до/);
    const file = path.join(S.dir, 'out.csv');
    run('codes', 'add', subscription.repo.redemptions({ userId: K.id })[0].campaign_id, '--count', '3', '--out', file);
    assert.equal(fs.readFileSync(file, 'utf8').trim().split('\n').length, 4);
    assert.equal(fs.statSync(file).mode & 0o777, 0o600);
    assert.match(run('audit', '--action', 'campaign.*'), /campaign.create/);
  });

  await t.test('коды для гостей включаются только явно, перенос в аккаунт сохраняет Plus', async () => {
    const S2 = await startStack({ plans: PLANS, env: { WISP_ACCESS_CODE_SECRET: SECRET, WISP_ACCESS_CODES_GUESTS: '1' } });
    try {
      const g = client(S2.base);
      await g.json('POST', '/api/session', {});
      const { codes } = S2.app.subscription.createCampaign({ name: 'g', kind: 'plus_30', count: 1 });
      assert.equal((await g.json('GET', '/api/subscription')).data.codes.can_redeem, true);
      assert.equal((await redeem(g, codes[0].code)).status, 200);
      const guestId = (await g.json('GET', '/api/session')).data.user.id;
      assert.equal((await g.json('POST', '/api/notes', { title: 'гость', content: 'x' })).status, 201);
      // тот же браузер регистрируется и переносит данные гостя
      clearThrottle(S2);
      await g.json('POST', '/api/auth/register', { name: 'Г', email: 'guest@example.com', password: PASS, password_confirm: PASS });
      const mail = [...S2.app.mailer.sent].reverse().find((m) => m.to === 'guest@example.com');
      await g.json('POST', '/api/auth/verify', { token: tokenFrom(mail) });
      const l = await g.json('POST', '/api/auth/login', { email: 'guest@example.com', password: PASS });
      assert.equal(l.data.user.plan, 'free', 'аккаунт отдельно от гостя');
      assert.equal((await g.json('POST', '/api/auth/guest/merge', { confirm: 'merge' })).status, 200);
      assert.equal(await plan(g), 'plus', 'Plus гостя перешёл в аккаунт');
      assert.equal(S2.app.store.getUser(guestId), null);
    } finally { await S2.close(); }
  });
});

test('Layer 10 · миграция: старый Plus (users.plan) становится бессрочным периодом', () => {
  const dir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'wisp-mig-'));
  const file = path.join(dir, 'wisp.db');
  let st = db.open(file);
  const u = st.createUser();
  st.db.prepare("UPDATE users SET plan = 'plus' WHERE id = ?").run(u.id);
  st.db.exec("DELETE FROM entitlements; DELETE FROM meta WHERE key = 'v8_legacy_plans'; UPDATE meta SET value = '7' WHERE key = 'schema_version'");
  st.close();
  st = db.open(file);
  const e = st.db.prepare('SELECT source, expires_at FROM entitlements WHERE user_id = ?').all(u.id);
  assert.deepEqual(e.map((x) => [x.source, x.expires_at]), [['legacy', null]]);
  assert.equal(st.db.prepare("SELECT value FROM meta WHERE key = 'schema_version'").get().value, '8');
  st.close();
  st = db.open(file);
  assert.equal(st.db.prepare('SELECT COUNT(*) AS n FROM entitlements').get().n, 1, 'миграция выполняется один раз');
  st.close();
  fs.rmSync(dir, { recursive: true, force: true });
});
