/* WISP · Tests · Layer 9 · Accounts & Authentication (сервер, без интернета)
 * Регистрация → письмо → вход до подтверждения запрещён → подтверждение → вход → данные → выход → повторный вход.
 * Восстановление пароля, смена пароля, сроки ссылок, ограничение попыток, повторная регистрация без утечки,
 * изоляция двух аккаунтов во всех слоях (чаты, память, заметки, задачи, напоминания, события, действия AI, профиль),
 * перенос данных гостя только по согласию, подмена user_id, хранение паролей, SMTP-транспорт. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const net = require('node:net');
const path = require('node:path');
const { startStack, client, text } = require('./helpers');
const { Mailer, smtpSend, buildMessage } = require('../server/auth/mailer');
const Password = require('../server/auth/password');
const Rules = require('../src/auth/rules');

const PASS = 'Лунный-кот-2026';
const PASS_B = 'tea Kettle river 77';
const soon = (d) => new Date(Date.now() + d * 86400000).toISOString().slice(0, 10);
const call = (name, args) => `[[call:${name} ${JSON.stringify(args)}]]`;

const tokenFrom = (mail, kind) => {
  const m = mail.text.match(new RegExp(`https://wisp\\.test/#/${kind}/([A-Za-z0-9_-]+)`));
  return m ? m[1] : null;
};
const lastMail = (S, to, kind) => [...S.app.mailer.sent].reverse().find((m) => m.to === to && (!kind || m.kind === kind));

/* Все тестовые клиенты ходят с 127.0.0.1: лимиты по адресу общие. Сбрасываем их там, где проверяем не лимиты. */
const clearThrottle = (S) => S.app.store.db.exec('DELETE FROM auth_throttle');

/* Полный путь нового аккаунта: регистрация → подтверждение → вход. Возвращает клиента с сессией аккаунта. */
async function signUp(S, { name, email, password }) {
  clearThrottle(S);
  const c = client(S.base);
  const r = await c.json('POST', '/api/auth/register', { name, email, password, password_confirm: password });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const token = tokenFrom(lastMail(S, email, 'verify'), 'verify');
  assert.ok(token, 'в письме есть ссылка подтверждения');
  assert.equal((await c.json('POST', '/api/auth/verify', { token })).status, 200);
  const l = await c.json('POST', '/api/auth/login', { email, password });
  assert.equal(l.status, 200, JSON.stringify(l.data));
  return c;
}

test('Layer 9 · аккаунты и авторизация', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const { store } = S.app;

  await t.test('правила: почта, пароль, имя (общие для клиента и сервера)', () => {
    assert.equal(Rules.emailError('anna@example.com'), null);
    assert.equal(Rules.emailError(' Anna@Example.COM '), null);
    assert.equal(Rules.normalizeEmail(' Anna@Example.COM '), 'anna@example.com');
    for (const bad of ['', 'anna', 'anna@', '@x.com', 'a@b', 'a..b@x.com', 'a@x..com', 'a b@x.com', 'a@x.c']) assert.ok(Rules.emailError(bad), bad);
    assert.equal(Rules.passwordCheck('short1!').error, 'password_too_short');
    assert.equal(Rules.passwordCheck('password123').error, 'password_common');
    assert.equal(Rules.passwordCheck('12345678').error, 'password_common');
    assert.equal(Rules.passwordCheck('abcdefghij').error, 'password_sequence');
    assert.equal(Rules.passwordCheck('aaaaaaaaaa').error, 'password_sequence');
    assert.equal(Rules.passwordCheck('lowercase1').error, 'password_weak');
    assert.ok(Rules.passwordCheck('lowercaseonlyphrase').ok, '12+ символов — любые');
    assert.equal(Rules.passwordCheck('annasmith2026!', { email: 'annasmith@x.com' }).error, 'password_personal');
    assert.ok(Rules.passwordCheck(PASS).ok);
    assert.ok(Rules.passwordCheck(PASS_B).ok);
    assert.ok(Rules.passwordCheck('Kq7#vbn2').ok, '8 символов, 4 вида');
    assert.ok(Rules.passwordCheck('correct horse battery').score >= 3);
    assert.equal(Rules.nameError('  '), 'name_required');
    assert.equal(Rules.nameError('Анна-Мария'), null);
  });

  await t.test('хеширование пароля: scrypt, соль, без открытого текста', async () => {
    const h1 = await Password.hash(PASS), h2 = await Password.hash(PASS);
    assert.match(h1, /^scrypt\$1\$ln=15,r=8,p=3\$/);
    assert.notEqual(h1, h2, 'у каждого хеша своя соль');
    assert.ok(await Password.verify(PASS, h1));
    assert.ok(!(await Password.verify(PASS + 'x', h1)));
    assert.ok(!(await Password.verify(PASS, 'plain:' + PASS)));
    assert.ok(!h1.includes(PASS));
  });

  await t.test('конфигурация сервера для клиента', async () => {
    const c = client(S.base);
    const r = await c.json('GET', '/api/auth/config');
    assert.equal(r.status, 200);
    assert.equal(r.data.registration, true);
    assert.equal(r.data.guest_mode, true);
  });

  const A = { name: 'Гера', email: 'gera@example.com', password: PASS };
  let a;

  await t.test('регистрация: проверка полей сервером', async () => {
    const c = client(S.base);
    const cases = [
      [{ ...A, email: 'gera@' }, 'email_invalid', 'email'],
      [{ ...A, name: ' ' }, 'name_required', 'name'],
      [{ ...A, password: 'qwerty123' }, 'password_common', 'password'],
      [{ ...A, password_confirm: PASS + '!' }, 'password_mismatch', 'password_confirm'],
    ];
    for (const [body, code, field] of cases) {
      const r = await c.json('POST', '/api/auth/register', { password_confirm: body.password, ...body });
      assert.equal(r.status, 400, code);
      assert.equal(r.data.error.code, code);
      assert.equal(r.data.error.field, field);
      assert.ok(r.data.error.message.length > 10, 'сообщение объясняет, что делать');
    }
    assert.equal(store.getUserByEmail(A.email), null, 'ничего не создано');
  });

  await t.test('регистрация → письмо → вход до подтверждения запрещён → подтверждение → вход', async () => {
    const c = client(S.base);
    const r = await c.json('POST', '/api/auth/register', { ...A, email: ' Gera@Example.com ', password_confirm: PASS });
    assert.equal(r.status, 200);
    assert.deepEqual([r.data.ok, r.data.email, r.data.email_sent], [true, A.email, true]);
    assert.equal(c.jar.size, 0, 'регистрация не выдаёт сессию');
    const u = store.getUserByEmail(A.email);
    assert.ok(u && !u.email_verified_at);
    assert.match(u.password_hash, /^scrypt\$/);
    // пароль нигде в базе в открытом виде
    store.db.exec('PRAGMA wal_checkpoint(FULL)');
    const raw = fs.readFileSync(path.join(S.dir, 'wisp.db'));
    assert.ok(!raw.includes(Buffer.from(PASS, 'utf8')), 'пароля нет в файле базы');

    const mail = lastMail(S, A.email, 'verify');
    assert.ok(mail, 'письмо подтверждения отправлено');
    assert.match(mail.subject, /Подтверди почту/);
    assert.match(mail.html, /#050508/);
    const token = tokenFrom(mail, 'verify');

    // вход до подтверждения: верный пароль → «почта не подтверждена», неверный → общее «неверная почта или пароль»
    let l = await c.json('POST', '/api/auth/login', { email: A.email, password: PASS });
    assert.equal(l.status, 403);
    assert.equal(l.data.error.code, 'email_not_verified');
    assert.equal(c.jar.size, 0);
    l = await c.json('POST', '/api/auth/login', { email: A.email, password: 'Wrong-pass-123' });
    assert.equal(l.status, 401);
    assert.equal(l.data.error.code, 'invalid_credentials');

    // нажатие «я подтвердил» на клиенте ничего не меняет: статус меняет только ссылка
    assert.equal((await c.json('POST', '/api/auth/verify', { token: 'x'.repeat(43) })).data.error.code, 'token_invalid');
    assert.equal((await c.json('POST', '/api/auth/verify', {})).status, 400);
    assert.ok(!store.getUserByEmail(A.email).email_verified_at);

    const v = await c.json('POST', '/api/auth/verify', { token });
    assert.equal(v.status, 200);
    assert.deepEqual([v.data.ok, v.data.email, v.data.already], [true, A.email, false]);
    assert.ok(store.getUserByEmail(A.email).email_verified_at);
    const again = await c.json('POST', '/api/auth/verify', { token });
    assert.equal(again.status, 200);
    assert.equal(again.data.already, true);

    l = await c.json('POST', '/api/auth/login', { email: 'GERA@example.com', password: PASS });
    assert.equal(l.status, 200, JSON.stringify(l.data));
    assert.equal(l.data.kind, 'account');
    assert.equal(l.data.account.email, A.email);
    assert.equal(l.data.account.name, 'Гера');
    assert.equal(l.data.account.email_verified, true);
    assert.equal(l.data.guest, null);
    assert.ok(c.jar.has('wisp_sid'));
    const s = await c.json('GET', '/api/session');
    assert.equal(s.status, 200);
    assert.equal(s.data.kind, 'account');
    const prof = await c.json('GET', '/api/profile');
    assert.equal(prof.data.profile.user.name, 'Гера', 'имя аккаунта хранится в профиле Layer 6');
    a = c;
  });

  await t.test('повторная регистрация занятого адреса: ответ тот же, владельцу письмо, пароль не меняется', async () => {
    clearThrottle(S);
    const c = client(S.base);
    const before = store.getUserByEmail(A.email).password_hash;
    const n = S.app.mailer.sent.length;
    const r = await c.json('POST', '/api/auth/register', { name: 'Злоумышленник', email: A.email, password: 'Another-pass-99', password_confirm: 'Another-pass-99' });
    assert.equal(r.status, 200);
    assert.deepEqual(Object.keys(r.data).sort(), ['email', 'email_sent', 'ok', 'resend_after']);
    assert.equal(store.getUserByEmail(A.email).password_hash, before);
    const m = S.app.mailer.sent.slice(n).find((x) => x.to === A.email);
    assert.equal(m.kind, 'exists');
    const l = await c.json('POST', '/api/auth/login', { email: A.email, password: 'Another-pass-99' });
    assert.equal(l.status, 401);
  });

  await t.test('данные аккаунта: чат, память, заметки, задачи, напоминания, события, действия AI, профиль', async () => {
    clearThrottle(S);
    const msg = await a.stream('/api/conversations/new/messages', { content: 'Привет ' + call('create_task', { title: 'Купить молоко' }) + call('remember', { content: 'Любит зелёный чай', category: 'preferences' }) });
    assert.equal(msg.status, 200);
    assert.ok(msg.events.some((e) => e.event === 'done'));
    assert.equal((await a.json('POST', '/api/notes', { title: 'Идея', content: 'Секретная идея Геры' })).status, 201);
    assert.ok([200, 201].includes((await a.json('POST', '/api/reminders', { title: 'Позвонить маме', date: soon(2), time: '10:00', timezone: 'Europe/Moscow' })).status));
    assert.ok([200, 201].includes((await a.json('POST', '/api/events', { title: 'Встреча', date: soon(3), start_time: '12:00' })).status));
    const p = await a.json('PATCH', '/api/account/profile', { name: 'Гера Л.' });
    assert.equal(p.status, 200);
    assert.equal(p.data.profile.user.name, 'Гера Л.');
    const st = store.stats(store.getUserByEmail(A.email).id);
    assert.ok(st.conversations >= 1 && st.notes === 1 && st.tasks === 1 && st.reminders === 1 && st.events === 1 && st.memories === 1, JSON.stringify(st));
  });

  await t.test('профиль: имя и аватар сохраняются на сервере, мусор отклоняется', async () => {
    const tiny = 'data:image/png;base64,' + Buffer.from('89504e470d0a1a0a', 'hex').toString('base64');
    let r = await a.json('PATCH', '/api/account/profile', { avatar: tiny });
    assert.equal(r.status, 200);
    assert.equal(r.data.profile.user.avatar, tiny);
    r = await a.json('PATCH', '/api/account/profile', { avatar: 'javascript:alert(1)' });
    assert.equal(r.status, 400);
    assert.equal(r.data.error.code, 'bad_avatar');
    r = await a.json('PATCH', '/api/account/profile', { name: '   ' });
    assert.equal(r.data.error.code, 'name_required');
    r = await a.json('PATCH', '/api/account/profile', { avatar: null });
    assert.equal(r.data.profile.user.avatar, null);
    assert.equal(r.data.profile.user.name, 'Гера Л.', 'имя не потерялось');
  });

  let B;
  await t.test('изоляция: второй аккаунт не видит и не может изменить данные первого', async () => {
    B = await signUp(S, { name: 'Бета', email: 'beta@example.org', password: PASS_B });
    const ga = (u) => a.json('GET', u), gb = (u) => B.json('GET', u);
    const convA = (await ga('/api/conversations')).data.conversations;
    const noteA = (await ga('/api/notes')).data.notes[0];
    const taskA = (await ga('/api/tasks')).data.tasks[0];
    const remA = (await ga('/api/reminders')).data.reminders[0];
    const memA = (await ga('/api/memories')).data.memories[0];
    assert.ok(convA.length && noteA && taskA && remA && memA);
    assert.equal((await gb('/api/conversations')).data.conversations.length, 0);
    assert.equal((await gb('/api/notes')).data.notes.length, 0);
    assert.equal((await gb('/api/tasks')).data.tasks.length, 0);
    assert.equal((await gb('/api/reminders')).data.reminders.length, 0);
    assert.equal((await gb('/api/memories')).data.memories.length, 0);
    assert.equal((await gb('/api/profile')).data.profile.user.name, 'Бета');
    assert.equal((await gb(`/api/conversations/${convA[0].id}`)).status, 404);
    assert.equal((await gb(`/api/notes/${noteA.id}`)).status, 404);
    assert.equal((await B.json('PATCH', `/api/notes/${noteA.id}`, { content: 'взлом' })).status, 404);
    assert.equal((await B.json('DELETE', `/api/tasks/${taskA.id}`)).status, 404);
    assert.equal((await B.json('DELETE', `/api/memories/${memA.id}`)).status, 404);
    assert.equal((await B.json('DELETE', `/api/conversations/${convA[0].id}`)).status, 404);
    // подмена user_id в теле и в query игнорируется
    const uidA = store.getUserByEmail(A.email).id;
    await B.json('POST', `/api/notes?user_id=${uidA}`, { title: 'B', content: 'Заметка Беты', user_id: uidA, userId: uidA });
    assert.equal((await ga('/api/notes')).data.notes.length, 1, 'у A по-прежнему одна заметка');
    assert.equal((await gb('/api/notes')).data.notes.length, 1);
    // действия AI (журнал) тоже свои
    const convB = await B.stream('/api/conversations/new/messages', { content: 'Удали задачу Купить молоко ' + call('delete_task', { id: taskA.id }) });
    assert.equal(convB.status, 200);
    assert.equal((await ga('/api/tasks')).data.tasks.length, 1, 'чужую задачу через AI не удалить');
  });

  await t.test('выход: сессия удалена на сервере, старая cookie больше не работает', async () => {
    const saved = a.cookie;
    const r = await a.json('POST', '/api/auth/logout', {});
    assert.equal(r.status, 200);
    assert.ok(!a.jar.has('wisp_sid'), 'cookie стёрта');
    assert.equal((await a.json('GET', '/api/notes')).status, 401);
    const thief = client(S.base); thief.cookie = saved;
    assert.equal((await thief.json('GET', '/api/notes')).status, 401, 'украденная до выхода cookie бесполезна');
    assert.equal((await thief.json('GET', '/api/session')).status, 401);
  });

  await t.test('повторный вход: все данные на месте', async () => {
    const c = client(S.base);
    const l = await c.json('POST', '/api/auth/login', { email: A.email, password: PASS });
    assert.equal(l.status, 200);
    assert.equal(l.data.account.name, 'Гера Л.');
    assert.equal((await c.json('GET', '/api/notes')).data.notes[0].content, 'Секретная идея Геры');
    assert.equal((await c.json('GET', '/api/tasks')).data.tasks.length, 1);
    assert.equal((await c.json('GET', '/api/memories')).data.memories.length, 1);
    assert.ok((await c.json('GET', '/api/conversations')).data.conversations.length >= 1);
    a = c;
  });

  await t.test('ограничение попыток входа (переживает перезапуск: счётчики в базе)', async () => {
    const c = client(S.base);
    const email = 'beta@example.org';
    let last;
    for (let i = 0; i < 5; i++) last = await c.json('POST', '/api/auth/login', { email, password: 'nope-' + i + 'Xx' });
    assert.equal(last.status, 401);
    const blocked = await c.json('POST', '/api/auth/login', { email, password: PASS_B });
    assert.equal(blocked.status, 429, 'даже верный пароль после 5 ошибок подряд');
    assert.equal(blocked.data.error.code, 'too_many_attempts');
    assert.ok(blocked.data.error.retry_after > 0);
    assert.match(blocked.res.headers.get('retry-after'), /^\d+$/);
    // подделать адрес заголовком X-Forwarded-For нельзя (без WISP_TRUST_PROXY он не учитывается)
    const spoof = await client(S.base).json('POST', '/api/auth/login', { email, password: PASS_B }, { headers: { 'X-Forwarded-For': '203.0.113.9' } });
    assert.equal(spoof.status, 429);
    // несуществующий адрес: тот же ответ, что и неверный пароль
    const ghost = await client(S.base).json('POST', '/api/auth/login', { email: 'nobody@example.net', password: 'Whatever-123' });
    assert.equal(ghost.status, 401);
    assert.equal(ghost.data.error.code, 'invalid_credentials');
    for (const k of store.db.prepare("SELECT key FROM auth_throttle WHERE key LIKE 'login:%'").all()) store.throttleDelete(k.key);
  });

  await t.test('восстановление пароля: ответ не раскрывает адрес, ссылка одноразовая, сеансы завершаются', async () => {
    clearThrottle(S);
    const c = client(S.base);
    const n = S.app.mailer.sent.length;
    const ghost = await c.json('POST', '/api/auth/password/forgot', { email: 'nobody@example.net' });
    const real = await c.json('POST', '/api/auth/password/forgot', { email: A.email });
    assert.equal(ghost.status, 200); assert.equal(real.status, 200);
    assert.deepEqual(Object.keys(ghost.data).sort(), Object.keys(real.data).sort());
    await S.app.accounts.flush();
    const sent = S.app.mailer.sent.slice(n);
    assert.equal(sent.length, 1, 'письмо только существующему адресу');
    const token = tokenFrom(sent[0], 'reset');
    assert.ok(token);
    const chk = await c.json('POST', '/api/auth/password/check', { token });
    assert.equal(chk.status, 200);
    assert.match(chk.data.email_hint, /^ge•+@example\.com$/);
    const weak = await c.json('POST', '/api/auth/password/reset', { token, password: '12345678', password_confirm: '12345678' });
    assert.equal(weak.data.error.code, 'password_common');
    const NEW = 'Новый-пароль-Геры-7';
    const r = await c.json('POST', '/api/auth/password/reset', { token, password: NEW, password_confirm: NEW });
    assert.equal(r.status, 200);
    assert.equal((await a.json('GET', '/api/notes')).status, 401, 'старый сеанс завершён');
    assert.equal((await c.json('POST', '/api/auth/password/reset', { token, password: NEW + '1', password_confirm: NEW + '1' })).data.error.code, 'token_used');
    assert.equal((await c.json('POST', '/api/auth/login', { email: A.email, password: PASS })).status, 401, 'старый пароль больше не подходит');
    const l = await c.json('POST', '/api/auth/login', { email: A.email, password: NEW });
    assert.equal(l.status, 200);
    await S.app.accounts.flush();
    assert.equal(lastMail(S, A.email).kind, 'changed', 'уведомление о смене пароля');
    a = c; A.password = NEW;
  });

  await t.test('просроченные ссылки: подтверждение и сброс → 410 и понятный следующий шаг', async () => {
    clearThrottle(S);
    const c = client(S.base);
    // просроченное подтверждение
    const email = 'late@example.com';
    await c.json('POST', '/api/auth/register', { name: 'Поздний', email, password: PASS_B, password_confirm: PASS_B });
    const vt = tokenFrom(lastMail(S, email, 'verify'), 'verify');
    store.db.prepare("UPDATE auth_tokens SET expires_at = ? WHERE purpose = 'verify'").run(Date.now() - 1000);
    const v = await c.json('POST', '/api/auth/verify', { token: vt });
    assert.equal(v.status, 410);
    assert.equal(v.data.error.code, 'token_expired');
    assert.equal(v.data.error.email, email, 'адрес для кнопки «отправить снова»');
    assert.ok(!store.getUserByEmail(email).email_verified_at);
    // письмо ещё раз: не чаще раза в минуту
    const tooSoon = await c.json('POST', '/api/auth/verify/resend', { email });
    assert.equal(tooSoon.status, 429);
    store.throttleDelete('mail:gap:' + require('../server/auth/throttle').emailKey(email));
    const rs = await c.json('POST', '/api/auth/verify/resend', { email });
    assert.equal(rs.status, 200);
    const ghostRs = await c.json('POST', '/api/auth/verify/resend', { email: 'ghost@example.com' });
    assert.equal(ghostRs.status, 200, 'для несуществующего адреса ответ тот же');
    await S.app.accounts.flush();
    const vt2 = tokenFrom(lastMail(S, email, 'verify'), 'verify');
    assert.notEqual(vt2, vt);
    assert.equal((await c.json('POST', '/api/auth/verify', { token: vt2 })).status, 200);
    // просроченный сброс
    store.throttleDelete('mail:gap:' + require('../server/auth/throttle').emailKey(email));
    await c.json('POST', '/api/auth/password/forgot', { email });
    await S.app.accounts.flush();
    const rt = tokenFrom(lastMail(S, email, 'reset'), 'reset');
    store.db.prepare("UPDATE auth_tokens SET expires_at = ? WHERE purpose = 'reset'").run(Date.now() - 1000);
    assert.equal((await c.json('POST', '/api/auth/password/check', { token: rt })).status, 410);
    assert.equal((await c.json('POST', '/api/auth/password/reset', { token: rt, password: 'Zz-new-pass-55', password_confirm: 'Zz-new-pass-55' })).status, 410);
  });

  await t.test('захват адреса заранее: пароль задаёт регистрация, по ссылке которой подтвердили почту', async () => {
    clearThrottle(S);
    const email = 'victim@example.com';
    const attacker = client(S.base), victim = client(S.base);
    await attacker.json('POST', '/api/auth/register', { name: 'X', email, password: 'Attacker-pass-1', password_confirm: 'Attacker-pass-1' });
    store.throttleDelete('mail:gap:' + require('../server/auth/throttle').emailKey(email));
    await victim.json('POST', '/api/auth/register', { name: 'Вика', email, password: 'Moonlight-pass-2026', password_confirm: 'Moonlight-pass-2026' });
    const victimToken = tokenFrom(lastMail(S, email, 'verify'), 'verify');
    assert.equal((await victim.json('POST', '/api/auth/verify', { token: victimToken })).status, 200);
    assert.equal((await attacker.json('POST', '/api/auth/login', { email, password: 'Attacker-pass-1' })).status, 401);
    assert.equal((await victim.json('POST', '/api/auth/login', { email, password: 'Moonlight-pass-2026' })).status, 200);
    assert.equal((await victim.json('GET', '/api/profile')).data.profile.user.name, 'Вика');
  });

  await t.test('истёкшая сессия: 401, данные не отдаются', async () => {
    const c = client(S.base);
    await c.json('POST', '/api/auth/login', { email: A.email, password: A.password });
    store.db.prepare('UPDATE sessions SET expires_at = ? WHERE user_id = ?').run(Date.now() - 1, store.getUserByEmail(A.email).id);
    const r = await c.json('GET', '/api/notes');
    assert.equal(r.status, 401);
    assert.equal(r.data.error.code, 'unauthorized');
    assert.equal((await c.json('GET', '/api/session')).status, 401);
    // абсолютный срок
    const d = client(S.base);
    await d.json('POST', '/api/auth/login', { email: A.email, password: A.password });
    store.db.prepare('UPDATE sessions SET absolute_expires_at = ? WHERE user_id = ?').run(Date.now() - 1, store.getUserByEmail(A.email).id);
    assert.equal((await d.json('GET', '/api/notes')).status, 401);
  });

  await t.test('смена пароля в аккаунте: текущий пароль обязателен, другие устройства выходят', async () => {
    const phone = client(S.base), laptop = client(S.base);
    await phone.json('POST', '/api/auth/login', { email: A.email, password: A.password });
    await laptop.json('POST', '/api/auth/login', { email: A.email, password: A.password });
    const sessions = await phone.json('GET', '/api/auth/sessions');
    assert.ok(sessions.data.sessions.length >= 2);
    assert.equal(sessions.data.sessions.filter((x) => x.current).length, 1);
    const wrong = await phone.json('POST', '/api/auth/password/change', { current: 'nope', password: 'Changed-pass-99', password_confirm: 'Changed-pass-99' });
    assert.equal(wrong.status, 400);
    assert.equal(wrong.data.error.code, 'wrong_password');
    const ok = await phone.json('POST', '/api/auth/password/change', { current: A.password, password: 'Changed-pass-99', password_confirm: 'Changed-pass-99' });
    assert.equal(ok.status, 200);
    assert.equal((await phone.json('GET', '/api/notes')).status, 200, 'это устройство остаётся в аккаунте');
    assert.equal((await laptop.json('GET', '/api/notes')).status, 401, 'другое устройство вышло');
    A.password = 'Changed-pass-99';
    const all = await phone.json('POST', '/api/auth/logout-all', {});
    assert.equal(all.status, 200);
    assert.equal((await phone.json('GET', '/api/notes')).status, 401);
  });

  await t.test('гость → аккаунт: данные устройства не смешиваются без согласия, переносятся по согласию', async () => {
    const c = client(S.base);
    await c.json('POST', '/api/session', {});
    assert.equal((await c.json('GET', '/api/session')).data.kind, 'guest');
    await c.json('POST', '/api/notes', { title: 'Гостевая', content: 'Заметка гостя' });
    await c.json('PUT', '/api/profile', { profile: { user: { name: 'Гость', onboarding_completed: true, interests: ['music'] } } });
    const guestId = (await c.json('GET', '/api/session')).data.user.id;
    // вход: гость откладывается в отдельную cookie, данные аккаунта и гостя не смешаны
    const l = await c.json('POST', '/api/auth/login', { email: 'beta@example.org', password: PASS_B });
    assert.equal(l.status, 200);
    assert.ok(c.jar.has('wisp_guest'));
    assert.deepEqual([l.data.guest.notes, l.data.guest.profile_name], [1, 'Гость']);
    const notesB = (await c.json('GET', '/api/notes')).data.notes;
    assert.ok(!notesB.some((n) => n.content === 'Заметка гостя'));
    assert.equal((await c.json('POST', '/api/auth/guest/merge', {})).status, 400, 'нужно явное согласие');
    // выход и «продолжить без аккаунта» возвращают того же гостя
    await c.json('POST', '/api/auth/logout', {});
    const back = await c.json('POST', '/api/session', {});
    assert.equal(back.data.user.id, guestId);
    assert.equal(back.data.kind, 'guest');
    // снова вход и перенос по согласию
    await c.json('POST', '/api/auth/login', { email: 'beta@example.org', password: PASS_B });
    const g = await c.json('GET', '/api/auth/guest');
    assert.equal(g.data.guest.notes, 1);
    assert.equal(g.data.account_has_profile, true);
    const m = await c.json('POST', '/api/auth/guest/merge', { confirm: 'merge' });
    assert.equal(m.status, 200);
    assert.equal(m.data.moved.notes, 1);
    assert.equal(m.data.profile_moved, false, 'профиль аккаунта не перезаписан');
    assert.equal((await c.json('GET', '/api/profile')).data.profile.user.name, 'Бета');
    assert.ok((await c.json('GET', '/api/notes')).data.notes.some((n) => n.content === 'Заметка гостя'));
    assert.ok(!c.jar.has('wisp_guest'));
    assert.equal(store.getUser(guestId), null, 'пустой гость удалён');
    assert.equal((await c.json('POST', '/api/auth/guest/merge', { confirm: 'merge' })).status, 404);
  });

  await t.test('пустой гость при входе удаляется; гость не может «выйти» с удалением аккаунта', async () => {
    const c = client(S.base);
    await c.json('POST', '/api/session', {});
    const gid = (await c.json('GET', '/api/session')).data.user.id;
    await c.json('POST', '/api/auth/login', { email: 'beta@example.org', password: PASS_B });
    assert.equal(store.getUser(gid), null);
    assert.ok(!c.jar.has('wisp_guest'));
    // старый путь Layer 6 «выход с удалением данных» в аккаунте только завершает сессию
    const r = await c.json('POST', '/api/account/logout', { confirm: 'delete_device_data' });
    assert.equal(r.data.deleted, false);
    assert.ok(store.getUserByEmail('beta@example.org'), 'аккаунт цел');
  });

  await t.test('CSRF: запросы без X-WISP-Client или с чужого Origin отклоняются', async () => {
    const r1 = await fetch(S.base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: A.email, password: A.password }) });
    assert.equal(r1.status, 403);
    const r2 = await fetch(S.base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WISP-Client': '1', Origin: 'https://evil.example' }, body: JSON.stringify({ email: A.email, password: A.password }) });
    assert.equal(r2.status, 403);
  });

  await t.test('cookie: HttpOnly, SameSite, гостевая — только для /api', async () => {
    const c = client(S.base);
    await c.json('POST', '/api/session', {});
    await c.json('POST', '/api/notes', { title: 'g', content: 'g' });
    const res = await c.req('POST', '/api/auth/login', { email: 'beta@example.org', password: PASS_B });
    const set = res.headers.getSetCookie();
    const sid = set.find((x) => x.startsWith('wisp_sid='));
    const guest = set.find((x) => x.startsWith('wisp_guest='));
    assert.match(sid, /HttpOnly/); assert.match(sid, /SameSite=Lax/);
    assert.match(guest, /HttpOnly/); assert.match(guest, /Path=\/api/); assert.match(guest, /SameSite=Strict/);
  });

  await t.test('удаление аккаунта: нужен пароль, данные удаляются целиком', async () => {
    const c = await signUp(S, { name: 'Временный', email: 'temp@example.com', password: PASS_B });
    await c.json('POST', '/api/notes', { title: 't', content: 't' });
    assert.equal((await c.json('POST', '/api/account/delete', { password: 'nope' })).status, 400);
    const r = await c.json('POST', '/api/account/delete', { password: PASS_B });
    assert.equal(r.status, 200);
    assert.equal(store.getUserByEmail('temp@example.com'), null);
    assert.equal((await c.json('GET', '/api/notes')).status, 401);
  });

  await t.test('неподтверждённые аккаунты без живой ссылки удаляются; сервер без почты честно отказывает', async () => {
    clearThrottle(S);
    const c = client(S.base);
    await c.json('POST', '/api/auth/register', { name: 'Забыл', email: 'forgot@example.com', password: PASS_B, password_confirm: PASS_B });
    const u = store.getUserByEmail('forgot@example.com');
    store.db.prepare('UPDATE users SET created_at = ? WHERE id = ?').run(Date.now() - 8 * 86400000, u.id);
    store.db.prepare('UPDATE auth_tokens SET expires_at = ? WHERE user_id = ?').run(Date.now() - 1, u.id);
    S.app.accounts.purge();
    assert.equal(store.getUserByEmail('forgot@example.com'), null);
    // сервер без транспорта
    const noMail = new Mailer({ config: { publicUrl: 'https://x.test', mail: { transport: null }, dataDir: S.dir }, log: S.app.log });
    assert.equal(noMail.configured, false);
    const prodOutbox = new Mailer({ config: { publicUrl: 'https://x.test', production: true, mail: { transport: 'outbox', from: 'a@x.test', smtp: {} }, dataDir: S.dir }, log: S.app.log });
    assert.equal(prodOutbox.configured, false, 'outbox запрещён в production');
  });
});

test('Layer 9 · сервер без почты: регистрация 503, вход в аккаунты работает', async (t) => {
  const S = await startStack({ env: { WISP_MAIL_TRANSPORT: '' } });
  t.after(() => S.close());
  const c = client(S.base);
  assert.equal((await c.json('GET', '/api/auth/config')).data.registration, false);
  const r = await c.json('POST', '/api/auth/register', { name: 'А', email: 'a@example.com', password: PASS, password_confirm: PASS });
  assert.equal(r.status, 503);
  assert.equal(r.data.error.code, 'mail_not_configured');
  const f = await c.json('POST', '/api/auth/password/forgot', { email: 'a@example.com' });
  assert.equal(f.status, 503);
  assert.equal(S.app.store.getUserByEmail('a@example.com'), null);
});

test('account export includes conversations beyond the previous 100,000-row cap', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const c = client(S.base);
  const session = await c.json('POST', '/api/session', {});
  assert.equal(session.status, 200);
  const userId = session.data.user.id;
  const store = S.app.store;
  const now = Date.now() - 10_000;
  const targetId = 'export-old-conversation';
  const insertConversation = store.db.prepare(`INSERT INTO conversations
    (id, user_id, title, title_source, model, created_at, updated_at)
    VALUES (?, ?, ?, 'user', NULL, ?, ?)`);
  const insertMessage = store.db.prepare(`INSERT INTO messages
    (id, conversation_id, seq, role, content, status, error_code, model, created_at, updated_at)
    VALUES (?, ?, 1, 'user', ?, 'complete', NULL, NULL, ?, ?)`);
  store.transaction(() => {
    insertConversation.run(targetId, userId, 'Старый диалог', now, now);
    insertMessage.run('export-old-message', targetId, 'Не теряй это сообщение', now, now);
    for (let i = 0; i < 100_000; i++) {
      const at = now + 20_000 + i;
      insertConversation.run(`export-empty-${i}`, userId, 'Пустой диалог', at, at);
    }
    for (let i = 0; i < 205; i++) {
      const id = `export-page-${i}`, at = now + 10_000 + i;
      insertConversation.run(id, userId, 'Диалог для страницы', at, at);
      insertMessage.run(`export-page-message-${i}`, id, 'Сообщение', at, at);
    }
  });
  const page1 = await c.json('GET', '/api/conversations');
  const page2 = await c.json('GET', '/api/conversations?offset=100');
  const page3 = await c.json('GET', '/api/conversations?offset=200');
  assert.equal(page1.data.conversations.length, 100);
  assert.equal(page2.data.conversations.length, 100);
  assert.equal(page3.data.conversations.length, 6);
  assert.equal(page1.data.has_more, true);
  assert.equal(page3.data.has_more, false);
  assert.ok(page3.data.conversations.some((conversation) => conversation.id === targetId));
  const exported = await c.json('GET', '/api/account/export');
  assert.equal(exported.status, 200);
  assert.ok(exported.data.conversations.some((conversation) =>
    conversation.id === targetId && conversation.messages[0]?.content === 'Не теряй это сообщение'));
});

test('Layer 9 · гостевой режим можно выключить', async (t) => {
  const S = await startStack({ env: { WISP_GUEST_MODE: '0' } });
  t.after(() => S.close());
  const c = client(S.base);
  const r = await c.json('POST', '/api/session', {});
  assert.equal(r.status, 403);
  assert.equal(r.data.error.code, 'guest_disabled');
});

/* ── SMTP: настоящий протокол против локального тестового сервера ── */
function fakeSmtp({ starttls } = {}) {
  const got = [];
  const server = net.createServer((sock) => {
    let buf = '', data = false, msg = '';
    const w = (l) => sock.write(l + '\r\n');
    w('220 fake ESMTP');
    sock.on('data', (ch) => {
      buf += ch.toString();
      let i;
      while ((i = buf.indexOf('\r\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 2);
        if (data) {
          if (line === '.') { data = false; got.push(msg); w('250 queued'); msg = ''; } else msg += line + '\r\n';
          continue;
        }
        const cmd = line.split(' ')[0].toUpperCase();
        if (cmd === 'EHLO') { sock.write(`250-fake\r\n${starttls ? '250-STARTTLS\r\n' : ''}250-AUTH PLAIN LOGIN\r\n250 OK\r\n`); }
        else if (cmd === 'AUTH') { got.push('AUTH ' + Buffer.from(line.split(' ')[2], 'base64').toString().split('\0').join('|')); w('235 ok'); }
        else if (cmd === 'MAIL' || cmd === 'RCPT') { got.push(line); w('250 ok'); }
        else if (cmd === 'DATA') { data = true; w('354 go'); }
        else if (cmd === 'QUIT') { w('221 bye'); sock.end(); }
        else w('502 no');
      }
    });
  });
  return new Promise((r) => server.listen(0, '127.0.0.1', () => r({ server, got, port: server.address().port })));
}

test('Layer 9 · SMTP-транспорт: письмо по протоколу, без пароля по открытому каналу', async () => {
  const F = await fakeSmtp();
  try {
    const from = { name: 'WISP', address: 'no-reply@wisp.test' };
    const message = buildMessage({ from, to: 'gera@example.com', subject: 'Подтверди почту', text: 'ссылка https://wisp.test/#/verify/abc\n.точка в начале', html: '<p>hi</p>', domain: 'wisp.test' });
    assert.match(message, /Subject: =\?UTF-8\?B\?/);
    assert.match(message, /multipart\/alternative/);
    await smtpSend({ host: '127.0.0.1', port: F.port, secure: false, requireTLS: false, user: 'u', pass: 'p', ehlo: 'wisp.test' }, { from: from.address, to: 'gera@example.com', message });
    assert.ok(F.got.includes('AUTH |u|p'));
    assert.ok(F.got.includes('MAIL FROM:<no-reply@wisp.test>'));
    assert.ok(F.got.includes('RCPT TO:<gera@example.com>'));
    const body = F.got.find((x) => x.includes('MIME-Version'));
    const text = Buffer.from(body.split('Content-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\n')[1].split('--')[0].replace(/\s+/g, ''), 'base64').toString();
    assert.match(text, /https:\/\/wisp\.test\/#\/verify\/abc/);
    // requireTLS: сервер без STARTTLS → отказ до AUTH
    const before = F.got.length;
    await assert.rejects(smtpSend({ host: '127.0.0.1', port: F.port, secure: false, requireTLS: true, user: 'u', pass: 'p', ehlo: 'wisp.test' }, { from: from.address, to: 'gera@example.com', message }), /TLS/);
    assert.ok(!F.got.slice(before).some((x) => x.startsWith('AUTH')), 'пароль SMTP не ушёл открытым текстом');
  } finally { F.server.close(); }
});

test('Layer 9 · регистрация через SMTP-транспорт целиком', async (t) => {
  const F = await fakeSmtp();
  const S = await startStack({ env: { WISP_MAIL_TRANSPORT: 'smtp', WISP_SMTP_HOST: '127.0.0.1', WISP_SMTP_PORT: String(F.port), WISP_SMTP_SECURE: '0', WISP_SMTP_REQUIRE_TLS: '0' } });
  t.after(async () => { await S.close(); F.server.close(); });
  const c = client(S.base);
  const r = await c.json('POST', '/api/auth/register', { name: 'Smtp', email: 'smtp@example.com', password: PASS, password_confirm: PASS });
  assert.equal(r.status, 200);
  assert.equal(r.data.email_sent, true);
  assert.ok(F.got.includes('RCPT TO:<smtp@example.com>'));
});
