/* WISP · Tests · Layer 7 Voice (node --test)
 * Настоящий серверный код распознавания и синтеза речи против локального двойника OpenAI Audio API:
 * доступность, приватность (ключ не уходит клиенту, аудио не сохраняется), проверка формата и размера записи,
 * лимиты тарифа, возврат лимита при сбое провайдера, характер WISP в манере речи, настройки голоса в профиле. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startStack, client } = require('./helpers');
const fake = require('./fake-provider');

const KEY = 'sk-voice-secret-abcdef123456';
const webm = (size) => { const b = Buffer.alloc(size || 4000, 7); b[0] = 0x1a; b[1] = 0x45; b[2] = 0xdf; b[3] = 0xa3; return b; };
const PLANS = {
  free: { title: 'Free', daily_requests: 100, per_minute: 100, history_tokens: 3000, max_output_tokens: 400, max_input_chars: 2000, max_images_per_message: 2,
    voice: { stt_daily: 3, stt_max_seconds: 30, tts_chars_daily: 200, tts_max_chars: 120, per_minute: 100 } },
  plus: { title: 'Plus', daily_requests: 1000, per_minute: 100, history_tokens: 12000, max_output_tokens: 800, max_input_chars: 8000, max_images_per_message: 4 },
};

/* req() из helpers шлёт JSON; для сырого тела — свой fetch с той же cookie */
async function raw(c, base, buf, type, ms, extra) {
  const res = await fetch(base + '/api/voice/transcribe', {
    method: 'POST',
    headers: { 'X-WISP-Client': '1', Origin: base, Cookie: c.cookie, 'Content-Type': type || 'audio/webm', 'X-WISP-Audio-Ms': String(ms || 2000), ...(extra || {}) },
    body: buf,
  });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

test('Layer 7 · голос выключен, если на сервере нет ключа', async (t) => {
  const S = await startStack();
  t.after(() => S.close());
  const a = client(S.base);
  await a.json('POST', '/api/session', {});
  const r = await a.json('GET', '/api/voice');
  assert.equal(r.status, 200);
  assert.equal(r.data.stt.available, false);
  assert.equal(r.data.tts.available, false);
  assert.deepEqual(r.data.tts.voices, []);
  const up = await raw(a, S.base, webm());
  assert.equal(up.status, 503);
  assert.equal(up.data.error.code, 'voice_unavailable');
  const sp = await a.json('POST', '/api/voice/speech', { text: 'Привет' });
  assert.equal(sp.status, 503);
  const health = await a.json('GET', '/api/health');
  assert.deepEqual(health.data.voice, { stt: false, tts: false });
});

test('Layer 7 · распознавание и синтез речи', async (t) => {
  const S = await startStack({ plans: PLANS, voice: KEY });
  t.after(() => S.close());
  const a = client(S.base);
  const b = client(S.base);
  await a.json('POST', '/api/session', {});
  await b.json('POST', '/api/session', {});

  await t.test('без сессии и без заголовка клиента — отказ', async () => {
    const anon = await fetch(S.base + '/api/voice'); assert.equal(anon.status, 401);
    const noHeader = await fetch(S.base + '/api/voice/transcribe', { method: 'POST', headers: { 'Content-Type': 'audio/webm', Cookie: a.cookie }, body: webm() });
    assert.equal(noHeader.status, 403);
    const evil = await raw(a, S.base, webm(), 'audio/webm', 1000, { Origin: 'https://evil.example' });
    assert.equal(evil.status, 403);
  });

  await t.test('GET /api/voice: голоса и лимиты, ключа и адреса провайдера нет', async () => {
    const r = await a.json('GET', '/api/voice');
    assert.equal(r.status, 200);
    assert.equal(r.data.stt.available, true);
    assert.equal(r.data.stt.engine, 'server');
    assert.equal(r.data.tts.available, true);
    assert.ok(r.data.tts.voices.length >= 5);
    assert.ok(r.data.tts.voices.every((v) => v.id && v.label));
    assert.equal(r.data.tts.default_voice, 'nova');
    assert.equal(r.data.stt.limit, 3);
    const s = JSON.stringify(r.data);
    assert.ok(!s.includes(KEY) && !s.includes(S.provider.url), 'ни ключа, ни адреса провайдера');
  });

  await t.test('запись → текст: multipart с моделью, правильное расширение, имя из профиля в подсказке', async () => {
    await a.json('PUT', '/api/profile', { profile: { schema_version: 1, user: { name: 'Гера', onboarding_completed: true }, meta: {} } });
    S.provider.voice.transcript = 'Напомни завтра в десять позвонить маме';
    const r = await raw(a, S.base, webm(), 'audio/webm;codecs=opus', 2400);
    assert.equal(r.status, 200);
    assert.equal(r.data.text, 'Напомни завтра в десять позвонить маме');
    assert.equal(r.data.duration_ms, 2400);
    const req = S.provider.requests.filter((x) => x.kind === 'stt').pop();
    assert.equal(req.headers.authorization, `Bearer ${KEY}`);
    assert.equal(req.body.fields.model, 'gpt-4o-mini-transcribe');
    assert.equal(req.body.file.name, 'speech.webm');
    assert.match(req.body.fields.prompt, /Гера/);
    assert.equal(r.data.usage.used, 1);
  });

  await t.test('формат определяется по содержимому, а не по заголовку (mp4 с iPhone, wav)', async () => {
    const mp4 = Buffer.alloc(3000, 1); mp4.write('ftypM4A ', 4, 'latin1');
    const r = await raw(b, S.base, mp4, 'audio/mp4');
    assert.equal(r.status, 200);
    assert.equal(S.provider.requests.filter((x) => x.kind === 'stt').pop().body.file.name, 'speech.mp4');
    const w = await raw(b, S.base, fake.speechWav('проверка связи'), 'audio/wav');
    assert.equal(w.status, 200);
    assert.equal(S.provider.requests.filter((x) => x.kind === 'stt').pop().body.file.name, 'speech.wav');
  });

  await t.test('мусор, пустая запись, слишком длинная, не аудио — отклоняются без вызова провайдера', async () => {
    const before = S.provider.requests.filter((x) => x.kind === 'stt').length;
    const junk = await raw(a, S.base, Buffer.alloc(3000, 65), 'audio/webm');
    assert.equal(junk.status, 415);
    const tiny = await raw(a, S.base, webm(100), 'audio/webm');
    assert.equal(tiny.status, 422);
    assert.equal(tiny.data.error.code, 'audio_empty');
    const long = await raw(a, S.base, webm(), 'audio/webm', 90000);
    assert.equal(long.status, 413);
    const text = await raw(a, S.base, webm(), 'text/plain');
    assert.equal(text.status, 415);
    const huge = await raw(a, S.base, webm(9 * 1024 * 1024), 'audio/webm');
    assert.equal(huge.status, 413);
    assert.equal(S.provider.requests.filter((x) => x.kind === 'stt').length, before);
  });

  await t.test('сбой провайдера: понятный код, попытка не засчитывается', async () => {
    const used = (await a.json('GET', '/api/voice')).data.stt.used;
    S.provider.voice.sttStatus = 500;
    const r = await raw(a, S.base, webm());
    assert.equal(r.status, 502);
    assert.equal(r.data.error.code, 'provider_error');
    assert.equal(r.data.error.retryable, true);
    S.provider.voice.sttStatus = 401;
    const r2 = await raw(a, S.base, webm());
    assert.equal(r2.data.error.code, 'provider_auth');
    assert.ok(!JSON.stringify(r2.data).includes(KEY));
    S.provider.voice.sttStatus = 0;
    assert.equal((await a.json('GET', '/api/voice')).data.stt.used, used, 'лимит возвращён');
  });

  await t.test('дневной лимит распознавания (Free: 3) — у каждого пользователя свой', async () => {
    let r;
    for (let i = 0; i < 5; i++) { r = await raw(a, S.base, webm()); if (r.status !== 200) break; }
    assert.equal(r.status, 429);
    assert.equal(r.data.error.code, 'voice_limit');
    assert.ok(r.data.error.reset_at > Date.now());
    const other = await a.json('GET', '/api/voice');
    assert.equal(other.data.stt.remaining, 0);
    const bb = await b.json('GET', '/api/voice');
    assert.equal(bb.data.stt.used, 2, 'у второго пользователя свои счётчики');
  });

  await t.test('синтез: настоящее аудио, голос, манера речи по характеру WISP', async () => {
    const res = await a.req('POST', '/api/voice/speech', { text: 'Привет! Я тебя слышу.', voice: 'shimmer', personality: 'calm' });
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-type'), 'audio/wav');
    assert.equal(res.headers.get('x-wisp-voice'), 'shimmer');
    const buf = Buffer.from(await res.arrayBuffer());
    assert.equal(buf.toString('latin1', 0, 4), 'RIFF');
    assert.ok(buf.length > 10000);
    const req = S.provider.requests.filter((x) => x.kind === 'tts').pop();
    assert.equal(req.body.model, 'gpt-4o-mini-tts');
    assert.equal(req.body.voice, 'shimmer');
    assert.equal(req.body.input, 'Привет! Я тебя слышу.');
    assert.match(req.body.instructions, /спокойно/i);
    assert.equal(req.body.response_format, 'mp3');
  });

  await t.test('синтез: неизвестный голос → голос по умолчанию; характер не из списка → адаптивный', async () => {
    const res = await a.req('POST', '/api/voice/speech', { text: 'Тест', voice: '../../etc', personality: 'evil' });
    assert.equal(res.status, 200);
    await res.arrayBuffer();
    const req = S.provider.requests.filter((x) => x.kind === 'tts').pop();
    assert.equal(req.body.voice, 'nova');
    assert.match(req.body.instructions, /естественно/i);
  });

  await t.test('синтез: пустой текст, слишком длинный фрагмент, дневной лимит символов', async () => {
    assert.equal((await a.json('POST', '/api/voice/speech', { text: '   ' })).status, 400);
    assert.equal((await a.json('POST', '/api/voice/speech', { text: 'а'.repeat(121) })).status, 413);
    let last;
    for (let i = 0; i < 4; i++) { last = await a.req('POST', '/api/voice/speech', { text: 'б'.repeat(100) }); if (last.status !== 200) break; await last.arrayBuffer(); }
    assert.equal(last.status, 429);
    const err = await last.json();
    assert.equal(err.error.code, 'voice_limit');
    assert.equal(err.error.kind, 'tts');
  });

  await t.test('сбой синтеза возвращает символы в лимит', async () => {
    const before = (await b.json('GET', '/api/voice')).data.tts.used;
    S.provider.voice.ttsStatus = 503;
    const r = await b.json('POST', '/api/voice/speech', { text: 'Проверка' });
    assert.equal(r.status, 503);
    assert.equal(r.data.error.code, 'provider_busy');
    S.provider.voice.ttsStatus = 0;
    assert.equal((await b.json('GET', '/api/voice')).data.tts.used, before);
  });

  await t.test('аудио и тексты не сохраняются: в базе только счётчики', async () => {
    const db = S.app.store.db;
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((x) => x.name);
    assert.ok(tables.includes('voice_usage'));
    const cols = db.prepare('PRAGMA table_info(voice_usage)').all().map((c) => c.name);
    assert.deepEqual(cols.sort(), ['day', 'stt_ms', 'stt_requests', 'tts_chars', 'user_id']);
    const dump = JSON.stringify(db.prepare('SELECT * FROM voice_usage').all());
    assert.ok(!dump.includes('Напомни'));
    // распознанный текст сервер в чат сам не отправляет
    const conv = await a.json('GET', '/api/conversations');
    assert.equal(conv.data.conversations.length, 0);
  });

  await t.test('настройки голоса в профиле: сохраняются и проверяются сервером', async () => {
    const put = await a.json('PUT', '/api/profile', { profile: { schema_version: 1, user: { name: 'Гера-Мария', preferences: { voice_replies: false, voice_autoplay: true, voice_rate: 'warp', voice_id: 'device:Milena\u0007 (ru-RU)' } }, meta: {} } });
    assert.equal(put.status, 200);
    const p = put.data.profile.user;
    assert.equal(p.name, 'Гера-Мария', 'дефис в имени не теряется');
    assert.equal(p.preferences.voice_replies, false);
    assert.equal(p.preferences.voice_autoplay, true);
    assert.equal(p.preferences.voice_rate, 'normal');
    assert.equal(p.preferences.voice_id, 'device:Milena (ru-RU)');
  });
});
