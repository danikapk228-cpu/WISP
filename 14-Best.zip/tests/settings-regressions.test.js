'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

test('home avatar renders the saved profile photo instead of the initial', () => {
  const App = {
    ui: {
      h(tag, props, ...children) { return { tag, props: props || {}, children: children.flat().filter(Boolean) }; },
      icon(name, className) { return { tag: 'svg', props: { name, class: className }, children: [] }; },
      Button() {}, ChoiceCard() {}, OptionRow() {},
    },
    core: { Profile: {}, Capabilities: {} },
    home: {},
  };
  const window = { WispApp: App };
  const source = fs.readFileSync(path.join(__dirname, '../src/home/sheets.js'), 'utf8');
  vm.runInNewContext(source, { window });

  const photo = 'data:image/jpeg;base64,AAAA';
  const avatar = App.home.Sheets.Avatar({ name: 'Даня', avatar: photo });
  assert.match(avatar.props.class, /has-photo/);
  assert.equal(avatar.children[0].tag, 'img');
  assert.equal(avatar.children[0].props.src, photo);
  assert.equal(avatar.children.some((child) => child.props.class === 'home-avatar__letter'), false);

  const fallback = App.home.Sheets.Avatar({ name: 'Даня', avatar: null });
  assert.equal(fallback.children[0].props.class, 'home-avatar__letter');
});

test('appearance save and delete update nested profile preferences', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/settings/settings.js'), 'utf8');
  assert.match(source, /store\.update\(\{\s*preferences:\s*\{\s*\.\.\.current,\s*themes,\s*theme:\s*'custom'/);
  assert.match(source, /store\.update\(\{\s*preferences:\s*\{\s*\.\.\.prefs\(\),\s*themes,\s*\.\.\.\(active/);
});
