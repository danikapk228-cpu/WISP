'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { load } = require('../server/config');
const { AIService } = require('../server/ai/service');
const OpenAIProvider = require('../server/ai/providers/openai');

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wisp-providers-'));
  const models = {
    providers: {
      groq: { type: 'openai', base_url: 'https://api.groq.com/openai/v1', api_key_env: 'GROQ_API_KEY' },
      gemini: { type: 'openai', base_url: 'https://generativelanguage.googleapis.com/v1beta/openai', api_key_env: 'GEMINI_API_KEY' },
      huggingface: { type: 'openai', base_url: 'https://router.huggingface.co/v1', api_key_env: 'HF_TOKEN' },
      cloudflare: { type: 'openai', base_url_env: 'CF_BASE', api_key_env: 'CF_TOKEN' },
      cf_gateway: {
        type: 'openai', base_url_env: 'CF_GATEWAY_BASE', api_key_env: 'CF_GATEWAY_TOKEN',
        headers_env: { 'cf-aig-gateway-id': 'CF_GATEWAY_ID' },
      },
      supabase: { type: 'openai', base_url_env: 'SUPABASE_AI_BASE_URL', api_key_env: 'SUPABASE_AI_PROXY_TOKEN' },
    },
    default_model: { free: 'groq-test', plus: 'gemini-test' },
    models: [
      { id: 'groq-test', provider: 'groq', model: 'openai/gpt-oss-120b', tier: 'free', tools: true },
      { id: 'gemini-test', provider: 'gemini', model: 'gemini-3.5-flash', tier: 'free', vision: true, tools: true },
      { id: 'hf-test', provider: 'huggingface', model: 'openai/gpt-oss-120b:groq', tier: 'free', tools: true },
      { id: 'cf-test', provider: 'cloudflare', model: '@cf/meta/llama-3.3-70b-instruct-fp8-fast', tier: 'free', tools: true },
      { id: 'cf-gateway-test', provider: 'cf_gateway', model: 'openai/gpt-4o-mini', tier: 'free', tools: true },
      { id: 'supabase-test', provider: 'supabase', model: 'supabase-proxy', tier: 'free', tools: true },
    ],
  };
  const file = path.join(dir, 'models.json');
  fs.writeFileSync(file, JSON.stringify(models));
  const config = load({
    skipEnvFile: true,
    env: {
      WISP_MODELS_FILE: file,
      GROQ_API_KEY: 'groq-secret',
      GEMINI_API_KEY: 'gemini-secret',
      HF_TOKEN: 'hf-secret',
      CF_BASE: 'https://api.cloudflare.com/client/v4/accounts/test-account/ai/v1',
      CF_TOKEN: 'cf-secret',
      CF_GATEWAY_BASE: 'https://api.cloudflare.com/client/v4/accounts/test-account/ai/v1',
      CF_GATEWAY_TOKEN: 'cf-gateway-secret',
      CF_GATEWAY_ID: 'test-gateway',
      SUPABASE_AI_BASE_URL: 'https://test.supabase.co/functions/v1/wisp-openai-proxy',
      SUPABASE_AI_PROXY_TOKEN: 'supabase-proxy-secret',
    },
  });
  return { config, dir };
}

test('Groq, Gemini, Hugging Face, Cloudflare and Supabase proxy load as OpenAI-compatible providers', (t) => {
  const { config, dir } = fixture();
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const ai = new AIService(config);

  assert.deepEqual(config.models.map((model) => model.id), [
    'groq-test', 'gemini-test', 'hf-test', 'cf-test', 'cf-gateway-test', 'supabase-test',
  ]);
  assert.ok(config.models.every((model) => ai.availability(model).available));
  assert.equal(config.providers.gemini.baseUrl, 'https://generativelanguage.googleapis.com/v1beta/openai');
  assert.equal(config.providers.huggingface.baseUrl, 'https://router.huggingface.co/v1');
  assert.equal(config.providers.cloudflare.baseUrl, 'https://api.cloudflare.com/client/v4/accounts/test-account/ai/v1');
  assert.equal(config.providers.supabase.baseUrl, 'https://test.supabase.co/functions/v1/wisp-openai-proxy');
  assert.equal(config.providers.cf_gateway.headers['cf-aig-gateway-id'], 'test-gateway');
});

test('default model catalog exposes configured vendors without leaking provider keys', () => {
  const config = load({
    skipEnvFile: true,
    env: {
      GROQ_API_KEY: 'groq-secret',
      GEMINI_API_KEY: 'gemini-secret',
      HF_TOKEN: 'hf-secret',
      CLOUDFLARE_AI_BASE_URL: 'https://api.cloudflare.com/client/v4/accounts/test-account/ai/v1',
      CLOUDFLARE_API_TOKEN: 'cf-secret',
      CLOUDFLARE_AI_GATEWAY_BASE_URL: 'https://api.cloudflare.com/client/v4/accounts/test-account/ai/v1',
      CLOUDFLARE_AI_GATEWAY_TOKEN: 'cf-gateway-secret',
      CLOUDFLARE_AI_GATEWAY_ID: 'test-gateway',
      SUPABASE_AI_BASE_URL: 'https://test.supabase.co/functions/v1/wisp-openai-proxy',
      SUPABASE_AI_PROXY_TOKEN: 'supabase-proxy-secret',
    },
  });
  const ai = new AIService(config);
  for (const id of ['groq-oss-120b', 'gemini-flash', 'huggingface-gpt-oss', 'cloudflare-llama', 'cloudflare-gateway-openai', 'supabase-edge-proxy']) {
    const model = ai.find(id);
    assert.ok(model, `missing model ${id}`);
    assert.equal(ai.availability(model).available, true, `provider not available for ${id}`);
    const publicModel = JSON.stringify(ai.publicModel(model, 'plus'));
    assert.doesNotMatch(publicModel, /groq-secret|gemini-secret|hf-secret|cf-secret|supabase-proxy-secret/);
    assert.doesNotMatch(publicModel, /router\\.huggingface|generativelanguage|api\\.groq\\.com|api\\.cloudflare\\.com|supabase\\.co/);
  }
});

async function serveOnce(t, checks) {
  const server = http.createServer(async (request, response) => {
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    const body = JSON.parse(Buffer.concat(chunks).toString());
    try { checks({ request, body }); }
    catch (error) {
      response.writeHead(500, { 'content-type': 'text/plain' });
      response.end(error.stack || error.message);
      return;
    }
    response.writeHead(200, { 'content-type': 'text/event-stream' });
    response.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n');
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  return `http://127.0.0.1:${server.address().port}/v1`;
}

async function firstDelta(provider, model) {
  for await (const event of OpenAIProvider.stream({
    provider,
    model: { model, temperature: null },
    system: 'system prompt',
    messages: [{ role: 'user', parts: [{ type: 'text', text: 'hello' }] }],
    maxTokens: 64,
    signal: new AbortController().signal,
    timeouts: { firstByteMs: 1000, idleMs: 1000 },
    tools: null,
  })) {
    if (event.type === 'delta') return event.text;
  }
  return null;
}

test('Cloudflare AI Gateway uses its model-routing header and standard Cloudflare API auth', async (t) => {
  const gatewayBase = await serveOnce(t, ({ request, body }) => {
    assert.equal(request.url, '/v1/chat/completions');
    assert.equal(request.headers['cf-aig-gateway-id'], 'test-gateway');
    assert.equal(request.headers.authorization, 'Bearer gateway-secret');
    assert.equal(body.model, 'openai/gpt-4o-mini');
    assert.equal(body.stream, true);
  });
  const delta = await firstDelta({
    baseUrl: gatewayBase,
    apiKey: 'gateway-secret',
    apiKeyHeader: 'Authorization',
    apiKeyPrefix: 'Bearer ',
    headers: { 'cf-aig-gateway-id': 'test-gateway' },
  }, 'openai/gpt-4o-mini');
  assert.equal(delta, 'ok');
});

test('Gemini-compatible provider sends standard bearer auth and its selected model', async (t) => {
  const baseUrl = await serveOnce(t, ({ request, body }) => {
    assert.equal(request.headers.authorization, 'Bearer gemini-secret');
    assert.equal(body.model, 'gemini-3.5-flash');
    assert.equal(body.max_tokens, 64);
    assert.equal(body.max_completion_tokens, undefined);
  });
  const delta = await firstDelta({
    baseUrl,
    apiKey: 'gemini-secret',
    apiKeyHeader: 'Authorization',
    apiKeyPrefix: 'Bearer ',
    maxTokensParam: 'max_tokens',
    headers: {},
  }, 'gemini-3.5-flash');
  assert.equal(delta, 'ok');
});
