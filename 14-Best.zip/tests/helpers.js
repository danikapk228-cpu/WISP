/* WISP · Tests · Helpers: запуск сервера с тестовым конфигом, HTTP-клиент с cookie, чтение SSE. */
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { load } = require('../server/config');
const { createApp } = require('../server/app');
const fake = require('./fake-provider');

async function startStack({ plans, models, env, voice } = {}) {
  const provider = await fake.start();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wisp-test-'));
  const modelsCfg = models || {
    providers: {
      openai: { type: 'openai', base_url_env: 'T_OPENAI_URL', api_key_env: 'T_OPENAI_KEY', max_tokens_param: 'max_completion_tokens', stream_usage: true },
      anthropic: { type: 'anthropic', base_url_env: 'T_ANTHROPIC_URL', api_key_env: 'T_ANTHROPIC_KEY' },
      missing: { type: 'openai', base_url: 'http://127.0.0.1:9', api_key_env: 'T_MISSING_KEY' },
    },
    default_model: { free: 'fast', plus: 'smart' },
    models: [
      { id: 'fast', label: 'Fast', provider: 'openai', model: 'test-fast', tier: 'free', vision: true, context_tokens: 16000, max_output_tokens: 500 },
      { id: 'smart', label: 'Smart', provider: 'anthropic', model: 'test-smart', tier: 'plus', vision: true, context_tokens: 16000, max_output_tokens: 800 },
      { id: 'blind', label: 'Blind', provider: 'anthropic', model: 'test-blind', tier: 'free', vision: false, context_tokens: 16000, max_output_tokens: 500 },
      { id: 'ghost', label: 'Ghost', provider: 'missing', model: 'x', tier: 'free', vision: false, context_tokens: 16000, max_output_tokens: 500 },
    ],
  };
  const plansCfg = plans || {
    free: { title: 'Free', daily_requests: 100, per_minute: 100, history_tokens: 3000, max_output_tokens: 400, max_input_chars: 2000, max_images_per_message: 2 },
    plus: { title: 'Plus', daily_requests: 1000, per_minute: 100, history_tokens: 12000, max_output_tokens: 800, max_input_chars: 8000, max_images_per_message: 4 },
  };
  fs.writeFileSync(path.join(dir, 'models.json'), JSON.stringify(modelsCfg));
  fs.writeFileSync(path.join(dir, 'plans.json'), JSON.stringify(plansCfg));
  const config = load({
    skipEnvFile: true,
    env: {
      T_OPENAI_URL: `${provider.url}/v1`, T_OPENAI_KEY: 'sk-test-openai-secret-123456',
      T_ANTHROPIC_URL: provider.url, T_ANTHROPIC_KEY: 'sk-ant-test-secret-123456',
      WISP_MODELS_FILE: path.join(dir, 'models.json'), WISP_PLANS_FILE: path.join(dir, 'plans.json'),
      WISP_DATA_DIR: dir, WISP_LOG_LEVEL: 'error', PORT: '0',
      WISP_REQUESTS_PER_IP_MINUTE: '1000', WISP_SESSIONS_PER_IP_HOUR: '1000',
      // Layer 7: голос выключен, пока тест явно не попросит (voice: 'ключ') — тогда он идёт в двойник провайдера
      WISP_VOICE_API_KEY: voice || '', OPENAI_API_KEY: '', WISP_VOICE_BASE_URL: `${provider.url}/v1`,
      // Layer 9: письма в память (app.mailer.sent), ссылки на условный адрес
      WISP_MAIL_TRANSPORT: 'memory', WISP_MAIL_FROM: 'WISP <no-reply@wisp.test>', WISP_PUBLIC_URL: 'https://wisp.test', NODE_ENV: 'test',
      ...(env || {}),
    },
  });
  const app = createApp(config, { dbFile: path.join(dir, 'wisp.db') });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  return {
    app, provider, base, dir, config,
    async close() { await app.close(); await provider.close(); fs.rmSync(dir, { recursive: true, force: true }); },
  };
}

/* Клиент «как браузер»: хранит cookie (несколько, с удалением по Max-Age=0), шлёт X-WISP-Client и Origin */
function client(base) {
  const jar = new Map();
  const cookieHeader = () => [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
  async function req(method, url, body, opts = {}) {
    const headers = { 'X-WISP-Client': '1', Origin: base, ...(opts.headers || {}) };
    if (jar.size && !opts.noCookie) headers.Cookie = cookieHeader();
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(base + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: opts.signal });
    const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : (res.headers.get('set-cookie') ? [res.headers.get('set-cookie')] : []);
    for (const c of list) {
      const [pair, ...attrs] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (!v || attrs.some((a) => /^\s*max-age=0$/i.test(a))) jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  return {
    req,
    jar,
    get cookie() { return cookieHeader(); },
    set cookie(v) {
      jar.clear();
      for (const part of String(v || '').split(';')) { const i = part.indexOf('='); if (i > 0) jar.set(part.slice(0, i).trim(), part.slice(i + 1).trim()); }
    },
    async json(method, url, body, opts) {
      const res = await req(method, url, body, opts);
      const data = await res.json().catch(() => null);
      return { status: res.status, data, res };
    },
    /* POST с потоком: возвращает события по мере прихода + отметки времени */
    async stream(url, body, opts = {}) {
      const res = await req('POST', url, body, opts);
      if (!(res.headers.get('content-type') || '').includes('text/event-stream')) {
        return { status: res.status, error: await res.json().catch(() => null), events: [] };
      }
      const events = [];
      const decoder = new TextDecoder();
      let buf = '';
      try {
        for await (const chunk of res.body) {
          buf += decoder.decode(chunk, { stream: true });
          let i;
          while ((i = buf.indexOf('\n\n')) >= 0) {
            const block = buf.slice(0, i); buf = buf.slice(i + 2);
            let ev = 'message'; const data = [];
            for (const line of block.split('\n')) {
              if (line.startsWith('event:')) ev = line.slice(6).trim();
              else if (line.startsWith('data:')) data.push(line.slice(5).trim());
            }
            if (data.length) {
              const e = { event: ev, data: JSON.parse(data.join('\n')), at: Date.now() };
              events.push(e);
              if (opts.onEvent) opts.onEvent(e);
            }
          }
        }
      } catch (e) { if (!opts.expectAbort) throw e; }
      return { status: res.status, events };
    },
  };
}

const text = (events) => events.filter((e) => e.event === 'delta').map((e) => e.data.text).join('');

module.exports = { startStack, client, text };
