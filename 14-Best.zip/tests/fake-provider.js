/* WISP · Tests · Local provider double
 * ТОЛЬКО ДЛЯ ТЕСТОВ. Локальный HTTP-сервер, который говорит по тем же протоколам, что и реальные API:
 * OpenAI Chat Completions (SSE: data: {choices:[{delta}]}, data: [DONE]) и Anthropic Messages (SSE-события).
 * Нужен, чтобы проверить настоящий потоковый код сервера без доступа в интернет. В приложение не подключается.
 *
 * Сценарий выбирается маркером в последнем сообщении пользователя:
 *   [[slow]] — паузы между токенами · [[drop]] — обрыв соединения посреди ответа · [[empty]] — пустой ответ
 *   [[http500]] / [[http404]] / [[http401]] / [[http429]] — ошибка HTTP · [[midError]] — ошибка в потоке
 * Layer 4 (только если в запросе есть tools): [[call:имя {"json":"аргументы"}]] — модель вызывает функцию
 * (можно несколько маркеров = несколько вызовов). Когда в диалоге уже есть результат функции, модель
 * отвечает текстом «Результат: <то, что вернул сервер>». [[silent]] — после функции ответ без текста. */
'use strict';
const http = require('node:http');

function lastUserText(messages) {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role !== 'user') continue;
    if (typeof m.content === 'string') return m.content;
    const t = (m.content || []).filter((p) => p.type === 'text').map((p) => p.text).join(' ');
    if (t || !(m.content || []).some((p) => p.type === 'tool_result')) return t;
  }
  return '';
}

/* Результаты функций в конце диалога (после последней реплики пользователя с текстом) */
function toolResults(kind, messages) {
  const out = [];
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (kind === 'openai') {
      if (m.role === 'tool') { out.unshift(m.content); continue; }
      if (m.role === 'assistant' && m.tool_calls) continue;
      break;
    } else {
      const parts = Array.isArray(m.content) ? m.content : [];
      if (m.role === 'user' && parts.some((p) => p.type === 'tool_result')) { parts.filter((p) => p.type === 'tool_result').forEach((p) => out.unshift(p.content)); continue; }
      if (m.role === 'assistant' && parts.some((p) => p.type === 'tool_use')) continue;
      break;
    }
  }
  return out;
}

function parseCalls(text) {
  const out = [];
  const re = /\[\[call:(\w+)\s+(\{.*?\})\]\]/gs;
  let m;
  while ((m = re.exec(text))) out.push({ name: m[1], args: m[2] });
  return out;
}

/* Layer 7 · Audio API (OpenAI-совместимый): /v1/audio/transcriptions (multipart) и /v1/audio/speech (JSON → WAV).
 * Управление из теста: provider.voice.transcript / sttStatus / ttsStatus / sttDelayMs. */
function parseMultipart(buf, type) {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(type || '');
  if (!m) return null;
  const boundary = '--' + (m[1] || m[2]);
  const text = buf.toString('latin1');
  const out = { fields: {}, file: null };
  for (const part of text.split(boundary)) {
    const i = part.indexOf('\r\n\r\n');
    if (i < 0) continue;
    const head = part.slice(0, i);
    const name = /name="([^"]+)"/.exec(head);
    if (!name) continue;
    const body = part.slice(i + 4).replace(/\r\n(--)?\s*$/, '');
    const filename = /filename="([^"]+)"/.exec(head);
    if (filename) out.file = { name: filename[1], type: (/Content-Type:\s*([^\r\n]+)/i.exec(head) || [])[1] || '', size: Buffer.byteLength(body, 'latin1'), head: Buffer.from(body.slice(0, 16), 'latin1') };
    else out.fields[name[1]] = Buffer.from(body, 'latin1').toString('utf8');
  }
  return out;
}
/* Настоящий WAV (PCM 16 бит, 16 кГц): тон с «слоговой» огибающей, длительность зависит от длины текста */
function speechWav(text) {
  const rate = 16000;
  const seconds = Math.min(4, Math.max(0.6, String(text || '').length * 0.045));
  const n = Math.floor(rate * seconds);
  const buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0, 'latin1'); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVE', 8, 'latin1');
  buf.write('fmt ', 12, 'latin1'); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36, 'latin1'); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const t = i / rate;
    const env = Math.max(0, Math.sin(Math.PI * t * 4.5)) * Math.min(1, t * 8, (seconds - t) * 8);
    buf.writeInt16LE(Math.round(Math.sin(2 * Math.PI * 220 * t) * env * 12000), 44 + i * 2);
  }
  return buf;
}

function start() {
  const requests = [];
  const voice = { transcript: 'Привет, WISP! Как дела?', sttStatus: 0, ttsStatus: 0, sttDelayMs: 0, ttsDelayMs: 0 };
  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', async () => {
      if (req.url.endsWith('/audio/transcriptions') || req.url.endsWith('/audio/speech')) {
        const raw = Buffer.concat(chunks);
        const stt = req.url.endsWith('/audio/transcriptions');
        const parsed = stt ? parseMultipart(raw, req.headers['content-type']) : (() => { try { return JSON.parse(raw.toString('utf8')); } catch (e) { return null; } })();
        requests.push({ kind: stt ? 'stt' : 'tts', url: req.url, headers: req.headers, body: parsed });
        if (!req.headers.authorization) { res.writeHead(401, { 'Content-Type': 'application/json' }); res.end('{"error":{"message":"no key"}}'); return; }
        const status = stt ? voice.sttStatus : voice.ttsStatus;
        const delay = stt ? voice.sttDelayMs : voice.ttsDelayMs;
        if (delay) await new Promise((r) => setTimeout(r, delay));
        if (res.destroyed) return;
        if (status) { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: { message: 'test error', type: 'test' } })); return; }
        if (stt) {
          if (!parsed || !parsed.file || !parsed.fields.model) { res.writeHead(400, { 'Content-Type': 'application/json' }); res.end('{"error":{"message":"bad multipart"}}'); return; }
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ text: voice.transcript }));
        } else {
          if (!parsed || !parsed.input || !parsed.voice) { res.writeHead(400, { 'Content-Type': 'application/json' }); res.end('{"error":{"message":"bad json"}}'); return; }
          const wav = speechWav(parsed.input);
          res.writeHead(200, { 'Content-Type': 'audio/wav', 'Content-Length': wav.length });
          res.end(wav);
        }
        return;
      }
      let body = {};
      try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { /* пусто */ }
      const kind = req.url.endsWith('/chat/completions') ? 'openai' : req.url.endsWith('/v1/messages') ? 'anthropic' : null;
      requests.push({ kind, url: req.url, headers: req.headers, body });
      if (!kind) { res.writeHead(404); res.end('{}'); return; }
      const text = lastUserText(body.messages || []);
      const httpErr = /\[\[http(\d{3})\]\]/.exec(text);
      if (httpErr) {
        const status = Number(httpErr[1]);
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: status === 404 ? 'The model does not exist' : 'error', type: 'test', code: status === 404 ? 'model_not_found' : null } }));
        return;
      }
      const auth = kind === 'openai' ? req.headers.authorization : req.headers['x-api-key'];
      if (!auth) { res.writeHead(401); res.end('{"error":{"message":"no key"}}'); return; }

      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
      const write0 = (s) => { if (!res.destroyed) res.write(s); };

      /* ── вызовы функций ── */
      const calls = Array.isArray(body.tools) && body.tools.length ? parseCalls(text) : [];
      const results = toolResults(kind, body.messages || []);
      if (calls.length && !results.length) {
        if (kind === 'openai') {
          calls.forEach((c, i) => {
            const half = Math.ceil(c.args.length / 2);
            write0(`data: ${JSON.stringify({ choices: [{ index: 0, delta: { tool_calls: [{ index: i, id: `call_${i}`, type: 'function', function: { name: c.name, arguments: c.args.slice(0, half) } }] }, finish_reason: null }] })}\n\n`);
            write0(`data: ${JSON.stringify({ choices: [{ index: 0, delta: { tool_calls: [{ index: i, function: { arguments: c.args.slice(half) } }] }, finish_reason: null }] })}\n\n`);
          });
          write0(`data: ${JSON.stringify({ choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }] })}\n\n`);
          write0('data: [DONE]\n\n');
        } else {
          write0(`event: message_start\ndata: ${JSON.stringify({ type: 'message_start', message: { usage: { input_tokens: 12 } } })}\n\n`);
          calls.forEach((c, i) => {
            const half = Math.ceil(c.args.length / 2);
            write0(`event: content_block_start\ndata: ${JSON.stringify({ type: 'content_block_start', index: i, content_block: { type: 'tool_use', id: `toolu_${i}`, name: c.name, input: {} } })}\n\n`);
            write0(`event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', index: i, delta: { type: 'input_json_delta', partial_json: c.args.slice(0, half) } })}\n\n`);
            write0(`event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', index: i, delta: { type: 'input_json_delta', partial_json: c.args.slice(half) } })}\n\n`);
            write0(`event: content_block_stop\ndata: ${JSON.stringify({ type: 'content_block_stop', index: i })}\n\n`);
          });
          write0(`event: message_delta\ndata: ${JSON.stringify({ type: 'message_delta', delta: { stop_reason: 'tool_use' }, usage: { output_tokens: 5 } })}\n\n`);
          write0(`event: message_stop\ndata: ${JSON.stringify({ type: 'message_stop' })}\n\n`);
        }
        res.end();
        return;
      }
      if (results.length) {
        const say = text.includes('[[silent]]') ? [] : ['Результат: ', results.map((r) => (typeof r === 'string' ? r : JSON.stringify(r))).join(' | ')];
        if (kind === 'anthropic') write0(`event: message_start\ndata: ${JSON.stringify({ type: 'message_start', message: { usage: { input_tokens: 12 } } })}\n\n`);
        for (const part of say) {
          if (kind === 'openai') write0(`data: ${JSON.stringify({ choices: [{ index: 0, delta: { content: part }, finish_reason: null }] })}\n\n`);
          else write0(`event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: part } })}\n\n`);
        }
        if (kind === 'openai') { write0(`data: ${JSON.stringify({ choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] })}\n\n`); write0('data: [DONE]\n\n'); }
        else { write0(`event: message_delta\ndata: ${JSON.stringify({ type: 'message_delta', delta: { stop_reason: 'end_turn' }, usage: { output_tokens: 9 } })}\n\n`); write0(`event: message_stop\ndata: ${JSON.stringify({ type: 'message_stop' })}\n\n`); }
        res.end();
        return;
      }

      const slow = text.includes('[[slow]]');
      const empty = text.includes('[[empty]]');
      const reply = empty ? [] : ['Привет', '! Это ', '**потоковый**', ' ответ', ' WISP.', '\n\n```js\nconst a = 1;\n```'];
      const pause = (ms) => new Promise((r) => setTimeout(r, ms));
      const write = (s) => { if (!res.destroyed) res.write(s); };
      if (kind === 'anthropic') write(`event: message_start\ndata: ${JSON.stringify({ type: 'message_start', message: { usage: { input_tokens: 12 } } })}\n\n`);
      for (let i = 0; i < reply.length; i++) {
        if (res.destroyed) return;
        if (text.includes('[[drop]]') && i === 2) { res.socket.destroy(); return; }
        if (text.includes('[[midError]]') && i === 2) {
          if (kind === 'openai') write(`data: ${JSON.stringify({ error: { message: 'overloaded', code: 503 } })}\n\n`);
          else write(`event: error\ndata: ${JSON.stringify({ type: 'error', error: { type: 'overloaded_error', message: 'Overloaded' } })}\n\n`);
          res.end();
          return;
        }
        if (kind === 'openai') write(`data: ${JSON.stringify({ choices: [{ index: 0, delta: { content: reply[i] }, finish_reason: null }] })}\n\n`);
        else write(`event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: reply[i] } })}\n\n`);
        await pause(slow ? 250 : 15);
      }
      if (kind === 'openai') {
        write(`data: ${JSON.stringify({ choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] })}\n\n`);
        write(`data: ${JSON.stringify({ choices: [], usage: { prompt_tokens: 20, completion_tokens: 9 } })}\n\n`);
        write('data: [DONE]\n\n');
      } else {
        write(`event: message_delta\ndata: ${JSON.stringify({ type: 'message_delta', delta: { stop_reason: 'end_turn' }, usage: { output_tokens: 9 } })}\n\n`);
        write(`event: message_stop\ndata: ${JSON.stringify({ type: 'message_stop' })}\n\n`);
      }
      res.end();
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => {
    const { port } = server.address();
    resolve({ server, port, requests, voice, url: `http://127.0.0.1:${port}`, close: () => new Promise((r) => { server.closeAllConnections(); server.close(r); }) });
  }));
}

module.exports = { start, speechWav };
