'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadStorage(localStorage) {
  const App = { core: { Profile: { normalize: (value) => value, toServerPayload: (value) => value } } };
  const window = { WispApp: App, localStorage, addEventListener() {} };
  const document = { addEventListener() {} };
  const source = fs.readFileSync(path.join(__dirname, '../src/core/storage.js'), 'utf8');
  vm.runInNewContext(source, { window, document, setTimeout, clearTimeout });
  return App.core.Storage;
}

test('LocalStorageAdapter reads quota fallbacks and honors a remove tombstone', async () => {
  const values = new Map();
  let failWrites = true;
  let failRemove = false;
  const localStorage = {
    setItem(key, value) {
      if (key !== '__wisp_probe__' && failWrites) throw new Error('quota exceeded');
      values.set(key, String(value));
    },
    getItem(key) { return values.has(key) ? values.get(key) : null; },
    removeItem(key) {
      if (key !== '__wisp_probe__' && failRemove) throw new Error('storage unavailable');
      values.delete(key);
    },
  };
  const Storage = loadStorage(localStorage);
  const adapter = new Storage.LocalStorageAdapter();

  await adapter.write('draft', { text: 'saved in memory' });
  assert.equal(JSON.stringify(await adapter.read('draft')), '{"text":"saved in memory"}');

  const profile = new Storage.ProfileRepository(adapter);
  await profile.save({ user: { name: 'Hebr' } });
  assert.equal((await profile.load()).user.name, 'Hebr');

  failWrites = false;
  values.set('wisp:profile:v1', JSON.stringify({ user: { name: 'stale' } }));
  failRemove = true;
  await profile.clear();
  assert.equal(await profile.load(), null);
});
