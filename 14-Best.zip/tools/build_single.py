#!/usr/bin/env python3
"""Собирает проект WISP в один самодостаточный HTML: инлайнит все <link rel=stylesheet> и <script src>.
Запуск из корня проекта:  python3 tools/build_single.py  → dist/wisp.html"""
import pathlib, re

ROOT = pathlib.Path(__file__).resolve().parent.parent
src = (ROOT / 'index.html').read_text(encoding='utf-8')

def css(m):
    path = ROOT / m.group(1)
    return '<style>\n/* ' + m.group(1) + ' */\n' + path.read_text(encoding='utf-8') + '\n</style>'

def js(m):
    path = ROOT / m.group(1)
    body = path.read_text(encoding='utf-8').replace('</script', '<\\/script')
    return '<script>\n/* ' + m.group(1) + ' */\n' + body + '\n</script>'

out = re.sub(r'<link rel="stylesheet" href="([^"]+)">', css, src)
out = re.sub(r'<script src="([^"]+)"></script>', js, out)
dist = ROOT / 'dist'
dist.mkdir(exist_ok=True)
(dist / 'wisp.html').write_text(out, encoding='utf-8')
print('dist/wisp.html', len(out.encode('utf-8')), 'bytes')
