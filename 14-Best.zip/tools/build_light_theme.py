#!/usr/bin/env python3
"""WISP · Layer 6 · генератор светлой темы.
Не трогает исходные стили Layers 0–5: читает их и пишет src/settings/theme-light.css, где каждое
объявление цветовых свойств повторено под html[data-theme="light"] с пересчитанным цветом.
Так тёмная тема остаётся пиксель-в-пиксель прежней, а порядок и приоритет правил сохраняются
(зеркалируются ВСЕ цветовые объявления, даже на токенах, чтобы каскад не перевернулся).
Ручные токены светлой темы — в TOKENS ниже.
Запуск из корня проекта: python3 tools/build_light_theme.py  (после правки любого CSS слоёв 0–5)."""
import colorsys, pathlib, re

ROOT = pathlib.Path(__file__).resolve().parent.parent
FILES = ['src/layer0-entrance/entrance.css', 'src/design-system/tokens.css', 'src/design-system/components.css',
         'src/design-system/layout.css', 'src/onboarding/onboarding.css', 'src/home/home.css', 'src/chat/chat.css',
         'src/tools/tools.css', 'src/memory/memory.css', 'src/settings/settings.css']
OUT = ROOT / 'src/settings/theme-light.css'
P = 'html[data-theme="light"]'

TOKENS = """
html[data-theme="light"] {
  color-scheme: light;
  --wisp-bg: #f3f2f9;
  --wisp-ink: #17152b;
  --wisp-ink-2: rgba(23, 21, 43, .70);
  --wisp-ink-3: rgba(23, 21, 43, .54);
  --wisp-on-ink: #f8f7ff;
  --wisp-lav: #5a4bd4;
  --wisp-lav-soft: rgba(98, 82, 224, .11);
  --wisp-lav-line: rgba(90, 75, 212, .46);
  --wisp-lav-glow: rgba(108, 92, 235, .26);
  --wisp-glass: rgba(255, 255, 255, .64);
  --wisp-glass-2: rgba(255, 255, 255, .86);
  --wisp-glass-strong: rgba(252, 251, 255, .86);
  --wisp-glass-line: rgba(38, 32, 92, .10);
  --wisp-glass-hi: inset 0 1px 0 rgba(255, 255, 255, .75);
  --wisp-shadow: 0 1px 2px rgba(38, 32, 92, .06), 0 14px 34px -16px rgba(38, 32, 92, .20);
}
"""

INK = (23, 21, 43)
ON_INK = (248, 247, 255)
ACCENT = (98, 82, 224)
SHADOW = (38, 32, 92)

COLOR_RE = re.compile(r'rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+%?)\s*)?\)|#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})\b|\b(white|black)\b')
TEXTY = ('color', 'fill', 'stroke', 'caret-color', 'text-decoration-color', 'scrollbar-color', 'outline', 'outline-color', 'column-rule')
BACKY = ('background', 'background-color', 'background-image')
SHADOWY = ('box-shadow', 'text-shadow', 'filter')

BORDERS = ('border', 'border-color', 'border-top', 'border-right', 'border-bottom', 'border-left',
           'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color', 'border-block', 'border-inline')

def is_color_prop(p):
    return p in TEXTY or p in BACKY or p in SHADOWY or p in BORDERS

def strip_comments(s):
    return re.sub(r'/\*.*?\*/', '', s, flags=re.S)

def parse(s):
    s = strip_comments(s); n = len(s)
    def block(i):
        out = []
        while i < n:
            while i < n and s[i].isspace(): i += 1
            if i >= n: break
            if s[i] == '}': return out, i + 1
            j = i; depth = 0
            while j < n and (s[j] not in '{;' or depth > 0):
                if s[j] == '(': depth += 1
                elif s[j] == ')': depth -= 1
                j += 1
            prelude = s[i:j].strip()
            if j >= n: break
            if s[j] == ';': out.append(('stmt', prelude, None)); i = j + 1; continue
            k = j + 1; d = 1
            while k < n and d > 0:
                if s[k] == '{': d += 1
                elif s[k] == '}': d -= 1
                k += 1
            body = s[j + 1:k - 1]
            if prelude.startswith('@keyframes') or prelude.startswith('@-webkit-keyframes') or prelude.startswith('@font-face'):
                out.append(('skip', prelude, body))
            elif prelude.startswith('@'):
                out.append(('at', prelude, block_text(body)))
            else:
                out.append(('rule', prelude, body))
            i = k
        return out, i
    def block_text(body):
        return parse_inner(body)
    return block(0)[0]

def parse_inner(body):
    return parse(body)

def decls(text):
    out = []; depth = 0; cur = ''
    for ch in text:
        if ch == '(': depth += 1
        if ch == ')': depth -= 1
        if ch == ';' and depth == 0: out.append(cur); cur = ''
        else: cur += ch
    if cur.strip(): out.append(cur)
    res = []
    for d in out:
        if ':' not in d: continue
        p, v = d.split(':', 1)
        res.append((p.strip().lower(), v.strip()))
    return res

def split_top(v, sep=','):
    out = []; depth = 0; cur = ''
    for ch in v:
        if ch == '(': depth += 1
        if ch == ')': depth -= 1
        if ch == sep and depth == 0: out.append(cur); cur = ''
        else: cur += ch
    out.append(cur)
    return out

def to_rgba(m):
    if m.group(1) is not None:
        a = m.group(4)
        if a is None: a = 1.0
        elif a.endswith('%'): a = float(a[:-1]) / 100
        else: a = float(a)
        return float(m.group(1)), float(m.group(2)), float(m.group(3)), a
    if m.group(5):
        h = m.group(5)
        if len(h) in (3, 4): h = ''.join(c * 2 for c in h)
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        a = int(h[6:8], 16) / 255 if len(h) == 8 else 1.0
        return r, g, b, a
    return (255, 255, 255, 1.0) if m.group(6) == 'white' else (0, 0, 0, 1.0)

def kind(r, g, b):
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    spread = max(r, g, b) - min(r, g, b)
    if l < 0.2: return 'dark', h, l, s
    if spread < 24 and l > 0.6: return 'light', h, l, s
    if spread < 30: return 'mid', h, l, s
    return 'chroma', h, l, s

def fmt(rgb, a):
    a = max(0.0, min(1.0, a))
    r, g, b = (int(round(x)) for x in rgb)
    return f'rgba({r}, {g}, {b}, {round(a, 3):g})'

def hls(h, l, s):
    r, g, b = colorsys.hls_to_rgb(h, max(0, min(1, l)), max(0, min(1, s)))
    return r * 255, g * 255, b * 255

BG = (243, 242, 249)
TRACKS = ('progress', '__bar', 'rail', 'grab', 'mm-switch', 'st-switch', 'meter', 'divider', '__line', '__sep', '__seg')

def map_text(c, sel):
    r, g, b, a = c; k, h, l, s = kind(r, g, b)
    if k == 'light': return fmt(INK, min(1, a * 1.02))
    if k == 'dark': return fmt(ON_INK, a)
    if k == 'mid': return fmt(INK, a)
    if l > .6: return fmt(hls(h, .46, min(.62, s)), min(1, a * 1.05))
    return fmt(hls(h, min(l, .42), s), a)

def map_back(c, sel, grad):
    r, g, b, a = c; k, h, l, s = kind(r, g, b)
    if grad:
        if k == 'dark': return fmt(BG, a)
        if k in ('light', 'mid'): return fmt((150, 138, 242), a * .5)
        return fmt(hls(h, .64, min(.75, s)), a)
    if a == 0: return fmt((255, 255, 255) if k != 'chroma' else hls(h, .64, .7), 0)
    if k == 'light':
        if 'knob' in sel: return fmt((255, 255, 255), 1)
        if any(t in sel for t in TRACKS): return fmt(INK, min(.5, a * .9 + .04))
        if a >= .6: return fmt(ACCENT, a) if ('spark' in sel or 'dot' in sel) else fmt(INK, a)
        return fmt((255, 255, 255), min(.92, a * 6 + .14))
    if k == 'dark':
        if 'scrim' in sel or 'veil' in sel: return fmt((24, 20, 52), a * .42)
        if a < .3: return fmt((255, 255, 255), min(.5, a * 1.8))
        if l < .05: return fmt(BG, a)
        return fmt((252, 251, 255), max(a, .82))
    if k == 'mid': return fmt(INK, a * .5)
    return fmt(hls(h, .64, min(.75, s)), min(1, a * 1.15))

def map_shadow_layer(layer):
    m = COLOR_RE.search(layer)
    if not m: return layer
    r, g, b, a = to_rgba(m); k, h, l, s = kind(r, g, b)
    rest = (layer[:m.start()] + ' ' + layer[m.end():])
    nums = re.findall(r'-?[\d.]+(?:px|em|rem)?', rest.replace('inset', ''))
    inset = 'inset' in rest
    blur = 0.0
    try:
        vals = [float(re.sub(r'[a-z]+', '', x)) for x in nums]
        if len(vals) >= 3: blur = vals[2]
    except ValueError:
        pass
    if k == 'dark':
        new = fmt(BG, a) if (blur == 0 and not inset and len(nums) >= 4) else fmt(SHADOW, a * (.6 if inset else .32))
    elif k in ('light', 'mid'):
        if inset and blur == 0 and len(nums) >= 2 and nums[1] not in ('0', '0px') and 'spread' not in rest:
            new = fmt((255, 255, 255), min(.9, a * 8 + .2))
        elif blur == 0:
            new = fmt(INK, min(1, a * 1.05))
        else:
            new = fmt((108, 92, 235), a * .5)
    else:
        new = fmt(hls(h, .6, min(.6, s)), a * .8)
    return layer[:m.start()] + new + layer[m.end():]

def transform(prop, value, sel):
    if prop in SHADOWY:
        if prop == 'filter':
            return re.sub(r'drop-shadow\(([^()]*(?:\([^()]*\))?[^()]*)\)', lambda mm: 'drop-shadow(' + map_shadow_layer(mm.group(1)) + ')', value)
        return ','.join(map_shadow_layer(x) for x in split_top(value))
    if prop in TEXTY or prop in BORDERS:
        return COLOR_RE.sub(lambda m: map_text(to_rgba(m), sel), value)
    if value.strip().lower() in ('#050508', 'rgb(5, 5, 8)'):
        return 'var(--wisp-bg)'
    grad = 'gradient' in value
    return COLOR_RE.sub(lambda m: map_back(to_rgba(m), sel, grad), value)

def prefix_sel(sel):
    out = []
    for s in split_top(sel):
        s = s.strip()
        if not s: continue
        if s.startswith(':root'): out.append(P + s[5:])
        elif re.match(r'^html\b', s): out.append(P + s[4:])
        elif re.match(r'^body\b', s): out.append(P + ' ' + s)
        else: out.append(P + ' ' + s)
    return ', '.join(out)

def emit(nodes, indent=''):
    out = []
    for t, pre, body in nodes:
        if t == 'at':
            inner = emit(body, indent + '  ')
            if inner: out.append(f'{indent}{pre} {{\n{inner}\n{indent}}}')
        elif t == 'rule':
            if pre.strip() == ':root': continue                     # токены — вручную (TOKENS)
            ds = [(p, v) for p, v in decls(body) if is_color_prop(p) and not p.startswith('--')]
            if not ds: continue
            lines = [f'{indent}  {p}: {transform(p, v, pre)};' for p, v in ds]
            out.append(f'{indent}{prefix_sel(pre)} {{\n' + '\n'.join(lines) + f'\n{indent}}}')
    return '\n'.join(out)

def main():
    parts = ['/* WISP · Layer 6 · Светлая тема. ФАЙЛ СОБРАН АВТОМАТИЧЕСКИ: python3 tools/build_light_theme.py\n'
             ' * Не правь вручную: правь исходные стили слоёв или TOKENS в генераторе и пересобери. */', TOKENS.strip()]
    for f in FILES:
        path = ROOT / f
        if not path.exists(): continue
        css = emit(parse(path.read_text(encoding='utf-8')))
        if css: parts.append(f'/* ── {f} ── */\n' + css)
    OUT.write_text('\n\n'.join(parts) + '\n', encoding='utf-8')
    print(OUT.relative_to(ROOT), OUT.stat().st_size, 'bytes')

if __name__ == '__main__':
    main()
