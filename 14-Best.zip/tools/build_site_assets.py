#!/usr/bin/env python3
"""WISP · Layer 12 · Сборка ресурсов публичного сайта (site/).

  python3 tools/build_site_assets.py

1. Таблица Free / Plus в site/index.html между <!-- plans:start --> и <!-- plans:end -->
   строится из server/config/plans.json: на сайте те же числа, что применяет сервер. (Только стандартная библиотека.)
2. Маскот WISP собирается из настоящих слоёв Layer 0 (src/layer0-entrance/entrance.js: тело, глаза, частицы)
   в site/assets/img/wisp.webp, иконки и картинку для соцсетей. (Нужен Pillow: pip install pillow.)
3. Скриншоты из site/.shots (tools/site_screenshots.js) превращаются в WebP двух размеров. (Нужен Pillow.)
Приложение WISP этот скрипт не меняет.
"""
import base64, html, io, json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SITE = os.path.join(ROOT, 'site')
IMG = os.path.join(SITE, 'assets', 'img')
SHOTS = os.path.join(SITE, '.shots')
SCREENS = ['home', 'chat', 'actions', 'voice', 'memory', 'tools', 'personality']
BG = (5, 5, 8)


def plural(n, one, few, many):
    a, b = abs(n) % 100, abs(n) % 10
    if 10 < a < 20: return many
    if 1 < b < 5: return few
    if b == 1: return one
    return many


def num(n):
    return f'{n:,}'.replace(',', '\u202f')


def plan_rows(F, P):
    rows = []
    def r(label, f, p): rows.append((label, f, p))
    r('Сообщений в день', num(F['daily_requests']), num(P['daily_requests']))
    r('Ответ за раз', f"до {num(F['max_output_tokens'])} токенов", f"до {num(P['max_output_tokens'])} токенов")
    r('История разговора', f"~{num(F['history_tokens'])} токенов", f"~{num(P['history_tokens'])} токенов")
    r('Модели', 'Базовые', 'Базовые и модели Plus¹')
    m, pm = F['memory'], P['memory']
    r('Память', f"{num(m['items_max'])} {plural(m['items_max'], 'факт', 'факта', 'фактов')}", f"{num(pm['items_max'])} {plural(pm['items_max'], 'факт', 'факта', 'фактов')}")
    r('Фактов в каждом ответе', f"до {m['context_items']}", f"до {pm['context_items']}")
    t, pt = F['tools'], P['tools']
    r('Заметки · задачи', f"{num(t['notes_max'])} · {num(t['tasks_max'])}", f"{num(pt['notes_max'])} · {num(pt['tasks_max'])}")
    r('Активные напоминания', num(t['reminders_active_max']), num(pt['reminders_active_max']))
    r('Планировщик вперёд', f"{t['planner_days_ahead']} {plural(t['planner_days_ahead'], 'день', 'дня', 'дней')}", f"{pt['planner_days_ahead']} {plural(pt['planner_days_ahead'], 'день', 'дня', 'дней')}")
    v, pv = F['voice'], P['voice']
    r('Голосовой ввод', f"{num(v['stt_daily'])} в день, до {v['stt_max_seconds']} с", f"{num(pv['stt_daily'])} в день, до {pv['stt_max_seconds']} с")
    a, pa = F['actions'], P['actions']
    r('Действия AI', f"{num(a['writes_per_day'])} в день", f"{num(pa['writes_per_day'])} в день")
    r('Фото в сообщении', f"до {F['max_images_per_message']}", f"до {P['max_images_per_message']}")
    return rows


def build_plans():
    with open(os.path.join(ROOT, 'server', 'config', 'plans.json'), encoding='utf-8') as f:
        plans = json.load(f)
    rows = plan_rows(plans['free'], plans['plus'])
    e = html.escape
    out = ['<!-- plans:start · сгенерировано tools/build_site_assets.py из server/config/plans.json, не править руками -->',
           '<div class="plans__table" role="table" aria-label="Сравнение Free и Plus">',
           '  <div class="plans__row plans__row--head" role="row"><span role="columnheader"><span class="sr-only">Возможность</span></span><span role="columnheader">Free</span><span role="columnheader" class="is-plus">Plus</span></div>']
    for label, fr, pl in rows:
        out.append(f'  <div class="plans__row" role="row"><span role="rowheader">{e(label)}</span><span role="cell" data-plan="Free">{e(fr)}</span><span role="cell" data-plan="Plus" class="is-plus">{e(pl)}</span></div>')
    out.append('</div>')
    out.append('<!-- plans:end -->')
    path = os.path.join(SITE, 'index.html')
    with open(path, encoding='utf-8') as f:
        src = f.read()
    new, n = re.subn(r'<!-- plans:start.*?<!-- plans:end -->', lambda _m: '\n'.join(out), src, flags=re.S)
    if not n:
        sys.exit('site/index.html: не найдены метки <!-- plans:start --> / <!-- plans:end -->')
    if new != src:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(new)
    print(f'plans: {len(rows)} строк из server/config/plans.json')


def build_images():
    try:
        from PIL import Image
    except ImportError:
        print('Pillow не установлен: картинки пропущены (pip install pillow)')
        return
    os.makedirs(IMG, exist_ok=True)
    src = open(os.path.join(ROOT, 'src', 'layer0-entrance', 'entrance.js'), encoding='utf-8').read()
    i = src.index('const ART = ')
    art = json.loads(src[i + len('const ART = '):src.index('};', i) + 1])
    dec = lambda u: Image.open(io.BytesIO(base64.b64decode(u.split(',', 1)[1]))).convert('RGBA')
    body = dec(art['body'])
    k = body.width / art['crop'][0]
    m = body.copy()
    for d in art['eyes'] + art['dots']:
        part = dec(d['src']).resize((round(d['w'] * k), round(d['h'] * k)), Image.LANCZOS)
        m.alpha_composite(part, (round(d['x'] * k), round(d['y'] * k)))
    m = m.crop(m.getbbox())
    for w in (360, 720):
        m.resize((w, round(m.height * w / m.width)), Image.LANCZOS).save(os.path.join(IMG, f'wisp-{w}.webp'), 'WEBP', quality=86, method=6)

    def on_bg(size, scale):
        c = Image.new('RGBA', (size, size), BG + (255,))
        w = round(size * scale); h = round(m.height * w / m.width)
        c.alpha_composite(m.resize((w, h), Image.LANCZOS), ((size - w) // 2, (size - h) // 2))
        return c.convert('RGB')
    on_bg(180, .86).save(os.path.join(IMG, 'apple-touch-icon.png'), optimize=True)
    on_bg(64, .92).save(os.path.join(IMG, 'favicon-64.png'), optimize=True)
    og = Image.new('RGBA', (1200, 630), BG + (255,))
    h = 500; w = round(m.width * h / m.height)
    og.alpha_composite(m.resize((w, h), Image.LANCZOS), ((1200 - w) // 2, 65))
    og.convert('RGB').save(os.path.join(IMG, 'og.jpg'), quality=86, optimize=True, progressive=True)
    print('mascot: wisp-360/720.webp, apple-touch-icon.png, favicon-64.png, og.jpg')

    if not os.path.isdir(SHOTS):
        print('site/.shots нет: скриншоты не обновлены (node tools/site_screenshots.js)')
        return
    for name in SCREENS:
        p = os.path.join(SHOTS, f'{name}.png')
        if not os.path.exists(p):
            print(f'нет {name}.png, пропущено'); continue
        im = Image.open(p).convert('RGB')
        for w in (360, 720):
            im.resize((w, round(im.height * w / im.width)), Image.LANCZOS).save(os.path.join(IMG, f'screen-{name}-{w}.webp'), 'WEBP', quality=84, method=6)
    print('screens:', ', '.join(SCREENS))


if __name__ == '__main__':
    build_images()
    build_plans()
