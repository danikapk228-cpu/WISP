#!/usr/bin/env python3
"""Build WISP's non-default theme color overrides.

Lavender literals are redirected to runtime palette variables. The source CSS stays
untouched, and no ordinary CSS rule is emitted for the default dark theme. Keyframes
are repeated with variable fallbacks, so their default-dark colors remain byte-for-byte
equivalent in appearance while other themes can recolor them.
Run from the project root: python3 tools/build_theme_engine.py
"""
import colorsys
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'tools'))
import build_light_theme as css  # shares the project's CSS parser/color scanner

FILES = [
    'src/layer0-entrance/entrance.css',
    'src/design-system/tokens.css',
    'src/design-system/components.css',
    'src/design-system/layout.css',
    'src/settings/settings.css',
    'src/settings/theme-light.css',
    'src/auth/auth.css',
    'src/onboarding/onboarding.css',
    'src/home/home.css',
    'src/chat/chat.css',
    'src/tools/tools.css',
    'src/memory/memory.css',
]
OUT = ROOT / 'src/settings/theme-engine.css'
VARIANTS = ('black', 'midnight', 'light', 'custom')
COLOR_PROPS = css.TEXTY + css.BACKY + css.SHADOWY + css.BORDERS
GLOW_SELECTORS = (
    '.wisp-ambient', '.wisp-spawn', '.wisp-floor', '.wisp-stage.is-home::before',
)


def is_lavender(rgba):
    r, g, b, _ = rgba
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    # Lavender/indigo hues only. Very pale near-white inks stay neutral.
    return 0.57 <= h <= 0.86 and s >= 0.18 and 0.25 < l < 0.94


def role(prop, selector=''):
    if prop in css.SHADOWY:
        return 'glow'
    if prop in css.BACKY and any(token in selector for token in GLOW_SELECTORS):
        return 'glow'
    if prop in css.BORDERS:
        return 'accent'
    if prop in css.TEXTY:
        return 'primary'
    return 'secondary'


def alpha_name(alpha):
    return f'--wisp-theme-glow-a{round(max(0, min(1, alpha)) * 100):03d}'


def replacement(match, prop, fallback=False, selector=''):
    rgba = css.to_rgba(match)
    r, g, b, a = rgba
    if prop in css.BACKY and (r, g, b) == (5, 5, 8) and a >= 0.999:
        return 'var(--wisp-bg)'
    if not is_lavender(rgba):
        return match.group(0)
    color_role = role(prop, selector)
    channel_var = f'--wisp-theme-{color_role}-rgb'
    rgb_fallback = f'{int(round(r))}, {int(round(g))}, {int(round(b))}'
    if fallback:
        channels = f'var({channel_var}, {rgb_fallback})'
    else:
        channels = f'var({channel_var})'
    if color_role == 'glow':
        alpha = f'var({alpha_name(a)}, {max(0, min(1, a)):.3f})' if fallback else f'var({alpha_name(a)})'
    else:
        alpha = f'{max(0, min(1, a)):.3f}'
    return f'rgba({channels}, {alpha})'


def transform(prop, value, fallback=False, selector=''):
    if prop not in COLOR_PROPS:
        return value
    return css.COLOR_RE.sub(lambda m: replacement(m, prop, fallback, selector), value)


def prefix_selector(selector, variant):
    prefix = f'html[data-theme-preset="{variant}"]'
    parts = []
    for item in css.split_top(selector):
        s = item.strip()
        if not s:
            continue
        # Light-theme rules need to stay light, including when the user picked a
        # custom light background. Other presets must not inherit those overrides.
        if 'html[data-theme="light"]' in s:
            if variant not in ('light', 'custom'):
                continue
            s = s.replace('html[data-theme="light"]', f'{prefix}[data-theme="light"]')
        elif re.match(r'^:root\b', s):
            s = re.sub(r'^:root\b', prefix, s)
        elif re.match(r'^html\b', s):
            s = re.sub(r'^html\b', prefix, s)
        elif re.match(r'^body\b', s):
            s = prefix + ' ' + s
        else:
            s = prefix + ' ' + s
        parts.append(s)
    return ', '.join(parts)


def emit(nodes, indent=''):
    out = []
    for kind, prelude, body in nodes:
        if kind == 'at':
            inner = emit(body, indent + '  ')
            if inner:
                out.append(f'{indent}{prelude} {{\n{inner}\n{indent}}}')
        elif kind == 'rule':
            changed = []
            for prop, value in css.decls(body):
                if prop.startswith('--') or prop not in COLOR_PROPS:
                    continue
                new_value = transform(prop, value, selector=prelude)
                if new_value != value:
                    changed.append((prop, new_value))
            if not changed:
                continue
            for variant in VARIANTS:
                selector = prefix_selector(prelude, variant)
                if not selector:
                    continue
                lines = [f'{indent}  {prop}: {value};' for prop, value in changed]
                out.append(f'{indent}{selector} {{\n' + '\n'.join(lines) + f'\n{indent}}}')
    return '\n'.join(out)


def keyframes(css_text):
    pattern = re.compile(r'@(-webkit-)?keyframes\s+([-\w]+)\s*\{', re.I)
    pos = 0
    while True:
        m = pattern.search(css_text, pos)
        if not m:
            return
        start = m.end()
        depth = 1
        i = start
        while i < len(css_text) and depth:
            if css_text[i] == '{':
                depth += 1
            elif css_text[i] == '}':
                depth -= 1
            i += 1
        if depth:
            return
        yield ('@' + (m.group(1) or '') + 'keyframes', m.group(2), css_text[start:i - 1])
        pos = i


def emit_keyframes(text):
    out = []
    frame_re = re.compile(r'([^{}]+)\{([^{}]*)\}')
    for prefix, name, body in keyframes(text):
        frames = []
        for frame_match in frame_re.finditer(body):
            frame = frame_match.group(1).strip()
            decls = css.decls(frame_match.group(2))
            if not decls:
                continue
            lines = [f'    {prop}: {transform(prop, value, fallback=True)};' for prop, value in decls]
            frames.append(f'  {frame} {{\n' + '\n'.join(lines) + '\n  }')
        if frames:
            out.append(f'{prefix} {name} {{\n' + '\n'.join(frames) + '\n}')
    return '\n'.join(out)


def main():
    parts = [
        '/* WISP · Layer 13 · Theme engine. GENERATED: python3 tools/build_theme_engine.py. */',
        '/* Default dark has no scoped color overrides; keyframe variables fall back to their source colors. */',
    ]
    rule_count = 0
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            continue
        text = path.read_text(encoding='utf-8')
        generated = emit(css.parse(text))
        if generated:
            parts.append(f'/* ── {rel} ── */\n{generated}')
            rule_count += generated.count(' {')
        frames = emit_keyframes(text)
        if frames:
            parts.append(f'/* ── keyframes: {rel} ── */\n{frames}')
    OUT.write_text('\n\n'.join(parts) + '\n', encoding='utf-8')
    print(f'{OUT.relative_to(ROOT)}: {OUT.stat().st_size} bytes, {rule_count} scoped rules')


if __name__ == '__main__':
    main()
