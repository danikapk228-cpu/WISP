/* WISP · Layer 12 · Локальный просмотр публичного сайта (только для разработки).
 *   node tools/site_serve.js [порт]     http://127.0.0.1:8080/site/
 * Отдаёт site/ по адресу /site/ и статический фронтенд приложения (/, /index.html, /src/) — так же, как его отдаёт
 * сервер WISP, чтобы кнопка «Открыть WISP» (appUrl "../") работала. Больше ничего: ни server/, ни .env, ни data/.
 * API здесь нет, поэтому приложение по этой ссылке честно скажет, что AI не подключён. Полный WISP: npm start. */
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.argv[2] || process.env.PORT || 8080);
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8', '.ico': 'image/x-icon' };

function resolve(pathname) {
  if (pathname === '/' || pathname === '/index.html') return path.join(ROOT, 'index.html');
  if (pathname === '/site') return null;
  let rel;
  if (pathname.startsWith('/site/')) rel = pathname.endsWith('/') ? pathname + 'index.html' : pathname;
  else if (pathname.startsWith('/src/')) rel = pathname;
  else return undefined;
  const parts = rel.slice(1).split('/');
  if (parts.some((s) => s === '..' || s.startsWith('.'))) return undefined;
  const file = path.resolve(ROOT, ...parts);
  return file.startsWith(ROOT + path.sep) ? file : undefined;
}

http.createServer((req, res) => {
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400); res.end(); return; }
  const file = resolve(pathname);
  if (file === null) { res.writeHead(301, { Location: '/site/' }); res.end(); return; }
  const type = file && MIME[path.extname(file).toLowerCase()];
  if (!file || !type || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Not found'); return; }
  res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(file).pipe(res);
}).listen(PORT, '127.0.0.1', () => console.log(`WISP site: http://127.0.0.1:${PORT}/site/`));
