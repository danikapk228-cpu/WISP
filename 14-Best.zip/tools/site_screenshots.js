/* WISP · Layer 12 · Скриншоты настоящего интерфейса для публичного сайта (site/).
 * Запускает настоящий сервер WISP и настоящий фронтенд, но вместо AI-провайдера использует локальный
 * демонстрационный двойник (как tests/fake-provider.js): ответы заранее написаны, в интернет ничего не уходит.
 * Данные (память, задачи, заметки, напоминание) создаются через настоящий API во временной базе и удаляются после.
 *
 *   node tools/site_screenshots.js [папка]        по умолчанию: site/.shots (PNG, 390×844 @3x)
 *   python3 tools/build_site_assets.py           превращает PNG в оптимизированные WebP для site/assets/img/
 *
 * Нужен Playwright, как для npm run test:e2e (PLAYWRIGHT_MODULE=путь, CHROME_PATH=путь к Chromium).
 * В приложение и на сервер ничего не подключается: это инструмент разработчика. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { startStack } = require('../tests/helpers');

let pw = null;
try { pw = require(process.env.PLAYWRIGHT_MODULE || 'playwright'); } catch (e) { try { pw = require('playwright-core'); } catch (er) { pw = null; } }
if (!pw) { console.error('Нужен Playwright: npm i -D playwright && npx playwright install chromium'); process.exit(1); }

const OUT = path.resolve(process.argv[2] || path.join(__dirname, '..', 'site', '.shots'));
const TZ = 'Europe/Moscow';
const ymd = (ms) => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date(ms));
const TOMORROW = ymd(Date.now() + 864e5);

/* Демонстрационный двойник OpenAI-совместимого API: потоковые ответы и один вызов функции create_reminder. */
function demoProvider() {
  const lastUser = (ms) => { for (let i = ms.length - 1; i >= 0; i--) { const m = ms[i]; if (m.role === 'user') return typeof m.content === 'string' ? m.content : (m.content || []).filter((p) => p.type === 'text').map((p) => p.text).join(' '); } return ''; };
  const afterTool = (ms) => ms.length && ms[ms.length - 1].role === 'tool';
  return new Promise((resolve) => {
    const s = http.createServer((req, res) => {
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => {
        let body = {};
        try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { /* пусто */ }
        res.writeHead(200, { 'Content-Type': 'text/event-stream' });
        const w = (o) => res.write(`data: ${JSON.stringify(o)}\n\n`);
        const say = (parts) => {
          parts.forEach((p) => w({ choices: [{ index: 0, delta: { content: p }, finish_reason: null }] }));
          w({ choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 50, completion_tokens: 40 } });
          res.end('data: [DONE]\n\n');
        };
        const ms = body.messages || [];
        const text = lastUser(ms);
        if (afterTool(ms)) return say(['Готово. Завтра в 10:00 напомню ', 'позвонить маме.']);
        if (/напомни/i.test(text) && body.tools) {
          const args = JSON.stringify({ title: 'Позвонить маме', date: TOMORROW, time: '10:00' });
          w({ choices: [{ index: 0, delta: { tool_calls: [{ index: 0, id: 'call_0', type: 'function', function: { name: 'create_reminder', arguments: args } }] }, finish_reason: null }] });
          w({ choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }] });
          return res.end('data: [DONE]\n\n');
        }
        if (/дизайн/i.test(text)) return say(['Смотри, три вещи, которые я бы поправил первыми:\n\n', '1. **Убери лишнее с первого экрана.** Один заголовок, одна кнопка.\n', '2. **Дай воздуху работать.** Отступы больше, чем кажется нужным.\n', '3. **Один акцентный цвет.** Остальное пусть молчит.\n\n', 'Скинешь скриншот? Посмотрю внимательнее.']);
        return say(['Конечно. Расскажи чуть подробнее, и начнём.']);
      });
    });
    s.listen(0, '127.0.0.1', () => resolve({ url: `http://127.0.0.1:${s.address().port}`, close: () => new Promise((k) => s.close(k)) }));
  });
}

const profile = (over) => {
  const now = new Date().toISOString();
  return { schema_version: 1, user: { name: 'Алекс', interests: ['music', 'design'], occupation: 'own_project', about: '', assistant_personality: 'friendly', permissions: {}, onboarding_completed: true, plan: 'free', ...over }, meta: { created_at: now, updated_at: now, completed_at: now } };
};

async function context(browser, prof, progress) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, locale: 'ru-RU', timezoneId: TZ, reducedMotion: 'reduce' });
  await ctx.addInitScript(([p, g]) => {
    if (!localStorage.getItem('wisp:profile:v1')) localStorage.setItem('wisp:profile:v1', JSON.stringify(p));
    if (g && !localStorage.getItem('wisp:onboarding:v1')) localStorage.setItem('wisp:onboarding:v1', JSON.stringify({ step: g, mode: 'first', updated_at: new Date().toISOString() }));
    const stream = { getTracks: () => [{ stop() {} }] };
    Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: { getUserMedia: async () => stream } });
    class DemoRecorder { static isTypeSupported() { return true; } constructor() { this.mimeType = 'audio/webm'; this.state = 'inactive'; } start() { this.state = 'recording'; } stop() { this.state = 'inactive'; } }
    window.MediaRecorder = DemoRecorder;
  }, [prof, progress || null]);
  return ctx;
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const demo = await demoProvider();
  const models = {
    providers: { demo: { type: 'openai', base_url_env: 'T_OPENAI_URL', api_key_env: 'T_OPENAI_KEY', max_tokens_param: 'max_completion_tokens', stream_usage: true } },
    default_model: { free: 'wisp-light', plus: 'wisp-deep' },
    models: [
      { id: 'wisp-light', label: 'WISP Light', provider: 'demo', model: 'demo-light', tier: 'free', vision: true, context_tokens: 16000, max_output_tokens: 500 },
      { id: 'wisp-deep', label: 'WISP Deep', provider: 'demo', model: 'demo-deep', tier: 'plus', vision: true, context_tokens: 16000, max_output_tokens: 800 },
    ],
  };
  const plans = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'server', 'config', 'plans.json'), 'utf8'));
  const S = await startStack({ models, plans, voice: 'sk-wisp-demo-voice', env: { T_OPENAI_URL: `${demo.url}/v1` } });
  const browser = await pw.chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
  const errors = [];
  const watch = (page) => { page.on('pageerror', (e) => errors.push(String(e))); };
  const shot = (page, name) => page.screenshot({ path: path.join(OUT, `${name}.png`) });
  const enter = async (page) => {
    await page.goto(S.base + '/');
    await page.waitForSelector('[data-auth-root], .home.is-in, .ob', { timeout: 15000 });
    if (await page.locator('[data-auth-action="guest"]').count()) await page.locator('[data-auth-action="guest"]').click();
  };
  try {
    /* 1 · основной сценарий */
    const ctx = await context(browser, profile());
    const page = await ctx.newPage(); watch(page);
    await enter(page);
    await page.waitForSelector('.home.is-in', { timeout: 15000 });
    await page.evaluate(async (tmr) => {
      const H = { 'Content-Type': 'application/json', 'X-WISP-Client': '1' };
      const post = (u, b) => fetch(u, { method: 'POST', headers: H, body: JSON.stringify(b) });
      for (const [category, content] of [['work', 'Делаю свой продукт: AI-компаньон WISP'], ['preferences', 'Предпочитаю короткие ответы без воды'], ['personal', 'Люблю эмбиент и синтвейв'], ['goals', 'Хочу запустить публичную версию до конца года'], ['people', 'Мама: звонить по воскресеньям']]) await post('/api/memories', { category, content });
      await post('/api/tasks', { title: 'Собрать скриншоты для сайта', due_date: tmr });
      await post('/api/tasks', { title: 'Проверить мобильную вёрстку' });
      await post('/api/notes', { title: 'Идеи для онбординга', content: 'Меньше вопросов, больше характера.' });
      await post('/api/reminders', { title: 'Созвон с дизайнером', date: tmr, time: '16:30', timezone: 'Europe/Moscow' });
    }, TOMORROW);
    await page.reload();
    await page.waitForSelector('.home.is-in', { timeout: 15000 });
    await page.waitForTimeout(1500);
    await shot(page, 'home');
    const tab = async (id) => { await page.evaluate((t) => document.querySelector(`#home-tab-${t}`).click(), id); await page.waitForTimeout(1200); };
    const send = async (txt) => {
      const before = await page.locator('#home-panel-chat .cm--wisp').count();
      await page.locator('#home-panel-chat textarea').fill(txt);
      await page.locator('#home-panel-chat .home-send').click();
      await page.waitForFunction((n) => document.querySelectorAll('#home-panel-chat .cm--wisp').length > n && !document.querySelector('#home-panel-chat.is-generating'), before, { timeout: 15000 });
      await page.waitForTimeout(900);
    };
    await tab('chat');
    await send('Нужен свежий взгляд на дизайн лендинга');
    await shot(page, 'chat');
    await send('Напомни завтра в 10 позвонить маме');
    await shot(page, 'actions');
    const mic = page.locator('#home-panel-chat .home-mic');
    await mic.click();
    await page.waitForFunction(() => document.querySelector('#home-panel-chat .home-mic')?.getAttribute('aria-label') === 'Остановить запись', null, { timeout: 5000 }).catch(() => {});
    await page.waitForTimeout(700);
    await shot(page, 'voice');
    await page.keyboard.press('Escape').catch(() => {});
    await tab('memory'); await shot(page, 'memory');
    await tab('tools'); await shot(page, 'tools');
    await ctx.close();

    /* 2 · знакомство: выбор характера */
    const ctx2 = await context(browser, { ...profile({ onboarding_completed: false, assistant_personality: 'calm' }), meta: { created_at: new Date().toISOString(), updated_at: new Date().toISOString(), completed_at: null } }, 'personality');
    const p2 = await ctx2.newPage(); watch(p2);
    await enter(p2);
    await p2.waitForTimeout(3500);
    await shot(p2, 'personality');
    await ctx2.close();
  } finally {
    await browser.close(); await S.close(); await demo.close();
  }
  if (errors.length) { console.error('Ошибки страницы:', errors); process.exitCode = 1; }
  console.log(`Скриншоты: ${OUT}`);
})().catch((e) => { console.error(e); process.exit(1); });
