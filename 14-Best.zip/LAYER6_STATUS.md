# WISP · Layer 6 (Settings) — промежуточное состояние, НЕ завершён

## Готово и проверено тестами (сервер)
- Миграция БД v4: таблица `profiles` (профиль + настройки на пользователя, каскадное удаление).
- `server/account/profile.js` — серверная нормализация профиля (белые списки, аватар ≤ 90 КБ, тариф и разрешения не сохраняются).
- `server/routes/account.js`: GET /api/app, GET /api/account, GET/PUT /api/profile, POST /api/account/logout.
- `DELETE /api/conversations {confirm:"clear_all"}` — очистка истории чатов (409, если идёт ответ).
- `server/ai/prompt.js` + `system.md` ({{answer}}): длина/стиль ответов, обращение по имени, персонализация.
- `limits.checkSettingsWrite`, `auth.clearCookie`, `config.app` (WISP_DEVELOPER, WISP_TELEGRAM_URL, WISP_WEBSITE_URL, WISP_PRIVACY_URL, WISP_SUPPORT_EMAIL).
- Существующие серверные тесты Layers 3–5 проходят (обновлена только проверка номера версии схемы).

## Написано, но НЕ подключено и НЕ проверено (фронтенд)
- `src/core/profile.js`: `user.avatar`, `user.preferences` (обратно совместимо), `profile-store.js: adopt()`, `assistant.js`: prefs в контексте чата.
- `src/settings/`: boot.js, preferences.js, api.js, sync.js, avatar.js, settings.js, settings.css, theme-light.css (генератор `tools/build_light_theme.py`).
- Новые иконки в `design-system/icons.js`.

## Осталось сделать
1. Подключить файлы в `index.html` (boot.js в <head>, CSS, скрипты после tools.js/memory.js).
2. `home.js`: кнопка настроек, панель Settings, история «назад», приветствие без имени; `sheets.js`: фото в аватаре.
3. `app.js`: Prefs.watch, ProfileSync, ожидание серверного профиля при запуске, выход; `scheduler.js`: учёт notify_reminders; `chat.js`: resetAfterClear; хук data-motion в Layer 0.
4. CSS компактного режима.
5. Тесты Layer 6 (server + e2e), скриншоты светлой темы на iPhone, проверка Layers 0–5, сборка dist.
- Известная проблема ещё до Layer 6: e2e-тест Layer 5 жмёт вкладки из чата, где навигация скрыта (9 из 13 шагов падают на исходном архиве).
