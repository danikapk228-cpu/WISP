# Дополнительные AI-провайдеры WISP

WISP хранит ключи только на Node-сервере. Не добавляй API-токены в браузер, `index.html` или клиентский `.js`.

В приложенном архиве уже есть локальный `.env` с Groq, Gemini, OpenRouter и Hugging Face из присланных ключей; основной режим WISP настроен на Groq. Cloudflare и Supabase оставлены пустыми, потому что для Cloudflare нужен Account ID/base URL, а для Supabase нужен URL развёрнутой Edge Function. Учитывай: `.env` внутри ZIP содержит реальные секреты; не пересылай архив дальше и отзови эти ключи после теста, так как они были присланы в комментарии задачи.

## Groq

Добавь в `.env`:

```env
GROQ_API_KEY=твой_ключ
```

В меню выбора модели появится **Groq GPT-OSS 120B**. Endpoint уже настроен на `https://api.groq.com/openai/v1`. Groq поддерживает OpenAI Chat Completions и вызов функций; модели, vision и доступность смотри в актуальном каталоге Groq.

## Gemini

```env
GEMINI_API_KEY=твой_ключ
```

WISP использует официальный OpenAI-compatible endpoint Gemini: `https://generativelanguage.googleapis.com/v1beta/openai`. В конфиге пример модели `gemini-3.5-flash`. Если Google поменяет модельные ID или ограничения совместимого endpoint, обнови `model` в `server/config/models.json`. Вызов функций и изображения зависят от возможностей выбранной модели и OpenAI compatibility layer Google.

## Hugging Face

```env
HF_TOKEN=твой_read_token
```

Пример настроен на `https://router.huggingface.co/v1` и модель `openai/gpt-oss-120b:groq`. Hugging Face Router использует ID вида `owner/model:provider`; выбирай модель и backend, которые доступны твоему аккаунту. Не у каждой комбинации есть vision или function calling.

## Cloudflare Workers AI и AI Gateway

**Workers AI REST API:**

```env
CLOUDFLARE_AI_BASE_URL=https://api.cloudflare.com/client/v4/accounts/ТВОЙ_ACCOUNT_ID/ai/v1
CLOUDFLARE_API_TOKEN=токен_Cloudflare_с_AI-доступом
```

Пример модели: `@cf/meta/llama-3.3-70b-instruct-fp8-fast`.

**Cloudflare AI Gateway** (authenticated gateway с настроенным BYOK):

```env
CLOUDFLARE_AI_GATEWAY_BASE_URL=https://api.cloudflare.com/client/v4/accounts/ТВОЙ_ACCOUNT_ID/ai/v1
CLOUDFLARE_AI_GATEWAY_TOKEN=токен_Cloudflare_AI_Gateway
CLOUDFLARE_AI_GATEWAY_ID=ID_твоего_gateway
```

Пример модели в gateway — `openai/gpt-4o-mini`. Создай/настрой gateway и BYOK у Cloudflare. `CLOUDFLARE_AI_GATEWAY_TOKEN` — Cloudflare API token с разрешением AI Gateway; gateway ID уходит отдельным `cf-aig-gateway-id` заголовком.

## Supabase Edge Function как AI-шлюз

У Supabase нет стандартного универсального LLM Chat Completions endpoint, и сам WISP backend нельзя развернуть как Supabase Edge Function без отдельного порта: сервер требует Node.js 22+ и файловую SQLite базу. В архив добавлен небольшой Supabase Edge Function proxy, чтобы использовать Supabase secrets как дополнительный OpenAI-compatible шлюз:

1. Установи Supabase CLI и выполни `supabase functions deploy wisp-openai-proxy`.
2. Задай секреты функции:

```sh
supabase secrets set \
  WISP_SUPABASE_PROXY_TOKEN='длинный_случайный_секрет' \
  WISP_AI_UPSTREAM_BASE_URL='https://api.groq.com/openai/v1' \
  WISP_AI_UPSTREAM_API_KEY='твой_Groq_ключ' \
  WISP_AI_UPSTREAM_MODEL='openai/gpt-oss-120b'
```

3. В `.env` на WISP Node-сервере укажи:

```env
SUPABASE_AI_BASE_URL=https://ТВОЙ_PROJECT_REF.supabase.co/functions/v1/wisp-openai-proxy
SUPABASE_AI_PROXY_TOKEN=тот_же_длинный_случайный_секрет
```

В настройках WISP появится **Supabase Edge AI Proxy**. В примере он проксирует на Groq, но `WISP_AI_UPSTREAM_BASE_URL`, `WISP_AI_UPSTREAM_API_KEY` и `WISP_AI_UPSTREAM_MODEL` можно настроить на любой OpenAI-compatible endpoint. Function JWT-проверка отключена только для этого маршрута; сам proxy проверяет отдельный shared secret.

## Модели и ограничения

- Перезапусти Node-сервер после правок `.env`.
- Наличие ключа включает подключённые модели в WISP; тариф WISP отдельно определяет, кому доступна модель.
- Вендор может тарифицировать запросы отдельно. Лимиты WISP не равны лимитам или оплате провайдера.
- Для нового ID модели отредактируй `server/config/models.json`: `provider`, `model`, `tier`, `vision`, `context_tokens`, `max_output_tokens`, `tools`.
- Для другого OpenAI-compatible endpoint создай provider в `server/config/models.json` с `type: "openai"`, `base_url_env` и `api_key_env`, затем добавь модель, указывающую на него.
- Cloudflare Pages может раздавать статический frontend, но backend WISP надо оставить на Node-хостинге. Cloudflare Workers/Supabase Edge Functions не запускают этот Node + SQLite backend как есть; перенос backend и базы на Workers/D1 или Supabase/Postgres потребует отдельной миграции.
