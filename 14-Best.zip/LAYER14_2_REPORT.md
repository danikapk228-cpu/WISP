# WISP Layer 14.2 · Settings taps and scrolling

## Fixed
- Settings now have a deliberate stacking and hit-testing path above Home; the background Home panels are hidden and cannot intercept touch events.
- The active settings screen and its scroll viewport explicitly accept pointer input.
- The settings content has a dedicated vertical touch-scroll configuration for iOS/Safari, including momentum scrolling and contained overscroll.
- Dialogs opened from Settings remain above the Settings screen.
- Added mobile E2E assertions for the scroll viewport, wheel scrolling, and an actual touchscreen tap to open Appearance.

## Verification
- Full Node server/tools/memory/voice/actions/auth/subscription/theme suite: **157 passed, 0 failed**.
- Changed JavaScript syntax checks: PASS.
- Single-file build: PASS.
- Mobile browser E2E: NOT VERIFIED. The Playwright run exceeded the available command window in this environment; no real-device claim is made.
